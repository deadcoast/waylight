/* standing.mjs — v3.40 THE STANDING GROUND: the letters (a post hand's round under THE LETTERS —
   a runner's bag gated on the letters mark, a parcels round packing the town's own parcels into a
   PARCEL RUN for the board, accepted, carried, thanked without fee); the wedge on the compass (every
   back as a pip at its bearing, bright when it has fallen out of the wedge); the square that rises
   (a garrison restless under thin shields and a town that hates the Order, thrown out by the night's
   roll unless reinforced or loved); the storm SEEN (knives on the ground walking for the fire, the
   shields' knocks, the party's intercept, the walker's shove and cut, held in the open or lost at
   the fire); the Society's war on the camps once the door is open (the northernmost live camp
   counted, its salvage gone north, its ring shrunk); the sheet rows; the save. */
import { chromium } from 'playwright';
const results = [];
const ok = (name, cond, extra = '') => { results.push(`${cond ? 'PASS' : 'FAIL'}  ${name}${extra ? '  — ' + extra : ''}`); if (!cond) process.exitCode = 1; };
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium', args: ['--disable-background-networking'] });
const page = await b.newPage({ viewport: { width: 1440, height: 860 } });
await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
const errors = [];
page.on('pageerror', e => errors.push(String(e.message)));
await page.goto('file:///home/claude/waylight/dist/test.html?debug', { waitUntil: 'domcontentloaded' });
await page.waitForFunction(() => window.WL && WL.snapshot && WL.snapshot().baked, null, { timeout: 60000 });
await page.evaluate(() => localStorage.clear());
await page.click('#btnNew'); await page.waitForTimeout(300);
await page.click('#btnBegin'); await page.waitForTimeout(400);
await page.click('#briefGo'); await page.waitForTimeout(300);
await page.click('#cgBegin'); await page.waitForTimeout(1200);
for (let i = 0; i < 30; i++) { const c = await page.evaluate(() => !!S.cine); if (!c) break; await page.evaluate(() => WL.skipCine()); await page.waitForTimeout(250); }
await page.evaluate(() => { S.flags.guideDone = true; WL.calm(); });
const ev = (fn, arg) => page.evaluate(fn, arg);

/* ================= 1 · THE REGISTRIES ================= */
let r = await ev(() => {
  const it = DATA.items.parcel, gi = DATA.goodsInfo.parcel, T2 = DATA.T;
  const item = it && it.kg === 4 && it.fragile === true && it.cat === 'goods' && it.service === true && gi && /own/.test(gi.why) && Ledger.classify('parcel') === 'post';
  const post = MUSTER.TREES.post && MUSTER.TREES.post.root === 'post' && MUSTER.TREES.post.def.post === true && MUSTER.POST.tree === 'post';
  const kinds = Ledger.itemsUnder('post').sort().join();
  const R = REP.DOCTRINE.storm.rise, K = REP.WATCHPOST.storm.seen, E = REP.EVENTS.bunkerSweep;
  const rise = R && R.likesAt === 5 && R.thinAt === 2 && R.chance > 0 && R.at > 0.5 && R.casualty > 0 && R.reinforceCost.metal > 0 && R.garrisonMax === 4 && !!R.line;
  const seen = K && K.dur > 0 && K.knifeSpeed > 0 && K.fireR > 0 && K.takeAfter > 0 && K.shieldCd > 0 && K.shieldReach > K.fireR && K.knockBack > 0 && K.downFor > 0 && K.shoveDmg > 0;
  const sweep = E && E.actor === 'diefenbunker' && E.victim === 'raiders' && E.kind === 'strike' && E.night === true && E.needs === 'campForTheSociety' && E.sweptDur > 0 && E.claimMul < 1 && E.rel === -1 && /\{site\}/.test(E.mail[1]) && !!E.line;
  const pair = REP.RELATIONS.base['diefenbunker|raiders'] !== undefined;
  const lessons = ['firstLetters', 'firstSquare', 'firstStormSeen'].every(k => DATA.tutorials[k] && DATA.tutorialTitles[k]);
  return { item, post, kinds, cap: T2.parcelCap, every: T2.parcelEvery, rise, seen, sweep, pair, events: Object.keys(REP.EVENTS).length, lessons };
});
ok('THE REGISTRIES: parcels are a fragile service good of the post (the third kind under THE LETTERS — letters, dispatch, parcels — three to a run, one every second shift), the storm doctrine carries its RISE row (restless at five likes under two shields, four shields at most), the watchpost its SEEN row (the knives\' walk, the fire\'s radius, the shields\' cadence and reach, the walker\'s cut), the Society\'s sweep is the eighth world event on a pair the ledger already held (nine events since v3.42), and three lessons are titled',
  r.item && r.post && r.kinds === 'dispatch,letters,parcel' && r.cap === 3 && r.every === 2 && r.rise && r.seen && r.sweep && r.pair && r.events === 9 && r.lessons, JSON.stringify(r));

/* ================= 2 · THE LETTERS: the runner's bag, the parcels round, the run ================= */
r = await ev(() => {
  S.banked.provisions = 600; S.banked.metal = 200;
  for (const id of ['elm', 'mill']) S.stations[id].connected = true;
  const T2 = DATA.T, day0 = Math.floor(S.time / T2.dayLen) * T2.dayLen; S.time = day0 + T2.dayLen * 0.3;
  /* the runner: the bag fills twice as fast only while the round is marked for letters */
  const ru = NPC.gen({ at: 'haven', cls: 'courier' }); ru.feeWaived = true; S.npcs.push(ru); NPC.hire(ru, 'post'); NPC.assignPost(ru, 'haven', 'runner');
  ru.shiftT = 9999; ru.hungry = false; ru.resting = false;
  const st = S.stations.haven;
  const allowsLetters = NPC.allows(ru, 'post', 'letters');
  st.bag = 0; for (let i = 0; i < 8; i++) Systems.update(0.25, {}); const bagOn = st.bag;
  NPC.setTreeMark(ru, 'post', 'letters', false, true);
  const struck = !NPC.allows(ru, 'post', 'letters');
  st.bag = 0; for (let i = 0; i < 8; i++) Systems.update(0.25, {}); const bagOff = st.bag;
  NPC.setTreeMark(ru, 'post', 'letters', true, true);
  /* the parcels round: every second shift a parcel, three at most, only while marked for parcels */
  const pr = NPC.gen({ at: 'haven', cls: 'courier' }); pr.feeWaived = true; S.npcs.push(pr); NPC.hire(pr, 'post'); NPC.assignPost(pr, 'haven', 'parcels');
  const allowsParcels = NPC.allows(pr, 'post', 'parcel');
  st.parcels = 0;
  const shift = () => { pr.shiftT = 1; ru.shiftT = 9999; for (let i = 0; i < 8; i++) Systems.update(0.25, {}); };
  shift(); const after1 = Economy.parcelsOf('haven').length, packing1 = NPC.svc(pr).packing;
  shift(); const after2 = Economy.parcelsOf('haven').length, note = NPC.svc(pr).last, lesson = !!S.flags.tut.firstLetters;
  for (let i = 0; i < 8; i++) shift(); const capped = Economy.parcelsOf('haven').length, packed = NPC.svc(pr).parcels;
  NPC.setTreeMark(pr, 'post', 'parcel', false, true); const p0 = NPC.svc(pr).packing; st.parcels = 1;   // an older save's count: derived into a list, never dropped
  shift(); shift(); const idle = NPC.svc(pr).packing === p0 && Economy.parcelsOf('haven').length === 1 && !!Economy.parcelsOf('haven')[0].to;
  NPC.setTreeMark(pr, 'post', 'parcel', true, true);
  st.parcels = [{ to: 'elm', kind: 'coat', name: 'a mended coat' }, { to: 'elm', kind: 'shoes', name: 'a child\'s shoes' }];   // v3.41: addressed (campsown.mjs walks the addressing itself)
  /* the board: one PARCEL RUN for the door the parcels name, as many parcels as are addressed there */
  S.orders.active = [];
  const board = Economy.ordersFor('haven'), run = board.find(o => o.item === 'parcel');
  const runWhole = run && run.n === 2 && run.service === true && run.likesMul === 0 && run.from === 'haven' && run.to === 'elm' && run.id === 'pc_haven_elm' && run.parcels.length === 2;
  const nearest = true;
  Systems.acceptOrder(run, false);
  const taken = Economy.parcelsOf('haven').length === 0, carried = S.cargo.filter(c => c.defId === 'parcel').length, active = S.orders.active.some(o => o.item === 'parcel');
  const reposted = Economy.ordersFor('haven').some(o => o.item === 'parcel');
  /* the delivery: a service — no fee, the thanks, no need line */
  WL.tp(run.to); WL.instantPar();
  const likes0 = S.likes;
  const { results } = Systems.handleDelivery(run.to);
  const res = results.find(x => x.order.item === 'parcel');
  const delivered = !!res && !S.orders.active.some(o => o.item === 'parcel') && S.cargo.filter(c => c.defId === 'parcel').length === 0;
  const service = !!res && res.service === true && res.likes === 0 && res.appr > 0 && res.needMul === 1 && !res.needMood && !res.letter && res.parcels && res.parcels.length === 2 && /a mended coat/.test(res.parcels[0]);
  window._runner = ru.id; window._parcels = pr.id;
  WL.tp([DATA.stations.haven.x, DATA.stations.haven.y + 60]);
  return { allowsLetters, bagOn: Math.round(bagOn * 1000) / 1000, struck, bagOff: Math.round(bagOff * 1000) / 1000, allowsParcels, after1, packing1, after2, note, lesson, capped, packed, idle, runWhole, nearest, taken, carried, active, reposted, delivered, service, likesGained: S.likes - likes0 };
});
ok('THE LETTERS: a runner fills the town\'s bag about twice as fast only while the round is marked for letters (struck, the pen slows to the town\'s own); a parcels round packs a parcel every second shift (the note, the lesson), three at most, none with the mark struck; the board posts ONE parcel run for the door the parcels name carrying what is addressed there; accepted, the town\'s shelf of parcels empties and the run is not reposted; delivered, the parcels are gone from the pack as a service — no fee (the town pays in appreciation), no need line, each parcel opened and read aloud',
  r.allowsLetters && r.bagOn > r.bagOff * 1.8 && r.bagOff > 0 && r.struck && r.allowsParcels && r.after1 === 0 && r.packing1 === 1 && r.after2 === 1 && /packed .* for /.test(r.note) && r.lesson && r.capped === 3 && r.packed === 3 && r.idle && r.runWhole && r.nearest && r.taken && r.carried === 2 && r.active && !r.reposted && r.delivered && r.service && r.likesGained === 0, JSON.stringify(r));

/* ================= 3 · THE WEDGE ON THE COMPASS ================= */
r = await ev(() => {
  for (const n of S.npcs.filter(x => x.state === 'companion')) n.state = 'pool';
  const a = NPC.gen({ at: 'haven' }); a.feeWaived = true; S.npcs.push(a); NPC.hire(a, 'companion');
  const c = NPC.gen({ at: 'haven' }); c.feeWaived = true; S.npcs.push(c); NPC.hire(c, 'companion');
  const party = NPC.party().length;
  S.dir = 0;
  const slots = MUSTER.STATIONS[NPC.ordersOf(a).station] || MUSTER.STATIONS.wedge;
  const at = (n, i) => { const [back, side] = slots[i]; n.cx = S.px + back; n.cy = S.py + side; };
  at(a, 0); at(c, 1);
  const settle = () => { S.time += 1; for (let i = 0; i < 90; i++) UI.tick(); };   // the strip's facing eases toward yours over a second or so
  settle();
  const pips = [...document.querySelectorAll('#compassInner .cBack')];
  const wpx = document.getElementById('compass').clientWidth, lx = p => parseFloat(p.style.left);
  const inSlot = pips.length === 2 && pips.every(p => !p.classList.contains('off'));
  /* the wedge walks BEHIND you: the pips ride the rear rail, inside the strip's visible middle (the rims are masked), the slot's own side */
  const rear = pips.every(p => !p.classList.contains('fore') && /behind you/.test(p.title) && lx(p) > wpx * 0.3 && lx(p) < wpx * 0.7);
  const named = pips.every(p => p.textContent.trim().length > 0) && pips.some(p => p.textContent.trim() === a.name.split(' ')[0]);
  const moodCol = pips.every(p => { const n = [a, c].find(x => p.title.startsWith(x.name)); return n && p.style.color && p.title.includes(NPC.moodCached(n).band); });
  /* one back falls out of the wedge — behind-right, in the grey: bright, and right of the rail's centre */
  c.cx = S.px - 260; c.cy = S.py + 90;
  settle();
  const pips2 = [...document.querySelectorAll('#compassInner .cBack')];
  const off = pips2.find(p => p.title.startsWith(c.name));
  const fell = !!off && off.classList.contains('off') && /out of the wedge/.test(off.title) && lx(off) > wpx / 2 && lx(off) < wpx * 0.8 && pips2.find(p => p.title.startsWith(a.name)) && !pips2.find(p => p.title.startsWith(a.name)).classList.contains('off');
  /* a back AHEAD rides the marks' row at its bearing */
  c.cx = S.px + 120; c.cy = S.py - 10;
  settle();
  const ahead = [...document.querySelectorAll('#compassInner .cBack')].find(p => p.title.startsWith(c.name));
  const fore = !!ahead && ahead.classList.contains('fore') && /ahead of you/.test(ahead.title) && Math.abs(lx(ahead) - wpx / 2) < wpx * 0.1;
  /* the card, put away and brought back, is the same wedge — the compass pips stay */
  UI2.toggleWedge(false); const putAway = !UI2.wedgeShown() && document.getElementById('compChip').classList.contains('hidden') && !document.getElementById('wcTab').classList.contains('hidden');
  S.time += 1; UI.tick(); const pipsStay = document.querySelectorAll('#compassInner .cBack').length === 2;
  UI2.toggleWedge(true); const back = UI2.wedgeShown() && !document.getElementById('compChip').classList.contains('hidden');
  for (const n of [a, c]) n.state = 'pool';
  S.time += 1; UI.tick(); const gone = document.querySelectorAll('#compassInner .cBack').length === 0;
  return { party, pips: pips.length, inSlot, rear, named, moodCol, fell, fore, putAway, pipsStay, back, gone };
});
ok('THE WEDGE ON THE COMPASS: every back walking with you is a pip on the compass — on the REAR RAIL under the strip (the wedge walks behind you; straight behind is the centre, inside the visible middle), first name under it, its mood\'s colour and band in the title, dim in its slot; a back that falls out of the wedge lights up, says so, and sits on its own side of the rail; a back ahead of you rides the marks\' row at its bearing; the wedge card put away leaves the pips (they are the sheet\'s wedge read without the sheet); the party dismissed, the pips go',
  r.party === 2 && r.pips === 2 && r.inSlot && r.rear && r.named && r.moodCol && r.fell && r.fore && r.putAway && r.pipsStay && r.back && r.gone, JSON.stringify(r));

/* ================= 4 · THE SQUARE RISES ================= */
r = await ev(() => {
  for (const k of Object.keys(REP.EVENTS)) S.rep.evCd[k] = 99999;
  S.banked.metal = 900; S.banked.wood = 300; S.banked.provisions = 500;
  for (const id of ['elm', 'mill', 'green', 'quarry']) S.stations[id].connected = true;
  Republic.tick(0.01); for (const k of Object.keys(REP.EVENTS)) S.rep.evCd[k] = 99999;
  Republic.fundMountain(); Republic.mountain().t = REP.MOUNTAIN.dur + 1; Republic.tick(0.6);
  const mr = Math.random;
  const storm = () => { Republic.rebellionStrike('mill'); S.stations.mill.likesTo = 55; const f = Republic.fundStorm('mill'); const q = Republic.quell(); Math.random = () => 0.9; q.t = q.dur + 1; Republic.tick(0.02); Math.random = mr; return f; };
  const D = REP.DOCTRINE.storm;
  const funded = storm();
  const held = Republic.isHeld('mill'), h = Republic.held().mill, shields0 = h && (h.shields || D.garrison);
  const likesAfter = S.stations.mill.likesTo;
  const restless0 = Republic.squareRestless('mill');   // the storming takes forty likes but leaves the town above the line: NOT restless yet — hate has to deepen (the garrison eats the shelf; the town is not delivered to)
  /* REINFORCE: a third shield settles the square; the fourth is the most; the fifth is refused */
  const m0 = S.banked.metal;
  const r1 = Republic.reinforce('mill'), calm = !Republic.squareRestless('mill'), paid = m0 - S.banked.metal === D.rise.reinforceCost.metal, three = h.shields === 3;
  const r2 = Republic.reinforce('mill'), four = h.shields === 4, r3 = Republic.reinforce('mill'), refused = r3 === false && h.shields === 4;
  /* the sheet reads the garrison: the shields of four, REINFORCE disabled at the most, no warning while it holds */
  RepublicUI.open(); let html = document.getElementById('repBody').innerHTML;
  const row = /4\/4<\/b> shields under the pennant/.test(html), btn = document.querySelector('#repBody [data-reinforce="mill"]'), disabledAtMax = btn && btn.disabled, noWarn = !/THE SQUARE IS RESTLESS/.test(html);
  RepublicUI.close();
  /* thinned back to two under a town that hates the Order: RESTLESS on the sheet */
  h.shields = 2; S.stations.mill.likesTo = 3;
  const restless = Republic.squareRestless('mill');
  RepublicUI.open(); html = document.getElementById('repBody').innerHTML; const warned = /THE SQUARE IS RESTLESS/.test(html); RepublicUI.close();
  /* the night's roll, missed: the garrison stands; made: the square rises */
  const T2 = DATA.T, day0 = Math.floor(S.time / T2.dayLen) * T2.dayLen;
  S.time = day0 + T2.dayLen * 0.75; h.riseDay = -1;
  Math.random = () => 0.9; Republic.tick(0.6); Math.random = mr;
  const stood = Republic.isHeld('mill') && h.riseDay === Math.floor(S.time / T2.dayLen);
  const onceANight = (() => { Math.random = () => 0.1; Republic.tick(0.6); Math.random = mr; return Republic.isHeld('mill'); })();   // the same night does not roll twice
  const relFR = Republic.rel('farkeep', 'rebels'), stones0 = S.legacy.length;
  S.time = day0 + T2.dayLen * 1.75; h.riseDay = -1;
  Math.random = () => 0.1; Republic.tick(0.6); Math.random = mr;
  const rose = !Republic.isHeld('mill') && Republic.isUnlit('mill');
  const mail = S.mails.find(m => /the square rose/.test(m.subj)), byChoice = mail && /BY CHOICE/.test(mail.body) && /under 2 shields/.test(mail.body);
  const relDown = Republic.rel('farkeep', 'rebels') === relFR - 1, stone = S.legacy.length === stones0 + 1 && /square rose/.test(S.legacy[S.legacy.length - 1].fate);
  const lesson = !!S.flags.tut.firstSquare, title = Render.crtActive && Render.crtActive();
  /* loved, a thin garrison does not rise: the same roll under a town above the line */
  const funded2 = storm(); const h2 = Republic.held().mill; S.stations.mill.likesTo = 30; h2.shields = 2;
  const loved = !Republic.squareRestless('mill');
  S.time = day0 + T2.dayLen * 2.75; h2.riseDay = -1;
  Math.random = () => 0.1; Republic.tick(0.6); Math.random = mr;
  const lovedStands = Republic.isHeld('mill');
  /* by hand — the verb the clock calls: not held, nothing rises */
  const byHand = Republic.squareRises('mill') === true && !Republic.isHeld('mill'), nothing = Republic.squareRises('mill') === false;
  return { funded, held, shields0, likesAfter, restless0, r1, calm, paid, three, r2, four, refused, row, disabledAtMax: !!disabledAtMax, noWarn, restless, warned, stood, onceANight, rose, mail: !!mail, byChoice, relDown, stone, lesson, title: !!title, funded2, loved, lovedStands, byHand, nothing };
});
ok('THE SQUARE RISES: the storming takes forty likes but leaves the town above the line — not restless yet; REINFORCE THE GARRISON pays the row\'s price for a third shield (a fourth is the most, a fifth refused; the sheet shows 4/4 and disables the button); thinned back to two under a town that hates the Order the sheet warns; the night\'s roll missed, the garrison stands (and the same night does not roll twice); made, the square RISES — the garrison thrown out, the lamp doused by choice, the mail, the mountain a step colder with the Unlit, a stone, the lesson, the title; the same thin garrison under a town above the line does not rise; the verb by hand throws a garrison out and does nothing where none stands',
  r.funded && r.held && r.shields0 === 2 && r.likesAfter === 15 && !r.restless0 && r.r1 && r.calm && r.paid && r.three && r.r2 && r.four && r.refused && r.row && r.disabledAtMax && r.noWarn && r.restless && r.warned && r.stood && r.onceANight && r.rose && r.mail && r.byChoice && r.relDown && r.stone && r.lesson && r.funded2 && r.loved && r.lovedStands && r.byHand && r.nothing, JSON.stringify(r));

/* ================= 5 · THE STORM, SEEN ================= */
r = await ev(() => new Promise(res => setTimeout(() => res(), 1400))).then(() => ev(() => {
  const cd = DATA.camps[0], W = REP.WATCHPOST.storm, K = W.seen, mr = Math.random;
  for (const k of Object.keys(REP.EVENTS)) S.rep.evCd[k] = 99999;
  S.banked.metal = 900; S.banked.wood = 300; S.banked.provisions = 500;
  const funded = Republic.fundTake(cd.id); const q = Republic.quell(); Math.random = () => 0.9; q.t = q.dur + 1; Republic.tick(0.02); Math.random = mr;
  const c = S.camps[cd.id], taken = !!c.taken; c.taken.shields = 2; c.runners = [];
  const season = !!Republic.reprisal();
  /* the walker in the ring with one fed back */
  for (const n of S.npcs.filter(x => x.state === 'companion')) n.state = 'pool';
  const a = NPC.gen({ at: 'haven' }); a.feeWaived = true; S.npcs.push(a); NPC.hire(a, 'companion'); NPC.setOrder(a, 'stand', 'meet');
  WL.tp([cd.x + 170, cd.y + 170]); S.room = null; a.cx = S.px; a.cy = S.py; a.shoveCd = 0; a.hungry = false;   // 240 from the fire: inside the walker's ring, outside the shields' reach
  const T2 = DATA.T, day0 = Math.floor(S.time / T2.dayLen) * T2.dayLen;
  S.time = day0 + T2.dayLen * 0.76; c.taken.stormDay = -1;
  Math.random = () => 0.1; Republic.tick(0.6); Math.random = mr;
  const seen = !!c.storm && !!c.taken, knives = c.storm ? c.storm.knives.length : 0;
  if (c.storm) for (const k of c.storm.knives) k.cls = 'knife';   // v3.41: the plain storm — the camps' own kit has its own suite (campsown.mjs)
  const d0 = c.storm ? c.storm.knives.map(k => U.dist(k.x, k.y, cd.x, cd.y)) : [];
  const atEdge = d0.length === W.knives && d0.every(d => Math.abs(d - cd.r * 0.95) < 40);
  const eyes = Republic.stormKnives().length, lesson = !!S.flags.tut.firstStormSeen, title = !!(Render.crtActive && Render.crtActive());
  const toast = /THE KNIVES COME FOR/.test(document.getElementById('toasts').innerHTML);
  /* the sheet while it rages */
  RepublicUI.open(); const html = document.getElementById('repBody').innerHTML; RepublicUI.close();
  const sheet = /THE KNIVES ARE AT THE FIRE/.test(html) && /s to hold; you stand the post/.test(html);
  /* the knives walk for the fire: a second of the storm */
  Republic.tick(1.0);
  const d1 = c.storm.knives.map(k => U.dist(k.x, k.y, cd.x, cd.y));
  const walked = d1.every((d, i) => d < d0[i] - K.knifeSpeed * 0.7 && d > K.fireR);
  /* the shields: the nearest knife at the fire's edge is knocked back, down for the row's span */
  const k0 = c.storm.knives[0]; k0.x = cd.x + 30; k0.y = cd.y; k0.cd = 0; c.storm.shieldT = 0.01;
  const tries0 = k0.downs;
  Republic.tick(0.02);
  const knocked = k0.cd > K.downFor - 0.1 && k0.downs === tries0 + 1 && U.dist(k0.x, k0.y, cd.x, cd.y) > 30 + K.knockBack - 2 && k0.atFire === 0;
  const cadence = Math.abs(c.storm.shieldT - K.shieldCd / 2) < 0.05;
  /* the party meets what comes inside its reach: the same intercept every runner meets */
  const k1 = c.storm.knives[1]; k1.x = a.cx + 60; k1.y = a.cy + 60; k1.cd = 0; a.shoveCd = 0; const met0 = NPC.svc(a).met;
  Republic.tick(0.02);
  const met = k1.cd > 0 && k1.downs === 1 && NPC.svc(a).met === met0 + 1 && /met a runner/.test(NPC.svc(a).last) && a.shoveCd > 0;
  /* the walker's own hands: with the back's hands full, a knife at your pack CUTS; with a hand free it is shoved */
  const k2 = c.storm.knives[2]; k2.x = S.px; k2.y = S.py; k2.cd = 0; a.shoveCd = 9; const hp0 = S.health;
  Republic.tick(0.02);
  const cut = k2.cd > 0 && S.health === hp0 - K.shoveDmg;
  k2.cd = 0; a.shoveCd = 0; a.cx = S.px + 400; a.cy = S.py; const downs2 = k2.downs; S.health = hp0;   // the back too far to meet it, a hand free to shove
  Republic.tick(0.02);
  const shoved = Math.abs(k2.cd - K.downFor * 0.8) < 0.05 && k2.downs === downs2 + 1 && S.health === hp0 && /shoved a runner/.test(NPC.svc(a).last);
  a.cx = S.px; a.cy = S.py;
  /* the storm spends itself: HELD in the open, the mail counting the knocks */
  const downsAll = c.storm.knives.reduce((s2, k) => s2 + k.downs, 0);
  for (const k of c.storm.knives) { k.x = cd.x + 400; k.y = cd.y + 400; }
  const relRF = Republic.rel('raiders', 'farkeep');
  c.storm.t = K.dur - 0.01;
  Math.random = () => 0.9; Republic.tick(0.02); Math.random = mr;
  const heldOpen = !c.storm && !!c.taken, heldMail = S.mails[0] && /the post HELD — you stood it/.test(S.mails[0].subj) && new RegExp(`knocked down ${downsAll} times`).test(S.mails[0].body);
  const relDown = Republic.rel('raiders', 'farkeep') === relRF - 1;
  /* and LOST at the fire: a knife that stands there long enough takes the post while you watch */
  const again = Republic.stormPost(cd) === true && !!c.storm;   // the walker in the ring: the storm starts, it is not rolled
  const k3 = c.storm.knives[0]; k3.x = cd.x; k3.y = cd.y; k3.cd = 0; k3.atFire = K.takeAfter;
  Math.random = () => 0.9; Republic.tick(0.02); Math.random = mr;
  const lost = !c.taken && !c.storm && !!c.lost && c.lost.n === 1;
  const lostMail = S.mails.find(m => /watchpost FELL/.test(m.subj) && /came in the open while you stood the post/.test(m.body));
  const noEyes = Republic.stormKnives().length === 0;
  for (const n of S.npcs.filter(x => x.state === 'companion')) n.state = 'pool';
  WL.tp([DATA.stations.haven.x, DATA.stations.haven.y + 60]);
  return { funded, taken, season, seen, knives, atEdge, eyes, lesson, title, toast, sheet, walked, knocked, cadence, met, cut, shoved, downsAll, heldOpen, heldMail: !!heldMail, relDown, again, lost, lostMail: !!lostMail, noEyes };
}));
ok('THE STORM, SEEN: with the walker standing the post the season\'s night is not rolled — three knives stand up at the ring\'s edge and the title, the lesson, the toast and the sheet say so; the knives WALK for the fire; the shields knock the nearest knife at the fire\'s edge back and down for the row\'s span, on the row\'s cadence; a back meets a knife inside its reach with the same intercept every runner meets; a knife at your pack CUTS while the back\'s hands are full and is SHOVED when a hand is free; the storm spent, the post HELD in the open (the mail counting the knocks, the camps a step colder with the mountain); and a knife that stands at the fire long enough takes the post while you watch — LOST, the mail saying you stood it',
  r.funded && r.taken && r.season && r.seen && r.knives === 3 && r.atEdge && r.eyes === 3 && r.lesson && r.title && r.toast && r.sheet && r.walked && r.knocked && r.cadence && r.met && r.cut && r.shoved && r.heldOpen && r.heldMail && r.relDown && r.again && r.lost && r.lostMail && r.noEyes, JSON.stringify(r));

/* ================= 6 · THE SOCIETY'S WAR ON THE CAMPS ================= */
r = await ev(() => {
  const E = REP.EVENTS.bunkerSweep, mr = Math.random;
  for (const k of Object.keys(REP.EVENTS)) S.rep.evCd[k] = 99999;
  if (!S.exile) Exile.tick(0.01);
  const T2 = DATA.T, day0 = Math.floor(S.time / T2.dayLen) * T2.dayLen;
  S.time = day0 + T2.dayLen * 0.8;
  for (const cd of DATA.camps) { const c = S.camps[cd.id]; if (c) c.swept = 0; }
  /* the door shut: the need finds nothing, the clock does not fire */
  S.exile.door = 'hidden'; S.rep.evCd.bunkerSweep = 0;
  Math.random = () => 0.1; Republic.tick(0.6); Math.random = mr;
  const shut = DATA.camps.every(cd => !S.camps[cd.id].swept);
  /* the door open: the northernmost camp that stands is COUNTED */
  S.exile.door = 'opened'; S.rep.evCd.bunkerSweep = 0;
  const live = DATA.camps.filter(cd => { const c = S.camps[cd.id]; return c && !c.pacified && !c.taken; }).sort((x, y) => x.y - y.y);
  const north = live[0], cN = S.camps[north.id]; cN.stash = [State.makeItem('metal'), State.makeItem('food')];
  const relDR = Republic.rel('diefenbunker', 'raiders');
  Math.random = () => 0.1; Republic.tick(0.6); Math.random = mr;
  const swept = cN.swept > 0 && S.time - cN.swept < 1, onlyNorth = DATA.camps.filter(cd => S.camps[cd.id].swept).length === 1;
  const emptied = cN.stash.length === 0, relDown = Republic.rel('diefenbunker', 'raiders') === relDR - 1;
  const mail = S.mails[0] && /The Society swept a camp/.test(S.mails[0].subj) && S.mails[0].body.includes(north.name) && /INVENTORIES/.test(S.mails[0].body);
  const toast = /The Society swept/.test(document.getElementById('toasts').innerHTML);
  const cooled = S.rep.evCd.bunkerSweep > 800;
  /* the ring shrinks for the count's span: the multiplier the runners answer to */
  const mul = Republic.sweptMul(north), mulOthers = live.slice(1).every(cd => Republic.sweptMul(cd) === 1);
  cN.swept = S.time - E.sweptDur - 1; const mulAfter = Republic.sweptMul(north); cN.swept = S.time;
  /* the sheet's plate */
  RepublicUI.open(); const html = document.getElementById('repBody').innerHTML; RepublicUI.close();
  const plate = /COUNTED BY THE SOCIETY/.test(html);
  /* a counted camp is not counted again while the count stands: the need walks to the next camp south */
  S.rep.evCd.bunkerSweep = 0;
  Math.random = () => 0.1; Republic.tick(0.6); Math.random = mr;
  const next = live[1] && S.camps[live[1].id].swept > 0;
  window._north = north.id;
  return { shut, swept, onlyNorth, emptied, relDown, mail: !!mail, toast, cooled, mul, claim: E.claimMul, mulOthers, mulAfter, plate, next: !!next, door: S.exile.door };
});
ok('THE SOCIETY\'S WAR ON THE CAMPS: with the cold door shut the need finds nothing; open, the Society sweeps the northernmost camp that stands — COUNTED, its salvage gone north, the pair a step colder, the mail naming the camp, the toast, the clock cooled for its span; the counted ring answers to the row\'s multiplier (the others do not; the count lapses with its span); the sheet shows the plate; a counted camp is skipped and the next one south is counted',
  r.shut && r.swept && r.onlyNorth && r.emptied && r.relDown && r.mail && r.toast && r.cooled && r.mul === r.claim && r.mul < 1 && r.mulOthers && r.mulAfter === 1 && r.plate && r.next, JSON.stringify(r));

/* ================= 7 · THE SAVE ================= */
r = await ev(() => {
  const north = window._north, pr = S.npcs.find(x => x.id === window._parcels);
  S.stations.haven.parcels = 2;
  const heldBefore = Republic.isHeld('mill') ? Republic.held().mill.shields : null;
  const h = Republic.held().mill; if (h) h.shields = 3;
  const sweptAt = S.camps[north].swept;
  State.save();
  S.stations.haven.parcels = 0; S.camps[north].swept = 0; if (h) h.shields = 1; pr.svc.parcels = 0;
  State.load();
  const back = S.stations.haven.parcels === 2 && S.camps[north].swept === sweptAt && (!h || Republic.held().mill.shields === 3);
  const stormDropped = DATA.camps.every(cd => !S.camps[cd.id].storm);
  const hand = S.npcs.find(x => x.id === window._parcels), packedBack = hand && hand.state === 'post' && hand.job === 'parcels' && (hand.svc.parcels || 0) === 3 && NPC.allows(hand, 'post', 'parcel');
  return { heldBefore, back, stormDropped, packedBack };
});
ok('THE SAVE: the parcels a town\'s round packed, the Society\'s count on a camp, a garrison\'s shields and the parcels hand\'s own tally survive a save and load; a storm in progress is dropped like every fight — a save never resumes mid-night', r.back && r.stormDropped && r.packedBack, JSON.stringify(r));

ok('no page errors across the standing ground', errors.length === 0, errors.slice(0, 3).join(' | '));
console.log(results.join('\n'));
console.log(`${results.filter(x => x.startsWith('PASS')).length}/${results.length} checks passed`);
await b.close();
