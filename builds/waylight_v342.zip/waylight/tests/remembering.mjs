/* remembering.mjs — v3.42 THE REMEMBERING: the marks (the rag on a stake, the survey's trade marks,
   the bolt) as registry rows in their palettes; the camps' own read from the survey sheet (the chief's
   fire lit, the rag gone to a stake, the Society's tongue); a chief who remembers (the road one knife
   short, the next storm without him, the leaderless fire courting the Unlit, the span); the town's own
   on the muster roll (records with a plate, THE HOURS — cover by the hour, the town's love and thanks,
   the Unlit's drum); a parcel lost as a grievance (raised on the road, deepened in a camp, given up;
   made right; remembered); the bolt as a wound the medic answers (the seep, the wind, the three pulls);
   the save. */
import { chromium } from 'playwright';
const results = [];
const ok = (name, cond, extra = '') => { results.push(`${cond ? 'PASS' : 'FAIL'}  ${name}${extra ? '  — ' + extra : ''}`); if (!cond) process.exitCode = 1; };
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium', args: ['--disable-background-networking'] });
const page = await b.newPage({ viewport: { width: 1440, height: 860 } });
await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
const errors = [];
page.on('pageerror', e => errors.push(String(e.message)));
await page.goto('file:///home/claude/waylight/dist/test.html?debug', { waitUntil: 'domcontentloaded' });
await page.waitForFunction(() => window.WL && WL.snapshot && WL.snapshot().baked, null, { timeout: 60000 });
await page.evaluate(() => localStorage.clear());
await page.click('#btnNew'); await page.waitForTimeout(300);
await page.click('#btnBegin'); await page.waitForTimeout(400);
await page.click('#briefGo'); await page.waitForTimeout(300);
await page.click('#cgBegin'); await page.waitForTimeout(1200);
for (let i = 0; i < 30; i++) { const c = await page.evaluate(() => !!S.cine); if (!c) break; await page.evaluate(() => WL.skipCine()); await page.waitForTimeout(250); }
await page.evaluate(() => { S.flags.guideDone = true; WL.calm(); });
const ev = (fn, arg) => page.evaluate(fn, arg);

/* ================= 1 · THE REGISTRIES ================= */
let r = await ev(() => {
  const inPal = (rows, pal, w, h) => rows.length === h && rows.every(rw => rw.length === w) && [...new Set(rows.join('').replace(/\./g, ''))].every(ch => pal[ch]);
  const stake = inPal(SPRITES.RAGSTAKE, SPRITES.RAGSTAKE_PAL, 7, 13);
  const marks = ['knife', 'bowman', 'ram', 'chief', 'fire', 'tongue', 'gone'].every(k => SPRITES.MARKS[k] && inPal(SPRITES.MARKS[k], SPRITES.MARK_PAL, 7, 7));
  const distinct = new Set(Object.values(SPRITES.MARKS).map(m => m.join(''))).size === 7;
  const bolt = inPal(SPRITES.ARROW_IN, SPRITES.ARROW_PAL, 5, 5);
  const G = DATA.T.grievance, A = DATA.T.arrow;
  const griev = G && G.ground > 0 && G.camp > 0 && G.given > G.ground && G.made > G.given && G.fadeDays > 0 && G.memory > 0;
  const arrow = A && A.seep > 0 && A.stamMul < 1 && A.medicR > 0 && A.medicTime > 0 && A.pullSelf > 0 && A.pullTime > 0;
  const FX = REP.DOCTRINE.storm.rise.hoursFx;
  const hours = FX && ['full', 'days', 'nights'].every(k => FX[k] && FX[k].cover && FX[k].line) && FX.full.cover === 'all' && FX.days.cover === 'day' && FX.nights.cover === 'night' && FX.full.likes < 0 && FX.days.appr > 0 && FX.nights.drum > 0 && FX.full.drum > 0 && !FX.days.drum;
  const mourn = REP.WATCHPOST.storm.seen.mourn > 0;
  const E = REP.EVENTS.campCourting;
  const court = E && E.kind === 'court' && E.needs === 'chieflessCamp' && E.night === true && E.actor === 'rebels' && E.victim === 'waylight' && /\{camp\}/.test(E.mail[1]) && /\{site\}/.test(E.mail[1]);
  const square = MUSTER.SQUARE && MUSTER.SQUARE.rows.join() === 'hours';
  const causes = MUSTER.MOOD.causes.ownSquare && MUSTER.MOOD.causes.ownClock && Object.keys(MUSTER.MOOD.causes).length === 23;
  const lessons = ['firstGrievance', 'firstArrow', 'firstMourning', 'firstSquareRoll'].every(k => DATA.tutorials[k] && DATA.tutorialTitles[k]), lessonsN = Object.keys(DATA.tutorials).length;
  const plain = UI.iconTag({ defId: 'parcel', cat: 'goods' }), torn = UI.iconTag({ defId: 'parcel', cat: 'goods', grieved: true });
  const icons = plain !== torn && /data:image/.test(plain) && /data:image/.test(torn);
  return { stake, marks, distinct, bolt, griev, arrow, hours, mourn, court, events: Object.keys(REP.EVENTS).length, square, causes, lessons, lessonsN, icons };
});
ok('THE REGISTRIES: the rag on a stake (7×13), seven trade marks for the survey (7×7, all distinct), the bolt overlay (5×5) — each in its own palette; the grievance row (raised, deepened, given, made right at more than it cost, remembered); the bolt row (the seep, the wind, three pulls); THE HOURS on the square (cover by the hour, the love worn round the clock, the thanks by day, the drum by night); the mourning span; the camp\'s courting as the ninth event (a court, by night, on a pair the ledger holds); the square\'s row on the muster; two more causes (twenty-three); four lessons (fifty-one); a torn parcel on paper',
  r.stake && r.marks && r.distinct && r.bolt && r.griev && r.arrow && r.hours && r.mourn && r.court && r.events === 9 && r.square && r.causes && r.lessons && r.lessonsN === 51 && r.icons, JSON.stringify(r));

/* ================= 2 · THE CAMPS' OWN ON THE SURVEY SHEET ================= */
r = await ev(() => {
  for (const k of Object.keys(REP.EVENTS)) S.rep.evCd[k] = 99999;
  const ash = DATA.camps.find(c => c.id === 'ash'), ridge = DATA.camps.find(c => c.id === 'ridge');
  S.camps.ridge.swept = S.time;   // counted: the tongue on the sheet
  /* the sheet opens centred on the walker: stand near each camp to read its marks */
  const cv = document.getElementById('map'), g = cv.getContext('2d');
  const under = (cd) => {   // a box in screen px under the camp's fire: every opaque colour in it
    const m = g.getTransform(), p = { x: m.a * cd.x + m.e, y: m.d * (cd.y + 12 / m.a) + m.f };
    const d = g.getImageData(Math.round(p.x - 75), Math.round(p.y), 150, 30).data, set = new Set();
    for (let i = 0; i < d.length; i += 4) if (d[i + 3] > 200) set.add('#' + [d[i], d[i + 1], d[i + 2]].map(v => v.toString(16).padStart(2, '0')).join(''));
    return set;
  };
  WL.tp([ash.x + 200, ash.y + 600]); UI.toggleMap(true);
  const a = under(ash);
  const chiefRed = a.has('#c9553a'), fireGold = a.has('#ffd98f'), plank = a.has('#8a6a42'), blade = a.has('#b8c2c8');
  /* the chief gone: the fire out on the sheet, the rag on a stake */
  Republic.chiefFalls(ash);
  UI.drawMap();
  const a2 = under(ash);
  const goneRed = a2.has('#c9553a'), noFire = !a2.has('#ffd98f'), stakeWood = a2.has('#a08050');
  S.camps.ash.chiefLost = 0;
  UI.toggleMap(false);
  WL.tp([ridge.x + 200, ridge.y + 600]); UI.toggleMap(true);
  const tongue = under(ridge).has('#8fb08a');
  UI.toggleMap(false);
  WL.tp([DATA.stations.haven.x, DATA.stations.haven.y + 60]);
  return { chiefRed, fireGold, plank, blade, tongue, goneRed, noFire, stakeWood };
});
ok('THE CAMPS\' OWN ON THE SURVEY SHEET: under Ash Camp\'s fire the sheet draws its roll — the chief\'s rag, the ram\'s plank, the knife\'s blade — with the chief\'s fire lit gold; a counted camp wears the Society\'s tongue; the chief fallen, the fire is out on the sheet and the rag stands on a stake',
  r.chiefRed && r.fireGold && r.plank && r.blade && r.tongue && r.goneRed && r.noFire && r.stakeWood, JSON.stringify(r));

/* ================= 3 · A CHIEF WHO REMEMBERS ================= */
r = await ev(() => {
  const ash = DATA.camps.find(c => c.id === 'ash'), c = S.camps.ash, K = REP.WATCHPOST.storm.seen, mr = Math.random;
  for (const k of Object.keys(REP.EVENTS)) S.rep.evCd[k] = 99999;
  for (const id of ['elm', 'mill', 'green', 'quarry']) S.stations[id].connected = true;
  c.runners = []; c.chiefLost = 0; c.taken = null; c.pacified = false; S.rep.courted = null;
  const up0 = Republic.chiefUp(ash);
  const fell = Republic.chiefFalls(ash) === true && Republic.chiefGone(ash) && !Republic.chiefUp(ash);
  const mail = S.mails[0] && /the chief did not get up/.test(S.mails[0].subj), lesson = !!S.flags.tut.firstMourning;
  /* the road walks one knife short */
  const T2 = DATA.T, day0 = Math.floor(S.time / T2.dayLen) * T2.dayLen; S.time = day0 + T2.dayLen * 0.3;
  WL.tp([DATA.stations.haven.x, DATA.stations.haven.y + 60]); Systems.update(0.25, {});
  const short = c.runners.length === ash.runners - 1 && !c.runners.some(x => x.cls === 'chief');
  /* the next storm comes without him */
  S.banked.metal = 900; S.banked.wood = 300; S.banked.provisions = 500;
  const mtOpen = Republic.mountain().phase === 'open' || (Republic.fundMountain(), Republic.mountain().t = REP.MOUNTAIN.dur + 1, Republic.tick(0.6), true);
  Republic.fundTake(ash.id); const q = Republic.quell(); Math.random = () => 0.9; q.t = q.dur + 1; Republic.tick(0.02); Math.random = mr;
  c.runners = []; c.taken.shields = 4;
  WL.tp([ash.x + 170, ash.y + 170]); S.room = null;
  const started = Republic.stormPost(ash) === true && !!c.storm;
  const noChief = started && !c.storm.knives.some(k => k.cls === 'chief') && c.storm.knives.map(k => k.cls).join() === 'bowman,ram,knife';
  c.storm = null;
  /* the leaderless fire courts the Unlit: the need finds the camp and its nearest lit door, the clock fires */
  c.taken = null; c.pacified = false;
  WL.tp([DATA.stations.haven.x, DATA.stations.haven.y + 60]);
  S.time = day0 + T2.dayLen * 0.8; S.rep.evCd.campCourting = 0;
  const relRW = Republic.rel('rebels', 'waylight');
  Math.random = () => 0.1; Republic.tick(0.6); Math.random = mr;
  const courted = S.rep.courted && S.rep.courted.by === 'ash' && S.stations[S.rep.courted.id] && S.stations[S.rep.courted.id].connected;
  const near = (() => { let best = null, bd = 1e9; for (const id of DATA.stationOrder) { const st = S.stations[id]; if (!st.connected || Republic.isUnlit(id) || Republic.isHeld(id)) continue; const d = U.dist(ash.x, ash.y, DATA.stations[id].x, DATA.stations[id].y); if (d < bd) { bd = d; best = id; } } return best; })();
  const nearest = courted && S.rep.courted.id === near;
  const courtMail = S.mails[0] && /courts the Unlit/.test(S.mails[0].subj) && S.mails[0].body.includes(ash.name) && S.mails[0].body.includes(DATA.stations[near].name), relDown = Republic.rel('rebels', 'waylight') === relRW - 1;
  const toast = /courts the Unlit/.test(document.getElementById('toasts').textContent);
  /* the sheet reads it; the span passes and a chief comes up again */
  RepublicUI.open(); const html = document.getElementById('repBody').innerHTML; RepublicUI.close();
  const sheet = /SHORT A CHIEF/.test(html);
  S.time = day0 + T2.dayLen * (0.8 + K.mourn) + 1;
  const back = Republic.chiefUp(ash) && !Republic.chiefGone(ash);
  S.rep.courted = null; c.runners = [];
  return { up0, fell, mail: !!mail, lesson, short, started, noChief, courted: !!courted, nearest, courtMail: !!courtMail, relDown, toast, sheet, back };
});
ok('A CHIEF WHO REMEMBERS: the chief fallen (the mail, the lesson), the camp is short a chief — the road walks one knife short, the next storm comes without him; by night the leaderless fire COURTS THE UNLIT at the nearest lit door (the camp named, the shutter up, the Unlit warmer against the Order, the toast), the sheet says so; the span passed, a chief comes up again',
  r.up0 && r.fell && r.mail && r.lesson && r.short && r.started && r.noChief && r.courted && r.nearest && r.courtMail && r.relDown && r.toast && r.sheet && r.back, JSON.stringify(r));

/* ================= 4 · THE TOWN'S OWN ON THE ROLL ================= */
r = await ev(() => {
  const mr = Math.random, R = REP.DOCTRINE.storm.rise, FX = R.hoursFx;
  for (const k of Object.keys(REP.EVENTS)) S.rep.evCd[k] = 99999;
  S.banked.metal = 900; S.banked.provisions = 500;
  Republic.rebellionStrike('mill'); S.stations.mill.likesTo = 55;
  Republic.fundStorm('mill'); const q = Republic.quell(); Math.random = () => 0.9; q.t = q.dur + 1; Republic.tick(0.02); Math.random = mr;
  const held = Republic.isHeld('mill');
  const a = Republic.recruitOwn('mill'), c = Republic.recruitOwn('mill');
  const records = NPC.ownAt('mill').length === 2 && a.state === 'square' && a.own === 'mill' && a.kit === 'townshield' && a.feeWaived && Republic.ownOf('mill') === 2;
  const sheet = NPC.workOf(a), kind = sheet.kind === 'square' && Object.keys(sheet.rows).join() === 'hours' && sheet.trees.length === 0;
  const every = NPC.everyone().find(x => x.n.id === a.id), placed = every && every.where === 'square' && /stands the square at The Mill/.test(every.place);
  /* the roll: AT THE SQUARES, a plate with the town's own figure, THE HOURS in the orders pane */
  MusterUI.open(a.id);
  const ov = document.getElementById('musterOv'), txt = ov.textContent;
  const group = /AT THE SQUARES · 2/.test(txt), plate = ov.querySelector(`.muPlate[data-mu="${a.id}"]`), fig = plate && plate.querySelector('.muFig img'), figSized = fig && fig.getAttribute('width') === '42' && /data:image/.test(fig.src);
  const stripe = plate && /watches stood/.test(plate.textContent) && /no tithe/.test(plate.textContent) && /THE TOWN'S OWN/.test(plate.textContent);
  const hoursBtns = [...ov.querySelectorAll('[data-order="hours"]')].map(x => x.dataset.choice).join();
  const paneLine = /not yours to hire or dismiss/.test(txt) && /drum/.test(txt);
  const daysBtn = ov.querySelector('[data-order="hours"][data-choice="days"]'); daysBtn && daysBtn.click();
  const setDays = NPC.ordersOf(a).hours === 'days', lesson = !!S.flags.tut.firstSquareRoll;
  MusterUI.close();
  /* the cover by the hour: nights stands the dark, days the light */
  const T2 = DATA.T, day0 = Math.floor(S.time / T2.dayLen) * T2.dayLen;
  S.time = day0 + T2.dayLen * 0.3; const byDay = Republic.standingOwn('mill');     // a: days · c: nights → 1
  S.time = day0 + T2.dayLen * 0.8; const byNight = Republic.standingOwn('mill');   // → 1
  NPC.setOrder(c, 'hours', 'full'); const byNightFull = Republic.standingOwn('mill');   // a: days (home) · c: full → 1
  S.time = day0 + T2.dayLen * 0.3; const byDayFull = Republic.standingOwn('mill');       // a: days · c: full → 2
  /* the mood reads the square */
  const moodA = NPC.mood(a).causes.map(x => x.id).join(), moodC = NPC.mood(c).causes.map(x => x.id).join();
  /* a period: the town feels THE HOURS — days: thanks; full: the love wears, the drum is slower */
  S.stations.mill.likesTo = 50; S.stations.mill.stock.food = 200;
  const h = Republic.held().mill; h.hoursT = R.recruitEvery - 0.4; h.recruitT = 0;
  const likes0 = S.stations.mill.likesTo, appr0 = S.stations.mill.appr, p0 = S.rep.pressure = 200;
  Math.random = () => 0.9; Republic.tick(0.6); Math.random = mr;
  const worn = S.stations.mill.likesTo === likes0 + FX.full.likes, thanked = S.stations.mill.appr === appr0 + FX.days.appr, drum = S.rep.pressure === p0 - FX.full.drum;
  const stood = (NPC.svc(a).stood || 0) === 1 && /works the fields/.test(NPC.svc(a).last);
  /* the sheet's garrison row reads them */
  RepublicUI.open(); const html = document.getElementById('repBody').innerHTML; RepublicUI.close();
  const row = /2 of the town's own/.test(html) && /in the square this hour/.test(html);
  /* home when the love falls: the records leave the roll */
  S.stations.mill.likesTo = 20; Math.random = () => 0.9; Republic.tick(0.6); Math.random = mr;
  const home = NPC.ownAt('mill').length === 0 && !S.npcs.some(n => n.id === a.id) && Republic.ownOf('mill') === 0;
  return { held, records, kind, placed, group, figSized: !!figSized, stripe: !!stripe, hoursBtns, paneLine, setDays, lesson, byDay, byNight, byNightFull, byDayFull, moodA, moodC, worn, thanked, drum, stood, row, home };
});
ok('THE TOWN\'S OWN ON THE ROLL: a garrison\'s recruits are records — on the muster roll AT THE SQUARES with the town\'s own figure on the plate, a stripe of watches stood, THE HOURS in the orders pane (full / days / nights; not yours to dismiss) and a lesson; the cover follows the hour (days stand the light, nights the dark, full both); the mood reads the square; a period passes and the town feels the hours — the love worn by the clock, the thanks grown by day, the Unlit\'s drum slower by night; the sheet\'s row reads them; the love fallen, the records leave the roll',
  r.held && r.records && r.kind && r.placed && r.group && r.figSized && r.stripe && r.hoursBtns === 'full,days,nights' && r.paneLine && r.setDays && r.lesson && r.byDay === 1 && r.byNight === 1 && r.byNightFull === 1 && r.byDayFull === 2 && /ownSquare/.test(r.moodA) && /ownClock/.test(r.moodC) && !/ownClock/.test(r.moodA) && r.worn && r.thanked && r.drum && r.stood && r.row && r.home, JSON.stringify(r));

/* ================= 5 · THE GRIEVANCE ================= */
r = await ev(() => {
  const G = DATA.T.grievance, mr = Math.random;
  for (const k of Object.keys(REP.EVENTS)) S.rep.evCd[k] = 99999;
  for (const n of S.npcs.filter(x => x.state === 'companion')) n.state = 'pool';
  S.grievances = [];
  const T2 = DATA.T, day0 = Math.floor(S.time / T2.dayLen) * T2.dayLen; S.time = day0 + T2.dayLen * 0.3;
  S.stations.haven.parcels = [{ to: 'elm', kind: 'coat', name: 'a mended coat' }, { to: 'elm', kind: 'shoes', name: 'a child\'s shoes' }];
  S.orders.active = []; for (const c2 of [...S.cargo]) if (c2.cat !== 'tool') State.removeCargo(c2.id);
  const run = Economy.ordersFor('haven').find(o => o.item === 'parcel' && o.to === 'elm');
  const o = Systems.acceptOrder(run, false);
  const addressed = S.cargo.filter(c2 => c2.parcel && c2.parcel.to === 'elm' && c2.parcel.id).length === 2;
  /* knocked off the pack by a knife inside Ridge Camp's ring: the town's grievance is raised */
  const ridge = DATA.camps.find(c2 => c2.id === 'ridge'), c = S.camps.ridge; c.runners = []; c.chiefLost = 0; c.swept = 0; c.taken = null; c.pacified = false;
  Systems.update(0.05, {});
  WL.tp([ridge.x + 150, ridge.y]); S.room = null; S.state = 'walk';
  const kn = c.runners.find(x => x.cls === 'knife'); for (const x of c.runners) { x.cd = 30; x.shotCd = 99; } kn.cd = 0; kn.x = S.px + 5; kn.y = S.py;
  const appr0 = S.stations.elm.appr, hp0 = S.health;
  Math.random = () => 0.9; Systems.update(0.05, {}); Math.random = mr;   // one crate knocked loose, not two
  const dropped = S.drops.filter(d => d.item.parcel), raised = S.grievances.length === dropped.length && dropped.length >= 1 && S.grievances.every(g => g.how === 'ground' && g.to === 'elm');
  const cost = S.stations.elm.appr === appr0 - G.ground * dropped.length, grieved = dropped.every(d => d.item.grieved);
  const mail = S.mails.find(m => /Elm Farm: a grievance/.test(m.subj)) && /lying on the road/.test(S.mails.find(m => /a grievance/.test(m.subj)).body), lesson = !!S.flags.tut.firstGrievance;
  const torn = UI.iconTag(dropped[0].item) !== UI.iconTag({ defId: 'parcel', cat: 'goods' });
  /* carried into the camp by a runner: the grievance deepens */
  for (const x of c.runners) x.cd = 30;
  const d0 = dropped[0]; d0.x = ridge.x + 40; d0.y = ridge.y; kn.x = d0.x; kn.y = d0.y; kn.cd = 30;
  WL.tp([DATA.stations.haven.x, DATA.stations.haven.y + 60]);   // the walker gone: no threat, the runner patrols and collects
  const appr1 = S.stations.elm.appr;
  for (let i = 0; i < 12; i++) Systems.update(0.25, {});
  const inCamp = c.stash.includes(d0.item) && S.grievances.find(g => g.id === d0.item.parcel.id).how === 'camp' && S.stations.elm.appr === appr1 - G.camp;
  /* the board at Elm reads the grievance */
  WL.tp('elm'); UI.openStation('elm'); UI.gotoTab('orders');
  const plate = document.querySelector('#stationBody .market.grievances'), board = plate && /a mended coat|a child's shoes/.test(plate.textContent) && /carried into a camp/.test(plate.textContent) && plate.querySelector('img');
  document.getElementById('stationClose').click();
  /* the run given up: what is still on the pack is the town's grievance too */
  const onPack = S.cargo.filter(c2 => c2.parcel).length, appr2 = S.stations.elm.appr;
  Systems.abandonOrder(o.idNum);
  const given = onPack >= 1 && S.grievances.filter(g => g.how === 'given').length === onPack && S.stations.elm.appr === appr2 - G.given * onPack && S.cargo.filter(c2 => c2.parcel).every(c2 => c2.lostTo === 'elm');
  /* carried through after all: the lost parcel delivered at Elm is MADE RIGHT — more than it cost */
  const appr3 = S.stations.elm.appr, n0 = S.grievances.length;
  WL.tp('elm'); WL.instantPar();
  const { results } = Systems.handleDelivery('elm');
  const made = S.grievances.length === n0 - onPack && S.stations.elm.appr === appr3 + G.made * onPack && results.some(x => x.lost);
  /* two days unanswered: the town REMEMBERS — likes gone for good, the board says so */
  const g2 = S.grievances.find(g => g.id === d0.item.parcel.id); g2.t = S.time - G.fadeDays * T2.dayLen - 1;
  const likes0 = S.stations.elm.likesTo;
  for (let i = 0; i < 24; i++) Systems.update(0.25, {});
  const remembered = g2.remembered === true && S.stations.elm.likesTo === Math.max(0, likes0 - G.memory) && S.mails[0] && /Elm Farm remembers/.test(S.mails[0].subj);
  UI.openStation('elm'); UI.gotoTab('orders');
  const plate2 = document.querySelector('#stationBody .market.grievances'), boardRem = plate2 && /REMEMBERED/.test(plate2.textContent);
  document.getElementById('stationClose').click();
  /* made right through the run itself: a parcel knocked loose, picked back up, delivered on the order */
  S.stations.haven.parcels = [{ to: 'elm', kind: 'tin', name: 'a tin of buttons' }];
  S.orders.active = [];
  const run2 = Economy.ordersFor('haven').find(o2 => o2.item === 'parcel' && o2.to === 'elm'); const o2 = Systems.acceptOrder(run2, false);
  const it = S.cargo.find(c2 => c2.parcel && c2.parcel.kind === 'tin');
  State.removeCargo(it.id); S.drops.push({ id: U.uid(), item: it, x: S.px, y: S.py }); Economy.grieve(it, 'ground');   // the knock's own path, by hand
  const appr4 = S.stations.elm.appr;
  const dr = S.drops.find(d => d.item === it); State.addCargo(dr.item); S.drops.splice(S.drops.indexOf(dr), 1);
  WL.tp('elm'); WL.instantPar();
  const res2 = Systems.handleDelivery('elm').results.find(x => x.order && x.order.item === 'parcel');
  const madeRight = !!res2 && res2.made && res2.made.length === 1 && /Made right/.test(res2.made[0]) && S.stations.elm.appr >= appr4 + G.made && !S.grievances.some(g => g.id === it.parcel.id);   // the run's own thanks land beside the making-right
  WL.tp([DATA.stations.haven.x, DATA.stations.haven.y + 60]); for (const x of c.runners) x.cd = 30;
  return { addressed, dropped: dropped.length, raised, cost, grieved, mail: !!mail, lesson, torn, inCamp, board: !!board, given, made, remembered, boardRem: !!boardRem, madeRight };
});
ok('THE GRIEVANCE: the address rides the crate; a knife\'s knock puts a parcel on the road and the door it was addressed to raises a grievance — appreciation lost, the mail, the lesson, the crate torn on paper; a runner carrying it into the camp deepens it; the board at Elm reads it; the run given up makes what is still on the pack a grievance too; the lost parcel carried through after all is MADE RIGHT at more than it cost; two days unanswered the town REMEMBERS (likes gone for good, the board says so); a parcel knocked loose, picked back up and delivered on its run is made right on the slip',
  r.addressed && r.dropped >= 1 && r.raised && r.cost && r.grieved && r.mail && r.lesson && r.torn && r.inCamp && r.board && r.given && r.made && r.remembered && r.boardRem && r.madeRight, JSON.stringify(r));

/* ================= 6 · THE BOLT ================= */
r = await ev(() => {
  const A = DATA.T.arrow, mr = Math.random;
  for (const n of S.npcs.filter(x => x.state === 'companion')) n.state = 'pool';
  WL.tp([DATA.stations.haven.x + 700, DATA.stations.haven.y + 700]); S.room = null; S.moveTo = null; S.speed = 0;   // off the town's rest: no regen to hide the seep
  S.arrow = null; S.health = 80; S.food = 40; S.bleeding = false; S.bruisedT = 0;
  /* the wind at half pace: standing still, the same second with and without the bolt */
  S.stam = 10; Systems.update(1, {}); const regen0 = S.stam - 10;
  Systems.boltIn('ridge');
  const set = !!S.arrow && S.arrow.from === 'ridge', lesson = !!S.flags.tut.firstArrow;
  UI.updateHUD(); const chip = /A BOLT IN/.test(document.getElementById('buffs').textContent);
  S.stam = 10; Systems.update(1, {}); const regen1 = S.stam - 10;
  const halved = regen0 > 0.5 && Math.abs(regen1 - regen0 * A.stamMul) < 0.15;
  /* the seep */
  const hp0 = S.health; for (let i = 0; i < 40; i++) Systems.update(0.25, {}); const seeped = Math.abs((hp0 - S.health) - A.seep * 10) < 0.35;
  /* your own hand: the prompt, standing still, for the price */
  const act = Systems.getInteractions().find(i => /Pull the bolt/.test(i.label));
  act && act.fn();
  const pulling = !!S.arrow && S.arrow.pulling === true;
  UI.updateHUD(); const chip2 = /PULLING THE BOLT/.test(document.getElementById('buffs').textContent);
  const hp1 = S.health; for (let i = 0; i < 12; i++) Systems.update(0.25, {});
  const pulledSelf = !S.arrow && Math.abs((hp1 - S.health) - A.pullSelf) < 0.5;
  /* the medic answers: a field medic walking with you, inside reach, a breath — no price */
  Systems.boltIn('ridge');
  const m = NPC.gen({ at: 'haven', cls: 'medic' }); m.feeWaived = true; S.npcs.push(m); NPC.hire(m, 'companion'); m.cx = S.px + 20; m.cy = S.py; m.hungry = false; m.shoveCd = 0;
  const hp2 = S.health, mendBefore = (m.trainXp || {}).mend || 0;
  for (let i = 0; i < Math.ceil(A.medicTime / 0.25) + 2; i++) { m.cx = S.px + 20; m.cy = S.py; Systems.update(0.25, {}); }
  const pulledMedic = !S.arrow && S.health > hp2 - 0.5 && /pulled a bolt/.test(NPC.svc(m).last) && NPC.svc(m).pulled === 1 && ((m.trainXp || {}).mend || 0) > mendBefore;
  /* a far medic is no medic: the bolt stays */
  Systems.boltIn('ridge'); m.cx = S.px + 400; m.cy = S.py;
  for (let i = 0; i < 12; i++) { m.cx = S.px + 400; Systems.update(0.25, {}); }
  const stays = !!S.arrow;
  m.state = 'pool';
  /* a lit town's hands pull it at the terminal */
  WL.tp('haven'); Systems.handleDelivery('haven');
  const pulledTown = !S.arrow;
  WL.tp([DATA.stations.haven.x, DATA.stations.haven.y + 60]);
  return { set, lesson, chip, regen0: Math.round(regen0 * 100) / 100, regen1: Math.round(regen1 * 100) / 100, halved, seeped, pulling, chip2, pulledSelf, pulledMedic, stays, pulledTown };
});
ok('THE BOLT: a bowman\'s arrow left in (the lesson, A BOLT IN on the HUD) halves the wind coming back and seeps; your own hand pulls it — the prompt, standing still, for the price; a field medic walking beside you pulls it in a breath for nothing (the note, the lesson of the trade); a medic out of reach is no medic; a lit town\'s hands pull it at the terminal',
  r.set && r.lesson && r.chip && r.halved && r.seeped && r.pulling && r.chip2 && r.pulledSelf && r.pulledMedic && r.stays && r.pulledTown, JSON.stringify(r));

/* ================= 7 · THE SAVE ================= */
r = await ev(() => {
  const ash = DATA.camps.find(c => c.id === 'ash');
  Republic.chiefFalls(ash); const lostAt = S.camps.ash.chiefLost;
  Systems.boltIn('ridge');
  const mr = Math.random;
  Republic.rebellionStrike('mill'); S.stations.mill.likesTo = 55;
  Republic.fundStorm('mill'); const q = Republic.quell(); Math.random = () => 0.9; q.t = q.dur + 1; Republic.tick(0.02); Math.random = mr;
  const a = Republic.recruitOwn('mill'); NPC.setOrder(a, 'hours', 'days');
  S.grievances = [{ id: 'g1', to: 'elm', from: 'haven', kind: 'coat', name: 'a mended coat', t: S.time, how: 'ground', n: 1, remembered: false }];
  State.save();
  S.camps.ash.chiefLost = 0; S.arrow = null; S.npcs = S.npcs.filter(n => n.state !== 'square'); S.grievances = [];
  State.load();
  const chief = S.camps.ash.chiefLost === lostAt && Republic.chiefGone(ash);
  const bolt = !!S.arrow && S.arrow.from === 'ridge';
  const own = NPC.ownAt('mill').length === 1 && NPC.ordersOf(NPC.ownAt('mill')[0]).hours === 'days' && Republic.ownOf('mill') === 1;
  const griev = S.grievances.length === 1 && S.grievances[0].name === 'a mended coat';
  S.arrow = null;
  return { chief, bolt, own, griev };
});
ok('THE SAVE: a camp\'s mourning, the bolt in, the town\'s own with their hours, and the grievances survive a save and load', r.chief && r.bolt && r.own && r.griev, JSON.stringify(r));

ok('no page errors across the remembering', errors.length === 0, errors.slice(0, 3).join(' | '));
console.log(results.join('\n'));
console.log(`${results.filter(x => x.startsWith('PASS')).length}/${results.length} checks passed`);
await b.close();
