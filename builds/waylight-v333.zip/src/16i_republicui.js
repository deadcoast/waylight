'use strict';
/* Waylight v3.32 — THE BANNER SHEET: the Republic in session, on LEDGERLIGHT paper. One sheet,
   two ledgers: THE COURT (every banner the world knows, its stance sealed by lore or walked by
   play) and THE HOLDINGS (every town's light as a political fact, the doctrines that answer the
   dark ones, the mountain road, the kit of Farkeep). Reads the REP registries and the Republic
   engine only — a new faction row renders here with zero new UI code. */

const RepublicUI = (() => {
  const $ = id => document.getElementById(id);

  const chip = pal => `<span class="rpChip"><i style="background:${pal.A}"></i><i style="background:${pal.B}"></i></span>`;
  const plate = st => { const d = REP.STANCES[st] || REP.STANCES.UNKNOWN; return `<span class="rpPlate" style="color:${d.col};border-color:${d.col}">${d.name.toUpperCase()}</span>`; };
  const cost = c => Systems.fmtCost(c);

  /* ---------- THE COURT ---------- */
  function courtRows() {
    let htm = '';
    for (const [fid, f] of Object.entries(FACT.FACTIONS)) {
      const rule = REP.RULES[fid] || {}, st = Republic.stance(fid);
      let ctl = '';
      if (rule.locked) ctl = `<span class="rpSeal">SEALED BY THE FOUNDING</span>`;
      else if (rule.mirror) ctl = `<span class="rpSeal dim">READ FROM THE ${rule.mirror === 'exileRank' ? 'GUILD LEDGER' : 'COLD DOOR'}</span>`;
      else {
        ctl = (rule.steps || []).map(s2 => {
          const on = st === s2, g = Republic.gateOk(fid, s2);
          return `<button class="miniBtn rpStep ${on ? 'on' : ''} ${g.ok ? '' : 'no'}" data-fid="${fid}" data-st="${s2}">${(REP.STANCES[s2] || {}).name || s2}</button>`;
        }).join('');
        const need = Object.entries(rule.gate || {}).map(([s2, g2]) => Republic.gateOk(fid, s2).ok ? '' : g2.line).filter(Boolean)[0];
        if (need) ctl += `<div class="rpGate">${need}</div>`;
      }
      /* the line: whole sentences until the row has enough voice, then a clean word-boundary cut */
      let line = '';
      for (const sen of f.culture.split('. ')) { line += (line ? '. ' : '') + sen; if (line.length > 90) break; }
      if (!line.endsWith('.')) line += '.';
      if (line.length > 170) line = line.slice(0, 167).replace(/\s+\S*$/, '') + '…';
      htm += `<div class="rpRow">
        <div class="rpTop">${chip(f.pal)}<span class="rpName">${f.name}</span><span class="rpPeople">${f.people}</span>${plate(st)}</div>
        <div class="rpLine">${line}</div>
        <div class="rpCtl">${ctl}</div></div>`;
    }
    return htm;
  }

  /* ---------- THE HOLDINGS ---------- */
  function holdingsRows() {
    const q = Republic.quell();
    let htm = '';
    for (const id of DATA.stationOrder) {
      const st = S.stations[id], def = DATA.stations[id];
      const unlit = Republic.isUnlit(id), quiet = !!(S.quiet && S.quiet[id]) && !unlit;
      const state = unlit ? '<span class="rpPlate" style="color:var(--rust);border-color:var(--rust)">UNLIT — BY CHOICE</span>'
        : quiet ? '<span class="rpPlate" style="color:var(--bone-faint);border-color:var(--line2)">QUIET — STARVED</span>'
        : st.connected ? '<span class="rpPlate" style="color:var(--gold);border-color:var(--gold)">LIT</span>'
        : '<span class="rpPlate" style="color:var(--bone-faint);border-color:var(--line2)">DARK</span>';
      let act = '';
      if (unlit) {
        if (q && q.kind === 'quell' && q.target === id) act = `<span class="rpGate">THE COLUMN MARCHES — ${Math.round(q.t / q.dur * 100)}%</span>`;
        else act = `<button class="miniBtn rpAct" data-quell="${id}" ${q ? 'disabled' : ''}>${REP.DOCTRINE.quell.name} — ${cost(REP.DOCTRINE.quell.cost)}</button>
          <span class="rpGate">or WALK there: the parley wants ${REP.DOCTRINE.parley.needLikes} likes at their door + ${cost(REP.DOCTRINE.parley.gift)}</span>`;
      }
      htm += `<div class="rpHold"><span class="rpName">${def.name}</span>${state}${act ? `<div class="rpCtl">${act}</div>` : ''}</div>`;
    }
    /* the larders the doctrine can answer */
    const all = (S.rep && S.rep.sites) || [];
    all.forEach((s2, i) => {
      if (s2.p !== 'hollowfire' || s2.cleared) return;
      const marching = q && q.kind === 'burn' && q.site === i;
      htm += `<div class="rpHold"><span class="rpName">A HOLLOW FIRE</span><span class="rpPlate" style="color:var(--rust);border-color:var(--rust)">LARDER STANDS</span>
        <div class="rpCtl">${marching ? `<span class="rpGate">THE STRIKE MARCHES — ${Math.round(q.t / q.dur * 100)}%</span>` : `<button class="miniBtn rpAct" data-burn="${i}" ${q ? 'disabled' : ''}>${REP.DOCTRINE.burn.name} — ${cost(REP.DOCTRINE.burn.cost)}</button>`}</div></div>`;
    });
    return htm;
  }

  /* ---------- THE MOUNTAIN + THE KIT ---------- */
  function mountainRow() {
    const mt = Republic.mountain(), M = REP.MOUNTAIN;
    if (mt.phase === 'unknown') return `<div class="rpHold"><span class="rpName">THE MOUNTAIN PASS</span><span class="rpPlate" style="color:var(--bone-faint);border-color:var(--line2)">UNCUT</span>
      <div class="rpCtl"><button class="miniBtn rpAct" data-mountain="1">FUND THE ROAD — ${cost(M.cost)}</button><div class="rpGate">the road their grandfathers walked DOWN — cut it back UP and Farkeep answers the wire</div></div></div>`;
    if (mt.phase === 'cutting') return `<div class="rpHold"><span class="rpName">THE MOUNTAIN ROAD</span><span class="rpPlate" style="color:var(--gold);border-color:var(--gold)">CUTTING — ${Math.round(mt.t / M.dur * 100)}%</span></div>`;
    let kit = '';
    for (const [cls, row] of Object.entries(REP.KIT)) {
      const def = FACT.FK_CLASSES[cls];
      kit += `<button class="miniBtn rpAct" data-hire="${cls}">${def.name} — ${cost(row.fee)}${row.req === 'horse' ? ' · wants a horse' : ''}</button>`;
    }
    return `<div class="rpHold"><span class="rpName">FARKEEP</span><span class="rpPlate" style="color:var(--gold);border-color:var(--gold)">THE ROAD IS CUT</span>
      <div class="rpCtl">${kit}<div class="rpGate">the kit of the mountain — each answers from its own row when trouble closes</div></div></div>`;
  }

  function body() {
    const t = Republic.truce();
    return `<div class="rpCols">
      <div class="rpCol"><div class="railHead">THE COURT — EVERY BANNER THE WORLD KNOWS</div>${courtRows()}</div>
      <div class="rpCol"><div class="railHead">THE HOLDINGS — THE LIGHT AS A POLITICAL FACT</div>
        ${t ? '<div class="rpGate" style="margin-bottom:8px">A RAIDER TRUCE STANDS — the camps hold, and the horns hold WITH them</div>' : ''}
        ${holdingsRows()}${mountainRow()}
        <div class="docFoot">THE REPUBLIC OF CONNECTION · <b>WAYLIGHT CARRIES THE LIGHT · FARKEEP CARRIES THE WEIGHT</b></div></div></div>`;
  }

  function render() { const el = $('repBody'); if (el) el.innerHTML = body(); }
  function open() {
    UI.closeAllModals();
    $('republicOv').classList.remove('hidden');
    render();
    Systems.tut && Systems.tut('firstBanner');
    Snd.sfx.ui();
  }
  function close() { $('republicOv').classList.add('hidden'); }
  
  /* ---------- the desks on the table ---------- */
  function renderDesk(el, id) {
    const bankRow = `<div class="fdBank">BANKED · ${['metal', 'wood', 'ceramic', 'provisions', 'lumen'].map(k => `${k} <b>${Math.floor(S.banked[k] || 0)}</b>`).join(' · ')}</div>`;
    const mt = Republic.mountain(), M = REP.MOUNTAIN;
    let head = '[ THE MOUNTAIN PASS ]', bodyH = '';
    if (id === 'mountain') {
      if (mt.phase === 'unknown') bodyH = `<div class="fdLine">The Farkeepers walked DOWN this pass when the Order fed the Farlands famine. Nobody has walked it UP since — the galleries fell, the pins rusted, the cold kept the rest.</div>
        <div class="fdLine dim">Fund the road-gangs and the mountain opens: Farkeep answers the wire, and the kit of the mountain hires at their desk.</div>
        ${bankRow}<button class="fdBtn" data-act="rep_mountain">FUND THE MOUNTAIN ROAD — ${Systems.fmtCost(M.cost)}</button>`;
      else if (mt.phase === 'cutting') bodyH = `<div class="fdLine">The road-gangs are on the switchbacks — <b>${Math.round(mt.t / M.dur * 100)}%</b>. The mountain does not hurry and does not stop.</div>`;
      else { head = '[ THE MOUNTAIN ROAD ]'; bodyH = `<div class="fdLine">CUT AND HELD. Farkeep answers the wire; the Republic sits in session on the banner sheet, and the kit hires at Farkeep's own desk past the pass.</div>`; }
    } else {
      head = '[ FARKEEP ]';
      let kit = '';
      for (const [cls, row] of Object.entries(REP.KIT)) { const def = FACT.FK_CLASSES[cls]; kit += `<button class="fdBtn" data-act="rep_hire_${cls}">${def.name.toUpperCase()} — ${Systems.fmtCost(row.fee)}${row.req === 'horse' ? ' · WANTS A HORSE' : ''}</button>`; }
      bodyH = `<div class="fdLine">The Republic's muscle, at home. Stone rows up the pass, shield-doors, and the long practice yards where the kit is made.</div>
        <div class="fdLine dim">Longbowman — the wall of Farkeep, carried on a shoulder. Rifle Rider — a breech and a horse. Berserker — a pistol, a claymore, and no argument.</div>
        ${bankRow}${kit}<button class="fdBtn" data-act="rep_sheet">OPEN THE BANNER SHEET</button>`;
    }
    el.innerHTML = `<div class="fdHead"><span>${head}</span><button class="fdX" data-act="close">✕</button></div>${bodyH}`;
  }
  function deskAct(act) {
    if (act === 'rep_mountain') Republic.fundMountain();
    else if (act === 'rep_sheet') { Continent.close && Continent.close(); UI.toggleMap(false); open(); }
    else if (act.startsWith('rep_hire_')) Republic.hireKit(act.slice(9));
  }

  /* ---------- wiring ---------- */
  function init() {
    const ov = $('republicOv');
    if (!ov) return;
    $('repClose').addEventListener('click', close);
    ov.addEventListener('click', e => {
      if (e.target === ov) { close(); return; }
      const t = e.target.closest ? e.target.closest('button') : null;
      if (!t) return;
      if (t.dataset.fid) { Republic.setStance(t.dataset.fid, t.dataset.st); render(); }
      else if (t.dataset.quell) { Republic.fundQuell(t.dataset.quell); render(); }
      else if (t.dataset.burn !== undefined) { Republic.fundBurn(+t.dataset.burn); render(); }
      else if (t.dataset.mountain) { Republic.fundMountain(); render(); }
      else if (t.dataset.hire) { Republic.hireKit(t.dataset.hire); render(); }
    });
    const rb = $('railRepublicBtn');
    if (rb) rb.addEventListener('click', () => { UI.toggleMap(false); open(); });
  }
  init();

  return { open, close, render, renderDesk, deskAct };
})();
