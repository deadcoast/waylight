'use strict';
/* Waylight v3.32 — THE REPUBLIC IN FORCE: the CK3-sandbox data layer. EVERYTHING here is a
   REGISTRY ROW read by one engine (15g_republic.js) and one set of render glyphs — a future
   faction, presence, doctrine, or interior plugs in a row, never a new code path. This is the
   scaling law the memorial proved (four designs, one renderer) applied to the whole sandbox. */

const REP = (() => {
  /* ---------- the stance ladder: one ordered scale, walked by play ---------- */
  const STANCES = {
    ABSOLUTE_ALLY:   { ord: 5, name: 'Absolute Ally',   line: 'defend at all costs',            col: '#ffd98f' },
    ALLY:            { ord: 4, name: 'Ally',            line: 'doors open, arms shared',        col: '#e8c87f' },
    FRIENDLY:        { ord: 3, name: 'Friendly',        line: 'trade and truce hold',           col: '#b3c98a' },
    WARY:            { ord: 2, name: 'Wary',            line: 'watched, not welcomed',          col: '#b8b29d' },
    HOSTILE:         { ord: 1, name: 'Hostile',         line: 'harm on opportunity',            col: '#d96b4f' },
    ABSOLUTE_HOSTILE:{ ord: 0, name: 'Absolute Hostile',line: 'shoot on sight — it is mercy',   col: '#c25038' },
    UNKNOWN:         { ord: -1, name: 'Unknown',        line: 'no account survives contact',    col: '#7a7666' },
  };

  /* ---------- per-faction stance RULES: what play can move, and through which gate ----------
     locked: lore holds the stance forever (the sheet shows the seal, not a control).
     steps: the stances play can reach, in ladder order. gate: the standing condition a step up
     demands, checked by the engine — every gate reads EXISTING systems (renegade tiers, exile
     rank, the cold door, shrines fed), never a new currency. */
  const RULES = {
    waylight:     { locked: true },
    farkeep:      { locked: true },
    reapers:      { locked: true },
    cannibals:    { locked: true },
    raiders:      { steps: ['HOSTILE', 'WARY'], gate: { WARY: { renegadeTier: 2, line: 'the Road\'s Own may call a truce — camps honor what the road keeps' } },
                    truce: 'WARY' },   // at truce the camps stand down and the horns stand DOWN with them
    rebels:       { steps: ['HOSTILE', 'WARY'], gate: {}, posture: true },   // posture: LISTEN (WARY) vs HARD LINE (HOSTILE) — it prices the doctrine below
    flamekeepers: { steps: ['WARY', 'FRIENDLY', 'ALLY'], gate: { FRIENDLY: { shrinesFed: 1, line: 'feed ONE shrine and they stop pitying you aloud' }, ALLY: { shrinesFed: 3, line: 'feed every shrine on the march and their tenders walk to meet you' } } },
    irongiants:   { locked: true },   // UNKNOWN is a stance too: nobody treats with a rumor
    lamplighters: { mirror: 'exileRank' },     // the sheet READS the guild ledger — rank 2+ shows FRIENDLY, 3 ALLY
    diefenbunker: { mirror: 'coldDoor' },      // the sheet READS the door — opened shows FRIENDLY
  };

  /* ---------- THE DOCTRINE: what force and what patience each cost ----------
     One table, two customers today (the Unlit rebellion, the Hollow Fires' larders) and any
     tomorrow: a doctrine names its verb, its price, its clock, and what it writes. */
  const DOCTRINE = {
    quell: {
      name: 'THE QUELL', verb: 'Send the Farkeepers',
      cost: { metal: 40, provisions: 20 },
      dur: 110,                       // the column marches in real seconds — SEEN on the ground
      column: 3,                      // shields on the road
      apprHit: 8,                     // the town remembers who sent soldiers instead of walking
      casualty: 0.35,                 // a quell can cost the mountain a name — the stone gets raised
      line: 'The mountain walks. The light is RESTORED by force; the town remembers the shields, not the smile.',
    },
    parley: {
      name: 'THE PARLEY', verb: 'Walk there yourself',
      gift: { provisions: 12 },
      needLikes: 30,                  // the town must have loved you once — likesTo at that door
      line: 'Your boots, their fire, a gift of stores. Slower to arrive, remembered longer.',
    },
    burn: {
      name: 'THE BURNING', verb: 'Fund the strike',
      cost: { metal: 60, provisions: 24 },
      dur: 90, column: 4,
      line: 'The Farkeepers do not parley with larders. The site is cleared and the roads near it breathe.',
    },
  };

  /* ---------- THE UNLIT: rebellion tuning ---------- */
  const REBELLION = {
    covMin: 0.35,                     // the wire must MATTER before anyone calls it a leash
    first: 'quarry',                  // the first rising is authored — stone-cutters, far from Haven's warmth
    period: 540,                      // pressure clock between risings (seconds, scaled by posture)
    posturePeriodMul: { WARY: 1.35, HOSTILE: 0.8 },   // LISTEN slows the drum; HARD LINE feeds it
    heatWeight: 2.2,                  // your caught work at a town is their best recruiter
    maxDark: 2,                       // the valley never collapses off-screen — the sandbox stays playable
  };

  /* ---------- WORLD PRESENCES: one registry, one engine, one glyph set ----------
     kind 'site'  — persistent ground the engine seeds once and keeps in the save.
     kind 'event' — a thing that HAPPENS under conditions and leaves. */
  const PRESENCES = {
    flameshrine: {
      fact: 'flamekeepers', kind: 'site', count: 3, glyph: 'shrine',
      near: 'road', minStationDist: 240,
      feedCost: { lumen: 2 }, fedDur: 480,          // a fed shrine burns most of a day
      appr: 1,
      lines: {
        cold: 'A stone bowl, scraped clean. The Flame Keepers hold that light must be FED, not wired.',
        fed: 'The bowl burns tall and clean. Somewhere, a tender marks your name kindly.',
      },
    },
    hollowfire: {
      fact: 'cannibals', kind: 'site', count: 2, glyph: 'larder',
      far: true, minStationDist: 620,
      dangerR: 230, stalkers: 2,                    // at night the ring hunts
      clearedBy: 'burn',
      lines: { stand: 'A fire that smells wrong and a rack nobody discusses. At night, the ring around it HUNTS.' },
    },
    reaperwalk: {
      fact: 'reapers', kind: 'event', glyph: 'procession',
      night: true, minMist: 0.5, cd: 300, dist: 460, file: 4,
      touchDmg: 26, line: 'A file of hooded shapes crossing the grey. They do not chase. They harvest what walks INTO them.',
    },
    irongiant: {
      fact: 'irongiants', kind: 'event', glyph: 'silhouette',
      duskDawn: true, minMist: 0.45, cd: 900, minDay: 2, dist: 118, dur: 45,   // it STANDS UP out of the near grey, in frame, and does not care that you are there; the mist takes it on its own clock
      mails: [
        ['A SHAPE IN THE FAR GREY', 'At the light\'s turn you saw it — a machine-shape over the mist, taller than any tower the Order keeps, gone when the grey shifted. The Farkeepers were told. They did not laugh.'],
        ['THE SHAPE AGAIN', 'Twice now. The same stillness, the same size that makes the hills look wrong. The Farkeepers sharpen accordingly.'],
        ['THE THIRD SIGHTING', 'Three times is a fact. The Republic\'s survey adds a mark it has no glyph for and the Farkeepers post a standing watch toward the far grey.'],
      ],
    },
  };

  /* ---------- THE MOUNTAIN ROAD: the expansion door, funded and CUT ---------- */
  const MOUNTAIN = {
    cost: { metal: 90, wood: 60, provisions: 30 },
    dur: 150,
    pin: { u: 0.965, v: 0.44 },       // the table's far EAST edge — the direction the Farlands lie
    farkeepPin: { u: 0.985, v: 0.40 },
    mails: {
      cut: ['THE MOUNTAIN ROAD IS CUT', 'Switchback by switchback the Farkeeper road-gangs took the pass their grandfathers walked DOWN. Farkeep answers the wire now: the kit of the mountain hires at their desk, and the Republic sits in session wherever you open the banner sheet.'],
      fund: ['The road-gangs muster', 'Metal for the pins, timber for the galleries, stores for the cold. The mountain does not hurry and does not stop.'],
    },
  };

  /* ---------- THE FARKEEPER KIT: the classes the door opens (rows read by NPC.intercept) ----------
     Fees are hiring costs at the Farkeep desk; stats override FACT.FK_CLASSES at go-live. */
  const KIT = {
    longbowmen:  { fee: { metal: 30, ceramic: 12 }, stats: { intercept: 1, interceptCd: 6, range: 320, wage: 2 } },
    rifle_rider: { fee: { metal: 60, ceramic: 20 }, stats: { intercept: 2, interceptCd: 7, range: 380, wage: 3 }, req: 'horse' },
    berserker:   { fee: { metal: 44, wood: 16 },    stats: { intercept: 3, interceptCd: 8, range: 170, knock: 340, wage: 3 } },
  };

  /* ---------- INTERIORS: rooms as registry rows — local coords, rect walls, hotspots ----------
     The Diefenbunker's entry hall is the first; Farkeep's long hall and Shutterlight's guild
     room are future rows. wallRects block, hotspots prompt, exit returns the walker. */
  const INTERIORS = {
    diefenbunker: {
      name: 'THE DIEFENBUNKER — ENTRY HALL', w: 520, h: 300,
      entry: { x: 260, y: 262 },
      furniture: [
        { x: 30, y: 40, w: 120, h: 34, kind: 'lockers' },
        { x: 370, y: 40, w: 120, h: 34, kind: 'lockers' },
        { x: 210, y: 34, w: 100, h: 40, kind: 'brasswall' },
        { x: 52, y: 150, w: 86, h: 30, kind: 'logdesk' },
        { x: 382, y: 150, w: 86, h: 30, kind: 'armory' },
      ],
      hotspots: [
        { x: 260, y: 74, r: 46, id: 'brass', label: 'THE BRASS WALL — read the plates' },
        { x: 95, y: 180, r: 40, id: 'logs', label: 'The log desk — the SBSN record' },
        { x: 425, y: 180, r: 40, id: 'armory', label: 'The armory cage' },
        { x: 260, y: 268, r: 40, id: 'exit', label: 'The cold door — walk out' },
      ],
      logs: [
        'SBSN 0001 — DAY ONE, AGAIN. Surface party reports the sky is the wrong kind of quiet. Recommend recalibration of every instrument built to measure anything.',
        'SBSN 0412 — The walking dark is not in any of the nine contingency binders. Drafting binder ten. Something about the cold. Something about the water.',
        'SBSN 0977 — The hooded marksmen supply the will our books never printed. The exchange holds: consistency for direction. The red leaf keeps its edge.',
      ],
      keeperLine: 'An archivist in pressed grey nods once. "Mind the plates. Everything down here outlived its century — act accordingly."',
    },
  };

  return { STANCES, RULES, DOCTRINE, REBELLION, PRESENCES, MOUNTAIN, KIT, INTERIORS };
})();
