# WAYLIGHT — Shipped Design Doc (v3.33 · LEDGERLIGHT · The Asset Pass)

Playable build: **https://claude.ai/code/artifact/9ed799db-2103-4667-b424-0de78dce88c5** (single-file HTML5, canvas, ~8,700 lines, no libraries; saves to localStorage per browser; v1/v2 saves migrate and are seeded with stock). Future sessions: republish to this URL via the Artifact tool's `url` parameter (read the live version first — the tool requires it). Source parts live in the session workspace at `waylight/src/*` assembled by `build.py`; that workspace is ephemeral — the artifact is the durable copy. Companion docs: `research-death-stranding-delivery-mechanics.md`, `research-loop-psychology.md`, `research-zomboid-permadeath.md`, `game-approaches.md`, `waylight-expansion-design.md`.

## Three lessons, all kept

**v2.0 → v2.1.** The character layer shipped verified only through debug shortcuts and was invisible from the player's chair. *Implemented and unreachable is the same as scaffolding.* Every feature must be encountered, unprompted, inside the first ten minutes, and verified by a keys-and-clicks-only bot.

**v2.1 → v2.2.** The first objective was impossible on foot (a wadeable creek carved as a canyon) and nothing on screen said what to do. *A test that borrows the game's internal knowledge is not a test of the game.* The first delivery is walked by a bot that reads only the screen (`tests/firstwalk.mjs`).

**v2.3 → v3.0.** The verdict on v2.3 in play: *"the game is just 'go here' … you failed to integrate the features … the theme is literally just lighting beacons."* Correct. Orders were random templates with no consequence; nothing a delivery did changed what the next delivery was worth; roads, porters, skills and weather sat beside the loop instead of inside it; and the fiction reduced to a light switch. v3.0 replaces the order generator with a **needs economy** so that every feature enters a decision, and reframes connection as a **wire** (goods move) rather than a light (a switch flips). The balance bot (`tests/session.mjs`) is the new law: *a greedy bot must not find a degenerate loop*. It found three before the design held — see Balance below.

## v3.2 — identity, hands, and a working companion

The v3.1 verdict in play: the pack UI was unclickable (its buttons sat under click-to-move), the hired companion was "a bag that follows you" and watched the player get beaten, travel had one rigid line, the UI gave no click feedback, and the world had no people in it — "am I a slave? am I a hero? a mailman?" — plus a vocabulary correction: *porter* is Death Stranding's word. Fixes, each with checks in `tests/feel.mjs`:

- **Input.** Every HUD panel is now event-solid: pack buttons (eat/use/study/equip/give/drop) click, and clicking a panel never starts a walk. Root cause: the HUD root is `pointer-events:none` and the pack panel never opted back in, so clicks fell through to the canvas.
- **The companion is a person with hands.** Their chip (portrait, class, carried kg) is clickable → opens the hand-over; clicking them in the world walks to them and opens it; `G` beside them does the same. They **intercept** scrappers charging a loaded Walker — the runner is met 220 u out and knocked sprawling (8 s cooldown, off while hungry), with an impact ring and a spoken line ("Not this one."); they call out when a wraith grabs you; they say something when hired.
- **Routes are strung, not straight.** Shift-click — in the world or on the map, which stays open for it — strings up to eight numbered marks; feet take them in order (each leg pathfinds; strung marks never snap to ruins or terminals). Plain click still walks-and-uses. Keys still cancel everything.
- **UI feedback.** Press states with brightness pulse on every button, hover glow, tab underline and shadow, panels animate in, an accepted order card flashes gold and slides off the board before the redraw.
- **Vocabulary.** *Porter* is gone from every player-facing line; the trade is **Waylighter**, informally **Walker**; pay is **trust** (◆), not likes; the dead in the grey are **the kept**; title ladder now Greenhand → Mudfoot → Waylighter → Pathbinder → Lifeline → Lamplord → Legend of the Valley.
- **Identity — The Postman, not Kojima.** The register is the 90s apocalyptic scorned hero: concrete, warm, dry, unapologetic. Three mechanisms carry it:
  1. **Keepers.** Every terminal has a named face — Mara Voss (Haven quartermaster), old Wren (Elm, farming for a diabetic granddaughter), Bo Tammen (Mill head sawyer), Dr. Callas (Greenhouse), Sela Marsh (Quarry forewoman), Corporal Finch (Relay Hill, still logging after four hundred days), Brand (Foundry, four words a sentence), Keeper Aster (the Pharos). Each greets by station state: a first-visit hello, a line per mood, a line for the day you relight them. The briefing is Mara talking, at the fire.
  2. **The Walker speaks.** A bark system (`Systems.bark`) — dry one-liners spoken into the world at nightfall in the open, wading, dropping cargo, tearing free of a wraith, entering the deep grey, overloading, landing a critical delivery, relighting a station, crossing scrapper ground. Cooldown-gated (30 s, each line retires after three uses): a voice, not a chatterbox.
  3. **The creed.** Title screen: *somebody has to walk it.* The intro ends on the trade's name and its pay: thanks, tomatoes, and a bed by whichever fire you reach by dark.

## v3.3 — the 90s pass, built from the named sources

The v3.2 identity pass was rejected: quiet prestige-drama lines wearing a 90s label. The correction demanded the actual sources, each as a mechanism (`tests/feel.mjs` covers all of it):

- **The Postman → the Order of Waylighters.** The why. There used to be an institution — coats, lanterns, an oath, a dispatch bell on every terminal — and the quiet ate it. The intro is Mara Voss taking the last coat off Haven's hook and holding it out: "It'll fit. It always fits somebody." Ranks are field promotions IN the Order (Greenhand of the Order → Mudfoot → Waylighter, Sworn → Pathbinder → Lifeline → Lamplord → Legend of the Valley).
- **Cannon Fodder → the Roll of the Order.** The title screen keeps the dead in view: Juno Longwalk, 214 deliveries, the Silt took her; Old Marrow, 402, sat down by his fire and stayed. Your own dead join the top of the Roll with their record and cause — and a save that used codes is marked WALKED WITH HELP, forever.
- **NBA Jam → the Dispatch booth.** The Order's pre-quiet automation still runs, all caps, zero doubt. Chained stops escalate across the screen: "DOUBLE DROP. THE WIRE NOTICES." → "THREE STOPS — THE WIRE SINGS!" → "FIVE STOPS — THEY WILL SING ABOUT THIS ONE." Grades slam with a stamp line ("TEXTBOOK. FRAME IT." / "IT ARRIVED. TECHNICALLY."). Rank-ups slam "ORDER OF WAYLIGHTERS — FIELD PROMOTION."
- **The era itself → cheat codes, typed blind on the title screen.** MELLYGIBS (five flares, go be the road warrior), TOMATOES, LONGLEGS, BIGLANTERN, BOOTHILL. The Dispatch answers ("DISPATCH SEES NOTHING. WINK." / "THAT CODE DIED WITH THE NINETIES."), the footer says CODES WORK HERE. TYPE ONE., and cheating goes on your permanent record on the Roll.
- **Z / Carmageddon attitude → everything talks.** Rotating box-copy taglines under the logo ("Scrappers hate this one weird trick: DELIVERY."). Scrappers yell when a chase starts ("DROP THE PACK AND WALK, HERO!"). Keepers were rewritten from mood into want — Bo Tammen shouts, Wren owes and hates owing, Finch rehearsed his greeting eleven times — and a keeper's own voice lands on the results screen when you fill a need they were short on. Death screens close with a cause epitaph ("The ground was there the whole time.").

## v3.4 → v3.5 — the game LOOKS 90s: skin, then strawman, then actual pixel art

Two-stage lesson, recorded because the first stage repeated the project's recurring failure in a new place.

**v3.4 (the skin and the pipeline).** The HUD was reskinned to the era — 2px borders, hard chunk shadows (`--chunk: 3px 3px 0`), uppercase 800-weight buttons that physically displace 3px when pressed, segmented tick meters, a hot gold/rust palette — and the world pass was rerouted through a 1/2.6-resolution buffer blitted back with smoothing off, plus a saturation filter. Verdict in play: *"slapping a pixel filter on the game is not what i said. what you just did is a strawman."* Correct. Downsampling soft gradient art produces mud, not pixel art; 90s games were not low-resolution photographs of modern games — they were **drawn** at that resolution.

**v3.5 (authored art).** The filter is gone and the art is drawn:

- **Terrain is painted in designed 4-tone ramps** — one authored palette per surface (meadow, forest, scree, rock, snow, marsh, shallow, deep, cliff, station pad) — with the tone at each texel picked by **4×4 ordered Bayer dithering**, the random RGB jitter deleted. Land dithers in deliberate 2×2 blocks; water keeps fine bands. Hillshade folds into the tone *index* (banded light, like a palette artist shaded it) instead of multiplying the colour. Contour steps at fixed height intervals. On top: a fixed 4-texel **grass-tuft glyph** stamped across scattered cells of meadow and marsh (the LTTP move), 2×2 canopy crowns clumped over the forest floor, speckle on scree and rock, banding on cliffs.
- **Characters are sprites.** One 9×14 humanoid rig with two stride frames and an idle, blitted on a snapped texel grid and flipped by facing — palette-swapped for the Walker (blue coat, tan pack), companions (green hoods, their portrait colours), and scrappers (rust). The companion animates when she walks and faces where she goes. The Walker pulls out a pixel hand-lantern in the dark. Cargo is chunky outlined crates with a lash strap, stacked on the pack; tools are slung poles.
- **Stations are buildings.** A 16×8 stone longhouse — ridge highlight, banded roof, three window bays that burn gold when the station is on the wire, dark doorway — with the beacon mast rising behind the roofline and a yard: stacked crates port side, a rain barrel starboard. A depot, not a lawn ornament.
- Honest scope: **wraiths are still gradient glow** (deliberately — they are the one thing in the valley that *isn't* solid), and the progression/item/risk-reward overhaul demanded alongside identity is still owed, not claimed.

Evidence standard for this pass: same-frame before/after screenshots against the previously published build (`tests/artshot.mjs` boots both, lights the Greenhouse, and shoots the identical composition), because the v3.1 lesson — *every mechanical claim had a bot, the pixel claim had none* — now applies to art claims too.

## v3.6 — one law: no alpha in the world. Light is palette; transparency is dither.

v3.5 drew the world in pixels but still LIT it like 2020: translucent veils, radial-gradient glows, an alpha night screen — modern compositing airbrushed over authored art. v3.6 states one art law and enforces it on every world-layer element: **nothing in the world is translucent. Light is a palette change; transparency is ordered dither.** The fusion this buys is the project's founding sentence made literal — the network's reach is not a glow over the picture, it IS the picture's palette:

- **The light field recolours the ground itself.** A per-texel overlay holds a palette-remapped copy of the terrain in five light bands — two cold blue-dark steps in the quiet, a bare neutral shelf, two warm gold steps on the wire — with Bayer dither only where bands meet. Band edges become dithered gradient rings around every station: territory with a visible edge. Mist deepens a band; there is no mist alpha.
- **The coastline.** At exactly L = 0.30 — the light level a wraith cannot cross — the band boundary is drawn as a dithered golden shore, day and night. The safety radius of the network is a gold checkered coastline you can walk along. Nobody ships their threat boundary as cartography; it is the single most identifying mark on the screen.
- **Night is a cartridge palette swap, not a veil.** A second night field bakes the same land two palette steps deeper and bluer, lit ground keeping its day face (the punch-through, now structural). Dusk steps through it in hard stages. The old full-screen rgba night veil is deleted.
- **Every glow is dithered shells.** Station halos, the beacon pillar, headlamp, camp fires, lumen pickups, ruin echoes, the peddler's lantern, grave-wraiths, mist wisps, the connection ring's flood: all rebuilt from three Bayer-coverage shells of solid additive dots (75/45/20%) — the era's faked light. Zero radial or linear gradients remain in the world pass (HUD and vignette keep their own language).
- **Wraiths are dither-bodied.** The one unsolid thing in the valley is rendered in the era's own language for unsolid things: its body IS a breathing ordered-dither cloud with two hard pixel eyes and tendrils of solid squares. Ghosts were checkerboards in 1996.
- **Water sparkles; rain is dashes.** Foam texels blink on shallow water in slow shifts; greyfall rain fell as alpha strokes and now falls as solid pixel dashes.
- Engineering: the light overlay repaints incrementally (diff of the light grid → dirty-region repaint, ~250 ms full paint once at bake, bursts batched to ~4 Hz through the connect cinematic); roads repaint their strip of the field when paved. Frame time unchanged at 16.6 ms.

## v3.7 — the ground remembers, and the world speaks in pixels

Two gaps remained after v3.6, both found by looking at the screenshots the way a player would.

**The seam of type.** The world was 1996 but its voice was 2024 — barks in italic serif, station names in display type, labels in UI sans, all floating over pixel art. Now every piece of text painted INTO the world uses one authored 3×5 bitmap face (five octal digits per glyph, drop-shadowed on the texel grid): station names and their trust diamonds, spoken barks (word-wrapped, fading in hard steps), companion and grave names, ruin and paver labels, the Peddler, structure credits, route-mark numbers. The DOM HUD keeps its clean era type; the valley itself is all texels.

**Desire paths — the ground remembers your feet.** The deepest missing Death Stranding idea: repeated walking should carve paths, and the land forgot every step. Now every six metres walked on grass leaves a print in a wear grid (companions tread lighter); enough passes and the meadow visibly wears — first trampled yellow-green, then bare packed earth — dithered into the terrain paint itself in the ground's own ramps, young paths broken, old paths solid. Worn-bare ground walks 7% faster: the network's roads are bought, but the walker's paths are EARNED, and both are read off the land, not a menu. Paths persist through save, death and inheritance (the next Waylighter walks the last one's trails); a new valley grows its grass back. The first path worn to bare earth teaches itself — a toast, and the Walker looks down: "A road nobody paid for. Mine."

Also in the pass: **footprints** stamped behind the feet (dark on grass, bright-pressed on snow, brief on scree), **foam splashes** while wading, **cloud shadows** — two slow dither-shade blobs drifting on the day wind under the no-alpha law — the **coastline breathes** (gold texels blinking along the wraith line), and scrapper **tents are an authored glyph** with fire-lit doors. Verification grew a tenth suite (`tests/paths.mjs`, 9 checks): wear accumulates and clamps, six real walking passes wear a visible trail through the systems (no debug shortcuts), the bare path lands in the terrain canvas and the light field's copy of it, the worn lane measurably outruns fresh meadow, paths round-trip save/load, and a spoken line lands as gold pixel-face texels on the composited canvas.

## v3.8 — integer-pixel discipline (the verdict: "unlegible text… over-sharpened grid overlays… glass UI")

The v3.7 screenshots from real play convicted the pass on one root cause: font texels, dither cells and pattern fills were drawn in WORLD space at fractional buffer pixels — the canvas antialiased them, the nearest-neighbour upscale magnified the antialiasing, and the result read as mush passing for pixels. Cartridges never did this: labels were screen-space tiles, glows were baked sprites. Three corrections, all structural:

- **Labels never scale with the camera and never land between pixels.** Every world label (station names, barks, grave and companion names, ruin/paver/peddler tags, route numbers) is queued during the world pass and drawn AFTER the upscale, in screen space, at integer texels snapped to the texel grid — constant size at every zoom, crisp by construction. `GREENHOUSE` is now readable at any camera height.
- **Every dithered glow is a baked sprite, drawn nearest.** Halos, the beacon pillar, fires, lanterns, wraith bodies, cloud shadows: hard Bayer dots baked once into an offscreen sprite and `drawImage`d with smoothing off — nearest sampling keeps the dots square at any scale, where pattern fills and per-frame fillRect dither produced the moiré the screenshots showed. (Rule of thumb now enforced: sparse dither may only reach the screen through nearest-sampled images, never through fractional-coordinate fills.)
- **The HUD stopped arguing with the world.** One typeface family (the serif display face is gone), opaque bevel-edged panels instead of translucent glass, solid borders instead of alpha borders, and every glow-blur text shadow replaced with a hard offset. The DOM chrome now reads like the game's menu system, not a modern overlay.

All 229 checks green on ten suites after the rewrite; 16.6 ms/frame.

## v3.9 — LEDGERLIGHT: the house style, named

What the art passes were converging on is now stated as doctrine, and it is ours:

> **LEDGERLIGHT.** Every system must write its state into the land itself, in palette steps and ordered dither. Nothing floats. The world is the interface.

The valley already kept three ledgers — light as palette bands, safety as a golden coastline, effort as desire paths. v3.9 makes the doctrine total:

- **The wire is caravans.** The economy's flow between connected stations was invisible arithmetic; now every feeding pair sends **caravans of light** down the road between them (the crow-line until one is paved) — three gold texels and a tail, spawn rate tied to the real flow multiplier. Stand anywhere in a grown network and you can watch it breathe. At night, the valley is crossed by moving lights you built.
- **The windows are the stock report.** A station's longhouse reads its own pantry: full, both window bays burn; running short, one goes dark; starved, both are out and the doorway gutters. Station health is read from across a field, not from a panel.
- **The coat is the rank.** The Order writes itself on the Walker's back: drab wool at Greenhand, the blue coat once Sworn, gold trim as a Lifeline, and the dark gold-lined coat of a Legend. Progression you can see on the sprite you steer.
- **The title screen is the ledger itself.** No static menu: the camera tours YOUR saved valley — its lights, its worn paths, its coastlines — behind an **authored WAYLIGHT wordmark** (drawn letter by letter, bone and gold, the beacon burning over the I of LIGHT). The save greets you as terrain. A new player tours the dark valley they are about to fix.

Verification grew an eleventh suite (`tests/ledger.mjs`, 8 checks): the title camera provably drifts, the wordmark's bone and gold pixels are counted, caravans spawn between connected stations and advance along their routes, stockRead maps pantry → bays (2 full / 0 starved) with the on-screen glass dimming measured as a delta, and the coat palette swaps by rank. A hard-won testing lesson is recorded here: pixel-hunting a busy composited frame kept getting defeated by the game's own honesty (a starving station dims, which moves its coastline into the sample box) — the reliable instruments are state-delta measurements and source-level asserts, with full-frame screenshots as the human check.

## v3.10 — the interface is the Order's paperwork (and the last curves die)

The gate question before expanding to new systems: *is the visual identity actually resolved, or would building on it propagate an unresolved one?* Honest answer: the world was resolved; the UI was not. v3.8's HUD pass was subtraction — glass and gradients removed — and subtraction is not identity. A clean dark game UI is nobody's. The chrome did not participate in LEDGERLIGHT.

The resolution extends the doctrine to the chrome by asking what interface this institution would actually have. The Order is postal. Its interface objects are its **paperwork**:

- **Orders are waybills.** Every card leads with a stamped tag — WAYBILL, MAILBAG, PRIORITY DISPATCH — and carries a perforated left edge. Accepting one is taking a slip off the board (the gold flash-and-slide was already there; now it reads as tearing off the sheet).
- **The terminal is the station's ledger book.** Its tabs are raised file-folder index tabs, not web nav; the active tab joins the page.
- **The results screen is the stamped delivery slip** — "WAYBILL — DELIVERED · OFFICE OF THE DISPATCH · THE ORDER OF WAYLIGHTERS", the grade slammed on it like ink.
- **Panels are printed on the world's own matter**: every panel and card is textured with a 4-pixel tile of the game's Bayer dither — paper grain in the same language as the terrain — via an inline SVG tile, nearest-rendered.
- **No curve survives in the world.** The remaining smooth geometry died: every sprite shadow is now two stacked slabs (`pixShadow`), the station platform is a stepped stone slab instead of an ellipse pair, the float sled is slab-drawn. `cx.ellipse` count in the world pass: zero.

Four new checks in `tests/ledger.mjs` pin the paperwork (dither-paper computed style, waybill stamps on live cards, raised ledger tabs, the delivery-slip title): 241 checks green across eleven suites.

## v3.11 — PLATE & PAPER: the pixel pass (a directed asset review, translated, not transplanted)

The direction arrived as a library of pixel-art techniques — push-buttons, hearts, a CRT display font, an SCSS pixel-border kit, texture generators, a retro documentation layout, suited pixel figures — with orders to review each one meticulously, integrate selectively and app-wide, and jam nothing. The review's full rulings live in `PIXELPASS-PLAN.md`; the thesis it produced completes the doctrine:

**Paper is read; plate is pressed.** Paperwork (cards, slips, waybills) stays typographic, perforated, dither-grained, casting the diagonal desk shadow. Everything interactive became a **plate**: its border is four side-slabs of box-shadow — which leaves the corner texels empty, the notch that reads "pixel" — its face sits raised on an extruded base, and pressing it drives the face *straight down* onto that base. One geometry, unchanged inks, applied to every button, mini-button, tab, prompt chip, key chip, build-bar cell. Values live in **grooves** (the same side-slabs plus a sunken bevel): every meter, needs bar, load bar, the rebuilt pixel slider, the new stamped checkbox. Every sheet announces itself from a riveted **nameplate**. The last chrome curve (`.k`'s border-radius) died; meter gradients flattened to two-step banded fills.

What each reviewed asset became, and where (adopt / adapt / reject, per the plan):

- **The push-button (third variant, the one that presses)** → the plate standard above, and the **[E] keycap in the world**: a pixel keycap beside the walker whenever E would do something, a bone arrow stepping down at it — and when the real E goes down, the drawn key goes down with it, glyph gone gold. Screen-space, integer texels, hidden in modals, QTE, struggle, cinematics. The bottom-left prompt list stays.
- **Animated pixel hearts** → health, exactly as directed: five hearts of twenty, half-heart steps, brick rust from the family palette. The last live heart beats, faster as it empties; damage knocks the row and flashes bone; bleeding is a slow texel of blood dripping from the last heart. Stamina, food and warmth stay meters — wounds are counted, flows are watched.
- **The CRT overlay font** → a full authored 5×7 display alphabet (grown from the wordmark letterforms — no third-party font crossed the border) behind `Render.crtTitle`: near-fullscreen white type burning through a dark band, scanlines, mains flicker, a roll-in tear. **Four doors only**: a station joining the wire, field promotions, first greyfall, first sight of the Kept. Chain callouts keep the mid-tier slam; headings never touch this face.
- **The retro documentation layout** → the map became the **Survey Sheet**: nameplate title bar, a docked left rail (legend, a live "THE WALK" readout, field options), a footer strip of keycap hints. And the QOL it houses: **the world no longer freezes under the open map** — `[ ] Pause Movement on Map` (browser-persistent, default off) restores the old behaviour for planners; a QTE or wraith grab tears the sheet away so you see what has you. Results slip gained the doc footer ("FILE UNDER · DELIVERED").
- **The pixel folder (folder only, as directed)** → the terminal's file-cabinet completed: closed folder on every shelf tab, open folder on the active one, a two-step pop on switch.
- **The block-texture generator** → **crate chips**: 12-texel planked crates stencil-banded per goods, cached as data-URIs, shown wherever cargo is physically handled (pack, companion carry, hand-over columns). Waybills stay typographic — paper is read.
- **The stone-wall generator (one variant, world-accurate)** → ruins: seeded courses of cut stone, light edge per block, dark mortar, a crown the years have bitten off, fallen blocks in the grass — replacing four loose grey rects. The same pass squared the surviving world curves it exposed: cairns restacked from slabs, cart and caravan wheels cut square, the zip wire and chute cord sagging in straight runs.
- **The D20 (die only, background stripped)** → the one place rolling happens: a 12-texel die tumbling three faces on "Roll a stranger" and "reroll". No dice mechanic was invented to justify a prop.
- **The suited pixel figures (black suits → leather brown)** → adapted, not transplanted: **Mara Voss's personnel photo** on the briefing — a 24×26 authored bust, leather-brown greatcoat, bone shirt, one gold pin the Order supposedly ran out of, in a bone photo frame captioned M. VOSS · HAVEN.
- **The night-sky scene** → rejected, with reasons on file: the title screen already runs the living valley — a real night in our own quantized light beats a recolored static one, and scenery does not belong on paperwork.

A latent race surfaced by the new timing (a deferred terminal refresh landing after the sheet closed) got its guard. Verification grew a twelfth suite (`tests/pixelpass.mjs`, 21 checks): Mara's palette counted on her canvas, the die confined to its two buttons, plate/groove/nameplate computed styles, square-cut chips, movement measured under the open sheet (walked with WASD, frozen by the toggle, the preference round-tripping the browser store), the grab tearing the sheet away, the keycap shown/pressed/released against real key events, hearts counted at 100/50/10 through the damage flash, the CRT voice burning white through its band and then going silent, first-greyfall firing once and never twice, folder states differing by tab, and the Survey Sheet's anatomy. 262 checks green across twelve suites.

## v3.12 — THE BUILDS: the player's trophies get station-grade art, and the doctrine closes

The honest note at the end of v3.11 named the debt: the player's own structures — the physical record of their progression — were still wireframes and quadratic domes next to authored stations. A progression game whose trophies are its worst art has its priorities inverted. v3.12 closes that, and with it the last open edges of the doctrine:

- **Every build is an authored sprite.** Generator (stone base, dynamo drum with a lumen window, a texel lamp breathing under dithered glow), shelter (timber A-frame, ridge highlight, dark doorway), watchtower (lattice legs, X-braces, railed platform, blinking lumen lamp), zip pylon (post, cross-arm, wheel) — row-string sprites in the timber palette, baked once per (type, echo, damage), drawn nearest on the texel grid. Echo builds remap to the lumen palette; **damage bites texels out of the sprite** and pulls planks from the bridge deck. Bridges became real decking — dark under-bed, walked-dull planks laid one by one, bone rope rails, end posts — and the zip rider is a hanging figure, not a marble.
- **Auras stopped being stroked circles.** A build's reach is a stitched hem of dots at its edge — baked once per radius — that only fades in while the walker is inside it: the ground tells you when you are in a build's care, and says nothing when the information is not yours to need.
- **The doctrine's circle is a ring of dots; its reticle is four brackets.** One `dotRing` draws every pulse that used to be a stroked arc — the connect cinematic's marching coastline, flare and build rings, scrapper-shock bursts, the supply-drop pulse. One `drawBrackets` replaces every targeting circle — the click-to-walk marker, the brace indicator, the Guide's beacon (its gradient shaft now a dithered column baked per ink). Beacon flames are stacked breathing texels; the scrapper's hunting headlamp is a checkered fan of dots; wraith-grave eyes are square. `cx.arc`, `quadraticCurveTo`, and `createLinearGradient` counts in the renderer: **zero** (one radial gradient survives — the screen vignette, which is the camera, not the world).
- **The Order's last paperwork is filed.** Death is a **CERTIFICATE OF PASSAGE** — dispatch stamp, greyscale file photo in a bone frame, TAKEN BY field, the record in ledger lines, filed under THE ROLL OF THE ORDER. Skills are a stamped **SERVICE RECORD** with the porter's photo; the help sheet is **FM-1 · PROPERTY OF THE ORDER**; chargen is the **ENLISTMENT** form, its portrait stapled square. The chrome's survivors joined the law: the steady-QTE timer drains around a square, moodles are square chips, the grade's stamp ghost is a stamp edge, and the last border-radius died.

Verification grew a thirteenth suite (`tests/builds.mjs`, 12 checks): the no-curve law asserted at the **source level** (arc/quadratic/linear-gradient counts equal zero, exactly one radial for the vignette), all four sprites bake at their authored dimensions, a seven-structure camp with a strung wire renders live without error, the certificate/service-record/manual/enlistment stamps all present, and the square steady-timer still reads progress. 274 checks green across thirteen suites.

## v3.13 — LIGHT BEHAVES (a retraction, then the fix)

The verdict: every light in the game was a checkered yellow circle, and at night the player just follows one around. **Correct, and the doc's own earlier claims about "dithered glow shells" were dressing on that failure.** Measured on the shipped build: the old lantern raised the ground brightness around the walker by a factor of **0.96 — that is, not at all.** The additive dot-discs painted gold OVER the world and lit NOTHING. The one part that was real light — the baked field that repaints terrain by palette band — only ever covered stations.

The fix is architectural, not cosmetic. Everything dark is now a **layer**: the night palette, and the quiet's grey dim (the day field was split — its warm bands are paint, drawn straight to the ground and never touched; its dim bands joined the darkness layer). Every local light — the walker's lantern, a generator, a watchtower, a camp fire, the peddler's cart, a lumen bloom, a companion in the dark — **erases banded holes in that layer** on the terrain's own texel grid: a solid heart, two hems of ordered dither, nothing else. What shows through a hole is the ground's real colours. And the law that governs the whole world was finally applied to light itself: **no partial alpha anywhere — a texel of night is either gone or intact, and falloff is carried entirely by dither coverage.** The old glow discs are dead; emitters keep a bloom a few texels wide at the flame itself, nothing on the ground.

Measured after (world-anchored, class-matched meadow, source-instrumented via the darkness layer's own alpha): ground inside the lantern pool is **×7.3 the brightness** of the same meadow 260 u away, reads as green-led terrain with **zero** painted-gold pixels, and the falloff steps 0.05 → 0.60 → 1.00 through the hems. A generator carves the same pool at its camp; by day the lantern clears the grey dim off the ground the walker holds; on station-lit ground there is nothing to punch. `tests/lamps.mjs`, 9 checks.

## v3.14 — THE HAND, DRAWN: the moiré dies, the people are hand-drawn, and DELIVER is a moment

Four more convictions from play, each traced to its mechanism and fixed there:

- **The phasing lines across the world** were the renderer's own arithmetic: the world buffer upscaled ×2.6 — a fraction — so every buffer pixel landed as alternately 2 and 3 screen pixels, and those uneven columns beat against the scrolling texels; a second beat came from terrain texels landing on fractional buffer pixels. Now the upscale is an **exact ×3**, zoom is quantized so a terrain texel is always a whole number of buffer pixels, and the world scrolls in whole pixels. No beat frequencies remain, in any direction, at any speed.
- **The characters were the last un-drawn art** — the old rig drew 1.7-unit texels that fell BETWEEN buffer pixels and antialiased into the "blurry mess"; palette-swapped patches on top of that made it worse. The porter is **redrawn by hand**: a 12×18 hooded figure with an eye in the hood, a real stride, the pack on the back — baked per palette (coat tiers, companions, scrappers) and landing on whole buffer pixels at every zoom, scaling with the world in whole-pixel steps, its tower, lantern and slung tools anchored to its own texels. Every humanoid in the valley now belongs to the same hand as Mara's photo. The TENT and HUT glyphs went through the same door.
- **DELIVER is the reward, and it was being auto-swallowed by a doorway.** Walking into a terminal no longer silently hands everything in. In range of a destination the prompt list leads with a gold **DELIVER** plate; pressing it roots the walker and the crates leave the pack **one by one** — an arc, a thud, one fewer on the back, a small pile by the door — then "RECEIVED — N CRATES", then the slips, then the board. What's still on the pack is announced in one line, and the tower on the walker's back empties crate by crate as the hand-over plays. The station stock-report windows (full pantry = both bays burning, short = one dark, starved = door guttering) were found regressed to static during the refactors and restored in the crisp glyph idiom.
- **Items got faces and one law.** An authored 12-texel icon leads every item title everywhere items are read — crate, ration tin, vial, book, boots, coat, pack-frame, charm, ladder, kit, cog, ingots, relic. **Mission items — order-bound crates, beacon cores, signed lost cargo — are gold, icon and title, always, immune to every setting.** A settings toggle colour-codes the rest for identification (consumables green, gear and utility blue, junk grey); off, they are neutral bone. The vitals reordered to hearts → stamina → load → food; the tab folder appears only on the open drawer and pops once.

Verification: the lamps suite above plus updated checks across the battery (the DELIVER ceremony walked by the screen-reading bot and the keys-only bot, ceremony fast-forward for the state-level suites via `WL.skipHandover` — the same door `skipCine` uses, icon law asserted with computed styles, single-folder law, stock windows full-vs-starved delta): **283 checks green across fourteen suites.**

## v3.15 — LIGHT HAS A BODY: the sources are fixed, not deleted, and the props join the hand

An honest correction of the correction. v3.13 fixed the ground — darkness is punched away, that stays —
but the sources themselves went two wrong ways: several glows were shrunk toward nothing (removal wearing
a fix's clothes), and every lit building still wore a 28-unit-wide full-body Bayer pillar, at noon and at
midnight alike. The research pass went to the people who solved this: Slynyrd's ramp law (hue warms as it
brightens, saturation peaks mid-ramp), saint11's halo and fire tutorials (a light source is an emissive
core plus a few HARD concentric bands; fire is 2–3 authored frames), the pillow-shading warning (light
with no direction reads fake), and Octopath Traveler II, whose HD-2D team calls dynamic day/night lighting
the heart of the look — warm sources against cool ambient dark, tight bloom cores, shafts that belong to
the atmosphere that justifies them.

The corona law replaces the checker: every lamp, flame, bloom and cairn-light now draws a **banded corona**
— a near-white emissive core, two solid hue-warmed bands at stepped alpha, and dither only as a one-texel
stitch at each seam. Full-coverage checker is reserved for the one thing it is for — the unsolid: wraith
bodies and the haze around the Kept keep it under its own name (`ghostBody`). The station pillar is dead;
in its place a **beacon shaft that belongs to the night**: gated to zero by day, at night a narrow column
brightest at the flame, three vertical alpha bands with dithered hems and a one-texel sway, dithering out
at its top. Lit longhouse bays cast **window-spill pools** on the yard after dark — banded trapezoids with
Bayer hems, the pillow-shading cure: light with a direction. Fires are **authored three-frame flames on
logs** — camps and every beacon cage. At night the walker takes a **one-texel rim light** down the lantern
side of the coat, baked from the rig's own edge — the source writing itself on the sprite.

And the prop patchwork joined the hand: authored sprites for the station mast (a timber lattice with a
stone footing and an iron fire-cage — the stroked A-frame retired), metal and ceramic salvage piles, lumen
blooms as two-frame crystal clusters, ground crates (planked, banded by the icon law: gold for signed and
lost cargo, lumen for cores), cairns, the supply drop with its fallen chute, the Peddler's cart with its
hanging lantern, the road paver with its warning stripe, the zip rider, and the Kept — who are now the rig
itself in a ghost palette, standing where they fell, because they were walkers. The scrapper headlamp cone
went from checker-skip to banded falloff with a dithered rim. Zero `.arc(` calls survive in the renderer.

Verification: `tests/glowpass.mjs` (10 checks — the law asserted at source level, the day-column measured
empty and the night shaft measured present AND narrow, prop sprites sampled at their own paint, the fire
caught changing shape between looks) plus the full battery re-run: **293 checks green across fifteen suites** (at v3.15; the battery has since grown).

## v3.16 — THE POST: letters stop being filler and become the Order itself

The verdict: letters repeated city-to-city forever and read as broke-insurance — a repeatable floor
wearing filler's clothes. The floor stays (there must always be repeat work); the filler dies, by
building the floor into four interlocking systems. Genre grounding: RimWorld's skills grow per unit
time worked, multiplied by passion — our callings — with rising level costs and redundancy as strategy;
Vagrus gates one-time prizes and persistent boons behind reputation tiers, with the biggest earned, not
accrued. Adopted whole.

**1 · The service rule.** Letters and dispatches take **no fee — ever**. Zero trust moves; the grade
still stamps (professional pride costs nothing). Every other crate is luxury, and luxury pays. The
service pays in the two things trust cannot buy: **porter skill by tier** (+14/+20/+26 Footwork, long
walks add Endurance, the grey walk adds Lumenistry) and **appreciation**. The results screen has a
service slip of its own: "Fee taken — NONE — Waylighters carry the mail", the read-aloud letter, and
the town's thanks counted in laurels, not diamonds.

**2 · The mailbag and its tiers.** Each station's outbound bag fills as the town writes (~0.11/s; a
Letter runner on the post more than doubles it). One bagful posts a run, two post a second, a brimming
bag posts the third — accepting drains 35. The WALK sets the tier, measured on the route the feet would
take: **LOCAL POST** (near, safe), **LONG POST** (far, or scrapper ground), **GREY POST** (deep grey en
route, or a dimmed/quiet destination). Tier sets the XP and the appreciation. Below one bagful nothing
posts: the mail is never fake.

**3 · Appreciation** — each town's own ladder, parallel to trust and stars, shown beside them
(KNOWN 40 · TRUSTED 100 · HONOURED 180 · BELOVED 280). The boons are things money is not: a warm meal
pressed into your hands when you arrive hungry; the town's children running your mailbags to the gate
(letters from there weigh nothing) and locals pointing out salvage; the **rider's dispatch** — a quest,
not an accrual — which swears the militia to you; and at BELOVED the town lamp and volunteer wages.

**4 · The militia.** Carry the riders' own dispatch and from then on an attack — a scrapper landing a
hit, a wraith's grab — brings **two riders at the gallop** from the nearest sworn town: authored
horse-and-rider sprites, dust, a spoken line, scrappers flung and cowed, wraiths burned by lantern-light,
your struggle broken. Then they leave. Five minutes between calls; when the Grey is thick a rider falls,
and rides home across a saddle. It clears the CHASE, never the camp — the militia is a boon, not a
trivializer.

**5 · The city post — hire, train, manage.** Six mailroom jobs, all letters, each training a different
verb: Letter runner (Footwork, fills the bag), Parcel rounds (Hauling), Tower courier (Climbing), Night
post (Lumenistry, extra appreciation), Hearth post (Hearthcraft), Sort & mend (Mending). A shift is 90
seconds: one provision out in wages (BELOVED towns volunteer), calling-multiplied XP in, appreciation up.
No provisions — the round stalls, honestly, until paid. Two desks per station, a third at TRUSTED. And
the point of it all: **staff are the same waylighters you field.** Train Hauling in the mailroom and the
same hire carries +6 kg beside you on the road tomorrow — the city is the training ground, the road is
the exam, and the road stays faster for the skills it teaches. Managed from the new **Post tab** (bag,
ladder, militia status, staff with per-skill progress) and the Waylighters roster.

Also in this pass: the wraith-line coastline is gradient-normalized — a fixed-width stitched LINE on the
ground (~3 texels) however shallow the light falloff runs, where a slow gradient used to fatten it into a
forty-unit checker band.

Verification: `tests/post.mjs` (18 checks — bag fill alone vs crewed, pacing thresholds, tier mapping,
zero-fee delivery with tiered appreciation and XP, weightless TRUSTED mailbags, wages/stall/level-up
carrying into field capacity, desk caps, the HONOURED-gated dispatch, the sworn rescue with cooldown,
save round-trip) plus the re-anchored shoreline check and the full battery: **311 checks green across
sixteen suites.**

## v3.17 — THE ROAD HAS MORE THAN ONE SPEED: attainable, alive, and taught in a line

The verdict: go-here-go-here is not a loop; prices read as fantasies; companions read as bags; the
player looked like the only person alive; mechanics arrived over hours instead of in a line. Fixed at
each mechanism:

**Reset vs. New Waylighter, finally honest.** The title menu gains **Reset the Valley** behind a
confirm that spells out what burns (stations, roads, appreciation, the Roll — everything) and that it
is NOT the New Waylighter button. And New Waylighter itself now means what it says: with a save
present it retires the current walker to the Roll — "hung up the coat" — racks their cargo in Haven's
lockers, and opens char-gen over the SAME valley; network, roads and reputation kept. Only the
confirmed reset unmakes the world.

**The price of things, re-laddered.** Hire fees halved (16+3/skill metal). Kit 16 metal, ladder 8,
flare 6 lumen. Generator 28, bridge 48, shelter 26, watchtower 18, zipline 30+8. Every road segment
cut ~a third (Elm Road 48+28). Gear cut 35-40% top to bottom — Exo Frame I is 70 metal now, and the
20-game-minute greedy bot banks **90 metal / 143 ceramic / 58 provisions** in one sitting, connects six
stations, and dies zero times: the ladder's every rung is inside a session's reach. Donations and
salvage yields rose to match (quarry 6+5★ metal, piles 12-20).

**The post horse — movement diversity, introduced early and honestly.** Accepting *Light for the Mill*
(minute ~2 of the taught line) puts you in the saddle of Mara's loaner: ×1.75 speed, the horse spends
its own legs (zero stamina drain), no wobble — and real limits: it balks at water and crossings (you
lead it off and walk), scrappers spook it into bolting, it comes back when the trouble is done. The
Mill delivered, the loaner trots home and a day's ride rents for 4 provisions at any lit terminal (R).
Walk → horse → roads → zipline is now a visible speed ladder from the first session.

**The valley is not just you.** Ambient waylighters — generated, named, packs stacked on their backs —
are always on runs of their own, along paved roads when they exist, greeting you as they pass. Lit
station yards keep two townsfolk pottering among the crates. Companions grew hands and a voice:
they pick up your dropped crates and stow them ("Got it."), speak to the ground you're crossing, and
**train while walking with you** — the road is a slower mailroom, feeding the same Balance and Hauling
the post trains, so the training loop and the field are one loop.

**Wants visible from the bottom rung.** The Fabricate board now lists tomorrow's gear LOCKED with its
condition on the plate (EXO FRAME I · ★ Foundry) instead of hiding it; the Post tab already shows the
appreciation ladder the same way. Leaving a yard with a fresh load gets its send-off — a spoken line
and THE RUN plate (crates · kg · destinations) — so a run begins with a moment, not a transition.

Verification: `tests/progression.mjs` (18 checks — the confirm's exact copy, price rails, the loaner
grant and its retirement, ride ratio ×1.78 measured, water dismount, spook, the rental charge, ambient
walkers advancing, companion pickup and field-training, locked rows refusing to print, the send-off
firing once, New-Waylighter-keeps-the-valley walked through a real reload, reset actually burning) plus
the full battery and the 20-minute balance session: **329 checks green across seventeen suites.**

## v3.18 — THE SHAPES OF WORK (the same walk, different questions)

The mid-game's remaining debt was order variety: past the taught line, every contract was
point-to-point — go here, go here, go here. v3.18 adds three order **shapes**, unlocked the moment
the Greenhouse joins the wire (four towns changes the questions; announced with NEW SHAPES OF WORK,
explained in a mail, backfilled quietly into old saves). Each shape asks a different skill of the
same walk, and each is a distinct card with its own tag on the board.

**CIRCUIT — one contract, many doors.** A ★★ station with three known neighbours posts a 2-3 leg
chain through the towns that want what it makes, nearest-neighbour ordered. **Every leg's crates
load at accept** — 60 kg all at once is a normal signing, so the pack is the puzzle before the boots
move (the pack-as-puzzle debt, landed). Doors open in order: the tray reads *door 1 of 3*, a middle
door takes its crates with the full hand-over ceremony, fills the town's stock, toasts LEG n/N —
ONWARD and hands you no slip — the ledger waits. The last door grades the whole contract: par over
the summed chain, condition averaged across every door, total kg carried, **×1.35** — and the slip's
route line names every door. Abandoning a circuit turns each remaining leg's crates into lost cargo
bound for its *own* door.

**CONVOY — the cargo is a person.** A junior walker of the Order (generated, named, skills capped
at 2 — that is the point) needs the road walked to a connected town the pathfinder can actually
find. Their pace caps yours: drift past 220 units and they stop and call out — the horse learns
patience. Scrappers inside camp ground go for **their** crates first (the softer mark): a catch
knocks a gold crate loose that you recover off the ground and hand back at their side. A wraith
within 260 of them in mist **freezes them mid-stride** (checker haze, FROZEN label, the tray says
go to them) until your lantern stands within 60. Arrival counts only when you BOTH stand at the
gate: luxury pay (letters stay the only service), +10 appreciation to the town that asked, CONVOY
THROUGH from the Dispatch — and the walker joins the destination's fire pool, hireable, already
road-trained (+26 Footwork): the convoy is a talent pipeline, not an escort minigame.

**SALVAGE — grey work is paid work.** A town short of something (worst stock under 70) posts its
top shortage by name; a wreck — tipped cart, fallen planks, two gold crates in the checker — stands
900-1400 units out where mistBase exceeds 0.5, drawn while the run holds it, labeled THE WRECK.
Walk out empty (the Guide aims at the site), E loads 2-3 *Salvaged* crates — 11-17 kg each,
55-80% condition, honest about their history — then walk it home. The slip pays **×1.6** on top of
the shortage multiplier, and condition grades **against what the wreck gave**, not the factory:
bring them back no worse and the stars are full.

All three survive save → reload mid-shape (a circuit at door 2, a convoy at 2/3 crates), the session
bot weighs circuits like a porter and leaves escorts to walkers, and the Guide arbitrates: a frozen
or left-behind convoy outranks the arrow's usual habits.

Verification: `tests/shapes.mjs` (19 checks — the lock before the Greenhouse, the unlock mail, circuit
posting/all-crates-at-accept/in-order doors/middle-door-no-slip/final ×1.35/abandon-per-door, convoy
posting/follow/lag-stop/knock-drop/hand-back/freeze-unfreeze/arrive-together, salvage naming/site-in-
the-grey/battered-gold-loot/×1.6-against-the-wreck, save/reload mid-shape, zero page errors) plus the
full battery: **536 checks green across twenty-eight suites.**

## The body remembers (v3.19 — the pack authored, the weather interactive, the pushback earned)

The post-testing verdict was about the BODY: what it carries, what lands on it, what it has learned.

**The pack is authored.** Every kind of thing on a back has its own glyph, stamped in texels on the
tower: the medicine crossed white, tins ribbed steel, bales soft-cornered, seed sacks tied, drums
stamped (coolant blue, filter teal), lumen cells with a lit cyan window, the mail in its satchel, the
core aglow, ingots and slabs as themselves — and every small thing rolls into one duffel at the base.
THE LAW extends to the new pack: order-bound cargo wears the gold band, on every glyph (a band row is
injected where the shape had none). The frame the walker EQUIPPED is drawn holding the load — the wide
pack's timber rails, the courier rig's strap and gold band, the exo's steel struts with lit nodes —
and the coat and boots they bought recolour the rig's own texels over rank's coat (the attachment-swap
law from the pixel-systems research: same rig, new cluster palette).

**Alive is interaction** — the MIVIM law, two canon proofs, zero effect-spam. Leaf gusts (capped at
14, meadow and forest, never in snowfall) put leaves in MOTION: one whose path crosses the walker
deflects off the coat, or sticks a beat and drops, or passes clean behind — and one that misses NEVER
bends its line. In the deep north greyfall falls as FLAKES, not more raindrops, and it lands: snow
piles on the hood, then the shoulders, then the full cap — by how hard it falls and how still the
body is (a working body sheds most of it; warmth and shelter melt it) — drawn in rig-texel space,
riding the pack's top crate too, saved with the porter.

**Nothing plops down blind.** Choosing a build hangs its BLUEPRINT: a half-there ghost at the cursor
(or ahead of the walker), honest about validity and why — BAD FOOTING, NEEDS WAYLIGHT, MATERIALS
SHORT, ANOTHER STANDS RIGHT THERE. Ladders and bridges seek their crossing around the aim and hang
at the exact pose they will take. Click or E lays it precisely there; Esc, B or right-click folds it
away un-spent; a click far past an invalid ghost is a walk order — placement never traps the mouse.
And built things stay the PLAYER'S: V re-hangs an owned structure as a free blueprint and re-seats it
exactly (sources refreshed, ziplines relinked); X takes it down — a ladder folds back onto the pack,
a structure hands back 60% of its metal.

**The wobble is earned pushback, not a minigame** — this is an AUTOMATION game: the porter builds a
kit and a body to automate the chain they planned. Calm ground at a sane load (≤62%) never wobbles at
all. Rough ground has a Balance level that walks it clean — scree 4, rock 2, snowfield 4, marsh 3,
shallows 5 — and a body at that level auto-steadies: a breath of stamina, no ring, walk on. The ring
is reserved for beyond-the-kit: overloaded, or untrained on rough country. A failed ring still costs
(the stumble, the dropped crate) but NEVER cancels the strung route — the chain finishes itself.

**The valley keeps walking when you switch away** — by choice. A pause-sheet toggle ("keep walking
when you switch away") lets long trips run while the window is hidden: a 250ms background clock steps
the sim, saves as it goes, and hands back to the render loop cleanly on return. Hidden windows always
auto-steady — a ring nobody sees must never hang the walk. Blur with the toggle off still pauses, the
old promise kept.

**Alive is never a burden.** A convoy junior stuck past a river — or stopped too long calling "can't
keep your pace" — finds the crossing you found and appears at your back within a few breaths. A
companion left three hundred units behind catches up on their own. The wraith-freeze stays (that is
drama, and your lantern is the answer); the pathfinding chore does not.

Verification: `tests/body.mjs` (30 checks — six glyphs distinct + the gold band law, cell window and
med cross measured in canvas pixels, worn boots/coat on the rig's texels, exo struts drawn, the leaf
three-way split + the never-bends law + the sparse cap, snow accumulate/shed/melt + flakes-not-rain at
the settled camera + the cap drawn on the hood, blueprint valid/refuse-with-why/exact-lay/keyboard-
aim/cancel-unspent, move-for-free + dismantle refund + ladder fold-back, escort suck-to-back +
companion catch-up, zero rings on mastered meadow + Balance-6 scree + overload keeps teeth + stumble-
survives-chain, the toggle off-by-default + hidden-window walking + no hidden rings, save strips the
ghost and keeps the snow) plus the full battery below.

## The working world (v3.20 — traffic writes the land, crews work it, every coin is seen)

**Living paths.** Every completed delivery and every route-charter run is FEET: the walked line
between the two towns wears in — trampled grass, then bare earth — whatever route the player took.
The player's own steps stay the accelerant, the stages are permanent (grass needs human intervention
to return), the tread spreads, and bare trail walks faster. Pathfinding costs prefer worn and paved
ground, so the player's click-routes and every walker of the Order fall onto the paths the world
made: the land itself becomes the map of how the valley moves.

**The tier ladder.** A bare trail can be IMPROVED, underfoot, with P: scrap plates (3 metal), then
cobbles (3 ceramic), then a wood way (3 timber) — each tier its own authored paint (riveted steel,
bright-set stones, warm plank rows), its own speed, wobble-free like a road, flat even over marsh
(the boardwalk law), and permanent: laid ground is finished ground and never repaints as dirt.

**Field crews.** From a terminal's Waylighters tab, the same pooled people go OUT (three per town, a
provision a round, stalled honest when unpaid): the PATH PRESSER walks the line until the ground
agrees; the MASON lays cobble along it, a slab a stretch; the FORRESTER walks to standing wood and
fells it — the map itself changes, stump by stump, timber to the bank, "the near woods are CLEARED"
when done; the HAULER walks real freight onto the far end's worst shelf, and a back grown to
Hauling 5 becomes the DONKEY CARAVAN — thirty crates behind a patient grey donkey, drawn where it
walks. All of them are visible in the world with their job on a label, and all of it survives the
save.

**The LOOTER habit (earned).** A companion trained to Hauling 2 sweeps ground cargo that enters the
player's sight — reach grows with every level — stows it, and falls back in line. QOL that is
BOUGHT with training, not given.

**The earn feed.** Every currency lands as a SEEN, animated chip beside the trust readout: the
Order's gold diamond for trust, a hearth-heart carrying the town's name for appreciation, the banded
crate for materials — bursts merge into one chip that counts up, bumps, and fades. The Renegade
bandana already has its seat for the karma ledger. Nobody wonders whether they just earned something
again.

Verification: `tests/working.mjs` (17 checks — traffic wears the delivery line and the charter line,
green grass refuses plates / bare trail takes them / tiers only climb / the way walks faster, presser
walks-and-wears, mason cobbles and drains ceramic, forrester turns forest to meadow and banks timber,
hauler stocks the far shelf and earns the caravan at Hauling 5, the three-hand cap and recall, the
earned looter sweep, chips merge-count-animate per currency, pave and fell ride the save and reload)
plus the full battery below.

## The builds earn their ground (v3.21 — upgrade ladders, towers that act, the room, the box)

"I only use ladders" was the verdict, and a chase once ran straight through a stronghold that did
nothing. Now the network acts.

**Every standing build has a ladder to climb** (U, beside it): the generator's Twin burner grows the
aura a third and pours stamina back, and its Hearth housing HEALS whoever rests by the fire; the
watchtower raises The horn, then the Armed post; the shelter opens The room, then makes The bed; the
zipline greases its line (×1.35 flight), then cradles it (+300 reach — far pylons come into range).
First upgrades are cheap and useful; the last asks for real work — the bed wants timber, and timber
wants a forrester. Gold pips on the base wear the rank.

**The towers fight back.** A scrapper chasing you under a horn tower's watch is CALLED OUT — "THE
TOWER SEES YOU" — and slowed to two-thirds pace; an armed post knocks a runner sprawling as it
passes beneath. Cover you built is cover that acts.

**The room.** A tier-2 shelter is enterable: step in and the walker rests unseen behind a lit
doorway — nothing with claws or made of grey can follow, stamina pours back, and the tier-3 bed
closes wounds and mends battered cargo while you breathe. Any step is a step out.

**The PO Box** (6 metal): stash the loose load on the road — mission crates stay on your back, THE
LAW — take it back later, or leave it for the walkers: donated hand tools ARM a waylighter, the
rest earns regard.

**Donation you can SEE.** Every crate of hand tools given — at the donate desk or through the box —
arms one walker at that town, counted aloud. At ten, the town says so out loud: the announce, a
letter, the town's regard — and an ARMED WATCH walks the yard's edge with lamps while the camps
nearby shrink their claim and slow their feet. The road is measurably safer, and everyone knows
whose tools did it.

Verification: `tests/ground.mjs` (15 checks — two earned tiers then finished, the grown aura, the
healing hearth, paid-for upgrades refused broke, the horn call and the post knock, ten-armed camp
shrinkage measured by chase-closure before/after, the letter and the regard, no-door-then-door, the
grab-proof rest, the healing bed and step-out, the box's stash/law/take/donate cycle, the cradled
line linking 1850 units, tiers/box/armed riding the save and reload) plus the full battery below.

## Karma & the Republic (v3.22 — two coins, the quiet work, and the mountain come down)

**The karma ledger** holds two currencies, and neither is the mirror of the other — the Han Solo
law, built the way CK3 builds loved-and-feared. APPRECIATION is what the towns hold of you.
RENEGADE is what the road knows you are willing to do: a global name that only grows — Clean Hands,
Grey Hand, Road's Own, Free Walker — landing as its own bandana-marked chip, read in the character
sheet under a heading that says it plainly: NOT GOOD AND BAD. TWO COINS, BOTH YOURS.

**The quiet work.** Elm's far lean-to offers two crates of highleaf smokes in OUTLAW GREEN — the
contra band, never the Order's gold — for a rotating buyer, and the risk is a number you can read:
an armed watch has eyes (+20%), daylight tells (+15%), night is kind (−10%), and a known grey hand
slips easier. Passed CLEAN it pays three ways at once — trust, renegade, and the buyer's
appreciation RISES, because the town wanted them — and the yard shows it: loungers on the steps,
embers, a lazy ribbon of smoke for ten minutes. CAUGHT, the crates are ash and HEAT lands at that
town alone (Bannerlord's per-territory lesson): a colder keeper, a mark in the ledger — which cools
with time, or is settled at the terminal for coin. After the first clean pass the fixer posts THE
SKIM — a counting-room cutpurse job at a named town, same equation, heavier fall.

**The road's respect is SEEN.** At Road's Own with no mission gold on the back, raider camps keep a
fifteen-percent shorter claim and their shouts change — "Road's own. Eyes forward, boys." Put the
Order's gold on your back and business is business again.

**The Republic of Connection.** At fifteen percent coverage — or the moment the road first learns
your name — the mountain takes notice: the banner, and the founding letter. Two peoples, one wire:
the WAYLIGHTERS — connection, warmth, love, loyalty, trust — and the FARKEEPERS, the larger,
fiercely loyal mountain folk who came down when the Waylighters fed the Farlands famine; ancient
men hardened by a climate neither man nor beast could face, NOT giants. The lore correction lands
everywhere at once: every rider who ever answered your horn was a FARKEEPER rider, in every line
the player reads. And Farkeeper WARDS join the fires — named, drawn a head taller and a hand wider
in iron and pale, hired as companions who meet trouble first and hit like the mountain.

**Eight factions, each with a culture and a palette** — the Republic's two, the live Raiders, the
shoot-on-sight Reapers and Hollow Fires, and the seeded Unlit, Flame Keepers and Iron Giants behind
the door the roadmap leaves open. **Five horse breeds** with stats where their real strengths are —
the Fjord stands its ground when scrappers hit, the Arabian measurably outruns everything and
spooks at shadows, the Percheron was born to carry — and every stable keeps its town's horse.

Verification: `tests/karma.mjs` (21 checks — the tiered ledger and its chip, the green-never-gold
crates, the three-way clean pay, the visible smoke, the Republic's arrival, per-town heat on a
caught pass with seizure and mail, settlement and decay, the legible risk equation, the skim, the
measured camp-claim respect and its gold exception, the seeded named wards and their heavy
intercept, the corrected strings, breed data and the measured Arabian, eight cultured factions, the
karma panel, save/reload) plus the full battery below.

## The myth in the flesh (v3.23 — the legend, the micro-cines, THE HANDOFF, the coat that is yours)

The Postman's best beat — the founder walking back into a city that treats him as a myth — carried
through gameplay, never a dialogue screen.

**The legend ladder.** Four tiers off the walker's level: a stranger, SPOKEN OF, THE WALKER, THE
MYTH IN THE FLESH. Lit yards STOP — townsfolk halt mid-stride and face you — and what they say is
CITED FROM THE RECORD: this town's stars, your delivery count, "I lived here UNLIT," the far towns
that know the name. Keepers bend their hellos at tier two. At the top, children run the fences to
keep you in sight and shout about touching the coat. The first yard you enter after a new tier
earns the zoom.

**Micro-cines** are cognitive signals, nothing more: letterbox, ONE slow zoom, the first line —
hard-capped at 2.2 seconds, skippable by any input, the sim never pausing underneath. Important
info announces itself and gets out of the way.

**THE HANDOFF.** Mounted, letters aboard, first approach to a town: a kid runs to the roadside
with the letter held HIGH, and the game spends effects money it has no business having — the world
drops to quarter speed, three camera CUTS land (wide, close, SUPER ZOOM), radial speed lines rake
the frame, the envelope arcs hand to hand, a white flash, a freeze frame stamped THE LETTER RIDES.
Three and a half seconds against the janky low-bit world — the contrast is the joke, and the
craft. Once per town, ever. The town's regard rises and a mother writes you about it.

**The coat is yours.** The enlistment form cuts it: six coats, six trims, the valley's own hoods
and skins, previewed on a LIVE rig. The look walks in-world — identity under rank, rank under
equipped gear — and THE TAILOR at any lit terminal recuts it whenever. The character panel now
stands the walker up: a live paperdoll, four gear slots, one-click wear. Permadeath stings because
the one who falls was YOURS.

**The breath.** From the audited pixel research: the idle now breathes by shading drift alone —
silhouette identical to the texel, interior clusters migrating on an uneven cadence (hold two
seconds, breathe for half of one). Measured in the suite: zero silhouette pixels moved, ten
interior pixels drifted.

Verification: `tests/myth.mjs` (19 checks — the chargen swatch rows and live rig, the look walking
in-world, idle/idle2 differing, the silhouette law by alpha-mask diff, tier climb + record-cited
lines, the capped letterboxed zoom + auto-release + skip, the stopped yard + new-tier zoom + keeper
prefixes, the handoff's wide-cut open at quarter speed, the measured world crawl, cuts to the SUPER
ZOOM with release + regard + the mother's letter, once-per-town + skip, the tailor recut, the
paperdoll and one-click wear, look and once-ledger riding the save while scenes never do) plus the
full battery below.

## The wider world & the production (v3.24 — the Cine engine, THE RIDE, the globe, the party of four)

Four systems shipped as one version, each leaning on what already stood (the standing law).

**The CINE ENGINE (`src/16cb_cine.js`).** The 90s grammar formalized so a scene is a SHOT LIST,
never bespoke camera code — built from the research (`research-90s-directing.md`: The Postman's
slow-mo myth beats and displaced violence; Waterworld/Semler's intimacy-first 27mm). Five moves:
**CUT** (hard reposition, 2%/s drift for life), **PUSH** (the Postman slow zoom), **DOLLY**
(Steadicam lag on a moving subject), **VEER** (the mercy crane — up and away while the SOUND
carries the event), **HOLD** (world frozen, stamp card slammed at −0.06 rad). Slow motion is the
world (`S.timeScale`) while the camera clock runs REAL — scenes stay short. Shot fields: dur/at
(point or fn)/zoom/zoomTo/move/ts/say/fx (speedlines, flash@, shots@ — three muzzle flickers plus
`Snd.sfx.gunshots` — stamp)/on(seq). Any input skips. The screen effects are shared primitives now
(`fxSpeedLines/fxFlash/fxStamp/fxBands` — stepped bands, never a gradient; the handoff rents the
same tools). The engine owns the camera outright while a sequence runs; letterbox and timeScale
restore on end or skip.

**THE RIDE (`16d_myth.js`).** The firing-squad parody, displaced the 90s way. Once ever, on the
first deep-grey push after the legend starts (mist > 0.6, tier ≥ 1, far from towns): a captive
Waylighter kneels before four Reaper cloaks (pale #9aa4ff eyes, one cold staff-lamp pooling light —
the only light out there), a second rider held at the edge, and on the watch ridge Haven's people
with a kid pressed to the front. Six shots: wide CUT ("Reapers. They took two of ours at the
crossing.") → PUSH on the ridge ("THAT'S MY DAD!") → CUT close ("RIDE, WAYLIGHTER! RIIIIIIIDE!!",
the rifles level, the rider BOLTS toward the nearest lit town) → DOLLY with speed lines → VEER up
and away, three gunshots HEARD (distant boom + crack + hills answering; muzzle flickers as faint
sky-flash pulses) → HOLD: "THE MAIL GOT OUT." Aftermath: recon mail, +4 likes, the kid "has not
stopped saying RIDE." Skippable at every beat; `WL.ride()` restages it for tests.

**THE GLOBE (`16e_globe.js`).** The survey sheet grew a second tab: THE VALLEY (texels and paper)
⇄ THE WORLD — a per-pixel shaded PLANET, laughably past the game's station: procedurally baked
equirect maps (murmur-finalizer value-noise fBm continents at 29% land, hypsometric tints, ice
caps, sea-ice fringe), orthographic per-pixel projection with static tables so spinning is cheap
(30 fps sustained), N·L diffuse with a softened terminator, specular sun on the sea, TWO cloud
laws (deck drifting at its own rate, its shadow thrown west), night-side city lights (a world FULL
of people we cannot reach yet), a stepped blue atmosphere rim and halo — and NOT ONE canvas
gradient call (the doctrine's builds check still counts exactly one radial gradient in the whole
build). Drag to turn, idle spin, inertia. Pins are game-UI chunk on top of the smooth planet (the
contrast kept on purpose): THE VALLEY — YOU ARE HERE on a coast, with the regional cargo tally
("N aboard"), plus four UNCHARTED regions (Frostreach, the Salt Flats, Emberfall, Low Marrow) as
`Globe.REGIONS` — {id, name, lon, lat, open, blurb} — the futureproofing for the Frostpunk-style
recon/outpost system.

**The delivery badges.** `Systems.deliverableCounts()` is the ONE truth about the load — mission
crates held per destination door plus lost finds riding home. The classic map draws a crate badge
(the earn feed's own authored 9×9 crate icon) with ×N at every town you hold cargo for — "unload
the most in one place," seen at a glance; the globe aggregates the same counts into the valley
pin's tally.

**THE PARTY OF FOUR (`15b_npc.js`).** Hire up to THREE companions (party cap 3 + the walker):
a staggered wedge with per-member positions (`n.cx/cy`), voices in turns, per-member upkeep,
anti-stuck, one looter-fetcher at a time, and the pack riding whichever back has the most room
(`give()` finds it; `take()` searches all three). Companions can be **mounted**: at any connected
town's stable, rent a saddle for a party member (3 provisions, loaner returns on dismissal/KO) or
buy it outright (12 — theirs for good); a mounted member holds a mounted pace (speed ×2.1). Every
single-companion contract still stands — intercept, steady, struggle bonus (now +12% per extra fed
back), shove — iterating the wedge.

**The party IS the health pool.** Any blow that would drop the walker is taken by a conscious
companion instead: they go down doing it (KO → carried to the nearest lit town, `recoverT` 540 s,
re-hirable fee-free when they wake — "you already paid it in blood"), and the walker stands back
up at 32. Three companions = three quarters; **the player character always falls last (4/4)** —
and the blood-debt dies with the porter (a dead walker's mending companions never rally to a
stranger's rescue).

**The rescue ride.** When the last quarter is spent, the town with the highest appreciation gets
ONE chance to reach you: odds `0.25 + 0.18 × apprLevel` (the riders who come are the riders you
fed), cooldown 1500 s. Success — a 2-shot Cine (CUT on the fallen walker, "RIDERS! Riders out of
HAVEN—" → DOLLY on three banner riders at the gallop, flare flash), the walker stood up at 30,
wraiths within 800 burned off the road, camp runners cooled, and every mending companion RALLIED
back to the saddle; the town is proud (+1 appr) and the mail says "Don't thank us. Deliver."
Failure — the mail says one saddle came home empty, and death is death. Inside the cooldown the
grey keeps what it catches.

**THE TOWN LAW.** No one starves or freezes to death inside walls — within 300 u of any station,
hunger and cold damage are OFF (immediate immunity), and a starving walker gets the mercy meal
(food → 24, once per town per 300 s: "Not in MY yard, walker. Eat."). The wild keeps its teeth —
the same hunger outside the walls drains as before.

**The sound, redesigned (`11_audio.js`).** The rain was radio static with the gain up; now it is
WATER — three layers on one bus (lowpassed wash, band-passed patter breathing on a gust LFO, a
storm rumble that only arrives when it pours), fed RAW intensity with the loudness law living in
Snd. The rain has its own persisted dial (pause sheet slider; zero mutes the weather while every
doorbell stays). The wraith drone — the one sound the scaffolding got right — was kept and taught
to breathe: a third barely-wrong partial and a slow filter swell. The sfx palette was designed,
not defaulted: jittered footfalls (no two alike), quieter hands, warmer accept bell, a low thump
under builds, plus `gunshots()` (distant triple crack with the hills answering) for the VEER.

Verification: `tests/wider.mjs` (27 checks — engine play/cut/hold-stamp/skip, RIDE actors/bolt/
displaced-gunfire/aftermath-once-ever, globe regions/planet-renders/rotation/counts/map-badge,
party hire-cap/wedge/roomiest-back/three-quarters/mend-refusal/player-falls-last, next-porter,
rescue fire/resolve/one-per-debt, town-law inside/outside, rain dial/layered-water) plus the full
battery: **477 checks green across twenty-four suites.**

## The names & the exiles (v3.25 — Waylight is a CITY, the protagonist framed, the Lamplighter, the Society)

**THE NAMES.** Waylight is the CAPITAL — the first dawning of the last light, seat of the REPUBLIC
OF CONNECTION (Waylight + Farkeep, per the karma notes) — so no sheet calls the world by it. The
land under the player's boots is formally THE GREYMARCH (the borderland march of the Grey;
"the valley" stays colloquial), the survey tabs read THE GREYMARCH ⇄ THE KNOWN WORLD, the title
ladder tops out LEGEND OF THE GREYMARCH, and the globe pins the lore's real places: the Greymarch
walked; WAYLIGHT (THE FIRST LIGHT · SEAT OF THE REPUBLIC, glowing from orbit, coastal by law) and
THE FARLANDS (FARKEEP · THE REPUBLIC OF CONNECTION) known across the water; two reaches uncharted
for recon.

**THE CLOAKED TORCH (the protagonist framed in fragments, before the class exists).** Beat one:
cross the deep grey and the next lit yard noticed — "You came out of the grey walking EASY. Where
does a coat learn the dark like that?" Beat two, two doors: a scrapper reads the stance ("I know
that stance. Lamplighter.") at renegade ≥ 1, or a tier-2 yard asks about the cloaked torch. Both
are micro-cines; both must land before the exiles come.

**THE LAMPLIGHTER (the rescue nobody else would ride).** Two doors into ONE once-ever Cine scene:
CORNERED (hurt, deep grey, scrappers closing, far from towns) or THE FALL — the rescue system's
exile lane: when the pool is spent and NO yard qualifies, the Lamplighters take the ride. Three
cracks from a ridge (the camera looks straight at the gun this time — THE RIDE's displacement,
subverted), every chase within 640 broken, the cloaked figure with the hooded lantern ("The Order
teaches falling; we teach standing."), the raised-tongue stranger stepping out, HOLD: "THE CLOAKED
TORCH." Handoff: the C14 Timberwolf + 12 counted rounds, the LAMPLIGHTER class unlocked for this
world (chargen gate S.flags.lampClass — a fresh world never offers it), two letters, the record
promised.

**THE TIMBERWOLF (karma with a bolt handle, KeyY).** No aim minigame — the shot is a DECISION.
Nothing in reach: a warning crack scatters every chase inside 540 for one round, ledger clean.
A scrapper inside 430: he drops for 25 s, his friends dive, and +2 RENEGADE and +2 town heat write
it — the exact violence that made the exiles exiles. Cooldown 6 s (renegade tier trims it and
reaches further — the outlaw's ladder trains the hand); ammo scarce; dry fire says so; the prompt
rail offers the rifle only when scrappers stand inside its argument. The class: −2 pts,
foot 1 / sal 1, +6 kg exile-trained back, spawns with the rifle and 6 rounds — and the rifle is a
hand-me-down between EXILES only (a courier successor starts without one; the Nomads collect
their own).

**THE FACTIONS (two step out of rumor).** THE LAMPLIGHTER NOMADS (WARY — exile marksmen, crafty,
hard to track, "somewhere out past the maps the exiles even found a city to call their own") and
THE DIEFENBUNKER SOCIETY (UNKNOWN — the last of the old world, all of one northern origin nobody
says outright: carbines with a red leaf etched into the sights, "something about the cold,
something about the water" — the Fallout homage played straight). Their record arrives as the comm
array allows: three SBSN founding logs (Reed / O'Connel / Butler — the unsealing, the doors that
cannot reseal, the red leaf and "a place called Canada") on Society paper (.sbsn dossier styling),
delivered in order after first contact, wording preserved and spelling normalized.

Verification: `tests/exiles.mjs` (20 checks — fresh-world class absence, names/tabs/regions/title
ladder, both framing beats in order, arc staging/cracks/stranger/handoff/once-ever, warning vs
connecting shot ledgers, cooldown/dry-fire, prompt rail, faction rosters and hints, the SBSN chain
in order with the Canada log, the fall lane, class unlock + lamplighter porter + courier reset)
plus the full battery: **536 checks green across twenty-eight suites.**

## The Darklands table (v3.26 — the scale ladder made honest)

The verdict was earned: the map ladder shipped local → planet with NOTHING between, and the globe's
atmosphere clipped square at its canvas edge — a pasted asset, shipped unexamined. v3.26 answers
with the CONTINENTAL MAP as the actual developed middle scale, and the ladder reads honestly:
**THE GREYMARCH** (survey sheet) → **THE DARKLANDS** (the briefing table) → **THE KNOWN WORLD**
(the globe, demoted to the farthest pull of the glass — an ornament, and it says so).

**THE DARKLANDS (`src/16f_continent.js`).** The reference grammar — a tilted plane receding to a
horizon, wire-grid and contour terrain, leader-line labels, side data columns — rebuilt in the
register's own ink, never the references' neon: bone contour lines climbing 13 rings with real
RELIEF lift, a dotted land-density field brighter with height, a stippled grey-blue sea (a
surface, never a hole), the graticule receding with depth-stepped alpha, far coasts continuing
past the table edge so the map never just ends, gold corner ticks, a scale bar, the survey stamp.
The terrain is sampled from the SAME planet bake the globe renders (`Globe.elevAt`) windowed
around the Greymarch pin — one truth about the world. The subject carries the LIVE game: the
Greymarch footprint framed in gold dashes, its light coverage as gold stipple that grows with
`S.cov`, station pips (lit gold / dark grey) that scale as the table is leaned into, rust rings on
un-quieted camps, the walker a white pulse. The uncharted region pins live on this table — the
recon system's future ground drawn where it will happen. The columns are the LEDGER, real:
[ CONTINENTAL SURVEY ] region/coverage/stations/roads/party · [ CONDITIONS ] weather/the walk ·
[ THE LEDGER ] trust/karma tier/deliveries/camps quiet. Drag turns the table (yaw, clamped, with
inertia); scroll leans in; 60 fps with every layer on.

**The globe, demoted and padded.** The canvas now carries padding past the halo (PADF 0.26) so the
atmosphere ends where IT ends — corners verified empty, glow verified alive between disc and edge
— and the caption owns the new station: "the farthest the glass pulls back · an ornament of the
survey, for now."

Verification: `tests/continent.mjs` (9 checks — the three-tab ladder with engine exclusivity,
reopen-where-you-left, same-bake windowing with the subject framed on real land, painted-density
floor (thousands of samples: bone/gold/sea all present), live yaw, ≥20 fps floor, footprint
mapping, uncharted-on-table, halo corners + glow + demotion caption) plus the full battery:
**506 checks green across twenty-six suites.**

## The ecosystem (v3.27 — utilities ride the pack, works hold the ground, the loop revolves)

The directive named the missing distinction and the missing motion: direct utilities and build
items are TWO SEPARATE THINGS, and both belong to a factory-style loop where everything has a
purpose and everything helps the other. v3.27 makes the taxonomy explicit and CLOSES the loop.

**The two shelves.** The terminal's Fabricate sheet opens on the split, named in the register's
voice — UTILITIES (what rides the pack) · WORKS (what holds the ground, via kits and B) — with the
loop law printed at the counter and a ↻ loop line per item saying what it eats and what it feeds.

**Works PRODUCE (`updateWorks`).** Three new production works, each SITED by terrain (the factory
floor is geography, and the ghost is honest about a bad site BEFORE the kit is spent):
- **LUMEN STILL** (metal 14 + ceramic 6) — wants the VEIL thick at its site (mistBase ≥ 0.22: the
  light's edge, not its heart); pays 1 lumen / 90 s, and GREY WEATHER RUNS IT AT DOUBLE — the
  storm is a harvest.
- **SAWCAMP** (metal 10 + wood 4) — wants a treeline in reach (240); pays 1 wood / 75 s — and a
  FORRESTER working the same stand runs the camp ×1.25 while the camp sharpens the axe ×1.25
  right back: the synergy is mutual and measured.
- **CLAY OVEN** (metal 8 + wood 6) — wants wet ground close (marsh/shallows within 160); pays
  1 ceramic / 85 s.
The TIERS join the loop: the watchtower's armed post sweeps the SPOTTER'S TITHE (1 metal / 110 s)
and the shelter's room hangs a DRYING RACK (1 provisions / 120 s where meadow grows in reach —
and says NO MEADOW IN REACH instead of paying where none does). Every banked resource now has an
automated, sited source.

**The loop's honesty.** Every unit LANDS as an earn chip labeled by its work, with a puff at the
site and a first-pay tutorial. DISREPAIR (hp < 30) pauses hands — the clock holds, nothing pays —
and repair costs 5 metal: the loop feeding back. Because forests and marshes sit at the light's
edge, the build-in-waylight law makes generators the road TO production sites — infrastructure
begets production begets infrastructure. `Systems.workInfo/workState` is the ONE truth read by
the tick, the ledger and the labels.

**The ledger reads it.** The station Ledger tab's [ THE ECOSYSTEM ] block lists every producing
work — state (WORKING / DISREPAIR / BAD SITE / NO MEADOW IN REACH), rate, lifetime pay, percent
mended — and the all-works, all-time tally from `S.eco.produced`.

Verification: `tests/ecosystem.mjs` (14 checks — the two shelves + loop lines, the build bar's
works, all three siting laws honest on the one-truth path AND the build path with the kit kept,
production paying bank/lifetime/tally/chip, the storm doubling the still, the mutual synergy at
×1.25 measured both ways, disrepair freezing the clock, tithe and rack with the honest no-meadow
state, the ledger block, the closed loop) plus the full battery: **520 checks green across
twenty-seven suites.**

## The watchdog (v3.28a — the frozen-input report answered as law)

The field report: inputs dead (no click-to-move, no WASD) with ESC still opening the menu. The
exact trigger could not be reproduced from fresh boots, migrated saves, or a full UI fuzz — so the
answer is DEFENSE IN DEPTH, shipped as law:

**The step can never die silently.** The sim, the myth clocks and the frame are each guarded; the
first fault of any kind is reported ON SCREEN (`⚠ Waylight caught a fault in <where> — the walk
continues`, with the message — so any future report carries its own diagnosis) and in full to the
console, and the loop keeps stepping. A save-borne crasher can no longer freeze the game.

**Stuck gates are repaired within two seconds.** The watchdog compares every input gate against
what is actually on screen and fixes desyncs silently: a paused clock with no pause sheet; a
station sheet with nobody home (which eats every click while it stands); a stranded timeScale or
letterbox with no scene running; a zip state with no ride under it; a map flag out of step with
its sheet; a mouse button the browser never released.

**The gaps found on the way are closed.** The tailor now counts as the modal it is
(modalExceptMap), answers ESC like every other sheet (escPressed), and is torn down by
closeAllModals. Unknown legacy structure types (the classic save-migration crasher) leave the
world quietly in decay and produce nothing, instead of throwing every frame.

**And the battery now walks the player's own page.** `tests/inputs.mjs` runs on waylight.html
with NO debug flag — the first suite that boots exactly what the artifact serves.

Verification: `tests/inputs.mjs` (16 checks — non-debug boot with live WASD/click, the pause/map/
skills/blueprint/tailor fuzz, all four watchdog repairs each within two seconds, the legacy-type
survival, the sabotage check where the sim is made to throw and must report on screen and keep
walking, zero uncaught page errors) plus the full battery: **536 checks green across
twenty-eight suites.**

## The economy (what a delivery is now)

Every station has a population, three or four **needs** and a few things it **makes**. Stock for each need sits on a 0–100 bar that drains with time (0.035/s × population; the unconnected ration at half rate). A delivered crate adds 28. Stock sets a **mood** — *critical* < 15, *wanting* < 35, *steady* < 65, *thriving* — and mood sets the price: ×2.2 / ×1.5 / ×1.0 / nothing. **A station never posts an order for a need it is thriving on.** The board at any terminal is therefore not a list of templates but a reading of the valley: what *this* station can spare, who among the places you know is short of it, how badly, how far, what the walk asks (wading, scrappers, deep grey, steep, or "river — needs a crossing"), and what your pack will weigh after you say yes. Several crates landed in one trip pay a rising chain bonus (+15% per further stop, capped ×1.6), so the load is a plan, not a pick.

The opening is true to the fiction: Elm Farm is out of medicine (8), Haven is eating its reserves (31), the Mill is hungry (18), the Greenhouse is nearly out of seed. Haven makes tools and textiles; Elm grows food and seed; the Greenhouse grows medicine and filters; the Mill makes parts and tools; the Quarry tools; Relay Hill lumen cells; the Foundry coolant and parts; the Pharos makes nothing and needs everything.

**The wire.** When a station is connected, what its connected neighbours make flows to it on its own (0.06/s per feeding maker) — more than its people consume, so a connected pair sustains itself and its stock climbs to full. A **paved road** between two stations multiplies that flow (×1.6 partial, ×2.2 complete); a **chartered route porter** adds ×1 more. The player is told this the first time it happens ("Haven is being fed by the wire now — Elm Farm sends what they can on their own") and the connection cinematic names who will feed whom. The consequence is the shape of the whole game: **the connected core saturates and stops posting; the frontier is where the crates are needed.** The wire pushes the player outward; roads and porters are how the player makes the core self-sufficient behind them.

**Neglect.** A connected station critical on a need that a *known* maker could supply **dims** (its light radius shrinks by a quarter, so the safe ground shrinks). If the wire is not already closing that shortage (no connected maker), four minutes of it costs a **star** — "people are leaving" — and with no stars left the station **goes quiet**: off the wire, light out, and every lit terminal posts a *Relight X* core order. Shortages of goods nobody you know makes are rationed, not held against you.

**Letters** go everywhere people are — light, half pay, and each one read aloud on delivery (24 lines from the valley). A place's mailbag refills only every ~5–8 minutes once carried off; they are proof, not income. **Crises** (events after three stations are lit) empty a station's best-stocked need in one stroke. A **day** is 8 minutes; the last 40% is night: wraiths wake in thinner mist, the cold bites harder, a veil settles on the screen, and the HUD says so.

**Skill verbs** (the character layer inside the loop): Rigging 2 lays a *field ladder* from 8 scrap when none is packed; Hearthcraft 2 cooks a warm meal anywhere; Salvage 2 (or a Scavenger) pings scrap and lumen on the compass.

## The light is the screen (v3.1)

The theme selection promised one thing above all: *"network % is not a number on a screen — it is the screen."* v3.0 shipped the mechanics of light (safety, regen, pacification, coverage) with the picture missing — a 55% dark veil over already-dark art and a warm glow at an effective 4% opacity, tuned to protect the terrain art instead of serving the design sentence. The failure mechanism is recorded here because it is the project's recurring one: every mechanical claim had a bot, the pixel claim had none, so it got no pressure.

v3.1 regrades the world and pins it with measurements (`tests/light.mjs`, sampling the composited canvas):

- **Grey land** sits under a cold blue-dark veil (62% + mist) — dark, not black; terrain stays faintly readable and the porter's own lantern carries them.
- **Lit land** burns the veil off entirely and takes a warm gold wash. Measured on the same meadow class: lit ground is **×2.6 the brightness** of grey ground by day, 30 points warmer in r−b.
- **The boundary** carries a golden rim (a measured warm bump above the inside→beyond blend line) at exactly the light level wraiths cannot stand — a hunting wraith crossing it burns away within a second, and the first burn teaches the rule on screen.
- **Night** is a veil the waylight burns holes in (destination-out by the light field): lit ground keeps ~96% of its day face while the grey drowns — the lit/grey ratio grows to **×3.2**. Crossing your own network at night reads as islands of day.
- **The map** draws the same overlay, so territory reclaimed is territory brightened: +19% whole-map luminance at 14% coverage, scaling with the network. Connecting a station repaints both the field and the map in the cinematic's expanding ring.

## Where the features now live

Weight and capacity (Hauling, packs, companions) decide how many orders one trip can chain. Balance, bracing and weather decide the condition grade. Ladders and bridges open the Silt and keep the creek's crates dry. Roads are speed on foot *and* wire throughput. Waylighters carry your overflow, and chartered routes are wire throughput. Camps sit on the routes to the Mill, the Greenhouse and the Quarry; auto-travel skirts scrapper territory when you are loaded (×5 path cost) and walks straight through when you are not, because scrappers only chase cargo. Night is a timing decision. Stars are now something you can lose. The map shows every known station's mood ring and "out of / short of" label; hovering reads its bars.

## Losing a crate

An order's crate can leave your back: a stumble drops it, a wraith snags it, scrapper runners haul drops to their stash, a companion carries it, you lock it in storage. The Guide reads where it went ("Medicine is on the ground — go back for it", "hangs at a snag", "Scrappers took Rations to Pass Camp — their stash holds it") and points there; the compass keeps a *crate* mark that never declutters; the tray card turns rust and says where. A companion's load delivers with you (handed over at the terminal). Any order can be **given up** (✕ on its tray card): its crates become lost cargo for the same place (half credit if they ever arrive) and a ★ order returns to its board.

## Controls: one hand for travel, two for trouble

**M1 tap** on the ground — walk there along a route feet can actually take (deep water and cliffs avoided, crossings used, camps skirted while loaded; a tap across an uncrossable river is refused with "No way through on foot — a ladder or bridge would change that"). **M1 tap on a terminal, ruin, crate, cairn, paver, pylon or event** — walk there and use it. **Hold M1** — steer at the cursor. **Hold M1 + M2** — sprint. **M1 on the valley map** — travel there. **W A S D** overrides; Shift sprints; Space steadies; E interacts. If feet stop advancing or six seconds of walking go nowhere, the ground ahead is marked impassable and the route re-plans (up to three times) before an honest "The ground stops you here".

## The first walk (unchanged, re-verified)

The gold Guide line under the compass always says what to do next, which key does it, and where it is. Order p1 medicine + a letter to Elm across the wadeable creek; p2 two crates of food home with two ladders granted; p3 the beacon core — "Elm Farm is on the wire: watch the terminal, Haven's food and Elm's tools now move between them on their own." Random events hold until the first delivery lands. The screen-reading bot finishes the arc in ~95 s.

## Balance (the session bot)

`tests/session.mjs` plays 30 game-minutes at 4× clock with real walking and real orders: at every terminal it takes the ★ if it fits, then the best pay-per-kilo orders up to capacity; it recovers crates it drops, gives up crates scrappers have stashed, and teleports only where a player would lay a ladder (logged). Three degenerate loops were found and closed with it:

1. **The overloaded stall.** Accepting 110% of capacity, it dropped the 18 kg core, then stood at the Mill forever with nothing deliverable. Fix: the lost-crate Guide, compass mark, tray line and give-up (above).
2. **The letter shuttle.** Letters were infinite, 4 kg and paid by distance; the bot carried mailbags Haven ⇄ Elm for twenty minutes. Fix: mailbags refill slowly, pay half.
3. **The full-station shuttle.** With Haven and Elm both at 100 stock the boards still posted food and tools at ×0.6; the bot ferried them for twenty minutes with the Mill's core riding along unopened. Fix: thriving needs are not posted. Also found: a station lost a star four minutes after its maker was connected because the wire had not yet caught up — now the wire closing a shortage exempts it from star loss.

Final run: 30 game-minutes, 49 deliveries, six stations connected (Haven, Elm, the Mill, the Greenhouse, the Quarry, Relay Hill), stars 3/3/2/1/1/0, zero deaths, zero scrapper knocks, no repeated decision anywhere in the log, and the decision mix keeps changing as the wire saturates the core — exactly the shape the design wants. (Two river legs were teleported with a note; a player lays a ladder there.)

## The two laws

1. **Connection makes land safer and richer** (DS): a core delivered puts a station on the wire; its light pushes back the grey and pacifies camps it reaches; its goods move to its neighbours on their own; roads and routes widen the wire.
2. **Porters are mortal, the network is immortal** (PZ): stations, stars, stock, roads, structures, banked materials, reputation, hired waylighters and route charters persist across deaths; class, traits, skills, equipment and cargo die with the body — recoverably.

## Everything below is as shipped in v2.x

Character layer (8 classes, 19 traits, 10 skills with PZ curve, manuals), survival-lite (health, food, warmth, moodles), death cosmology (cairns, porter-wraiths, journals), items and 36 ruins, waylighters (companions and route porters), events, terrain rules (riverbanks never cliffs; only painted cliffs and deep water block), HUD layout, the permadeath ★ re-post fix.

## Verification

450 automated Playwright checks green, console clean, frame time 16.6 ms, across twenty-three suites — the twelfth the pixel pass, the thirteenth the builds pass, the fourteenth the lamps pass, the fifteenth the glow pass, the sixteenth the post suite, the seventeenth the progression suite, the eighteenth the shapes suite, the nineteenth the body suite (30), the twentieth the working-world suite (17), the twenty-first the ground suite (15), the twenty-second the karma suite (21), the twenty-third the myth suite above (19) — all rerun against the v3.6 light field (the light suite's pixel measurements — lit/grey luma and warmth ratios, the boundary rim, night punch-through, map growth — hold on the quantized palette bands) — including **the feel suite** (31: the Roll on the title screen, rotating taglines, a cheat typed end-to-end onto the record, the coat in the intro, Dispatch chain callouts and field promotions, scrapper trash talk, keeper voices on the results screen, panel clicks never move the Walker, two-click hand-over, companion interception, strung routes in world and map, keeper voices by state, barks, no DS vocabulary anywhere a player reads) — including **the light, measured in pixels** (10: lit/grey brightness and warmth ratios on matched terrain, the boundary rim, whole-map brightening with coverage, night punch-through, wraith burn and its tutorial) — the other seven: the delivery loop and network progression (33), the character-layer systems (35), the keys-and-clicks player-fidelity run (31), the **screen-reading first walk** (24), the **mouse-only run** (18), the **economy dynamics** (24: needs and moods set boards and pay, stock fills and drains, the wire flows and is multiplied by roads and porters, dimming, star loss, going quiet and relighting, chain bonuses, letters, crises, night, skill verbs, save migration), and the **v3 loop rules** (14: the lost-crate Guide/compass/tray chain, pickup recovery, stash tracking, giving up, companion hand-over, thriving suppression, letter scarcity, camp-skirting loaded routes, the wire's star-loss exemption, best-stock crises, honest stall handling, the wire cinematic) — plus the 30-game-minute balance session above.

## Future-work candidates

Touch controls; a suggested-route line on the map; NPC route events; relationships between waylighters; gear durability with Mending repairs; a second procedural valley after the Pharos; stock visible from the field (a bar over the station when near).


## The dead boot law (v3.28b — the frozen-input report answered at the ROOT)

The report stood after v3.28a: still no click-to-move, no WASD, ESC menu alive. The watchdog's
gates were all sound — so the cause had to be a gate the watchdog never checked. It was `S.dead`.

**The mechanism, reproduced end to end.** `die()` set `dead:true` and showed the Certificate of
Passage — but never saved; the death-screen AUTO-SAVE (switching tabs fires it, and `playing` is
still true on the death screen) wrote the save WITH the death and WITHOUT the ceremony. Every
boot after: `load()` normalized every transient EXCEPT `dead`, no death sheet was presented, and
every input gate that reads `S.dead` stayed shut forever — clicks refused by `canTravel`, the sim
(and so WASD movement) gated off at the step, ESC menu the one living surface. The player's
report, word for word.

**The law.** Death is COMMITTED the moment it happens: `die()` stores the certificate's facts on
the save (`S.deadInfo`) and saves at once — no alt-F4 resurrection; the Zomboid doctrine with
teeth. A save carrying a committed death boots INTO the Certificate (older dead saves that lack
the facts get an honest fallback: "the road took them between saves"), the ceremony hands off to
char-gen, and the next walker takes a valley EXACTLY as it was left — likes, structures, graves,
legacy, all proven untouched by the suite. The watchdog stands guard behind it all: any zombie
world it ever meets (dead walker, no certificate on screen) is presented the ceremony within ~2s.

**The no-purge law** (a standing order from the desk): nothing is ever deleted as fixing. Before
`load()` reads a byte, the save as it stood is stashed whole in a backup slot
(`waylight_save_v1_bak`). The v3.28a guard that dropped unknown legacy structure types was
amended the same hour it was named: they now go to THE ATTIC — kept in the save, out of the sim —
and step back into the world the moment a build that knows their type loads it. Proven round-trip
in the suite.

**The player's own tools, in the one menu that always answers.** The ESC menu carries a live
diagnostic line naming every gate holding the boots ("boots: held by a scene · a slowed clock"),
and FREE MY BOOTS — a release that clears stuck transient state (scenes, rings, sheets, clocks,
stolen focus), closes every sheet, and DELETES NOTHING; a committed death is not "released" but
finally shown its certificate. And when a fault fires every frame, a pinned chip spells the
diagnosis verbatim (`⚠ FAULT EVERY FRAME · the sim: <message> · ESC → FREE MY BOOTS`) so any
future report carries its own root cause.

**Proof.** `deadboot.mjs`, 19 checks green on the player's own page: the commit, the dead boot
into the Certificate, the fallback text, the backup slot, valley continuity across the handoff,
live boots after, the watchdog heal, the diag line, the release and its no-deletion proof, the
fault chip, and the attic's round-trip restore. Full battery: **475 tallied checks across
twenty-nine suites, zero fails.**


## The frontier (v3.28 — RECON & OUTPOSTS: the Darklands table becomes a working desk)

The v3.26 table promised it in its own caption — "recon will open the far marches" — and v3.28
delivers it as the Frostpunk law: send scouts to the frontier and the map fills in behind them,
then hold the frontier and it pays.

**The desk.** The uncharted pins (THE SALT FLATS, LOW MARROW) are click targets now. A click on a
pin (not a drag — the table still turns by hand) opens the frontier desk: a LEDGERLIGHT paper
sheet pinned to the table's corner — the reach's blurb, the honest costs, the banked line, one
gold button. Far pins clamp to the table's edge rather than dropping off it: the pin marks the
direction the rider goes; recon is what pulls the march onto the paper.

**The ride.** FUND THE RECON RIDE (20 metal · 6 provisions, and it wants a connected stable town
— the rider is a named Farkeeper on that town's own breed). Recon runs itself: a white dot walks
the dashed survey line across the table, live. At the midpoint the hazard rolls (30%): the rider
GOES QUIET — rust label, a worried mail, +45s — but always comes home; the mountain does not lose
riders to weather. The reach CHARTS with a survey letter in the register's voice.

**The outposts.** A charted reach takes an outpost (40 metal · 20 wood · 12 provisions; the
founding caravan takes half a cycle to arrive). Each reach is a DIFFERENT mouth feeding the v3.27
loop: PANHOUSE STATION cuts salt-pan slabs (ceramic) and cures stores (provisions); MARROW
DIGGINGS rakes bog-iron (metal) and bottles the marsh-light that pools instead of fleeing
(lumen). Every cycle the caravan walks the haul into the SAME bank the ecosystem revolves
through — earn chips land, the ecosystem tally counts it, and the caravan dot walks home across
the table as the cycle closes.

**The raid dice and the escort.** An unguarded haul rolls 35%: raided caravans limp in at half,
on record — mail, a rust toast, the table's CARAVANS RAIDED line. The answer is the Republic's
muscle at the wage law's price: fund the FARKEEPER ESCORT (2 provisions a cycle) and the mountain
walks beside every haul — zero raids while paid, and an unpaid escort LAPSES exactly like any
unpaid hand. [ THE FRONTIER ] column keeps the whole business on the table: riders out, reaches
charted, outposts, hauls landed, caravans raided — one truth.

**The batched automations, same logistics family.** The path-presser takes a CLICKED MARK: the
picker gains "→ a point on the land," and the presser wears a trail from town to wherever you
clicked (right-click or ESC puts the mark away). And the LOOTER completes (haul ≥ 4, earned):
trained backs work blooms, scrap and ruins in your sight straight into the bank, and a back past
80% full empties itself into the next lit town's lockers — kept and retrievable, never the void.

**Proof.** frontier.mjs, 24 checks green: refusals with the bank untouched, exact costs, the
chart and its mail, hauls landing in the bank, clean escorted arithmetic (3+1 per cycle, to the
unit), the lapse, both reaches' distinct yields, the desk's buttons working the real contract,
the presser walking a real path to the mark, the looter's sweep and locker deposit, and the
frontier riding the save. Full battery: **480 tallied checks across thirty suites, zero fails.**


## The clean shop (v3.28c — the standards correction, executed as work)

The verdict from the desk: a guardrail against deletion-as-fixing had been answered with
hoarding-as-fixing — the attic — and the shop floor was covered in artifacts nobody could
account for. v3.28c answers with the two things actually owed: the real mechanism, and the
accounting.

**The type ledger.** The audit of every shipped version found the structure-type history
ADDITIVE-ONLY — no rename or removal ever shipped — so the attic quarantined a case that could
not occur while the real case (a save from a NEWER build) had no correct path. Now:
`DATA.MIGRATE_TYPES` is the standing law that a type is forever (any future rename ships its map
entry in the same edit), `load()` walks every save through it at ONE seam, and a type past the
map becomes a real `unmapped` world object — authored tarp-and-rope glyph, visible, inert,
original type carried on the object — that steps back into itself the moment a build that knows
it loads the save. No attic, no splice, no guard forest: def is always real, and runtime garbage
is a code bug that surfaces LOUDLY through the fault guard instead of being absorbed.

**The shop audit.** `tools/audit.py` — destructure-aware, spread-aware, ternary-aware lexical
reference analysis over every source and test file, honest in print about what lexical analysis
cannot see. It raised 61 findings; every one was verified by hand before anything was touched:
one shipped unreachable branch (`&& false`) removed; six dead declarations removed; one dead UI
subsystem removed end to end (the DOM cine-title — a title with a hide routine and no show
caller, superseded by the canvas cine engine); forty-four dead exports trimmed while their
living functions stayed; nine analyzer false-positives fixed in the INSTRUMENT, not the code.
The complete finding-by-finding ledger ships as SHOP-AUDIT.md.

**The gate.** `tests/shopaudit.mjs` runs the audit inside the battery: any future dead
declaration, dead export, unread tuning constant, unfired tutorial, unreachable branch, or ghost
save-field FAILS the build. The shop stays swept because the sweep is a gate, not a memory.

**Proof.** Battery green after the sweep: **481 checks across thirty-one suites, zero fails** —
deadboot re-proves the ledger round-trip, inputs re-proves loud-not-absorbed, and the gate
itself stands in the count.


## The memorial (v3.29 — the ground that keeps the Order's own)

The permadeath research said it plainly: every life must bank something VISIBLE, and the
strongest form of a dead self is a world entity. v3.29 makes the bank a PLACE.

**The Lantern Rows.** A war-memorial ground near Haven, found once on open passable ground and
kept on the save. Every fallen or retired walker on the roll earns a stone, cut to the walk they
walked — the Darkest Dungeon headstone law: small for the short road, mid past eight deliveries,
GRAND past twenty-five or 350 ◆, and the grand stones carry their own glow. The ground GROWS
with the roll — kept ground (a plinth and a promise), the stones (flanked by lit lantern posts),
the rows (a paved apron up the center), and THE HALL (an etched wall crowning the ground at six
names). Lanterns, not crosses: this is the Order's ground, and its light is the point.

**The ceremony.** A new stone doesn't stand itself — it waits as a cut block on skids until the
walking successor RAISES it by hand (the Dwarf Fortress slab law: the interaction is the
memorial). Raising pays +8 ◆, mails the epitaph in the register's voice, and an unraised stone is
a DUTY mark on the compass from anywhere — the ground pulls until the Order's debt is paid.

**The sheet.** Read the stones and the roll opens as PLAYERCARDS: the stapled portrait (drawn by
the same engine that drew the walker alive — old rows without a stored face get one deterministic
face forever), name, class, epitaph, the numbers, the fate, and the REMEMBERED stamp. Grand
walkers read gold on paper too; WALKED WITH HELP is stamped exactly where the Roll always
stamped it. Full modal law, all four lists.

**Cross-faction by architecture — the future-proofing order.** ONE data table, ONE renderer,
FOUR complete designs shipped today: THE LANTERN ROWS (Waylight — bone stelae, gold light, the
open flame), THE HOODED ROW (Lamplighters — dark stones, the hood lifted exactly once), THE
STANDING TEETH (Farkeep — grey monoliths, a cold iron ring, no flame by doctrine), THE BRASS
WALL (Diefenbunker — green-bronze plaques, the red leaf etched and never explained). Legacy rows
carry their banner at write; the renderer reads the table; the Lamplighter city (v3.30) and every
ground after plugs in without touching the architecture. This per-walker, per-faction identity
layer is what the CK3-style sandbox (v3.31) hangs forces and cities from.

**Proof.** memorial.mjs, 20 checks green: the site real and saved, the full stage ladder, the
tier law, the paid ceremony oldest-first, the sheet with a card per name and the modal law, the
ground standing in PIXELS at the site, the compass duty, four-design completeness with honest
fallback, the save round-trip whole, and a real death writing a stone-ready row. Full battery:
**501 checks across thirty-two suites, zero fails.**


## The exile roads (v3.30 — Shutterlight, the guild, the C-series, the Hooded Row)

The v3.25 lore made a promise — "somewhere out past the maps the exiles even found a city" — and
v3.30 keeps it on the systems already standing.

**Shutterlight is REVEALED, never charted.** No Farkeeper rider will ride toward the exiles; the
city arrives because the exiles decide you have seen enough. The v3.25 rescue (or an exile
walker's own coat) MARKS the Darklands table — "a mark nobody made," a hooded lantern charcoaled
onto the frame — and FOLLOW THE MARK runs a guided journey down a road no survey will hold. The
city opens on the table's far north-west edge with its own pin (a lantern with the shutter half
down) and its own desk.

**The exchange and the guild.** The exchange sells .338 at three metal a round from a cycled
stock of six — dear, because the Nomads collect rifles, not brass. The guild posts the quiet
work, gated HONESTLY by what already exists: a rifle on your back (v3.25) and a party of two at
it (v3.24). Ridge watch, caravan gun, and the quiet collection — which writes the Renegade
ledger, because the karma system was always going to color this — run on the wage-law clock with
a mid-contract hazard roll: "it went loud" pays half and asks no questions it already knows the
answers to. Contracts done build guild standing: three opens the C3A1 shelf, seven turns THE
COLD DOOR's corner of the table.

**The C-series rides ONE fire path.** C14 Timberwolf, the hand-me-down; C3A1 at standing two,
the red-leaf service bolt; C20 behind the cold door, the semi-automatic answer. Each is a set of
multipliers on the v3.25 rifle constants — range, cooldown, drop time, warning radius — and the
rifle is NAMED on the pack, the prompt, and the dry-fire line. A knock at the cold door plays
the raised-tongue scene and opens the last shelf; the walkable interior itself rides v3.32 with
the faction-places work, stated plainly.

**The Hooded Row — the cross-faction law proven in play.** The Lamplighter memorial ground goes
LIVE on the v3.29 architecture: revealed with the city, sited far from every station (the exiles
bury their own where no map minds), dark stelae under hooded-lantern accents, UNHOODED for a
stamp — and a Lamplighter-class walker's death routes their stone THERE by the banner on their
legacy row, never to the Lantern Rows. One table, one renderer, two grounds standing.

**Standards revisions, same ship.** Screen shake is REMOVED AT THE ROOT by directive: the
per-frame random camera jolt — fed continuously by damage-over-time, which is why the game read
as violently vibrating — is deleted with all nine callers and the HUD heart jitter; impact
speaks through sound, stagger, and bursts, and THE STILLNESS LAW now stands in the battery (the
ground provably still to the pixel under bleeding). And the appreciation icon is sized like it
matters: 30px beside "+N APPRECIATION" on the waybill, proven on a real local-post delivery.

**Proof.** exileroads.mjs, 22 checks green end to end; the stillness law and the icon in the
battery; full battery **524 checks across thirty-four suites, zero fails**; shop audit CLEAN.


## The delivery ledgers (v3.31 — the RimWorld-style management layer)

**The item-system audit came first, and the verdict is: NO database.** The game already keeps
ONE merged flat definition map (DATA.items, with the character-era table folded in at load) —
97 defs, each carrying its own cat/slot/scrap fields. A database would be overhead with no
customer: what the management layer needed was not storage but MEANING — a taxonomy over the
defs and a policy store over the taxonomy. Both ship as pure data layers; zero defs moved.

**THE TAXO TREE.** Cargo → Equipable (utilities, provisions, weapon, wearables by SLOT — boots,
coats, packs, charms) · Buildables (station, works) · Resources (wood — every cut and grade
files under the one parent — metal, ceramic, lumen) · Consumables (food, medical, books) ·
Freight (post, trade) · Curios (relics, junk, contraband). classify() reads each def's own
fields, a four-line OVERRIDES map catches the tools that build rather than deploy, and
coverage() is a standing battery check: 97 classified, zero missed — a def added tomorrow
that fits no branch FAILS the suite rather than silently vanishing from the books.

**ONE policy store, three sheets over it.** S.ledger holds marks per node or per item across
five verbs — Deliver / Store / Donate / Scrap / Pickup — resolved item → leaf → root →
default. THE PARENT LAW is the sandbox standard done visibly: marking a parent clears every
descendant override so the whole column under it flips as one, and a mixed column renders the
half-bar tri-state. The three sheets are THE DELIVERY DOSSIER (the pass and its toggles, with
the donate-EXEMPT search box), HAULIN' MANIFEST (the streamlined book — ONE take-mark over the
category tree), and THE CARGO CHECKLIST (the in-depth book — a searchable grid where every
category and item unfolds to its five marks; Enter opens the chain and lights the row).

**THE DOSSIER RUNS IN STRICT ORDER at any lit town: missions FIRST** — the priority chain is
accepted before anything else moves — then Deliver (letters walk before cargo), Store, Donate
(exemptions held back), Scrap, Pickup (letters first, capacity honest). One slip totals the
pass. The map rail carries the travel-options widget as sketched: run-on-arrival, grab all
letters, deliver applicable — and the on-arrival edge fires once per town with a cooldown, so
riding past a door is never a surprise transaction. The whole engine is ITEM-AGNOSTIC by
imperative: the same policy resolution is the base the COMPANION management layer will stand on.

## The fairness pass (v3.31 — four field verdicts, answered at the root)

The field report named four core-loop injustices. Each was found in source, fixed at the root,
and pinned by fairness.mjs — ten checks that measure the WORLD, not the code's opinion of it.

**1 · The chase obeys the world.** The scrapper sprint was flat 152 — faster than an unloaded
walk, tuned to "catch the player" rather than to be a pair of boots. Now: 118 on the flat,
taxed by the SAME terrain and slope the player pays, a leash at 720, a stall-giveup, and the
mounted law — a runner who sees the gap growing under hooves calls it ("A horse. Forget it.")
and stops burning your attention. Proof: mounted gap 150→613 px in 3.5 s with the give-up
line; on foot, light-and-sprinting pulls away while loaded-and-walking stays honestly caught.

**2 · The hill is not a minigame.** The wobble rang on slope alone, so every hill on a route
demanded Space — the route-killer verdict. The ring now needs a REASON: overloaded past 1.0,
sprinting on rough ground, fear, or empty lungs — a sane load WALKING steep ground never
rings; the hill's price is breath and pace. Proof with the wobble LIVE (the calm debug flag
explicitly cleared — the earlier green here was vacuous and is called out as such): sixteen
seconds on 0.32+ slope, ZERO rings; overloaded on the same ground, the ring still comes.

**3 · The balk is a beat, not a chore.** Water and rungs still dismount the rider — the horse
has an opinion — but the horse now WANTS back on: it auto-remounts the far side of the
obstacle with no button, no spook lockout, one quiet line the first time. A CHOSEN dismount
(R) stays dismounted — the automation serves the balk only and never overrides the player.

**4 · The ladder law — every warp found and killed.** Root cause: planned waypoints landed
NEAR spans, not ON them, so walkers ground against cliff faces beside their own ladders — and
three separate "self-heal" mechanisms then MOVED them by fiat. snapCrossings() now projects
any planned waypoint within a span's reach ONTO the rungs — player routes and field crews
both — and the fiat movers are dead: escortSnap (the convoy junior "sucked to your back") is
DELETED — a wedged junior now plans the crossing and WALKS it under the same passable() law as
the player, trudging at half pace when left behind (never frozen, never warped); the field-hand
no-progress check — which counted slow walkers as stuck because they gain under 1px a frame
and would have popped every mason forward every eight seconds forever — now measures ground
gained over a full window and RETARGETS without ever writing a position; and the companion
catch-up teleport (300 px behind for 7 s = appear at your boots) is replaced by a visible run
that closes any gap in seconds on their own legs. Proof: a routed ladder crossing sampled at
100 ms — crossed, max step NINE pixels; the snap math exact on a real placed ladder; the
convoy junior closing 200+ px with every stride bounded under 60.

**Proof.** ledgers.mjs 16 checks (coverage, chains, the parent law, a full dossier pass at
Haven with the slip totalled, exemptions, letters-first, the arrival edge, save round-trip,
modal law); fairness.mjs 10; body and shapes rewritten where they had enshrined the OLD warp
law as correct; full battery **571 tallied checks across thirty-five suites, zero fails**;
shop audit CLEAN.


## The Republic in force (v3.32 — the CK3 sandbox foundation)

The memorial proved a scaling law in v3.29 — four faction designs, one renderer, a row per
banner. v3.32 applies that law to the WHOLE sandbox. Every faction, presence, doctrine and
interior is a REGISTRY ROW (12d_republic.js) read by ONE engine (15g_republic.js) and one set
of render glyphs. A future faction, a future doctrine, a future room is a row — never a new code
path. That is the entire architectural bet, and it is the reason this ships lean on eleven
sources instead of exploding across the codebase.

**STANCE PLAY, sealed where lore seals it, walked where it doesn't.** One ordered ladder —
Absolute Ally · Ally · Friendly · Wary · Hostile · Absolute Hostile · Unknown — and a RULES row
per banner saying what play may move it and through which gate. Waylight and Farkeep are SEALED
ABSOLUTE_ALLY by the founding; the Reapers and Hollow Fires SEALED ABSOLUTE_HOSTILE (shoot on
sight is mercy). No play moves a seal. The rest walk: the Raiders can be brought to a WARY TRUCE
at Road's-Own renegade standing; the Flame Keepers climb Wary → Friendly → Ally as you FEED their
shrines; the Unlit's posture is yours to set (LISTEN slows their drum, HARD LINE feeds it); the
Lamplighters and the Diefenbunker MIRROR ledgers that already exist (the guild rank, the cold
door). Every gate reads a system already standing — the renegade tiers, the exile rank, shrines
fed — never a new currency. THE BANNER SHEET (the survey-sheet rail, or Farkeep's own desk once
the road is cut) is the Republic in session: the court on the left, the holdings on the right.

**THE UNLIT, and the two answers.** A town whose people decide the wire is a leash douses its
own waylight BY CHOICE — political dark, not starvation, and NO delivered core will answer it.
The Republic holds two doctrines, and the choice between them is the game: THE QUELL sends a
column of Farkeeper shields that MARCHES the real road (snapped to the crossings like any
walker), restores the light by force, costs the town's love, and can cost the mountain a name —
a casualty raises a stone on the Standing Teeth. THE PARLEY is your own boots at their cold
fire, a gift of stores, and the oldest argument the Order owns — slower, gated behind a town
that loved you once, remembered longer. The first rising is authored (the stone-cutters at the
Quarry); after that the drum reads your caught work at each town, and the valley never loses more
than two lights off-screen, so the sandbox stays playable.

**PRESENCES from one table, all SEEN on the ground.** The Flame Keepers' shrines stand on the
walked ways — a stone bowl you FEED with carried lumen, burning tall for most of a day, warming
their stance. The Hollow Fires' larders burn far from every station, and at night the ring
around one HUNTS; the Farkeepers answer a larder with THE BURNING, not a parley. The Reapers
cross the night grey in a hooded FILE that harvests only what walks into it — no chase. And the
Iron Giant is a machine-shape that stands up out of the far mist at the light's turn, too tall,
one red running-light turning over once, gone when the grey shifts — sighted, mailed, and after
three sightings the Republic posts a standing watch. (The far shape draws LATE, after the mist
that would otherwise bury it, with the world transform restored by hand — a render-order bug
found and fixed in this pass; without it the shape would never have appeared in play at all.)

**THE MOUNTAIN ROAD — the expansion door, funded and CUT.** The pass the Farkeepers walked DOWN
when the Order fed the Farlands famine is cut back UP: a road-gang project on the Darklands
table's far east edge. When it opens, the Farlands go live on the globe, Farkeep answers the wire
with its own desk, and the kit of the mountain HIRES — the Longbowman (answers trouble at 320),
the Rifle Rider (a breech and a horse, 380), the Berserker (a claymore and a horrible knock up
close). The intercept READS THE CLASS ROW: a ward meets a runner from its own trade — a fist
knocks him flat, a bow or a breech DROPS him where he stands. A future class is a stats row.

**THE DIEFENBUNKER, WALKED.** The cold door, once knocked open (v3.30), now STEPS INSIDE — a
registry ROOM with its own floor: concrete ribs, cold strip light, lockers, the SBSN log desk
you can read standing up, the brass wall of a century's names, and the armory cage with the
red-stencilled C20 crate. Nothing made of grey follows you in. The room is a data row
(INTERIORS.diefenbunker); Farkeep's long hall and Shutterlight's guild room are future rows on
the same engine.

**Proof.** republic.mjs — 19 checks measuring the WORLD: the registries seed real open ground,
the seals hold against play, the truce gates then walks and stands the camps AND the horns down,
the rising douses a lamp with no core posted, the parley and the quell each restore it (the quell
marching on real ground, paying appreciation, raising a Standing Teeth stone), the shrines feed
and climb the ladder, the procession harvests only what walks in, the far shape stands whole in
frame, the mountain road cuts and lives the whole kit, the class-read intercept drops a runner at
range, the hall is walked end to end, and the banner sheet obeys the modal law with no TODO
anywhere. Full battery **~590 tallied checks across thirty-six suites, zero fails**; shop audit
CLEAN.


## The asset pass (v3.33 — the PixelLab pipeline, on our terms)

The gate opened: PixelLab credits landed (a Pixel Artisan subscription, 3,324 generations in the
cycle). The asset law had been written for this moment — generate → quantize to OUR bands → embed
as rows, never hotlink — and the pass spent twenty generations proving where that law holds and
where it doesn't.

**Where it doesn't: people.** The Farkeeper probe came back clean and thirty-eight texels tall in
realistic proportion. Against the hand-authored 12×18 rig it is a giant at native scale (canon says
NOT giants) and a nine-wide stick at an integer downscale. No scale makes a generated human sit in
this game's stocky texel grammar — so the rig stays hand-authored, as the standing directive
already said, and THE KIT was DRAWN: five Farkeeper classes at 14×22 in the walker's own letters —
a head taller and a hand wider, which v3.22 had faked with a 1.16×1.22 scale and v3.33 now draws.
The Pugugly's shoulders fill the grid; the Longbowman carries the stave up the back; the Berserker's
claymore stands over the shoulder above a fur collar; the Rifle Rider's breech crosses the back; the
Recon Rider wears the pale short cloak. The Flame Keeper tender — promised at ALLY since v3.32 and
never drawn — is drawn, and stands the fed bowls with her torch.

**Where it holds: the stable.** A horse is a big object with more texels, and at the right size the
generated quadruped lands at exactly this world's density (3 screen px a texel) and proportion. The
right size was the discovery: the standard model draws the animal to the requested size inside its
canvas, and size 24 yields 26–30 texels of horse — a walker's height and a half its length,
which is what a horse is. (Size 48 gave house-sized animals; a ×2 downscale of those gave mush —
legs merged, shading gone — and was rejected on sight.) Six were generated: the five breeds the
data already named and the caravan donkey the field crews already hauled with, each with a
four-frame template walk. Every one is DISTINCT — dun Mustang with black points, dun Fjord with the
cream upright mane, white Arabian, black Percheron with the massive neck, chestnut Icelandic under a
flaxen mane, and the grey donkey with its crates lashed on.

**The quantize.** Each sprite's opaque pixels are clustered by a k-means in CIE Lab (six centres —
hue survives, so the donkey's crates stay wood beside a grey coat), each centre snapped to the
nearest of the game's own sprite bands (the union of every authored palette plus a set of coat
bands), letters assigned darkest→lightest with the outline forced to the game's one outline. Rows
are cropped on ONE bounding box across a frame set (pivot-centred frames keep their anchors), then
cluster-disciplined: a texel whose four neighbours all differ is noise, not a cluster, and takes the
majority. The registry row carries the anchors — GROUND under the hooves, SEAT on the back — and
the renderer composes any rider onto the seat with exact texel math (a texel is k buffer pixels,
k/m.a local units under whatever transform the caller stands in). One `drawMount` serves every
saddle in the game: the player's rented breed, the militia and rescue wards on the Farkeepers' own
Fjords, companions on their home town's stable, the ride set-piece, the caravan donkey. The authored
HORSE_F stands as the fallback row. The walk runs on an UNEVEN cadence (0.17 · 0.11 · 0.17 · 0.11),
per the audited research: a four-beat with two short beats reads as a gait, not a loop.

**A bug the pass surfaced.** `glyphSprite` cached by the FIRST row only; every idle/A/B frame of a
figure shares its top row, so the first walk cycle through the cache would have collided every
frame into one. The key now hashes every row.

**What waits.** The courier set was queued against the user's own 32×32 sheet as the style
reference; that sheet is not in the workspace, so the player rig was left exactly as authored
rather than regenerated blind. When the sheet lands, the pipeline is ready for it.

**Proof.** assets.mjs, 13 checks: the registry embeds (no URL, under budget), integrity (rectangular
rows, letters in palette, anchors inside), THE SCALE LAW (horses 24–32 × 18–26, classes 14×22, the
tender 12×18), distinctness of every breed/class/frame, zero orphan texels, the uneven cadence — and
ON SCREEN: five mounts as five different pictures, the seat anchor on the back, three hired classes
as three different figures, the crated donkey and the torch-bearing tender in pixels, the fallback
row standing, the cache key fixed. Full battery **~583 tallied checks across thirty-seven suites,
zero fails**; shop audit CLEAN; twenty generations spent, 3,304 in hand.
