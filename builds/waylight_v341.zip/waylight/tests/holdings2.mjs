/* holdings2.mjs — v3.39 THE LOSABLE HOLDINGS: the v3.34 REMAINING, whole. The registries (the
   storming doctrine gated on the road, the watchpost's storm rows, seven world events); THE
   STORMING of a risen town (the column, the arrival, the garrison: lit, the love gone, relations
   written, the Unlit's season, the garrison eating off the shelf, the town unable to rise, the
   shields and the pennant in the yard, RELEASE); THE POST STORMED (the reprisal season's night
   roll, LOST against two shields with the ring reverting, the fallen pennant, the price of a retake;
   STAND THE POST; HELD at three shields; the walker's presence counting); the two new wars of the
   grey banners (a larder raided — burns low, the camp's stash richer; the file's crossing — hushed,
   no bite); the banner sheet; the lessons; the save. */
import { chromium } from 'playwright';
const results = [];
const ok = (name, cond, extra = '') => { results.push(`${cond ? 'PASS' : 'FAIL'}  ${name}${extra ? '  — ' + extra : ''}`); if (!cond) process.exitCode = 1; };
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium', args: ['--disable-background-networking'] });
const page = await b.newPage({ viewport: { width: 1440, height: 860 } });
await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
const errors = [];
page.on('pageerror', e => errors.push(String(e.message)));
await page.goto('file:///home/claude/waylight/dist/test.html?debug', { waitUntil: 'domcontentloaded' });
await page.waitForFunction(() => window.WL && WL.snapshot && WL.snapshot().baked, null, { timeout: 60000 });
await page.evaluate(() => localStorage.clear());
await page.click('#btnNew'); await page.waitForTimeout(300);
await page.click('#btnBegin'); await page.waitForTimeout(400);
await page.click('#briefGo'); await page.waitForTimeout(300);
await page.click('#cgBegin'); await page.waitForTimeout(1200);
for (let i = 0; i < 30; i++) { const c = await page.evaluate(() => !!S.cine); if (!c) break; await page.evaluate(() => WL.skipCine()); await page.waitForTimeout(250); }
await page.evaluate(() => { S.flags.guideDone = true; WL.calm(); });
const ev = (fn, arg) => page.evaluate(fn, arg);

/* ================= 1 · THE REGISTRIES ================= */
let r = await ev(() => {
  const D = REP.DOCTRINE.storm, W = REP.WATCHPOST.storm, E = REP.EVENTS;
  return {
    storm: !!D && D.needs === 'mountain' && D.column === 5 && D.likesHit > 0 && D.garrison === 2 && D.tithePeriod > 0 && D.titheGood === 'food' && D.releaseLikes > 0 && !!D.line,
    post: !!W && W.chance > 0 && W.knives === 3 && W.shieldsMax === 4 && W.retakeMul > 1 && !!W.reinforceCost.metal && W.fallenDur > 0,
    events: Object.keys(E).length, kinds: Object.values(E).map(e => e.kind).join(),
    newRows: ['unlitReprisal', 'larderRaid', 'reaperVisit'].every(k => E[k] && E[k].actor && E[k].victim && E[k].mail && E[k].line),
    pairs: ['cannibals|raiders', 'cannibals|reapers', 'farkeep|rebels'].every(k => REP.RELATIONS.base[k] !== undefined),
    lessons: ['firstStorm', 'firstPostFell'].every(k => DATA.tutorials[k] && DATA.tutorialTitles[k]),
  };
});
ok('THE REGISTRIES: a storming doctrine gated on the road (five shields, a garrison of two, a tithe of rations, a release), the watchpost\'s storm rows (three knives, four shields at most, a dearer retake), eight world events now — a second reprisal, two wars of the grey banners on pairs the ledger already held, and the Society\'s sweep — and two lessons', r.storm && r.post && r.events === 8 && r.kinds === 'strike,strike,court,reprisal,reprisal,strike,strike,strike' && r.newRows && r.pairs && r.lessons, JSON.stringify(r));

/* ================= 2 · THE STORMING ================= */
r = await ev(() => {
  S.banked.metal = 600; S.banked.wood = 300; S.banked.provisions = 400; S.banked.ceramic = 80;
  for (const id of ['elm', 'mill', 'green', 'quarry']) S.stations[id].connected = true;
  S.cov = 0.5;
  /* a rising at the quarry; the road not yet cut — the storming stands gated beside the quell */
  Republic.rebellionStrike('quarry');
  const gatedBefore = !Republic.canStorm('quarry').ok, refused = !Republic.fundStorm('quarry');
  RepublicUI.open();
  const btn = document.querySelector('#repBody [data-storm="quarry"]');
  const gatedBtn = !!btn && btn.disabled, quellBeside = !!document.querySelector('#repBody [data-quell="quarry"]');
  RepublicUI.close();
  /* the road cut: the storming is on the table */
  Republic.fundMountain(); Republic.mountain().t = REP.MOUNTAIN.dur + 1; Republic.tick(0.6);
  const st = S.stations.quarry; st.likesTo = 50;
  const m0 = S.banked.metal, p0 = S.banked.provisions;
  const funded = Republic.fundStorm('quarry');
  const q = Republic.quell();
  const marching = q && q.kind === 'storm' && q.target === 'quarry' && q.col === 5 && q.pts.length > 1;
  const paid = m0 - S.banked.metal === REP.DOCTRINE.storm.cost.metal && p0 - S.banked.provisions === REP.DOCTRINE.storm.cost.provisions;
  const relBefore = Republic.rel('rebels', 'waylight'), relFk = Republic.rel('farkeep', 'rebels');
  const mr = Math.random; Math.random = () => 0.9;   // no stone this time
  q.t = q.dur + 1; Republic.tick(0.02);
  Math.random = mr;
  const lit = st.connected && !Republic.isUnlit('quarry'), held = Republic.isHeld('quarry');
  const loveGone = st.likesTo === 10;
  const relShift = Republic.rel('rebels', 'waylight') === relBefore - 1 && Republic.rel('farkeep', 'rebels') === relFk - 2;   // the storming, then the Unlit's own answer
  const season = !!Republic.unlitReprisal();
  const mail = S.mails.find(m => /taken by the mountain/.test(m.subj));
  const lesson = !!S.flags.tut.firstStorm;
  return { gatedBefore, refused, gatedBtn, quellBeside, funded, marching, paid, lit, held, loveGone, relShift, season, mail: !!mail, lesson };
});
ok('THE STORMING: gated beside the quell until the road is cut (the button stands disabled, the fund refused); funded, five shields march on the door; the arrival LIGHTS the town under a GARRISON — forty likes gone, the relations written (Farkeep↔the Unlit two steps: the storming and their answer), the Unlit\'s season begun, the mail and the lesson', r.gatedBefore && r.refused && r.gatedBtn && r.quellBeside && r.funded && r.marching && r.paid && r.lit && r.held && r.loveGone && r.relShift && r.season && r.mail && r.lesson, JSON.stringify(r));

/* ================= 3 · HELD GROUND: the garrison eats, the town cannot rise, the yard shows it, RELEASE ================= */
r = await ev(() => {
  const st = S.stations.quarry, D = REP.DOCTRINE.storm;
  st.stock.food = 60;
  const f0 = st.stock.food;
  S.cov = 0.1;   // the drum held still while the tithe is counted (below the wire's floor no rising ticks)
  for (let i = 0; i < D.tithePeriod * 2 + 4; i += 0.5) Republic.tick(0.5);
  S.cov = 0.5;   // the wire matters again (the storm's relight recomputed coverage from the lamps that stand)
  const ate = Math.round(f0 - st.stock.food), fed = Republic.held().quarry.ate;
  /* the drum beats faster in the season — measured over one whole flush of the slow clock */
  const R = REP.REBELLION, r2 = S.rep, mul = REP.EVENTS.unlitReprisal.pressureMul;
  r2.pressure = 0; r2.courted = null;
  Republic.tick(0.5); Republic.tick(0.5); const rate = r2.pressure;
  const perSec = stanceMul => (1 / stanceMul) * mul;
  const rateOk = Math.abs(rate - perSec(R.posturePeriodMul[Republic.stance('rebels') === 'WARY' ? 'WARY' : 'HOSTILE'])) < 0.4;   // one second of the season's drum, give or take the slow clock's remainder
  /* the quarry is NEVER the pick while garrisoned: the hottest town by far, and the rising goes elsewhere */
  S.heat.quarry = 99; r2.pressure = R.period + 1; const dark0 = Object.keys(r2.unlit).length;
  Republic.tick(0.6);
  const rose = Object.keys(r2.unlit), notQuarry = rose.length === dark0 + 1 && !rose.includes('quarry');
  for (const id of rose) { delete r2.unlit[id]; S.stations[id].connected = true; S.stations[id].litT = 1; } State.refreshSources(); S.heat.quarry = 0;
  const rateBase = perSec(R.posturePeriodMul.HOSTILE);
  /* on the ground: two shields in the square and the pennant on the pole */
  WL.tp([DATA.stations.quarry.x, DATA.stations.quarry.y + 120]);
  return new Promise(res => setTimeout(() => {
    const cv = document.getElementById('game'), g = cv.getContext('2d');
    const img = g.getImageData(0, 0, cv.width, cv.height).data;
    let grey = 0; for (let i = 0; i < img.length; i += 4) { const R2 = img[i], G = img[i + 1], B = img[i + 2]; if (R2 > 120 && R2 < 160 && G > 135 && G < 175 && B > 140 && B < 185) grey++; }
    /* RELEASE: the garrison leaves, ten likes come back, the town may rise again */
    const l0 = st.likesTo;
    const released = Republic.release('quarry');
    const free = !Republic.isHeld('quarry'), likesBack = st.likesTo === l0 + D.releaseLikes;
    const mail = S.mails.find(m => /marches home/.test(m.subj));
    res({ ate, fed, rateOk, rate, rateBase, notQuarry, rose, grey, released, free, likesBack, mail: !!mail });
  }, 1700));
});
ok('HELD GROUND: the garrison eats six rations off the quarry\'s shelf in two tithe periods (and the ledger counts them); the Unlit\'s drum beats at the season\'s rate; the hottest town in the valley is never the pick while garrisoned — the rising goes elsewhere; the square shows Farkeep\'s grey (shields and the pennant); RELEASE frees the town, gives ten likes back, and mails it', r.ate === 6 && r.fed === 6 && r.rateOk && r.notQuarry && r.grey > 30 && r.released && r.free && r.likesBack && r.mail, JSON.stringify(r));

/* ================= 4 · THE POST STORMED: lost against two, the ring reverts, the retake dearer ================= */
r = await ev(() => {
  WL.tp([DATA.stations.haven.x, DATA.stations.haven.y + 60]);
  S.banked.metal = 600; S.banked.wood = 300; S.banked.provisions = 400;
  const cd = DATA.camps[0];
  const funded = Republic.fundTake(cd.id);
  const q = Republic.quell();
  const mr = Math.random; Math.random = () => 0.9;
  q.t = q.dur + 1; Republic.tick(0.02);
  Math.random = mr;
  const c = S.camps[cd.id];
  const held = !!c.taken && c.taken.shields === REP.WATCHPOST.shields && !!Republic.reprisal();
  const near = (() => { let bId = 'haven', bd = 1e9; for (const id of DATA.stationOrder) { const d = U.dist(cd.x, cd.y, DATA.stations[id].x, DATA.stations[id].y); if (d < bd) { bd = d; bId = id; } } return bId; })();
  const likes0 = S.stations[near].likesTo;
  /* the season's night: the roll, forced to come, with the walker far away */
  const T2 = DATA.T, day0 = Math.floor(S.time / T2.dayLen) * T2.dayLen;
  S.time = day0 + T2.dayLen * 0.75;
  Math.random = () => 0.1;   // the storm comes, and the stone is raised
  Republic.tick(0.6);
  Math.random = mr;
  const lost = !c.taken && !c.pacified && !!c.lost && c.lost.n === 1;
  Systems.update(0.25, {});   // the ring respawns its runners
  const runnersBack = c.runners.length > 0, stashGone = c.stash.length === 0;
  const likesHit = S.stations[near].likesTo === Math.max(0, likes0 - REP.WATCHPOST.storm.lostLikes);
  const mail = S.mails.find(m => /watchpost FELL/.test(m.subj)), stone = S.legacy.some(l => /lost/.test(l.fate));
  const lesson = !!S.flags.tut.firstPostFell;
  const cost2 = Republic.takeCost(cd.id), dearer = cost2.metal === Math.round(REP.DOCTRINE.take.cost.metal * REP.WATCHPOST.storm.retakeMul);
  const onceOnly = c.lost && S.time - c.lost.t < 5;
  return { funded, held, lost, runnersBack, stashGone, likesHit, mail: !!mail, stone, lesson, cost2, dearer, onceOnly };
});
ok('THE POST STORMED: taken and held at two shields in the reprisal season; the night\'s roll comes with the walker far away — three knives against two shields — and the post is LOST: the ring is the camps\' again with its runners back and the salvage scattered, the nearest town six likes poorer, the mail, a stone, the lesson; the retake now costs ×1.5', r.funded && r.held && r.lost && r.runnersBack && r.stashGone && r.likesHit && r.mail && r.stone && r.lesson && r.dearer, JSON.stringify(r));

/* ================= 5 · STAND THE POST, and the walker standing it ================= */
r = await ev(() => {
  const cd = DATA.camps[0], c = S.camps[cd.id];
  S.banked.metal = 900; S.banked.wood = 300; S.banked.provisions = 400;
  const m0 = S.banked.metal;
  const retaken = Republic.fundTake(cd.id);
  const paidMore = m0 - S.banked.metal === Republic.takeCost(cd.id).metal && m0 - S.banked.metal > REP.DOCTRINE.take.cost.metal;
  const q = Republic.quell();
  const mr = Math.random; Math.random = () => 0.9; q.t = q.dur + 1; Republic.tick(0.02); Math.random = mr;
  const held2 = !!c.taken;
  /* STAND THE POST: three shields match three knives */
  const stood = Republic.standPost(cd.id), shields = c.taken.shields;
  const T2 = DATA.T, day0 = Math.floor(S.time / T2.dayLen) * T2.dayLen;
  S.time = day0 + T2.dayLen * 0.75; c.taken.stormDay = -1;
  Math.random = () => 0.1; Republic.tick(0.6); Math.random = mr;
  const heldAgainst = !!c.taken, heldMail = S.mails.find(m => /the post HELD/.test(m.subj));
  /* the walker's own presence: two shields, the walker in the ring with a fed back — 2 + 1 + 1 = 4 ≥ 3 */
  c.taken.shields = 2; c.taken.stormDay = -1;
  const a = NPC.gen({ at: 'haven' }); a.feeWaived = true; S.npcs.push(a); NPC.hire(a, 'companion');
  WL.tp([cd.x + 40, cd.y + 40]); a.cx = S.px; a.cy = S.py;
  S.time = day0 + T2.dayLen * 0.76;
  Math.random = () => 0.1; Republic.tick(0.6); Math.random = mr;
  /* v3.40: with the walker in the ring the night is not rolled — the knives are on the ground (standing.mjs fights it out); the arithmetic is asked by hand here */
  const seen = !!c.storm && c.storm.knives.length === REP.WATCHPOST.storm.knives && !!c.taken;
  c.storm = null;
  Math.random = () => 0.9; const resolvedHeld = Republic.stormPost(cd, 'resolve') === false; Math.random = mr;
  const walkerHeld = resolvedHeld && !!c.taken, walkerMail = S.mails[0] && /the post HELD/.test(S.mails[0].subj) && /walker who stood the fire with 1 back/.test(S.mails[0].body);
  /* the sheet: the shields count and STAND THE POST on the row; the max refused */
  c.taken.shields = REP.WATCHPOST.storm.shieldsMax;
  const refusedMax = !Republic.standPost(cd.id);
  const mr2 = Math.random; Math.random = () => 0.9; const heldAtMax = Republic.stormPost(cd, 'resolve') === false && !!c.taken; Math.random = mr2;   // four shields against three knives, resolved by hand: the post holds
  RepublicUI.open();
  const html = document.getElementById('repBody').innerHTML;
  const row = /4\/4<\/b> shields stand the fire/.test(html), standBtn = document.querySelector(`#repBody [data-stand="${cd.id}"]`), disabledAtMax = standBtn && standBtn.disabled, warned = /may STORM it by night/.test(html);
  RepublicUI.close();
  for (const n of S.npcs.filter(x => x.state === 'companion')) n.state = 'pool';
  WL.tp([DATA.stations.haven.x, DATA.stations.haven.y + 60]);
  return { retaken, paidMore, held2, stood, shields, heldAgainst, heldMail: !!heldMail, seen, walkerHeld, walkerMail, refusedMax, heldAtMax, row, disabledAtMax, warned };
});
ok('STAND THE POST: retaken at the dearer price; a third shield stands the fire and the night\'s storm BREAKS on it (the mail says so); at two shields the walker standing the ring sees the knives come (the night is not rolled), and resolved by hand with a fed back holds it too, the mail naming them; the sheet shows the shields of four, STAND THE POST disabled at the most, and the season\'s warning', r.retaken && r.paidMore && r.held2 && r.stood && r.shields === 3 && r.heldAgainst && r.heldMail && r.seen && r.walkerHeld && r.walkerMail && r.refusedMax && r.heldAtMax && r.row && r.disabledAtMax && r.warned, JSON.stringify(r));

/* ================= 6 · THE WARS OF THE GREY BANNERS ================= */
r = await ev(() => {
  const E = REP.EVENTS;
  for (const k of Object.keys(E)) S.rep.evCd[k] = 99999;   // the world's own clocks held: this check fires the wars by hand
  const larder = Republic.sites('hollowfire')[0];
  larder.hushed = 0; larder.raided = 0;   // whatever the file and the camps did on their own in the nights above, the larder starts this check whole
  const cd = DATA.camps.find(x => !S.camps[x.id].taken && !S.camps[x.id].pacified) || DATA.camps[1];
  const c = S.camps[cd.id]; c.stash = [];
  const relRC = Republic.rel('raiders', 'cannibals');
  const fired = Republic.fireEvent('larderRaid', { site: larder, camp: cd });
  const low = larder.raided === S.time, meat = c.stash.length === 1 && c.stash[0].defId === 'food';
  const relDown = Republic.rel('raiders', 'cannibals') === relRC - 1;
  const mail = S.mails.find(m => /raided a larder/.test(m.subj)) && /the fire there burns low/.test(S.mails[0].body);
  /* the ring halves: at 0.55 of the danger radius by night, nothing bites while the fire is low */
  const T2 = DATA.T, day0 = Math.floor(S.time / T2.dayLen) * T2.dayLen;
  S.time = day0 + T2.dayLen * 0.8;
  const H = REP.PRESENCES.hollowfire;
  WL.tp([larder.x + H.dangerR * 0.55, larder.y]); S.room = null;
  const hp0 = S.health; larder.biteT = 0;
  for (let i = 0; i < 12; i++) Republic.tick(0.5);
  const noBiteLow = S.health === hp0;
  larder.raided = 0;   // the fire back up: the same spot bites
  for (let i = 0; i < 12; i++) Republic.tick(0.5);
  const bitesFull = S.health < hp0;
  /* the file's crossing: hushed, no bite even in the ring's heart */
  S.health = hp0;
  const relRe = Republic.rel('reapers', 'cannibals');
  const fired2 = Republic.fireEvent('reaperVisit', larder);
  const hushed = larder.hushed > S.time, relRe2 = Republic.rel('reapers', 'cannibals') === relRe - 1;
  WL.tp([larder.x + 40, larder.y]);
  for (let i = 0; i < 12; i++) Republic.tick(0.5);
  const noBiteHushed = S.health === hp0;
  const mail2 = S.mails[0] && /walked through a larder/.test(S.mails[0].subj);
  /* the sheet reads the larder */
  RepublicUI.open(); const html = document.getElementById('repBody').innerHTML; RepublicUI.close();
  const plate = /HUSHED — THE FILE PASSED/.test(html);
  /* the needs resolve from the live world: a larder a live camp can reach, a larder in the mist */
  larder.hushed = 0; larder.raided = 0;
  const need1 = (function () { const out = []; for (const s2 of Republic.sites('hollowfire')) for (const cd2 of DATA.camps) { const c2 = S.camps[cd2.id]; if (c2 && !c2.pacified && !c2.taken && U.dist(cd2.x, cd2.y, s2.x, s2.y) < E.larderRaid.reach) out.push(1); } return out.length; })();
  WL.tp([DATA.stations.haven.x, DATA.stations.haven.y + 60]); S.time = day0 + T2.dayLen * 0.2;
  return { fired, low, meat, relDown, mail: !!mail, noBiteLow, bitesFull, fired2, hushed, relRe2, noBiteHushed, mail2: !!mail2, plate, need1 };
});
ok('THE WARS OF THE GREY BANNERS: a camp\'s raid on a larder leaves the fire burning LOW (no bite at half the ring while it lasts; the same spot bites once the fire is back), a crate of rations in the camp\'s stash, the relation a step colder and the mail; the file\'s crossing HUSHES the larder (no bite in its heart), the relation colder, the sheet reading it — and the needs resolve from the live world', r.fired && r.low && r.meat && r.relDown && r.mail && r.noBiteLow && r.bitesFull && r.fired2 && r.hushed && r.relRe2 && r.noBiteHushed && r.mail2 && r.plate && r.need1 >= 1, JSON.stringify(r));

/* ================= 7 · THE SAVE ================= */
r = await ev(() => {
  Republic.rebellionStrike('green');
  Republic.fundStorm('green'); const q = Republic.quell(); const mr = Math.random; Math.random = () => 0.9; q.t = q.dur + 1; Republic.tick(0.02); Math.random = mr;
  const cd = DATA.camps[0], c = S.camps[cd.id];
  const shields = c.taken.shields, lostN = c.lost.n;
  State.save(); const loaded = State.load();
  const c2 = S.camps[cd.id];
  return { loaded, held: Republic.isHeld('green'), ate: typeof Republic.held().green.tithe === 'number', shields: c2.taken.shields === shields, lost: c2.lost && c2.lost.n === lostN, season: !!Republic.unlitReprisal() };
});
ok('THE SAVE carries a garrisoned town with its tithe clock, a post\'s shields and its record of falls, and the Unlit\'s season', r.loaded && r.held && r.ate && r.shields && r.lost && r.season, JSON.stringify(r));

const realErrors = errors.filter(e => !/CHIP-FAULT/.test(e));
ok('no uncaught page errors across the losable holdings', realErrors.length === 0, realErrors.join(' | ').slice(0, 300));
console.log(results.join('\n'));
console.log(`\n${results.filter(x => x.startsWith('PASS')).length}/${results.length} passed`);
await b.close();
