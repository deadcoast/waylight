/* postorders.mjs — v3.38 THE POSTED ORDERS: the posts on the same store, the working world's mood,
   the wedge and the chain on the survey sheet. The registry rows for the posts; THE HOURS keeping
   the shift clock to daylight or lamplight (a resting hand on the plate); THE KEEP taking rations
   off the town's own shelf for thinner thanks, stalling at the floor; THE TRAINING splitting the
   lesson to the weakest skill; the mood's working causes (greyfall, nights, far from home, a town
   that thanks them, the table) on field hands and post hands with the work pace they set; a DONE
   field hand coming in with the mail; the survey drawing field hands, a presser's flags and line,
   and the wedge at the walker's marker in the walker's frame; the lesson; the save. */
import { chromium } from 'playwright';
const results = [];
const ok = (name, cond, extra = '') => { results.push(`${cond ? 'PASS' : 'FAIL'}  ${name}${extra ? '  — ' + extra : ''}`); if (!cond) process.exitCode = 1; };
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium', args: ['--disable-background-networking'] });
const page = await b.newPage({ viewport: { width: 1440, height: 860 } });
await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
const errors = [];
page.on('pageerror', e => errors.push(String(e.message)));
await page.goto('file:///home/claude/waylight/dist/test.html?debug', { waitUntil: 'domcontentloaded' });
await page.waitForFunction(() => window.WL && WL.snapshot && WL.snapshot().baked, null, { timeout: 60000 });
await page.evaluate(() => localStorage.clear());
await page.click('#btnNew'); await page.waitForTimeout(300);
await page.click('#btnBegin'); await page.waitForTimeout(400);
await page.click('#briefGo'); await page.waitForTimeout(300);
await page.click('#cgBegin'); await page.waitForTimeout(1200);
for (let i = 0; i < 30; i++) { const c = await page.evaluate(() => !!S.cine); if (!c) break; await page.evaluate(() => WL.skipCine()); await page.waitForTimeout(250); }
await page.evaluate(() => { S.flags.guideDone = true; WL.calm(); });
const ev = (fn, arg) => page.evaluate(fn, arg);

/* ================= 1 · THE REGISTRY ================= */
let r = await ev(() => {
  const W = MUSTER.WORK_ORDERS, P = MUSTER.POST, M = MUSTER.MOOD;
  const postWhole = P.rows.every(k => W[k] && W[k].name && W[k].choices[W[k].def]);
  const hours = W.hours && Object.keys(W.hours.choices).join() === 'full,days,nights' && W.hours.appr.nights === 1;
  const keep = W.keep && W.keep.apprMul.table < 1 && W.keep.food.table > 0 && W.keep.foodFloor > 0;
  const training = W.training && Object.keys(W.training.choices).join() === 'round,cross';
  const causes = ['greyfall', 'nightWork', 'far', 'thanked', 'table'].every(id => M.causes[id] && M.causes[id].line);
  const workMul = M.bands.every(b2 => typeof M.fx[b2[1]].workMul === 'number') && M.fx.BRIGHT.workMul > 1 && M.fx.LOW.workMul < 1;
  return { rows: P.rows.join(), postWhole, hours, keep, training, causes, causesN: Object.keys(M.causes).length, workMul, total: Object.keys(W).length };
});
ok('THE REGISTRY: the posts walk under three rows (THE HOURS full/days/nights, THE TRAINING round/cross, THE KEEP wages/table) on the same WORK_ORDERS table (ten rows now), five working causes joined the mood (twenty-one; twenty-five since v3.44 with the stones\'s own two, twenty-six with v3.45\'s score to settle), and every band carries a work pace', r.rows === 'hours,training,keep' && r.postWhole && r.hours && r.keep && r.training && r.causes && r.causesN === 26 && r.workMul && r.total === 10, JSON.stringify(r));

/* ================= 2 · THE HOURS ================= */
r = await ev(() => {
  S.banked.provisions = 400;
  const n = NPC.gen({ at: 'haven', cls: 'courier' }); n.feeWaived = true; S.npcs.push(n);
  NPC.hire(n, 'post'); NPC.assignPost(n, 'haven', 'runner');
  const sheet = NPC.workOf(n);
  const T2 = DATA.T, day0 = Math.floor(S.time / T2.dayLen) * T2.dayLen;
  /* days: the clock ticks in daylight, rests at night */
  NPC.setOrder(n, 'hours', 'days');
  S.time = day0 + T2.dayLen * 0.2; n.shiftT = 1;   // morning, a shift about to close
  const s0 = NPC.svc(n).shifts || 0;
  for (let i = 0; i < 8; i++) Systems.update(0.25, {});
  const dayShift = (NPC.svc(n).shifts || 0) - s0, restingDay = !!n.resting;
  S.time = day0 + T2.dayLen * 0.8; n.shiftT = 1;   // night: the same hand rests, the clock stands
  const s1 = NPC.svc(n).shifts || 0;
  for (let i = 0; i < 8; i++) Systems.update(0.25, {});
  const nightShift = (NPC.svc(n).shifts || 0) - s1, restingNight = !!n.resting, clockHeld = n.shiftT === 1;
  /* nights: the lamp-lit round pays the town one more */
  NPC.setOrder(n, 'hours', 'nights'); n.shiftT = 1;
  const a0 = S.stations.haven.appr;
  for (let i = 0; i < 8; i++) Systems.update(0.25, {});
  const nightAppr = S.stations.haven.appr - a0, nightNote = NPC.svc(n).last;
  NPC.setOrder(n, 'hours', 'full'); S.time = day0 + T2.dayLen * 0.2; n.shiftT = 1;
  const a1 = S.stations.haven.appr;
  for (let i = 0; i < 8; i++) Systems.update(0.25, {});
  const fullAppr = S.stations.haven.appr - a1;
  window._post = n.id;
  return { kind: sheet.kind, rows: Object.keys(sheet.rows), name: sheet.name, dayShift, restingDay, nightShift, restingNight, clockHeld, nightAppr, nightNote, fullAppr, postAppr: DATA.T.postAppr };
});
ok('THE HOURS: a post hand\'s sheet is hours + training + keep; under DAYS a morning shift closes and a night one never starts (resting, the clock held); under NIGHTS the lamp-lit round pays the town one more than a full round does', r.kind === 'post' && r.rows.join() === 'hours,training,keep' && r.dayShift === 1 && !r.restingDay && r.nightShift === 0 && r.restingNight && r.clockHeld && r.nightAppr === r.fullAppr + 1 && /lamplight/.test(r.nightNote), JSON.stringify(r));

/* ================= 3 · THE KEEP ================= */
r = await ev(() => {
  const n = S.npcs.find(x => x.id === window._post);
  NPC.setOrder(n, 'keep', 'table');
  const st = S.stations.haven; st.stock.food = 30;
  const p0 = S.banked.provisions, f0 = st.stock.food, a0 = st.appr;
  n.shiftT = 1; for (let i = 0; i < 8; i++) Systems.update(0.25, {});
  const provisionsKept = S.banked.provisions === p0, foodTaken = Math.round((f0 - st.stock.food) * 10) / 10, tableAppr = st.appr - a0;
  const tableCause = NPC.mood(n).causes.some(c => c.id === 'table');
  /* the floor: a bare shelf stalls the round, and says so */
  st.stock.food = MUSTER.WORK_ORDERS.keep.foodFloor + 1;
  n.shiftT = 1; for (let i = 0; i < 8; i++) Systems.update(0.25, {});
  const stalled = n.hungry, note = NPC.svc(n).last;
  NPC.setOrder(n, 'keep', 'wages'); n.shiftT = 1; for (let i = 0; i < 8; i++) Systems.update(0.25, {});
  const resumed = !n.hungry && S.banked.provisions < p0;
  return { provisionsKept, foodTaken, tableAppr, tableCause, stalled, note, resumed, eat: MUSTER.WORK_ORDERS.keep.food.table };
});
ok('THE KEEP — the town\'s table: a shift draws no provision, takes two rations off Haven\'s own shelf (the stock drains besides) and pays half the thanks; the mood reads the table; at the floor the round STALLS and says the table is bare; back on wages it runs', r.provisionsKept && r.foodTaken >= r.eat && r.tableAppr === 1 && r.tableCause && r.stalled && /table is bare/.test(r.note) && r.resumed, JSON.stringify(r));

/* ================= 4 · THE TRAINING ================= */
r = await ev(() => {
  const n = S.npcs.find(x => x.id === window._post);
  for (const id of CHAR.SKILL_IDS) n.skills[id] = 3; n.skills.lum = 0; n.trainXp = {};
  NPC.setOrder(n, 'training', 'cross');
  n.shiftT = 1; for (let i = 0; i < 8; i++) Systems.update(0.25, {});
  const xpFoot = n.trainXp.foot || 0, xpLum = n.trainXp.lum || 0, note = NPC.svc(n).last;
  NPC.setOrder(n, 'training', 'round'); n.trainXp = {};
  n.shiftT = 1; for (let i = 0; i < 8; i++) Systems.update(0.25, {});
  const roundFoot = n.trainXp.foot || 0, roundLum = n.trainXp.lum || 0;
  return { xpFoot, xpLum, note, roundFoot, roundLum, shiftXp: DATA.T.shiftXp };
});
ok('THE TRAINING — cross-train: half the round\'s lesson lands on Footwork and half on the weakest skill (Lumen at nought), the note naming it; the round\'s verb alone puts the whole lesson on Footwork and none on Lumen', r.xpFoot > 0 && r.xpLum > 0 && r.xpLum <= r.xpFoot && /cross-training/.test(r.note) && r.roundFoot > r.xpFoot && r.roundLum === 0, JSON.stringify(r));

/* ================= 5 · THE WORKING WORLD'S MOOD ================= */
r = await ev(() => {
  S.stations.elm.connected = true;
  const T2 = DATA.T, day0 = Math.floor(S.time / T2.dayLen) * T2.dayLen;
  S.time = day0 + T2.dayLen * 0.2;
  const H = NPC.gen({ at: 'haven' }); H.feeWaived = true; H.skills.foot = 6; S.npcs.push(H);
  NPC.assignField(H, 'haven', 'hauler', 'elm');
  for (let i = 0; i < 4; i++) Systems.update(0.25, {});
  const dayIds = NPC.mood(H).causes.map(c => c.id);
  /* the greyfall falls where the mist is: the same hand read at the greenhouse's latitude, at night */
  S.time = day0 + T2.dayLen * 0.8; S.weather.state = 'grey'; S.weather.intensity = 1;
  const wasAt = [H.fx, H.fy]; H.fx = DATA.stations.green.x; H.fy = DATA.stations.green.y + 60;
  const rain = Systems.rainAt(H.fx, H.fy);
  const nightIds = NPC.mood(H).causes.map(c => c.id).join();
  H.fx = wasAt[0]; H.fy = wasAt[1];
  /* a hand thanked by an HONOURED town */
  S.stations.haven.appr = DATA.T.apprTiers[2];
  const thanked = NPC.mood(H).causes.some(c => c.id === 'thanked');
  /* far from home: a presser sent past the far line */
  const d = DATA.stations.haven;
  const P = NPC.gen({ at: 'haven' }); P.feeWaived = true; S.npcs.push(P);
  NPC.assignField(P, 'haven', 'presser', { x: d.x + 1500, y: d.y - 2100 });
  const far = NPC.mood(P).causes.some(c => c.id === 'far'), beyond = MUSTER.MOOD.causes.far.beyond;
  const spBright = MUSTER.MOOD.fx.BRIGHT.workMul, spLow = MUSTER.MOOD.fx.LOW.workMul;
  S.weather.state = 'clear'; S.weather.intensity = 0; S.time = day0 + T2.dayLen * 0.2; S.stations.haven.appr = 0;
  window._H2 = H.id; window._P2 = P.id;
  return { dayIds, rain, nightIds, thanked, far, beyond, spBright, spLow };
});
ok('THE WORKING WORLD\'S MOOD: a hauler on the Haven–Elm run by day in clear weather carries no cause; by night in the greyfall the plate reads working in the greyfall AND working nights; an HONOURED town thanks them; a presser sent past the far line (2.4 km) is far from home — and the bands set a work pace', r.dayIds.length === 0 && r.rain > 0 && r.nightIds === 'greyfall,nightWork' && r.thanked && r.far && r.beyond === 2400 && r.spBright > 1 && r.spLow < 1, JSON.stringify(r));

/* ================= 6 · A DONE FIELD HAND COMES IN ================= */
r = await ev(() => {
  const H = S.npcs.find(x => x.id === window._H2);
  const T2 = DATA.T, day0 = Math.floor(S.time / T2.dayLen) * T2.dayLen;
  /* the greyfall, the night, far from home, and no thanks — and unpaid on top: past the last band */
  S.time = day0 + T2.dayLen * 0.8; S.weather.state = 'grey'; S.weather.intensity = 1;
  H.route.b = 'green'; H.fpath = null; H.fx = DATA.stations.green.x; H.fy = DATA.stations.green.y + 60;   // the long haul, out where the mist is
  const home = DATA.stations.haven, green = DATA.stations.green;
  const farNow = U.dist(home.x, home.y, green.x, green.y) > MUSTER.MOOD.causes.far.beyond;
  S.banked.provisions = 0; H.shiftT = 0.1; Systems.update(0.25, {});   // the wage fails: unpaid, and they stand out there in it
  const m = NPC.mood(H);
  let t = 0; for (let i = 0; i < 400 && H.state === 'field'; i++) { Systems.update(0.25, {}); t += 0.25; }
  const mail = S.mails.find(m2 => m2.subj === `${H.name} came in`);
  S.weather.state = 'clear'; S.weather.intensity = 0; S.time = day0 + T2.dayLen * 0.2; S.banked.provisions = 400;
  return { farNow, v: m.v, band: m.band, ids: m.causes.map(c => c.id).join(), state: H.state, at: H.at, t, mail: !!mail, last: NPC.svc(H).last };
});
ok('A DONE FIELD HAND COMES IN: unpaid, in the greyfall, at night, far from home sums past the last band — after the minute the hauler comes in to Haven\'s fire, off the job, the mail naming every cause', r.farNow && r.band === 'DONE' && r.ids === 'unpaid,greyfall,nightWork,far' && r.state === 'pool' && r.at === 'haven' && r.t >= 58 && r.mail && /came in DONE/.test(r.last), JSON.stringify(r));

/* ================= 7 · THE SURVEY: field hands, the chain, the wedge ================= */
r = await ev(() => {
  const P = S.npcs.find(x => x.id === window._P2);
  const d = DATA.stations.haven;
  NPC.addMark(P, d.x + 1700, d.y - 300);
  for (let i = 0; i < 4; i++) Systems.update(0.25, {});
  for (const n of S.npcs.filter(x => x.state === 'companion')) n.state = 'pool';
  const a = NPC.gen({ at: 'haven', cls: 'medic' }); a.fee = { metal: 0, ceramic: 0 }; a.feeWaived = true; S.npcs.push(a); NPC.hire(a, 'companion'); NPC.setOrder(a, 'stand', 'hold');
  a.cx = S.px - 40; a.cy = S.py; S.dir = 0;
  UI.toggleMap(true);
  /* read the sheet's pixels: the chain's gold along the presser's line, a flag at each mark, the party's dot beside the marker */
  const c = document.getElementById('map'), ctx = c.getContext('2d');
  const m = ctx.getTransform();
  const toS = (x, y) => ({ x: m.a * x + m.e, y: m.d * y + m.f });
  const sample = (x, y, rad) => { const s2 = toS(x, y); const img = ctx.getImageData(Math.max(0, s2.x - rad), Math.max(0, s2.y - rad), rad * 2, rad * 2).data; let gold = 0, green = 0, mood = 0; for (let i = 0; i < img.length; i += 4) { const R = img[i], G = img[i + 1], B = img[i + 2]; if (R > 150 && G > 118 && G < 225 && B < 130 && R > G) gold++; if (G > 190 && R < 190 && B < 170) green++; if (R > 180 && G > 180 && B > 140 && B < 200) mood++; } return { gold, green, mood }; };
  const marks = NPC.marksOf(P);
  const flag1 = sample(marks[0].x, marks[0].y - 4, 8), flag2 = sample(marks[1].x, marks[1].y - 4, 8);
  /* the walked line: sampled at every third point of the path, summed (a dash may fall in a gap) */
  const line = { gold: 0 }; for (let i = 1; i < P.fpath.pts.length - 1; i += 3) { const pt2 = P.fpath.pts[i]; line.gold += sample(pt2[0], pt2[1], 5).gold; }
  const hand = sample(P.fx, P.fy, 5);
  const back = sample(S.px + (a.cx - S.px) * 0.55 / (m.a), S.py, 5);
  /* the party dot: 0.55 screen-px per world unit behind the marker along -x (S.dir = 0 → behind is west) */
  const dotS = toS(S.px, S.py); const px2 = ctx.getImageData(Math.round(dotS.x - 40 * 0.55) - 4, Math.round(dotS.y) - 4, 8, 8).data;
  let dotLit = 0; for (let i = 0; i < px2.length; i += 4) if (px2[i] + px2[i + 1] + px2[i + 2] > 380) dotLit++;
  const legend = document.getElementById('mapLegend').innerText;
  UI.toggleMap(false);
  return { flag1, flag2, line, hand, dotLit, legend: /field hands/.test(legend) && /presser/.test(legend) && /wedge/.test(legend), marks: marks.length };
});
ok('THE SURVEY draws the working world: a gold flag stands at each of the presser\'s two marks, the walked line is gold between them, the hand is a green pip, the party\'s back is a lit dot behind the walker\'s marker at the glyph\'s scale, and the legend names all three', r.flag1.gold >= 4 && r.flag2.gold >= 4 && r.line.gold >= 3 && r.hand.green >= 4 && r.dotLit >= 4 && r.legend && r.marks === 2, JSON.stringify(r));

/* ================= 8 · THE SHEET, THE LESSON, THE SAVE ================= */
r = await ev(() => {
  const n = S.npcs.find(x => x.id === window._post);
  NPC.setOrder(n, 'hours', 'nights'); NPC.setOrder(n, 'keep', 'table'); NPC.setOrder(n, 'training', 'cross');
  MusterUI.open(n.id);
  const pane = document.getElementById('muOrders').innerText;
  const rows = /THE HOURS/.test(pane) && /THE TRAINING/.test(pane) && /THE KEEP/.test(pane) && !/STATION/.test(pane) && !/THE FREIGHT LIST/.test(pane) && /at Haven/.test(pane);
  const stripe = document.querySelector(`.muPlate[data-mu="${n.id}"] .muSvc`).innerText;
  const ord = document.querySelector(`.muPlate[data-mu="${n.id}"] .muOrd`).innerText;
  document.querySelector('#muOrders [data-order="hours"][data-choice="days"]').click();
  const set = NPC.ordersOf(n).hours === 'days', lesson = !!S.flags.tut.firstPosted && !!DATA.tutorials.firstPosted && !!DATA.tutorialTitles.firstPosted;
  MusterUI.close();
  State.save(); const loaded = State.load();
  const n2 = S.npcs.find(x => x.id === n.id), O = NPC.ordersOf(n2);
  return { rows, stripe, ord, set, lesson, loaded, hours: O.hours, keep: O.keep, training: O.training, shifts: NPC.svc(n2).shifts };
});
ok('THE SHEET: a post hand\'s pane shows THE HOURS, THE TRAINING and THE KEEP at Haven (no walk rows, no freight list); the plate\'s stripe counts shifts, the skill trained and the appreciation given, stamped LETTER RUNNER — WORKING ORDERS; a click sets the hours and walks the lesson; THE SAVE carries hours, keep, training and the shifts', r.rows && /shifts/.test(r.stripe) && /appreciation given/.test(r.stripe) && /LETTER RUNNER — WORKING ORDERS/.test(r.ord) && r.set && r.lesson && r.loaded && r.hours === 'days' && r.keep === 'table' && r.training === 'cross' && r.shifts >= 4, JSON.stringify(r).slice(0, 500));

const realErrors = errors.filter(e => !/CHIP-FAULT/.test(e));
ok('no uncaught page errors across the posted orders', realErrors.length === 0, realErrors.join(' | ').slice(0, 300));
console.log(results.join('\n'));
console.log(`\n${results.filter(x => x.startsWith('PASS')).length}/${results.length} passed`);
await b.close();
