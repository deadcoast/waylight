/* kept.mjs — v3.45 THE WORD KEPT: the hands' faces (every hand on the keepers' alphabet, from the seed and the trade,
   on the cards, the muster plates, the passage slots and the new walker's sheet); a word remembered (the town's book,
   the keeper's errand, promises shut and opened again); the kin's errand (the shield brought home, the lantern carried
   lit to the stone); the grudge answered (the parley: a gift, a stand, a word — and the word broken); the Walker's score
   (a camp that fells one of the party, on the roll and the sheet, settled or cooled); the line at the ring (THE RING on
   the compass, the wedge abreast at the ring's edge facing the camp); the save. */
import { chromium } from 'playwright';
const results = [];
const ok = (name, cond, extra = '') => { results.push(`${cond ? 'PASS' : 'FAIL'}  ${name}${extra ? '  — ' + extra : ''}`); if (!cond) process.exitCode = 1; };
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium', args: ['--disable-background-networking'] });
const page = await b.newPage({ viewport: { width: 1440, height: 860 } });
await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
const errors = [];
page.on('pageerror', e => errors.push(String(e.message)));
await page.goto('file:///home/claude/waylight/dist/test.html?debug', { waitUntil: 'domcontentloaded' });
await page.waitForFunction(() => window.WL && WL.snapshot && WL.snapshot().baked, null, { timeout: 60000 });
await page.evaluate(() => localStorage.clear());
await page.click('#btnNew'); await page.waitForTimeout(300);
await page.click('#btnBegin'); await page.waitForTimeout(400);
await page.click('#briefGo'); await page.waitForTimeout(300);
/* the new walker's sheet: the bust on the keepers' alphabet, in the coat being cut, following the swatches */
const cg = await page.evaluate(async () => {
  const img = document.getElementById('cgPortrait'); await new Promise(r => setTimeout(r, 50));
  const src0 = img.src, sw = document.querySelector('#cgLookRows [data-look="hood:2"]'); if (sw) sw.click();
  await new Promise(r => setTimeout(r, 50));
  return { data: /^data:image\/png/.test(src0), w: img.naturalWidth, changed: img.src !== src0 && /^data:image\/png/.test(img.src) };
});
await page.click('#cgBegin'); await page.waitForTimeout(1200);
for (let i = 0; i < 30; i++) { const c = await page.evaluate(() => !!S.cine); if (!c) break; await page.evaluate(() => WL.skipCine()); await page.waitForTimeout(250); }
await page.evaluate(() => { S.flags.guideDone = true; WL.calm(); });
const ev = (fn, arg) => page.evaluate(fn, arg);
await ev(() => {
  window.__toScr = (wx, wy) => { const z2 = Render.effZoom() / devicePixelRatio; return { x: innerWidth / 2 + (wx - Render.cam.x) * z2, y: innerHeight / 2 + (wy - Render.cam.y) * z2 }; };
  window.__near = (wx, wy, col, tol, rad) => { const p = __toScr(wx, wy), cv = document.getElementById('game'), g = cv.getContext('2d'), dpr = devicePixelRatio; const x0 = Math.max(0, Math.round((p.x - rad) * dpr)), y0 = Math.max(0, Math.round((p.y - rad) * dpr)), w = Math.round(rad * 2 * dpr); const d = g.getImageData(x0, y0, w, w).data; let hit = 0; for (let i = 0; i < d.length; i += 4) if (Math.abs(d[i] - col[0]) < tol && Math.abs(d[i + 1] - col[1]) < tol && Math.abs(d[i + 2] - col[2]) < tol) hit++; return hit; };
  /* a face URL's own pixels: the colour at a texel of a 1× render */
  window.__texel = (url, x, y) => new Promise(res => { const im = new Image(); im.onload = () => { const c = document.createElement('canvas'); c.width = im.width; c.height = im.height; const g = c.getContext('2d'); g.drawImage(im, 0, 0); const k = im.width / 16, d = g.getImageData(Math.floor(x * k + k / 2), Math.floor(y * k + k / 2), 1, 1).data; res('#' + [d[0], d[1], d[2]].map(v => v.toString(16).padStart(2, '0')).join('')); }; im.src = url; });
  for (const k of Object.keys(REP.EVENTS)) S.rep.evCd[k] = 99999;
  for (const id of ['elm', 'mill', 'green', 'quarry']) S.stations[id].connected = true;
  S.banked.metal = 900; S.banked.wood = 300; S.banked.provisions = 500; S.banked.ceramic = 120;
});

/* ================= 1 · THE REGISTRIES ================= */
let r = await ev(async () => {
  const inPal = (rows, pal, w, h) => rows.length === h && rows.every(rw => rw.length === w) && [...new Set(rows.join('').replace(/\./g, ''))].every(ch => pal[ch]);
  const H = SPRITES.HANDS, trades = Object.keys(H.trades);
  const layers = [H.base, ...Object.values(H.jaws), ...Object.values(H.hair), ...Object.values(H.facial), ...Object.values(H.eyes), ...trades.map(t => H.trades[t].rows)].filter(Boolean).every(L => L.length === 16 && L.every(rw => rw.length === 16));
  let allPal = true; const faces = new Set();
  for (const t of trades) for (let i = 0; i < 40; i++) { const f = SPRITES.handFace(i * 7919 + 13, t); if (!inPal(f.rows, f.pal, 16, 16)) allPal = false; faces.add(f.rows.join('') + JSON.stringify(f.pal)); }
  const distinct = faces.size >= trades.length * 36;   // near every seed a face of its own
  const stable = JSON.stringify(SPRITES.handFace(4242, 'medic')) === JSON.stringify(SPRITES.handFace(4242, 'medic'));
  const byTrade = new Set(trades.map(t => SPRITES.handFace(4242, t).rows.join(''))).size === trades.length;   // the same person in every trade reads as that trade
  const skins = SPRITES.HAND_SKINS.length >= 5 && SPRITES.HAND_HAIRS.length >= 6 && SPRITES.HAND_SKINS.every(p => p.length === 2);
  const chiefs = ['chief', 'chief2'].every(k => inPal(SPRITES.CHIEF_FACES[k].rows, SPRITES.CHIEF_FACES[k].pal, 16, 16)) && SPRITES.CHIEF_FACES.chief.rows.join('') !== SPRITES.CHIEF_FACES.chief2.rows.join('');
  const marks = ['kept', 'broken', 'shut', 'errand', 'gift', 'stand', 'score', 'lantern', 'home'].every(k => inPal(SPRITES.MARKS[k], SPRITES.MARK_PAL, 7, 7)) && new Set(Object.values(SPRITES.MARKS).map(m => m.join(''))).size === Object.keys(SPRITES.MARKS).length;
  const kin = inPal(SPRITES.KINSHIELD_DOWN, SPRITES.KPAL, 9, 5) && inPal(SPRITES.KINLANTERN, SPRITES.KPAL, 5, 8) && inPal(SPRITES.KINLANTERN_DARK, SPRITES.KPAL, 5, 8);
  const cgs = ['parcelSealed', 'kinShield', 'kinLantern', 'kinLanternDark'].every(k => { const g = Render.cargoGlyph(k === 'parcelSealed' ? { defId: 'parcel', cat: 'goods', sealed: true } : k === 'kinShield' ? { defId: 'kinShield', cat: 'kin' } : { defId: 'kinLantern', cat: 'kin', lit: k === 'kinLantern' }); return inPal(g.rows, g.pal, 8, 5); });
  const urls = [Render.handFaceURL({ seed: 1, cls: 'medic' }, 2), Render.chiefFaceURL('chief', 4), Render.chiefFaceURL('chief2', 4)].every(u => /^data:image\/png/.test(u));
  /* the trade layer is drawn: the courier's cap, the medic's green cross, the lamplighter's clasp — read off the URL's own texels */
  const courierCap = await __texel(Render.handFaceURL({ seed: 7, cls: 'courier' }, 1), 7, 3), medicCross = await __texel(Render.handFaceURL({ seed: 7, cls: 'medic' }, 1), 7, 3), clasp = await __texel(Render.handFaceURL({ seed: 7, cls: 'lamplighter' }, 1), 7, 13);
  const texels = courierCap === '#3d5a74' && medicCross === '#4a8a5a' && clasp === '#ffd98f';
  const T2 = DATA.T, rows = T2.word.errandAt === 2 && T2.word.errandDays > 0 && T2.kin.burn > 0 && T2.parley.standTime > 0 && T2.parley.gift.provisions > 0 && T2.score.reachMul > 1 && T2.ring.gap > 0;
  const items = DATA.items.kinShield && DATA.items.kinLantern && DATA.items.kinShield.cat === 'kin';
  const voices = DATA.stationOrder.every(id => ['errand', 'errandKept', 'shut'].every(k => DATA.keeperGrief[id][k] && DATA.keeperGrief[id][k].length > 8)) && !!DATA.errandLetter;
  const causes = Object.keys(MUSTER.MOOD.causes).length, lessons = ['firstBook', 'firstErrand', 'firstKinErrand', 'firstParley', 'firstScore', 'firstLine'].every(k => DATA.tutorials[k] && DATA.tutorialTitles[k]), lessonsN = Object.keys(DATA.tutorials).length;
  return { layers, allPal, distinct, stable, byTrade, skins, chiefs, marks, kin, cgs, urls, texels, courierCap, medicCross, clasp, rows, items: !!items, voices, causes, lessons, lessonsN };
});
ok('THE REGISTRIES: the hands\' layers (every one 16×16), eleven trades × forty seeds composed in palette and nearly all distinct, the same seed and trade the same face, one person in every trade reading as that trade, six skins and seven hairs; the two chiefs\' faces distinct; nine new marks, every mark distinct; the kin\'s shield and lantern (lit, dark); four cargo glyphs; the face URLs, with the trade drawn (the courier\'s cap, the medic\'s cross, the lamplighter\'s clasp read off the image\'s own texels); the rows, the items, twenty-four keeper lines, twenty-seven causes (v3.46: a score settled), seventy-three lessons',
  r.layers && r.allPal && r.distinct && r.stable && r.byTrade && r.skins && r.chiefs && r.marks && r.kin && r.cgs && r.urls && r.texels && r.rows && r.items && r.voices && r.causes === 27 && r.lessons && r.lessonsN === 73, JSON.stringify(r));

/* ================= 2 · THE HANDS' FACES, WORN ================= */
r = await ev(async () => {
  /* the terminal's Waylighters tab: every hand in the pool wears their face */
  NPC.seedStarterPool && NPC.seedStarterPool();
  const pool = S.npcs.filter(n => n.state === 'pool' && n.at === 'haven');
  WL.tp('haven'); UI.openStation('haven'); UI.gotoTab('way');
  const imgs = [...document.querySelectorAll('#stationBody img.handFace')];
  await Promise.all(imgs.map(im => im.complete ? 0 : new Promise(res => { im.onload = res; })));
  const cards = imgs.length >= Math.min(1, pool.length) && imgs.every(im => /^data:image\/png/.test(im.src) && im.width === 32 && im.naturalWidth === im.clientWidth); const cardDbg = imgs.map(im => [im.src.slice(0, 22), im.width, im.naturalWidth, im.clientWidth]);
  const matches = pool.slice(0, 3).every(n => imgs.some(im => im.src === Render.handFaceURL(n, 2)));
  document.getElementById('stationClose').click();
  /* the muster plate: the face beside the figure */
  const n = pool[0]; NPC.hire(n, 'companion');
  MusterUI.open(); await new Promise(res => setTimeout(res, 60));
  const mu = document.querySelector(`[data-mu="${n.id}"] img.muFace`), muster = !!mu && mu.src === Render.handFaceURL(n, 3);
  UI.closeAllModals();
  /* the passage: a saved slot shows its walker's face in their coat */
  State.save(); ManualUI.open('passage'); await new Promise(res => setTimeout(res, 60));
  const sf = document.querySelector('#fmBody .fmSlotFace'), slot = !!sf && sf.src === Render.walkerFaceURL(3, S.look || {});
  ManualUI.close();
  /* THE WHOLE-PIXEL LAW: every framed portrait is shown at exactly the size it was drawn (image pixels = screen pixels) */
  WL.tp('elm'); UI.openStation('elm'); const kf = document.querySelector('#keeperLine .keeperFace'); await new Promise(res => kf.complete ? res() : (kf.onload = res));
  const lawTerminal = kf.naturalWidth === kf.clientWidth && kf.naturalWidth === 48; document.getElementById('stationClose').click();
  UI.keeperAtDoor('haven', 'A test of the frame.', 'grief'); const ki = document.querySelector('#keeperSay img'); await new Promise(res => ki.complete ? res() : (ki.onload = res));
  const lawPlate = ki.naturalWidth === ki.clientWidth && ki.naturalWidth === 64; document.getElementById('keeperSay').classList.add('hidden');
  MusterUI.open(); await new Promise(res => setTimeout(res, 60)); const mf = document.querySelector('img.muFace'); const lawMuster = !!mf && mf.naturalWidth === mf.clientWidth; UI.closeAllModals();
  /* a mountain hire and the town's own wear their trades */
  const fk = await __texel(Render.handFaceURL({ seed: 99, fk: true }, 1), 7, 2), own = await __texel(Render.handFaceURL({ seed: 99, kit: 'townshield', own: 'mill' }, 1), 7, 2);
  return { pool: pool.length, cards, cardDbg: cards ? null : cardDbg, matches, muster, slot, lawTerminal, lawPlate, lawMuster, fk, own, hired: n.id };
});
const hiredId = r.hired;
ok('THE HANDS\' FACES, WORN: the new walker\'s sheet wears the bust in the coat being cut and follows the swatches; the terminal\'s hands wear their own faces at 2× on whole pixels; the muster plate carries the face beside the figure; a saved slot on the passage shows its walker in their coat; a mountain hire wears the grey helm and the town\'s own the flat cap; THE WHOLE-PIXEL LAW — the terminal\'s keeper, the door plate and the muster face are shown at exactly the size they were drawn',
  cg.data && cg.w === 80 && cg.changed && r.cards && r.matches && r.muster && r.slot && r.lawTerminal && r.lawPlate && r.lawMuster && r.fk === '#8d979c' && r.own === '#5a4630', JSON.stringify({ cg, ...r }));

/* ================= 3 · A WORD REMEMBERED — THE BOOK AND THE KEEPER'S ERRAND ================= */
const grievanceAt = (to, from, kind) => ev(({ to, from, kind }) => {
  S.stations[from].parcels = [{ to, kind, name: kind === 'coat' ? 'a mended coat' : 'a tin of buttons' }];
  S.orders.active = S.orders.active.filter(o => o.errand); for (const c2 of [...S.cargo]) if (c2.cat !== 'tool' && !c2.sealed) State.removeCargo(c2.id);
  const run = Economy.ordersFor(from).find(o => o.item === 'parcel' && o.to === to && !o.errand); Systems.acceptOrder(run, false);
  const it = S.cargo.find(c2 => c2.parcel && !c2.sealed && c2.parcel.to === to);
  State.removeCargo(it.id); S.drops.push({ id: U.uid(), item: it, x: DATA.stations[from].x + 200, y: DATA.stations[from].y }); Economy.grieve(it, 'ground');
  return it.parcel.id;
}, { to, from, kind });
const keepWord = gid => ev(gid => {
  Economy.giveWord(gid, 'promise');
  const dr = S.drops.find(d => d.item && d.item.parcel && String(d.item.parcel.id) === String(gid)); State.addCargo(dr.item); S.drops.splice(S.drops.indexOf(dr), 1);
  const to = dr.item.parcel.to; WL.tp(to); WL.instantPar();
  return Systems.handleDelivery(to).results.find(x => x.order && x.order.item === 'parcel');
}, gid);
let g1 = await grievanceAt('elm', 'haven', 'coat'); await keepWord(g1);
let g2 = await grievanceAt('elm', 'haven', 'tin'); await keepWord(g2);
r = await ev(async () => {
  const b = Economy.book('elm'), counted = b.kept === 2 && b.credit === 2 && b.log.filter(e => e.kind === 'kept').length === 2, lessonBook = !!S.flags.tut.firstBook;
  WL.tp('elm'); UI.openStation('elm');
  const bl = document.getElementById('bookLine'), header = !!bl && /AN ERRAND ON THE BOARD/.test(bl.textContent) && bl.querySelectorAll('img.mkImg').length >= 3;
  UI.gotoTab('ledger'); const page2 = document.getElementById('stationBody').textContent, ledger = /Your word in Elm Farm's book — 2 kept/.test(page2) && (page2.match(/KEPT/g) || []).length >= 2;
  /* the keeper's errand on the board: the sealed letter for the farthest lit door */
  UI.gotoTab('orders');
  const eo = Economy.ordersFor('elm').find(o => o.errand === 'elm');
  const far = ['haven', 'mill', 'green', 'quarry'].sort((a, c) => U.dist(DATA.stations.elm.x, DATA.stations.elm.y, DATA.stations[c].x, DATA.stations[c].y) - U.dist(DATA.stations.elm.x, DATA.stations.elm.y, DATA.stations[a].x, DATA.stations[a].y))[0];
  const posted = !!eo && eo.to === far && eo.parcels[0].kind === 'sealed' && /Aldous Wren's sealed letter/.test(eo.parcels[0].name);
  const card = [...document.querySelectorAll('#stationBody .orderCard.errand')].some(el => /THE KEEPER'S ERRAND/.test(el.textContent) && /2 days/.test(el.textContent));
  document.getElementById('stationClose').click();
  /* accepted: the seal on the pack, the keeper's own ask, the credit spent, the clock */
  const o = Systems.acceptOrder(eo, false), it = S.cargo.find(c2 => c2.sealed);
  const accepted = !!o && o.errand === 'elm' && o.due > S.time && !!it && Render.cargoGlyph(it).rows.join('').includes('R') && Economy.book('elm').credit === 0 && S.mails.some(m => /the keeper's errand/.test(m.subj)) && !!S.flags.tut.firstErrand;
  const plate = document.getElementById('keeperSay'), ask = !plate.classList.contains('hidden') && /This one's mine/.test(plate.textContent);
  /* delivered inside the word at the far door: more than any run on the board */
  const apprH0 = S.stations.elm.appr, likes0 = S.stations.elm.likesTo, apprF0 = S.stations[far].appr;
  WL.tp(far); WL.instantPar();
  const res = Systems.handleDelivery(far).results.find(x => x.order && x.order.errand);
  const kept = !!res && res.errand && res.errand.kept && S.stations.elm.appr >= apprH0 + DATA.T.word.errandAppr && S.stations.elm.likesTo >= Math.min(100, likes0 + DATA.T.word.errandLikes) && S.stations[far].appr >= apprF0 + DATA.T.word.errandDest && Economy.book('elm').errands === 1 && Economy.book('elm').kept === 3;
  const letter = res && res.parcels && /breaks the seal/.test(res.parcels[0]);
  UI.queueResults([res], null); await new Promise(r2 => setTimeout(r2, 80));
  const slip = /THE KEEPER'S ERRAND — KEPT/.test(document.getElementById('scoreRows').textContent);
  UI.closeAllModals();
  const noSecond = !Economy.ordersFor('elm').some(o2 => o2.errand);
  return { counted, lessonBook, header, ledger, posted, card, accepted, ask, kept, letter: !!letter, slip, noSecond, far };
});
ok('A WORD REMEMBERED — THE BOOK AND THE ERRAND: two words kept at Elm are written in its book (the counts, the log, the lesson); the terminal header carries the book in marks and says an errand is on the board; the Ledger tab writes the words out; the board posts THE KEEPER\'S ERRAND — Wren\'s sealed letter for the farthest lit door, two days; accepted, the seal rides the pack, Wren asks it to your face, the credit is spent (the mail, the lesson); through inside the word, it pays more than any run (appreciation and likes at home, appreciation at the far door), the far keeper breaks the seal on the slip, the slip says KEPT, and no second errand posts without new credit',
  r.counted && r.lessonBook && r.header && r.ledger && r.posted && r.card && r.accepted && r.ask && r.kept && r.letter && r.slip && r.noSecond, JSON.stringify(r));

/* ================= 4 · A WORD REMEMBERED — BROKEN, SHUT, OPENED ================= */
let g3 = await grievanceAt('mill', 'haven', 'coat');
r = await ev(async gid => {
  const Wd = DATA.T.word, T2 = DATA.T;
  Economy.giveWord(gid, 'promise'); const g = S.grievances.find(x => String(x.id) === String(gid)); g.wordT = S.time - Wd.promiseDays * T2.dayLen - 5;
  for (let i = 0; i < 24; i++) Systems.update(0.25, {});
  const b = Economy.book('mill'), shut = g.word === 'broken' && b.broken === 1 && !!b.shut && Economy.shutAt('mill');
  return { shut };
}, g3);
let g4 = await grievanceAt('mill', 'haven', 'tin');
const shutJson = JSON.stringify(r);
r = await ev(async gid => {
  const g = S.grievances.find(x => String(x.id) === String(gid)), plate = document.getElementById('keeperSay');
  const noPromise = Economy.canWord(g) && !Economy.canPromise(g);
  /* at the door: the plate offers only the apology, and says the promises are shut */
  plate.classList.add('hidden'); S.stations.mill.faceSaid = null;
  WL.tp([DATA.stations.haven.x, DATA.stations.haven.y + 400]); Systems.update(0.05, {});
  WL.tp([DATA.stations.mill.x + 60, DATA.stations.mill.y + 40]); S.room = null; Systems.update(0.05, {});
  const atDoor = !plate.classList.contains('hidden') && !!plate.querySelector('.ksShut') && !plate.querySelector('[data-word^="promise"]') && !!plate.querySelector('[data-word^="sorry"]');
  const rail = Systems.getInteractions(), railOk = !rail.some(i => i.key === 'P' && /Give your word/.test(i.label)) && rail.some(i => i.key === 'X' && /Apologize/.test(i.label));
  const refused = Economy.giveWord(gid, 'promise') === false && /No more promises|NO MORE PROMISES|No\. No more/i.test(plate.textContent);
  WL.tp('mill'); UI.openStation('mill'); UI.gotoTab('orders');
  const board = [...document.querySelectorAll('#stationBody .needRow.grv')].some(el => el.querySelector('.ksShut') && !el.querySelector('[data-word^="promise"]'));
  const bl = /PROMISES SHUT/.test(document.getElementById('bookLine').textContent);
  document.getElementById('stationClose').click();
  /* made right with no word at all: the deed opens the door */
  const dr = S.drops.find(d => d.item && d.item.parcel && String(d.item.parcel.id) === String(gid)); State.addCargo(dr.item); S.drops.splice(S.drops.indexOf(dr), 1);
  WL.tp('mill'); WL.instantPar(); Systems.handleDelivery('mill');
  const opened = !Economy.shutAt('mill') && S.mails.slice(0, 4).some(m => /opens its door again/.test(m.subj)) && Economy.book('mill').log[0].kind === 'opened';
  return { noPromise, atDoor, railOk, refused, board, bl, opened };
}, g4);
/* the errand late: accepted and left past its span — a broken word, the door shut; delivered late, the slip says so */
const late = await ev(async () => {
  const T2 = DATA.T, b = Economy.book('haven'); b.credit = DATA.T.word.errandAt; b.shut = 0;
  const eo = Economy.ordersFor('haven').find(o => o.errand === 'haven'); if (!eo) return { posted: false };
  const o = Systems.acceptOrder(eo, false); o.due = S.time - 1;
  for (let i = 0; i < 24; i++) Systems.update(0.25, {});
  const shutLate = o.errandLate && Economy.shutAt('haven') && Economy.book('haven').broken >= 1 && S.mails.slice(0, 4).some(m => /the errand, late/.test(m.subj));
  WL.tp(o.to); WL.instantPar();
  const res = Systems.handleDelivery(o.to).results.find(x => x.order && x.order.errand);
  UI.queueResults([res], null); await new Promise(r2 => setTimeout(r2, 80));
  const slip = /THE KEEPER'S ERRAND — LATE/.test(document.getElementById('scoreRows').textContent) && res.errand.kept === false;
  UI.closeAllModals(); Economy.book('haven').shut = 0;
  return { posted: true, shutLate, slip };
});
ok('A WORD REMEMBERED — BROKEN, SHUT, OPENED: a promise broken at the Mill writes it in the book and SHUTS the door; there the grievance can be answered but not promised — the plate shows PROMISES SHUT and offers only the apology, the rail prints X and no P, a promise is refused in the keeper\'s own words, the board and the header say so; a grievance there made right with no word opens the door again (the mail, the book); a keeper\'s errand left past its span is a broken word that shuts the door, and delivered late the slip says LATE',
  JSON.parse(shutJson).shut && r.noPromise && r.atDoor && r.railOk && r.refused && r.board && r.bl && r.opened && late.posted && late.shutLate && late.slip, shutJson + ' ' + JSON.stringify(r) + ' ' + JSON.stringify(late));

/* ================= 5 · THE KIN'S ERRAND ================= */
r = await ev(() => {
  const mr = Math.random, T2 = DATA.T;
  for (const k of Object.keys(REP.EVENTS)) S.rep.evCd[k] = 99999;
  Republic.tick(0.01); for (const k of Object.keys(REP.EVENTS)) S.rep.evCd[k] = 99999;
  Republic.fundMountain(); Republic.mountain().t = REP.MOUNTAIN.dur + 1; Republic.tick(0.6);
  Republic.rebellionStrike('mill'); S.stations.mill.likesTo = 55;
  Republic.fundStorm('mill'); const q = Republic.quell(); Math.random = () => 0.9; q.t = q.dur + 1; Republic.tick(0.02); Math.random = mr;
  const a = Republic.recruitOwn('mill'), c = Republic.recruitOwn('mill'); a.name = 'Halvard Penrose'; c.name = 'Ottilie Marsh';
  NPC.setOrder(a, 'hours', 'nights'); NPC.setOrder(c, 'hours', 'nights');
  S.time = Math.floor(S.time / T2.dayLen) * T2.dayLen + T2.dayLen * 0.8;
  S.stations.mill.likesTo = 5; Republic.held().mill.shields = 2;
  Math.random = () => 0.1; Republic.squareRises('mill'); Math.random = mr;
  Memorial.raise('town'); Memorial.raise('town');
  const open = Republic.kinOpen('mill'), kinds = open.map(e => e.kind).sort().join(',');
  const drops = S.drops.filter(d => d.item && d.item.kin), onGround = drops.length === 2 && drops.some(d => d.item.defId === 'kinShield' && /Halvard's round shield/.test(d.item.name)) && drops.some(d => d.item.defId === 'kinLantern' && !d.item.lit);
  const mails = S.mails.filter(m => /at THE FIELD STONES/.test(m.subj)).length === 2, lesson = !!S.flags.tut.firstKinErrand;
  /* the kin waits at the stones past the day in the square */
  S.time += T2.dayLen * 1.1; const waits = !Republic.kinAt('mill') && Republic.kinWaits('mill');
  UI.tick(); const compass = [...document.querySelectorAll('#compassInner .cMark')].some(m => /shield · lantern — the kin asks|lantern · shield — the kin asks/.test(m.title));   // one mark for the square's worth; its words on the strip or, crowded, on the pin
  return { n: open.length, kinds, onGround, mails, lesson, waits, compass };
});
const kin1 = JSON.stringify(r), kinOk1 = r.n === 2 && r.kinds === 'lantern,shield' && r.onGround && r.mails && r.lesson && r.waits && r.compass;
r = await ev(async () => {
  const T2 = DATA.T, K = T2.kin, site = Memorial.site('town');
  /* the shield: picked up in the square, the guide and the compass point home, given at the stones */
  const ds = S.drops.find(d => d.item && d.item.defId === 'kinShield'); State.addCargo(ds.item); S.drops.splice(S.drops.indexOf(ds), 1);
  WL.tp([DATA.stations.mill.x, DATA.stations.mill.y + 200]); Guide.tick(0.3); const gs = Guide.current(), guide = gs && gs.id === 'kin' && /THE FIELD STONES/.test(gs.head);
  UI.tick(); const compassTxt = [...document.querySelectorAll('#compassInner .cMark')].map(m => m.title).join(' | '), compass = /stones|the kin waits/.test(compassTxt);   // the guide's own mark takes the spot when it points there
  const likes0 = S.stations.mill.likesTo, appr0 = S.stations.mill.appr;
  WL.tp([site.x + 20, site.y + 40]);
  const give = Systems.getInteractions().find(i => i.key === 'G' && /Halvard's shield/.test(i.label)); give && give.fn();
  const row = S.legacy.find(x => x.name === 'Halvard Penrose');
  const home = !!give && row.home === true && S.stations.mill.likesTo === Math.min(100, likes0 + K.likes) && S.stations.mill.appr >= appr0 + K.appr && !S.cargo.some(c => c.defId === 'kinShield') && S.mails.some(m => /the shield is home/.test(m.subj));
  /* the lantern: cold at the stones — a waylight gives it a flame, and it burns down */
  const dl = S.drops.find(d => d.item && d.item.defId === 'kinLantern'); State.addCargo(dl.item); S.drops.splice(S.drops.indexOf(dl), 1);
  const dark = Systems.getInteractions().some(i => i.key === 'G' && /DARK/.test(i.label));
  Guide.tick(0.3); const gs2 = Guide.current(), guideCold = gs2 && /is cold — take a flame/.test(gs2.head);
  WL.tp('haven'); const light = Systems.getInteractions().find(i => i.key === 'L' && /Take the flame/.test(i.label)); light && light.fn();
  const lt = S.cargo.find(c => c.defId === 'kinLantern'); UI.updateHUD();
  const lit = !!light && lt.lit && /A FLAME/.test(document.getElementById('buffs').textContent) && Render.cargoGlyph(lt).rows[0] === '..OOOO..';
  lt.litT = S.time - K.burn - 1; Republic.tick(0.02);
  const burned = !lt.lit;
  WL.tp('haven'); Systems.getInteractions().find(i => i.key === 'L' && /Take the flame/.test(i.label)).fn();
  /* carried lit to the stone and set there */
  WL.tp([site.x + 20, site.y + 40]);
  const set = Systems.getInteractions().find(i => i.key === 'G' && /Ottilie's lantern/.test(i.label)); set && set.fn();
  const row2 = S.legacy.find(x => x.name === 'Ottilie Marsh'), litDone = !!set && row2.lit === true && Republic.kinOpen('mill').length === 0;
  const home2 = !Republic.kinWaits('mill');
  /* the memorial card: both marks */
  Memorial.open('town'); const cards = [...document.querySelectorAll('#memBody .memCard')];
  const card = cards.some(el => /Halvard/.test(el.textContent) && /the shield brought home/.test(el.textContent)) && cards.some(el => /Ottilie/.test(el.textContent) && /the lantern kept lit/.test(el.textContent));
  Memorial.close();
  return { guide, compass, compassTxt: compass ? '' : compassTxt.slice(0, 300), home, dark, guideCold, lit, burned, litDone, home2, card };
});
const kin2 = JSON.stringify(r), kinOk2 = r.guide && r.compass && r.home && r.dark && r.guideCold && r.lit && r.burned && r.litDone && r.home2 && r.card;
/* the stone, seen: the lantern burning beside Ottilie's stone at night */
await ev(() => { const T2 = DATA.T; S.time = Math.floor(S.time / T2.dayLen) * T2.dayLen + T2.dayLen * 0.9; const rw = Memorial.rows('town').find(x => x.name === 'Ottilie Marsh'), sl = Memorial.slotFor(rw.ord, 'town'); WL.tp([sl.x + 20, sl.y + 90]); S.dir = -Math.PI / 2; Render.setZoom(3); Render.cam.x = sl.x + 10; Render.cam.y = sl.y + 10; WL.timeScale = 0.001; });
await page.waitForTimeout(500);
const lampSeen = await ev(() => { const rw = Memorial.rows('town').find(x => x.name === 'Ottilie Marsh'), sl = Memorial.slotFor(rw.ord, 'town'); return __near(sl.x + 16, sl.y + 14, [0xff, 0xd9, 0x8f], 30, 30); });
await ev(() => { WL.timeScale = 1; Render.setZoom(null); });
/* an errand left its days: the kin goes home, the thing goes with them */
const kinGone = await ev(() => {
  const e = { id: 'kinT', town: 'mill', fallen: 'Test Fallen', kin: 'Wenna Fallen', kind: 'shield', t: S.time - DATA.T.kin.errandDays * DATA.T.dayLen - 5, state: 'open' };
  S.kinErrands.push(e); const it = State.makeItem('kinShield'); it.kin = 'kinT'; it.name = "Test's round shield"; S.drops.push({ id: U.uid(), item: it, x: 0, y: 0 });
  Republic.tick(0.02);
  return e.state === 'gone' && !S.drops.some(d => d.item && d.item.kin === 'kinT') && S.mails.some(m => /Wenna Fallen went home/.test(m.subj));
});
ok('THE KIN\'S ERRAND: the town\'s own fell and the kin asks for what they left — two errands (a shield, a lantern), the shield and the cold lantern lying in the square, two mails, the lesson; the kin waits at the stones after the day in the square; the compass names them; the shield carried home (the guide, the compass) and given at the stones: the stone\'s row marked home, the town warmer, the mail; the lantern cold at the stone, the guide sends it to a waylight, the flame taken there (the HUD, the lit glyph) burns down on the clock, is taken again and set lit at the stone; the kin goes home; the memorial card carries both marks; the lantern burns beside the stone at night (pixel-sampled); an errand left its days goes home with the kin',
  kinOk1 && kinOk2 && lampSeen > 10 && kinGone, kin1 + ' ' + kin2 + ' lamp=' + lampSeen + ' gone=' + kinGone);

/* ================= 6 · THE GRUDGE ANSWERED — THE PARLEY ================= */
const grudgeAt = () => ev(() => {
  const ash = DATA.camps.find(c => c.id === 'ash'), c = S.camps.ash;
  c.taken = null; c.pacified = false; c.runners = []; c.storm = null; c.chiefLost = 0; c.chiefReturn = null; c.chiefGen = 1; c.chiefFelledBy = 'walker'; c.truce = 0; c.pact = null;
  c.grudge = { t: S.time, said: true, fired: Math.floor(S.time / DATA.T.dayLen) };
  S.stand = null; S.room = null;
  WL.tp([ash.x - 30 + 40, ash.y + 18 + 60]);
  document.getElementById('keeperSay').classList.add('hidden');
  return true;
});
await grudgeAt();
r = await ev(() => {
  const ash = DATA.camps.find(c => c.id === 'ash');
  const act = Systems.getInteractions().find(i => i.key === 'P' && /Parley/.test(i.label)), near = Republic.parleyNear() === ash;
  act.fn();
  const plate = document.getElementById('keeperSay');
  const face = plate.querySelector('img') && plate.querySelector('img').src === Render.chiefFaceURL('chief2', 4), walker = !!plate.querySelector('img.ksWalker');
  const three = ['gift', 'stand', 'word'].every(k => plate.querySelector(`[data-parley^="${k}"]`)) && plate.querySelectorAll('img.mkImg').length >= 3;
  return { act: !!act, near, face, walker, three, line: /You put my brother down/.test(plate.textContent) };
});
const parleyJson = JSON.stringify(r), parleyOpen = r.act && r.near && r.face && r.walker && r.three && r.line;
const bank0 = await ev(() => ({ p: S.banked.provisions, m: S.banked.metal }));
await page.click('#keeperSay [data-parley^="gift"]'); await page.waitForTimeout(100);
const gift = await ev(b0 => ({ cooled: !S.camps.ash.grudge, paid: S.banked.provisions === b0.p - DATA.T.parley.gift.provisions && S.banked.metal === b0.m - DATA.T.parley.gift.metal, mail: S.mails.some(m => /the gift taken/.test(m.subj)), lesson: !!S.flags.tut.firstParley, hidden: document.getElementById('keeperSay').classList.contains('hidden') }), bank0);
/* the stand: his runners come in and look you over; stood out, a truce */
await grudgeAt();
r = await ev(() => {
  const ash = DATA.camps.find(c => c.id === 'ash'), c = S.camps.ash;
  c.runners = [0, 1, 2].map(i => ({ x: ash.x + 200 + i * 30, y: ash.y + 150, cd: 0, cls: 'knife', wa: i }));
  UI.chiefParley('ash'); document.querySelector('#keeperSay [data-parley^="stand"]').click();
  const started = !!S.stand;
  S.speed = 0; for (let i = 0; i < 20; i++) Systems.update(0.25, {});
  const ringed = c.runners.every(r2 => r2.watch && U.dist(r2.x, r2.y, S.px, S.py) < 110), hp = S.health;
  UI.updateHUD(); const chip = /STANDING AT HIS FIRE/.test(document.getElementById('buffs').textContent);
  for (let i = 0; i < 60; i++) Systems.update(0.25, {});
  const stood = !S.stand && !c.grudge && Republic.truceAt(ash) && S.mails.some(m => /you stood at his fire/.test(m.subj)) && S.health >= hp - 0.01;
  /* the truce: loaded, inside his ring, his runners let you walk */
  State.addCargo(State.makeItem('food')); c.runners.forEach(r2 => { r2.x = S.px + 60; r2.y = S.py; r2.cd = 0; });
  const hp2 = S.health; for (let i = 0; i < 12; i++) Systems.update(0.25, {});
  const truce = S.health >= hp2 - 0.01 && !c.runners.some(r2 => U.dist(r2.x, r2.y, S.px, S.py) < DATA.T.scrapCatch);
  for (const c2 of [...S.cargo]) if (c2.defId === 'food') State.removeCargo(c2.id);
  return { started, ringed, chip, stood, truce };
});
const standJson = JSON.stringify(r), standOk = r.started && r.ringed && r.chip && r.stood && r.truce;
/* the stand broken: walk away and his storm comes tonight */
await grudgeAt();
const walked = await ev(() => {
  const ash = DATA.camps.find(c => c.id === 'ash'), c = S.camps.ash;
  UI.chiefParley('ash'); document.querySelector('#keeperSay [data-parley^="stand"]').click();
  WL.tp([ash.x + 600, ash.y + 400]); Republic.tick(0.1);
  return !S.stand && !!c.grudge && c.grudge.fired === -1 && S.mails.some(m => /you walked from his fire/.test(m.subj));
});
/* the word: no column for three days — and the word broken by a column */
await grudgeAt();
const word = await ev(() => {
  const ash = DATA.camps.find(c => c.id === 'ash'), c = S.camps.ash;
  UI.chiefParley('ash'); document.querySelector('#keeperSay [data-parley^="word"]').click();
  const pact = Republic.pactAt(ash) && !c.grudge;
  S.banked.metal = 2000; S.banked.wood = 2000; S.banked.ceramic = 2000; S.banked.provisions = 2000; S.banked.lumen = 500;
  if (Republic.quell()) S.rep.quell = null;
  Republic.fundTake('ash');
  const broken = !Republic.pactAt(ash) && !!S.fireWordBroken && !!Republic.reprisal() && S.mails.some(m => /Your word at the fires, broken/.test(m.subj));
  S.rep.quell = null;
  /* no fire takes your word again for a while */
  c.grudge = { t: S.time, said: true, fired: Math.floor(S.time / DATA.T.dayLen) };
  const refused = Republic.parley('ash', 'word') === false && !!c.grudge;
  c.grudge = null; S.rep.reprisal = null;
  return { pact, broken, refused };
});
ok('THE GRUDGE ANSWERED — THE PARLEY: at the new chief\'s fire the rail prints P; the parley plate carries his face (the new man\'s), the Walker\'s, his line and three answers with their marks; the GIFT by a real click pays the bank and cools the grudge (the mail, the lesson); the STAND — his runners come in and ring the Walker without cutting, the HUD counts, stood out the grudge cools and a truce holds: loaded inside his ring, his runners let you walk; walked away from, his storm comes tonight; the WORD holds his fire from the column, a column sent against it breaks the word (every fire hears: a season of reprisal) and no fire takes your word after',
  parleyOpen && gift.cooled && gift.paid && gift.mail && gift.lesson && gift.hidden && standOk && walked && word.pact && word.broken && word.refused, parleyJson + ' ' + JSON.stringify(gift) + ' ' + standJson + ' walked=' + walked + ' ' + JSON.stringify(word));

/* ================= 7 · THE WALKER'S SCORE ================= */
r = await ev(async hid => {
  const T2 = DATA.T, ash = DATA.camps.find(c => c.id === 'ash'), n = S.npcs.find(x => x.id === hid);
  if (n.state !== 'companion') { n.state = 'pool'; n.at = 'haven'; NPC.hire(n, 'companion'); }
  n.cx = S.px + 20; n.cy = S.py + 20;
  /* Ash's knife cuts the Walker to the ground: the companion takes it and goes down */
  S.hitBy = { camp: 'ash', t: S.time }; S.health = 3; Porter.damage(7, 'scrappers', { bruise: true });
  const sc = Republic.scores().ash, set = !!sc && sc.npc === n.id && n.state === 'recover' && S.mails.some(m => /Your score with Ash Camp/.test(m.subj)) && !!S.flags.tut.firstScore;
  /* marked on the roll */
  MusterUI.open(); await new Promise(res => setTimeout(res, 60));
  const plate = document.querySelector(`[data-mu="${n.id}"] .muScore`), roll = !!plate && /FELLED BY ASH CAMP'S KNIVES — YOUR SCORE/.test(plate.textContent);
  UI.closeAllModals();
  /* back on their feet and walking again: the mood, and the reach against Ash's runners only */
  n.state = 'pool'; n.recoverT = 0; NPC.hire(n, 'companion'); n.cx = S.px; n.cy = S.py; n.shoveCd = 0;
  const mood = NPC.mood(n).causes.some(c => c.id === 'score');
  const r1 = { x: n.cx + 170, y: n.cy, cd: 0 }; n.shoveCd = 0;
  const reachAsh = NPC.intercept(r1, 'ash'); n.shoveCd = 0;
  const r2 = { x: n.cx + 170, y: n.cy, cd: 0 };
  const reachRidge = NPC.intercept(r2, 'ridge');
  /* on the sheet and the roll's plate */
  const html = UI.campRollHTML ? '' : '';
  /* paid: Ash's chief goes down (v3.46: paid is not yet settled — the one who fell walks to the ring to settle it; carried.mjs walks it) */
  Republic.chiefFalls(ash, 'shield');
  const settled = !!Republic.scores().ash && Republic.scores().ash.paid === 'chief' && S.mails.some(m => /The score with Ash Camp, paid/.test(m.subj));
  delete Republic.scores().ash; S.settle = null;
  /* a score left its days cools */
  Republic.scores().ridge = { t: S.time - T2.score.days * T2.dayLen - 1, npc: n.id, name: n.name }; Republic.tick(0.02);
  const cooled = !Republic.scores().ridge && S.mails.some(m => /The score with Ridge Camp cools/.test(m.subj));
  S.camps.ash.chiefLost = 0;
  return { set, roll, mood, reachAsh, reachRidge, settled, cooled };
}, hiredId);
/* the score on the survey sheet: the mark under the camp */
const scoreSheet = await ev(async () => {
  const ridge = DATA.camps.find(c => c.id === 'ridge'); Republic.scores().ridge = { t: S.time, npc: 1, name: 'Test Hand' };
  WL.tp([ridge.x, ridge.y + 400]); UI.toggleMap(true); await new Promise(res => setTimeout(res, 120));
  const c = document.getElementById('map'), g = c.getContext('2d'), p = UI.mapPoint(ridge.x, ridge.y), r0 = c.getBoundingClientRect(), dpr = devicePixelRatio;
  const d = g.getImageData(Math.round((p.x - r0.left - 90) * dpr), Math.round((p.y - r0.top) * dpr), Math.round(180 * dpr), Math.round(60 * dpr)).data;
  let hit = 0; for (let i = 0; i < d.length; i += 4) if (Math.abs(d[i] - 0xff) < 12 && Math.abs(d[i + 1] - 0xd9) < 14 && Math.abs(d[i + 2] - 0x8f) < 16) hit++;
  const rollHtml = UI.campRollHTML(ridge, true); UI.toggleMap(false); delete Republic.scores().ridge;
  return { hit, roll: /your score/.test(rollHtml) && /Test Hand/.test(rollHtml) };
});
ok('THE WALKER\'S SCORE: Ash\'s knife cuts the Walker down and the companion takes it — the score is set against Ash (the mail, the lesson); the muster roll marks the one who went down; walking again they carry a score to settle and meet Ash\'s runners from farther (not another camp\'s); Ash\'s chief going down pays it; a score left its days cools; the survey sheet draws the score\'s mark under the camp (pixel-sampled) and the camp\'s roll names it',
  r.set && r.roll && r.mood && r.reachAsh && !r.reachRidge && r.settled && r.cooled && scoreSheet.hit > 8 && scoreSheet.roll, JSON.stringify(r) + ' ' + JSON.stringify(scoreSheet));

/* ================= 8 · THE LINE AT THE RING ================= */
r = await ev(async hid => {
  const ash = DATA.camps.find(c => c.id === 'ash'), c = S.camps.ash; c.runners = []; c.grudge = null; c.truce = 0;
  for (const c2 of [...S.cargo]) if (c2.cat !== 'tool') State.removeCargo(c2.id);
  const pool = S.npcs.filter(n => n.state === 'pool' && n.at === 'haven' && n.id !== hid).slice(0, 1); for (const n of pool) NPC.hire(n, 'companion');
  const pt = NPC.party(); for (const n of pt) { n.cx = S.px + 20; n.cy = S.py + 20; }
  WL.tp([ash.x + 100, ash.y + 1150]); for (const n of pt) { n.cx = S.px + 20; n.cy = S.py + 20; }
  UI.toggleMap(true); const planned = UI.ringWalk('ash'); UI.toggleMap(false);
  UI.tick(); const cm = document.querySelector('#compassInner .cMark.ring'), compassWalk = !!cm && /THE RING/.test(cm.textContent) && !!cm.querySelector('img.cPin');
  /* arrive: the last steps */
  const m = S.moveTo; WL.tp([m.x + 4, m.y + 4]); S.stagger = 0; S.arrow = null; S.struggle = null; Systems.update(0.05, {});   // arriving on their feet: a knock or a grab taken in the gap before the walk would hold the step
  const hold = !!S.ringHold && S.ringHold.camp === 'ash' && !!S.flags.tut.firstLine;
  for (let i = 0; i < 40; i++) Systems.update(0.1, {});
  const h = S.ringHold, ux = ash.x - h.x, uy = ash.y - h.y, ul = Math.hypot(ux, uy), px2 = -uy / ul, py2 = ux / ul, slots = [-1, 1, -2, 2];
  const line = pt.every((n, i) => U.dist(n.cx, n.cy, h.x + px2 * slots[i] * DATA.T.ring.gap, h.y + py2 * slots[i] * DATA.T.ring.gap) < 14 && Math.abs(n.holdDir - Math.atan2(uy, ux)) < 0.01);
  UI.tick(); const compassHold = /THE RING · ASH/.test(document.getElementById('compassInner').textContent);
  return { planned, compassWalk, hold, line, compassHold, party: pt.length };
}, hiredId);
const lineJson = JSON.stringify(r);
/* the line, seen: the pin planted where it holds, the label on the ground */
await ev(() => { const h = S.ringHold; Render.setZoom(2); Render.cam.x = h.x; Render.cam.y = h.y; WL.timeScale = 0.001; });
await page.waitForTimeout(400);
const pinSeen = await ev(() => { const h = S.ringHold, ash = DATA.camps.find(c => c.id === 'ash'), ux = ash.x - h.x, uy = ash.y - h.y, ul = Math.hypot(ux, uy); return __near(h.x - ux / ul * 26, h.y - uy / ul * 26 - 8, [0xc9, 0x55, 0x3a], 26, 24); });
/* the names on the line read as names: every back's name is drawn and no two labels on the ground overlap */
const lineNames = await ev(() => { const bx = Render.labelBoxes(), names = NPC.party().map(n => n.name.split(' ')[0].toUpperCase()); let overlap = 0; for (let i = 0; i < bx.length; i++) for (let j = i + 1; j < bx.length; j++) { const a = bx[i], b2 = bx[j]; if (a.x0 < b2.x1 && b2.x0 < a.x1 && a.y0 < b2.y1 && b2.y0 < a.y1) overlap++; } return { all: names.every(nm => bx.some(b2 => String(b2.str).toUpperCase() === nm)), overlap, n: bx.length }; });
await ev(() => { WL.timeScale = 1; Render.setZoom(null); });
const release = await ev(() => { const h = S.ringHold; WL.tp([h.x + 500, h.y + 300]); Systems.update(0.05, {}); for (let i = 0; i < 10; i++) Systems.update(0.1, {}); return !S.ringHold && NPC.party().every(n => n.holdDir === undefined); });
ok('THE LINE AT THE RING: a ring walk planned from the sheet puts THE RING on the compass with its pin; arriving, the line holds (the lesson); the backs stand abreast at the ring\'s edge on their slots, facing the camp; the compass names the ring the line faces; the pin stands planted where it holds (pixel-sampled); every back\'s name is on the ground and no two labels overlap; walked away from, the line lifts and the wedge follows again',
  JSON.parse(lineJson).planned && JSON.parse(lineJson).compassWalk && JSON.parse(lineJson).hold && JSON.parse(lineJson).line && JSON.parse(lineJson).compassHold && pinSeen > 6 && lineNames.all && lineNames.overlap === 0 && release, lineJson + ' pin=' + pinSeen + ' names=' + JSON.stringify(lineNames) + ' release=' + release);

/* ================= 9 · THE SAVE ================= */
r = await ev(() => {
  const ash = DATA.camps.find(c => c.id === 'ash');
  Economy.book('green').kept = 2; Economy.book('green').credit = 2; Economy.book('green').shut = S.time; Economy.book('green').log.unshift({ t: S.time, kind: 'broken', name: 'a test' });
  S.kinErrands.push({ id: 'kinS', town: 'mill', fallen: 'Save Test', kin: 'Wenna Test', kind: 'lantern', t: S.time, state: 'open' });
  Republic.scores().ridge = { t: S.time, npc: 1, name: 'Test Hand' };
  S.camps.ash.truce = S.time; S.camps.ash.pact = { t: S.time }; S.fireWordBroken = S.time;
  S.stand = { camp: 'ash', t: 3 }; S.ringHold = { camp: 'ash', x: 0, y: 0, t: S.time };
  State.save();
  Economy.book('green').kept = 0; S.kinErrands = []; delete Republic.scores().ridge; S.camps.ash.truce = 0; S.camps.ash.pact = null; S.fireWordBroken = 0;
  State.load();
  const book = Economy.book('green').kept === 2 && Economy.book('green').credit === 2 && !!Economy.book('green').shut && Economy.book('green').log[0].kind === 'broken';
  const kin = S.kinErrands.some(e => e.id === 'kinS' && e.state === 'open'), score = !!Republic.scores().ridge;
  const camp = Republic.truceAt(ash) && Republic.pactAt(ash) && !!S.fireWordBroken;
  const moments = !S.stand && !S.ringHold;
  const rows = S.legacy.some(x => x.name === 'Halvard Penrose' && x.home) && S.legacy.some(x => x.name === 'Ottilie Marsh' && x.lit);
  S.kinErrands = S.kinErrands.filter(e => e.id !== 'kinS'); delete Republic.scores().ridge; S.camps.ash.truce = 0; S.camps.ash.pact = null; S.fireWordBroken = 0; Economy.book('green').shut = 0;
  return { book, kin, score, camp, moments, rows };
});
ok('THE SAVE: the town\'s book (counts, credit, the shut door, the log), an open kin errand, a score, a truce, a pact and a word broken at the fires, and the stones\' home and lit marks survive a save and load; a stand and a line are moments, not state', r.book && r.kin && r.score && r.camp && r.moments && r.rows, JSON.stringify(r));

/* ================= 10 · THE LAMP LAW AND THE CROWDED STRIP ================= */
/* the lamp in hand at night: its corona lies behind the Walker, so the coat keeps its own texels (no pale wash at
   the chest) while the glass glints at the hand, whichever way the Walker faces */
const lamp = [];
for (const dir of [0, Math.PI]) {
  await ev(dir => {
    const d = DATA.stations.haven, T2 = DATA.T; WL.timeScale = 1;
    S.time = Math.floor(S.time / T2.dayLen) * T2.dayLen + T2.dayLen * 0.85;
    WL.tp([d.x + 1700, d.y - 1300]); S.dir = dir; S.room = null; S.scar = null; S.arrow = null; S.wraiths.length = 0;
    for (const c2 of [...S.cargo]) if (c2.cat !== 'tool') State.removeCargo(c2.id);
    Systems.update(0.05, {}); Render.clearFx();
    Render.setZoom(3); Render.cam.x = S.px; Render.cam.y = S.py - 14; WL.timeScale = 0.001;
  }, dir);
  await page.waitForTimeout(400);
  lamp.push(await ev(dir => {
    const cv = document.getElementById('game'), g = cv.getContext('2d'), dpr = devicePixelRatio;
    const count = (wx, wy, rad, pred) => { const p = __toScr(wx, wy), x0 = Math.round((p.x - rad) * dpr), y0 = Math.round((p.y - rad) * dpr), w = Math.round(rad * 2 * dpr), d = g.getImageData(x0, y0, w, w).data; let n = 0; for (let i = 0; i < d.length; i += 4) if (pred(d[i], d[i + 1], d[i + 2])) n++; return n; };
    const side = Math.cos(dir) < 0 ? -1 : 1;
    const wash = count(S.px, S.py - 15, 8, (r, g2, b2) => b2 > r + 18 && (r + g2 + b2) / 3 > 140);           // a pale-blue wash on the navy coat
    const glass = count(S.px + side * 13, S.py - 13, 9, (r, g2, b2) => r > 235 && g2 > 205);                  // the glass glinting in the hand
    return { wash, glass, dark: World.lightAt(S.px, S.py) < 0.3 };
  }, dir));
}
await ev(() => { WL.timeScale = 1; Render.setZoom(null); });
/* the crowded strip: two cairns on one bearing and a ruin beside them — the first keeps its words, the second its
   pin (bare, the words on hover), the ruin yields; no two labels on the strip overlap */
const strip = await ev(() => {
  const saved = S.graves; WL.tp('haven'); S.orders.active.length = 0;
  const bx = S.px + Math.cos(S.dir) * 900, by = S.py + Math.sin(S.dir) * 900;
  S.graves = [{ id: 'g1', x: bx, y: by, name: 'A', wraith: false, items: [], ph: 0 }, { id: 'g2', x: bx + Math.cos(S.dir) * 400, y: by + Math.sin(S.dir) * 400, name: 'B', wraith: false, items: [], ph: 0 }];
  UI.tick();
  const marks = [...document.querySelectorAll('#compassInner .cMark')], cairns = marks.filter(m => /^cairn/.test(m.title));
  const labeled = marks.filter(m => !m.classList.contains('bare') && m.textContent.trim()), rects = labeled.map(m => m.getBoundingClientRect());
  let overlap = 0; for (let i = 0; i < rects.length; i++) for (let j = i + 1; j < rects.length; j++) { const a = rects[i], b2 = rects[j]; if (a.left < b2.right - 1 && b2.left < a.right - 1 && a.top < b2.bottom - 1 && b2.top < a.bottom - 1) overlap++; }
  const out = { cairns: cairns.length, oneWords: cairns.filter(m => /cairn/.test(m.textContent)).length === 1, oneBare: cairns.filter(m => m.classList.contains('bare') && !m.textContent.trim() && getComputedStyle(m).pointerEvents === 'auto').length === 1, overlap, labeled: labeled.length };
  S.graves = saved; UI.tick();
  return out;
});
ok('THE LAMP LAW AND THE CROWDED STRIP: at night the lamp in hand lights round the Walker, not over them — the coat keeps its own texels at the chest (no pale wash) and the glass glints at the hand, facing either way (pixel-sampled); two cairns on one bearing keep one label and one bare pin with its words on hover, and no two labels on the compass overlap',
  lamp.every(l => l.dark && l.wash === 0 && l.glass > 6) && strip.cairns === 2 && strip.oneWords && strip.oneBare && strip.overlap === 0, JSON.stringify(lamp) + ' ' + JSON.stringify(strip));

/* the keepsake in the book: filed under Curios › Keepsakes, and a dossier told to store all cargo leaves it in the pack */
const keep = await ev(() => {
  const filed = Ledger.classify('kinShield') === 'keepsakes' && Ledger.classify('kinLantern') === 'keepsakes' && Ledger.CHAIN.keepsakes.includes('curios') && Ledger.coverage().length === 0;
  WL.tp('elm'); const it = { ...DATA.items.kinShield, id: U.uid(), defId: 'kinShield', kin: 'kinTest' }; S.cargo.push(it);
  const P = Ledger.led().policy, saved = JSON.stringify(P); Ledger.setMark('cargo', 'store', true);
  Ledger.runDossier('elm');
  const kept = S.cargo.includes(it) && !S.stations.elm.storage.includes(it);
  S.cargo.splice(S.cargo.indexOf(it), 1); Ledger.led().policy = JSON.parse(saved);
  return { filed, kept };
});
ok('THE KEEPSAKE IN THE BOOK: the kin\'s shield and lantern file under Curios › Keepsakes (the tree covers every item), and a dossier marked to store all cargo leaves the keepsake in the pack', keep.filed && keep.kept, JSON.stringify(keep));

ok('no page errors across the kept word', errors.length === 0, errors.slice(0, 3).join(' | '));
console.log(results.join('\n'));
console.log(`${results.filter(x => x.startsWith('PASS')).length}/${results.length} checks passed`);
await b.close();
