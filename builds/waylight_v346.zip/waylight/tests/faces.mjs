/* faces.mjs — v3.43 THE FACE AT THE DOOR: the keepers' faces (eight hand-drawn busts) and their
   grievance voices — said to your face as you arrive and at the terminal, before the board, and said
   again when it is made right; the town's own who fall when a square rises (a stone at THE FIELD
   STONES, the town colder, their hours deciding who stood); the chief's return as a scene (the walk
   in, the rag down, the fire his, the bare stake a day); the bolt's scar the medic dresses over a day
   (the wind's ceiling, three dressings, a town's hands once a visit, healed or hanging on); the
   survey's marks as a click into the camp's roll; the save. */
import { chromium } from 'playwright';
const results = [];
const ok = (name, cond, extra = '') => { results.push(`${cond ? 'PASS' : 'FAIL'}  ${name}${extra ? '  — ' + extra : ''}`); if (!cond) process.exitCode = 1; };
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium', args: ['--disable-background-networking'] });
const page = await b.newPage({ viewport: { width: 1440, height: 860 } });
await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
const errors = [];
page.on('pageerror', e => errors.push(String(e.message)));
await page.goto('file:///home/claude/waylight/dist/test.html?debug', { waitUntil: 'domcontentloaded' });
await page.waitForFunction(() => window.WL && WL.snapshot && WL.snapshot().baked, null, { timeout: 60000 });
await page.evaluate(() => localStorage.clear());
await page.click('#btnNew'); await page.waitForTimeout(300);
await page.click('#btnBegin'); await page.waitForTimeout(400);
await page.click('#briefGo'); await page.waitForTimeout(300);
await page.click('#cgBegin'); await page.waitForTimeout(1200);
for (let i = 0; i < 30; i++) { const c = await page.evaluate(() => !!S.cine); if (!c) break; await page.evaluate(() => WL.skipCine()); await page.waitForTimeout(250); }
await page.evaluate(() => { S.flags.guideDone = true; WL.calm(); });
const ev = (fn, arg) => page.evaluate(fn, arg);

/* ================= 1 · THE REGISTRIES ================= */
let r = await ev(() => {
  const F = SPRITES.FACES, ids = DATA.stationOrder;
  const faces = ids.every(id => F[id] && F[id].rows.length === 16 && F[id].rows.every(rw => rw.length === 16) && [...new Set(F[id].rows.join('').replace(/\./g, ''))].every(ch => F[id].pal[ch]));
  const distinct = new Set(ids.map(id => F[id].rows.join(''))).size === ids.length;
  const urls = ids.map(id => Render.faceURL(id, 4)), faceUrls = urls.every(u => /^data:image\/png/.test(u)) && new Set(urls).size === ids.length;
  const stake = SPRITES.BARESTAKE.length === 13 && SPRITES.BARESTAKE.every(rw => rw.length === 7) && [...new Set(SPRITES.BARESTAKE.join('').replace(/\./g, ''))].every(ch => SPRITES.RAGSTAKE_PAL[ch]);
  const scar = [...new Set((SPRITES.SCAR.join('') + SPRITES.DRESSING.join('')).replace(/\./g, ''))].every(ch => SPRITES.SCAR_PAL[ch]);
  const V = DATA.keeperGrief;
  const voices = ids.every(id => V[id] && ['ground', 'camp', 'given', 'remembered', 'made'].every(k => V[id][k] && /\{name\}/.test(V[id][k])));
  const C = DATA.T.scar, O = DATA.T.ownFall;
  const rows = C && C.stamMul < 1 && C.dressings === 3 && C.dressEvery > 0 && C.medicR > 0 && C.healDays > 0 && C.undressedDays > C.healDays && O && O.chance > 0 && O.likes > 0;
  const D = Memorial.DESIGNS.town, design = D && D.ground === 'THE FIELD STONES' && D.accent === 'shield' && D.stampWord === 'HOME' && !!D.line;
  const lessons = ['firstFace', 'firstOwnFell', 'firstScar', 'firstChiefBack'].every(k => DATA.tutorials[k] && DATA.tutorialTitles[k]), lessonsN = Object.keys(DATA.tutorials).length;
  return { faces, distinct, faceUrls, stake, scar, voices, rows, design, lessons, lessonsN };
});
ok('THE REGISTRIES: eight keepers\' faces (16×16, each in its own palette, all distinct, each a portrait the renderer serves), the bare stake and the scar\'s rows in their palettes, five grievance lines in every keeper\'s voice, the scar row and the fall row, THE FIELD STONES with a shield on the stone, four lessons (sixty)',
  r.faces && r.distinct && r.faceUrls && r.stake && r.scar && r.voices && r.rows && r.design && r.lessons && r.lessonsN === 73, JSON.stringify(r));

/* ================= 2 · THE FACE AT THE DOOR ================= */
r = await ev(() => {
  for (const k of Object.keys(REP.EVENTS)) S.rep.evCd[k] = 99999;
  for (const id of ['elm', 'mill']) S.stations[id].connected = true;
  S.grievances = []; S.stations.elm.met = true; S.stations.elm.faceSaid = null; S.stations.elm.madeSaid = null;
  const T2 = DATA.T, day0 = Math.floor(S.time / T2.dayLen) * T2.dayLen; S.time = day0 + T2.dayLen * 0.3;
  /* a parcel for Elm on the road: the grievance stands */
  S.stations.haven.parcels = [{ to: 'elm', kind: 'coat', name: 'a mended coat' }];
  S.orders.active = []; for (const c2 of [...S.cargo]) if (c2.cat !== 'tool') State.removeCargo(c2.id);
  const run = Economy.ordersFor('haven').find(o => o.item === 'parcel' && o.to === 'elm'); const o = Systems.acceptOrder(run, false);
  const it = S.cargo.find(c2 => c2.parcel);
  State.removeCargo(it.id); S.drops.push({ id: U.uid(), item: it, x: DATA.stations.haven.x + 300, y: DATA.stations.haven.y }); Economy.grieve(it, 'ground');
  const gl = Economy.keeperGriefLine('elm');
  const line = gl && gl.how === 'ground' && /A mended coat — for the kid/.test(gl.line);
  /* arriving inside Elm's reach: the keeper says it to your face, before the board */
  document.getElementById('keeperSay').classList.add('hidden');
  WL.tp([DATA.stations.haven.x, DATA.stations.haven.y + 400]); Systems.update(0.05, {});
  WL.tp([DATA.stations.elm.x + 60, DATA.stations.elm.y + 40]); S.room = null; Systems.update(0.05, {});
  const plate = document.getElementById('keeperSay');
  const shown = !plate.classList.contains('hidden'), named = /Aldous Wren/.test(plate.textContent) && /farmer/.test(plate.textContent), said = /A mended coat — for the kid/.test(plate.textContent);
  const face = plate.querySelector('img') && /^data:image/.test(plate.querySelector('img').src) && plate.querySelector('img').src === Render.faceURL('elm', 4);
  const grief = !!plate.querySelector('.ksLine.grief'), lesson = !!S.flags.tut.firstFace;
  /* the terminal: the face beside the words, the grievance in the keeper's mouth */
  UI.openStation('elm');
  const kl = document.getElementById('keeperLine');
  const atTerminal = !!kl.querySelector('.keeperFace') && kl.querySelector('.keeperFace').src === Render.faceURL('elm', 3) && kl.querySelector('.keeperWords.grief') && /A mended coat — for the kid/.test(kl.textContent);
  document.getElementById('stationClose').click();
  /* said once: leaving and coming back inside the while does not say it again */
  plate.classList.add('hidden');
  WL.tp([DATA.stations.haven.x, DATA.stations.haven.y + 400]); Systems.update(0.05, {});
  WL.tp([DATA.stations.elm.x + 60, DATA.stations.elm.y + 40]); Systems.update(0.05, {});
  const once = plate.classList.contains('hidden');
  /* the grievance deepens: carried into a camp — a new thing to say */
  Economy.grieve(it, 'camp', DATA.camps.find(c2 => c2.id === 'ridge'));
  WL.tp([DATA.stations.haven.x, DATA.stations.haven.y + 400]); Systems.update(0.05, {});
  WL.tp([DATA.stations.elm.x + 60, DATA.stations.elm.y + 40]); Systems.update(0.05, {});
  const deeper = !plate.classList.contains('hidden') && /The camps have a mended coat/.test(plate.textContent);
  /* the plate goes down on its own after a while */
  S.time += 23; UI.tick(); const down = plate.classList.contains('hidden');   // v3.44: the plate holds longer while it offers the Walker's answer
  /* made right: the face says that too, at the door and at the terminal */
  const dr = S.drops.find(d => d.item === it); State.addCargo(dr.item); S.drops.splice(S.drops.indexOf(dr), 1);
  WL.tp('elm'); WL.instantPar();
  const res = Systems.handleDelivery('elm').results.find(x => x.order && x.order.item === 'parcel');
  const madeShown = !plate.classList.contains('hidden') && plate.classList.contains('made') && /Kid, come see — it CAME/.test(plate.textContent);
  UI.openStation('elm');
  const madeTerminal = /Kid, come see — it CAME/.test(document.getElementById('keeperLine').textContent) && !document.querySelector('#keeperLine .keeperWords.grief');
  document.getElementById('stationClose').click();
  /* every keeper has a face at the terminal, grievance or none */
  UI.openStation('haven'); const havenFace = document.querySelector('#keeperLine .keeperFace') && document.querySelector('#keeperLine .keeperFace').src === Render.faceURL('haven', 3) && !document.querySelector('#keeperLine .keeperWords.grief'); document.getElementById('stationClose').click();
  UI.closeAllModals();
  return { line, shown, named, said, face: !!face, grief, lesson, atTerminal: !!atTerminal, once, deeper, down, made: !!(res && res.made && res.made.length), madeShown, madeTerminal, havenFace: !!havenFace };
});
ok('THE FACE AT THE DOOR: a grievance open at Elm — arriving inside the town\'s reach, Aldous Wren says it to your face (his portrait, his words about the coat for the kid, in rust; the lesson), before the board; at the terminal the face sits beside the same words; said once, not again on a second arrival — until the grievance deepens and there is a new thing to say; the plate goes down on its own (longer while it offers the answer); made right, the face says THAT at the door and at the terminal; every keeper has a face at the terminal, grievance or none',
  r.line && r.shown && r.named && r.said && r.face && r.grief && r.lesson && r.atTerminal && r.once && r.deeper && r.down && r.made && r.madeShown && r.madeTerminal && r.havenFace, JSON.stringify(r));

/* ================= 3 · THE TOWN'S OWN WHO FALL ================= */
r = await ev(() => {
  const mr = Math.random, F = DATA.T.ownFall;
  for (const k of Object.keys(REP.EVENTS)) S.rep.evCd[k] = 99999;
  S.banked.metal = 900; S.banked.wood = 300; S.banked.provisions = 500;
  for (const id of ['elm', 'mill', 'green', 'quarry']) S.stations[id].connected = true;
  Republic.tick(0.01); for (const k of Object.keys(REP.EVENTS)) S.rep.evCd[k] = 99999;
  Republic.fundMountain(); Republic.mountain().t = REP.MOUNTAIN.dur + 1; Republic.tick(0.6);
  Republic.rebellionStrike('mill'); S.stations.mill.likesTo = 55;
  Republic.fundStorm('mill'); const q = Republic.quell(); Math.random = () => 0.9; q.t = q.dur + 1; Republic.tick(0.02); Math.random = mr;
  const a = Republic.recruitOwn('mill'), c = Republic.recruitOwn('mill');
  NPC.setOrder(a, 'hours', 'days'); NPC.setOrder(c, 'hours', 'nights');   // by night only c stands
  const T2 = DATA.T, day0 = Math.floor(S.time / T2.dayLen) * T2.dayLen; S.time = day0 + T2.dayLen * 0.8;
  S.stations.mill.likesTo = 5; Republic.held().mill.shields = 2;
  const stones0 = S.legacy.length, likes0 = S.stations.mill.likesTo, noGround = !Memorial.site('town');
  Math.random = () => 0.1; const rose = Republic.squareRises('mill'); Math.random = mr;
  const town = S.legacy.filter(x => x.fact === 'town');
  const oneFell = town.length === 1 && town[0].name === c.name && town[0].kit === 'townshield' && /fell when the square rose at The Mill/.test(town[0].fate) && town[0].cls === 'The town\'s own';
  const colder = S.stations.mill.likesTo === Math.max(0, likes0 - F.likes);
  const ground = !!Memorial.site('town'), mailG = S.mails.find(m => /THE FIELD STONES/.test(m.subj)), mail = S.mails.find(m => /its own fell in the square/.test(m.subj)) && S.mails.find(m => /its own fell/.test(m.subj)).body.includes(c.name);
  const lesson = !!S.flags.tut.firstOwnFell, home = NPC.ownAt('mill').length === 0;
  /* the memorial reads the ground: the town's own figure on the card, the ground's name */
  Memorial.open('town');
  const sheet = document.getElementById('memHead').textContent + document.getElementById('memBody').textContent;
  const card = /the field stones/i.test(sheet) && sheet.includes(c.name) && !!document.querySelector('#memBody .memCard img[width="42"]');
  Memorial.close();
  return { rose, stones: town.length, oneFell, colder, noGround, ground, mailG: !!mailG, mail: !!mail, lesson, home, card };
});
ok('THE TOWN\'S OWN WHO FALL: the square rising at night, the recruit on NIGHTS stood and fell (the one on DAYS was home) — a stone with the town\'s own figure and the fate, the town colder by the row, THE FIELD STONES revealed at the fields\' edge with its mail, the fallen named in the mail, the lesson, the rest gone home; the memorial sheet reads the ground and the card',
  r.rose && r.stones === 1 && r.oneFell && r.colder && r.noGround && r.ground && r.mailG && r.mail && r.lesson && r.home && r.card, JSON.stringify(r));

/* ================= 4 · THE CHIEF'S RETURN, AS A SCENE ================= */
r = await ev(() => {
  const ash = DATA.camps.find(c => c.id === 'ash'), c = S.camps.ash, K = REP.WATCHPOST.storm.seen, T2 = DATA.T;
  for (const k of Object.keys(REP.EVENTS)) S.rep.evCd[k] = 99999;
  c.taken = null; c.pacified = false; c.runners = []; c.chiefReturn = null; c.stakeBare = 0;
  Republic.chiefFalls(ash);
  const gone0 = Republic.chiefGone(ash);
  S.time += K.mourn * T2.dayLen + 1;
  Republic.tick(0.1);
  const rt = c.chiefReturn;
  const begun = !!rt && rt.x0 !== undefined && Math.abs(U.dist(rt.x0, rt.y0, ash.x, ash.y) - ash.r * 0.9) < 2 && rt.tx === ash.x - 30;
  const stillGone = Republic.chiefGone(ash) && !Republic.chiefUp(ash);
  for (let i = 0; i < 30; i++) Republic.tick(0.2);   // six seconds: the walk in
  const arrived = !!c.chiefReturn && Math.abs(c.chiefReturn.x - rt.tx) < 2 && Math.abs(c.chiefReturn.y - rt.ty) < 2 && c.chiefReturn.said === true;
  const mails0 = S.mails.length;
  for (let i = 0; i < 9; i++) Republic.tick(0.2);    // the rag comes down
  const done = !c.chiefReturn && c.chiefLost === 0 && c.stakeBare > 0 && c.chiefReturned > 0 && Republic.chiefUp(ash) && !Republic.chiefGone(ash);
  const mail = S.mails[0] && /a new chief/.test(S.mails[0].subj) && S.mails.length === mails0 + 1, lesson = !!S.flags.tut.firstChiefBack;
  const bare = Republic.stakeBare(ash);
  /* the road walks whole again; the next storm brings him */
  WL.tp([DATA.stations.haven.x, DATA.stations.haven.y + 60]); Systems.update(0.25, {});
  const whole = c.runners.length === ash.runners;
  S.time += T2.dayLen + 1; const bareGone = !Republic.stakeBare(ash);
  return { gone0, begun, stillGone, arrived, done, mail: !!mail, lesson, bare, whole, bareGone };
});
ok('THE CHIEF\'S RETURN, AS A SCENE: the span passed, a new chief begins at the ring\'s edge (the camp still short a chief while he walks), reaches the stake in six seconds and says so, and takes the rag down — the camp whole again (the mail, the lesson), the stake bare for a day, the road walking whole',
  r.gone0 && r.begun && r.stillGone && r.arrived && r.done && r.mail && r.lesson && r.bare && r.whole && r.bareGone, JSON.stringify(r));

/* ================= 5 · THE SCAR ================= */
r = await ev(() => {
  const C = DATA.T.scar, T2 = DATA.T;
  for (const n of S.npcs.filter(x => x.state === 'companion')) n.state = 'pool';
  WL.tp([DATA.stations.haven.x + 700, DATA.stations.haven.y + 700]); S.room = null; S.moveTo = null; S.speed = 0;
  S.arrow = null; S.scar = null; S.health = 80; S.food = 40; S.stam = S.stamMax;
  /* the pull leaves the scar; the wind's ceiling drops */
  Systems.boltIn('ridge');
  const act = Systems.getInteractions().find(i => /Pull the bolt/.test(i.label)); act.fn();
  for (let i = 0; i < 12; i++) Systems.update(0.25, {});
  const scarred = !S.arrow && !!S.scar && S.scar.dressed === 0 && S.scar.by === 'self', lesson = !!S.flags.tut.firstScar;
  S.stam = S.stamMax; Systems.update(0.05, {});
  const ceiling = Math.abs(S.stam - S.stamMax * C.stamMul) < 0.01;
  UI.updateHUD(); const chip = /A SCAR · 0\/3 DRESSED/.test(document.getElementById('buffs').textContent);
  /* the medic dresses it, every dressEvery inside reach */
  const m = NPC.gen({ at: 'haven', cls: 'medic' }); m.feeWaived = true; S.npcs.push(m); NPC.hire(m, 'companion'); m.cx = S.px + 20; m.cy = S.py; m.hungry = false; m.shoveCd = 0;
  S.scar.dressT = C.dressEvery - 0.1; Systems.update(0.25, {});
  const dressed1 = S.scar.dressed === 1 && /dressed the bolt's wound \(1\/3\)/.test(NPC.svc(m).last) && NPC.svc(m).dressed === 1;
  const stillCeiling = (S.stam = S.stamMax, Systems.update(0.05, {}), Math.abs(S.stam - S.stamMax * C.stamMul) < 0.01);
  m.state = 'pool';
  /* a lit town's hands, once a visit */
  WL.tp('haven'); Systems.handleDelivery('haven');
  const dressed2 = S.scar.dressed === 2;
  Systems.handleDelivery('haven');
  const onceAVisit = S.scar.dressed === 2;
  const byHand = Systems.dressScar('town') === true && S.scar.dressed === 3;
  UI.updateHUD(); const chip2 = /A SCAR · DRESSED/.test(document.getElementById('buffs').textContent);
  /* dressed: the ceiling lifts, and it closes in a day */
  S.stam = S.stamMax; Systems.update(0.05, {}); const lifted = S.stam > S.stamMax * 0.99;
  S.scar.t0 = S.time - C.healDays * T2.dayLen - 1; Systems.update(0.05, {});
  const healed = !S.scar && /scar closes/.test(document.getElementById('toasts').textContent);
  /* undressed: it hangs on longer, then closes late */
  Systems.boltIn('ridge'); Systems.pullBolt ? null : null;
  const act2 = Systems.getInteractions().find(i => /Pull the bolt/.test(i.label)); act2.fn(); for (let i = 0; i < 12; i++) Systems.update(0.25, {});
  S.scar.t0 = S.time - C.healDays * T2.dayLen - 1; Systems.update(0.05, {}); const hangs = !!S.scar;
  S.scar.t0 = S.time - C.undressedDays * T2.dayLen - 1; Systems.update(0.05, {}); const late = !S.scar && /late/.test(document.getElementById('toasts').textContent);
  WL.tp([DATA.stations.haven.x, DATA.stations.haven.y + 60]);
  return { scarred, lesson, ceiling, chip, dressed1, stillCeiling, dressed2, onceAVisit, byHand, chip2, lifted, healed, hangs, late };
});
ok('THE SCAR: the pulled bolt leaves a scar (the lesson) — the wind\'s ceiling at 85 until it is dressed (the HUD counts the dressings); a medic walking with you winds it once a minute (their note, still a ceiling at one of three); a lit town\'s hands dress it once a visit; dressed thrice the ceiling lifts and the scar closes in a day; undressed it hangs on and closes late',
  r.scarred && r.lesson && r.ceiling && r.chip && r.dressed1 && r.stillCeiling && r.dressed2 && r.onceAVisit && r.byHand && r.chip2 && r.lifted && r.healed && r.hangs && r.late, JSON.stringify(r));

/* ================= 6 · THE CLICK INTO THE ROLL ================= */
{
  await ev(() => { const ash = DATA.camps.find(c => c.id === 'ash'); S.camps.ash.chiefLost = 0; S.camps.ash.chiefReturn = null; S.moveTo = null; S.route = []; WL.tp([ash.x, ash.y + 500]); UI.toggleMap(true); });
  await page.waitForTimeout(300);
  const pt = await ev(() => { const ash = DATA.camps.find(c => c.id === 'ash'); return UI.mapPoint(ash.x, ash.y + 22 / 0.14); });
  await page.mouse.move(pt.x, pt.y); await page.waitForTimeout(150);
  const hover = await ev(() => { const tip = document.getElementById('mapTip'); return { shown: tip.style.display === 'block' && tip.classList.contains('roll'), own: /THE CAMP'S OWN/.test(tip.textContent), rows: ['Chief', 'Bowman', 'Ram', 'Knife'].every(k => tip.textContent.includes(k)), fire: /the chief keeps it/.test(tip.textContent), imgs: tip.querySelectorAll('img').length, hint: /click the marks to pin/.test(tip.textContent) }; });
  await page.mouse.down(); await page.mouse.up(); await page.waitForTimeout(150);
  const pinned = await ev(() => { const tip = document.getElementById('mapTip'); return { shown: tip.style.display === 'block', pinnedLine: /pinned — click anywhere/.test(tip.textContent), noWalk: !S.moveTo, mapOpen: !document.getElementById('mapWrap').classList.contains('hidden') }; });
  await page.mouse.move(pt.x + 200, pt.y + 150); await page.waitForTimeout(150);
  const stays = await ev(() => document.getElementById('mapTip').style.display === 'block');
  await page.mouse.down(); await page.mouse.up(); await page.waitForTimeout(150);
  const released = await ev(() => ({ hidden: document.getElementById('mapTip').style.display === 'none', noWalk: !S.moveTo, mapOpen: !document.getElementById('mapWrap').classList.contains('hidden') }));
  /* the chief gone reads on the roll too */
  await ev(() => { Republic.chiefFalls(DATA.camps.find(c => c.id === 'ash')); UI.drawMap(); });
  await page.mouse.move(pt.x, pt.y); await page.waitForTimeout(150);
  const goneRow = await ev(() => { const t = document.getElementById('mapTip').textContent; return /GONE — the rag on a stake/.test(t) && /nobody keeps it/.test(t); });
  await ev(() => { UI.toggleMap(false); S.camps.ash.chiefLost = 0; });
  r = { ...hover, pinned, stays, released, goneRow };
  ok('THE CLICK INTO THE ROLL: hovering a camp\'s marks on the sheet opens the camp\'s roll — every trade with its mark, name and line, the fire\'s keeper, the hint; a click pins it (no walk is planned, the sheet stays open); moved away it stays; the next click lets it go and plans no walk; the chief gone reads on the roll',
    hover.shown && hover.own && hover.rows && hover.fire && hover.imgs >= 5 && hover.hint && pinned.shown && pinned.pinnedLine && pinned.noWalk && pinned.mapOpen && stays && released.hidden && released.noWalk && released.mapOpen && goneRow, JSON.stringify(r));
}

/* ================= 7 · THE SAVE ================= */
r = await ev(() => {
  const ash = DATA.camps.find(c => c.id === 'ash');
  S.scar = { t0: S.time, dressed: 2, dressT: 0, by: 'self' };
  S.camps.ash.stakeBare = S.time; S.stations.elm.madeSaid = { line: 'Kid, come see — it CAME.', t: S.time };
  const townStones = S.legacy.filter(x => x.fact === 'town').length, site = Memorial.site('town');
  State.save();
  S.scar = null; S.camps.ash.stakeBare = 0; S.stations.elm.madeSaid = null; S.legacy = S.legacy.filter(x => x.fact !== 'town'); S.mem.sites.town = null;
  State.load();
  const scar = !!S.scar && S.scar.dressed === 2, stake = Republic.stakeBare(ash), said = !!S.stations.elm.madeSaid, stones = S.legacy.filter(x => x.fact === 'town').length === townStones && townStones >= 1;
  const ground = Memorial.site('town') && Memorial.site('town').x === site.x;
  S.scar = null;
  return { scar, stake, said, stones, ground: !!ground };
});
ok('THE SAVE: the scar and its dressings, a bare stake, what the keeper last said, the town\'s own stones and THE FIELD STONES survive a save and load', r.scar && r.stake && r.said && r.stones && r.ground, JSON.stringify(r));

ok('no page errors across the faces', errors.length === 0, errors.slice(0, 3).join(' | '));
console.log(results.join('\n'));
console.log(`${results.filter(x => x.startsWith('PASS')).length}/${results.length} checks passed`);
await b.close();
