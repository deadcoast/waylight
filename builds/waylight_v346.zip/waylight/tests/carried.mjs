/* carried.mjs — v3.46 THE WORD CARRIED: the word on the wire (a letter walking the wire to the nearest lit towns, heard
   there — warmer or cooler, the book, the keeper at the door, the weight on every lit terminal; the wire's caravans drawn
   again); the kin's thanks (a keepsake under the pack, seen at every delivery in its town, on the plate, kept out of the
   lockers, carried to the stone) and the stone's flame asked again at the next dark; the truce as a road (a charter run
   through an open ring runs quicker, white rags at the ring's edge, the runner seen walking it, the chief's runner with a
   gift on the pact's last day — or turned back when the word breaks); a score settled (paid, then walked to the ring:
   said, a stone left, the plate carrying it); the line's orders (HOLD the edge and turn the knives; COME in abreast,
   the knives holding off, no running); the save. */
import { chromium } from 'playwright';
const results = [];
const ok = (name, cond, extra = '') => { results.push(`${cond ? 'PASS' : 'FAIL'}  ${name}${extra ? '  — ' + extra : ''}`); if (!cond) process.exitCode = 1; };
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium', args: ['--disable-background-networking'] });
const page = await b.newPage({ viewport: { width: 1440, height: 860 } });
await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
const errors = [];
page.on('pageerror', e => errors.push(String(e.message)));
await page.goto('file:///home/claude/waylight/dist/test.html?debug', { waitUntil: 'domcontentloaded' });
await page.waitForFunction(() => window.WL && WL.snapshot && WL.snapshot().baked, null, { timeout: 60000 });
await page.evaluate(() => localStorage.clear());
await page.click('#btnNew'); await page.waitForTimeout(300);
await page.click('#btnBegin'); await page.waitForTimeout(400);
await page.click('#briefGo'); await page.waitForTimeout(300);
await page.click('#cgBegin'); await page.waitForTimeout(1200);
for (let i = 0; i < 30; i++) { const c = await page.evaluate(() => !!S.cine); if (!c) break; await page.evaluate(() => WL.skipCine()); await page.waitForTimeout(250); }
await page.evaluate(() => { S.flags.guideDone = true; WL.calm(); S.flags.torchCross = S.flags.torchSeen = S.flags.torchNamed = true; S.flags.mythSeen = 9; });   // the valley's first-sight scenes are spent: no letterbox takes a world frame mid-read
const ev = (fn, arg) => page.evaluate(fn, arg);
const T00 = Date.now(), lap = n => { if (process.env.DBG) console.log('lap', n, ((Date.now() - T00) / 1000).toFixed(1)); };
await ev(() => {
  window.__toScr = (wx, wy) => { const z2 = Render.effZoom() / devicePixelRatio; return { x: innerWidth / 2 + (wx - Render.cam.x) * z2, y: innerHeight / 2 + (wy - Render.cam.y) * z2 }; };
  /* the game canvas, sampled: how many pixels near a world point are within tol of a colour */
  window.__near = (wx, wy, col, tol, rad) => { const p = __toScr(wx, wy), cv = document.getElementById('game'), g = cv.getContext('2d'), dpr = devicePixelRatio; const x0 = Math.max(0, Math.round((p.x - rad) * dpr)), y0 = Math.max(0, Math.round((p.y - rad) * dpr)), w = Math.round(rad * 2 * dpr); const d = g.getImageData(x0, y0, w, w).data; let hit = 0; for (let i = 0; i < d.length; i += 4) if (Math.abs(d[i] - col[0]) < tol && Math.abs(d[i + 1] - col[1]) < tol && Math.abs(d[i + 2] - col[2]) < tol) hit++; return hit; };
  window.__hex = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16));
  for (const k of Object.keys(REP.EVENTS)) S.rep.evCd[k] = 99999;
  for (const id of ['elm', 'mill', 'green', 'quarry', 'relay', 'foundry', 'pharos']) S.stations[id].connected = true;
  S.banked.metal = 900; S.banked.wood = 300; S.banked.provisions = 500; S.banked.ceramic = 120; S.cov = 0.6;
});
const frame = async (fn, arg) => { await ev(fn, arg); await page.waitForTimeout(450); };
/* the valley's big white voice drains before a world frame is read (a storming's title would sit over it), and the frame is read by day */
const drain = async () => { for (let i = 0; i < 150; i++) { const on = await ev(() => Render.crtActive && Render.crtActive()); if (!on) break; await page.waitForTimeout(200); } await ev(() => { const DL = DATA.T.dayLen; S.time = Math.floor(S.time / DL) * DL + DL * 1.3; }); };
const unfreeze = () => ev(() => { WL.timeScale = 1; Render.setZoom(null); });

lap(1);
/* ================= 1 · THE REGISTRIES ================= */
let r = await ev(() => {
  const inPal = (rows, pal, w, h) => rows.length === h && rows.every(rw => rw.length === w) && [...new Set(rows.join('').replace(/\./g, ''))].every(ch => pal[ch]);
  const NEW = ['heard', 'keepsake', 'relight', 'truce', 'settled', 'hold', 'come', 'turned', 'ks_whetstone', 'ks_button', 'ks_bird', 'ks_whistle', 'ks_flower', 'ks_ring'];
  const marks = NEW.every(k => inPal(SPRITES.MARKS[k], SPRITES.MARK_PAL, 7, 7)) && new Set(Object.values(SPRITES.MARKS).map(m => m.join(''))).size === Object.keys(SPRITES.MARKS).length;
  const notes = inPal(SPRITES.WORDNOTE.kept, SPRITES.WORD_PAL, 7, 5) && inPal(SPRITES.WORDNOTE.broken, SPRITES.WORD_PAL, 7, 5) && SPRITES.WORDNOTE.kept.join('') !== SPRITES.WORDNOTE.broken.join('');
  const stake = inPal(SPRITES.TRUCESTAKE, SPRITES.TRUCE_PAL, 7, 13), stone = inPal(SPRITES.SETTLESTONE, SPRITES.SETTLE_PAL, 8, 7);
  const gift = SPRITES.GIFT_CELLS.length >= 12 && SPRITES.GIFT_CELLS.every(([c, rr, ch]) => c >= 0 && c < 12 && rr >= 0 && rr < 18 && SPRITES.GIFT_PAL[ch]);
  const ks = Object.values(SPRITES.KEEPSAKES), keepsakes = ks.length === 6 && ks.every(k => SPRITES.MARKS[k.mark] && inPal(k.token, SPRITES.TOKEN_PAL, 2, 3) && k.name.length > 3) && new Set(ks.map(k => k.token.join(''))).size === 6;
  const T2 = DATA.T, rows = T2.word.wire.near === 2 && T2.word.wire.speed > 0 && T2.kin.relights >= 1 && T2.kin.keepsakeLikes > 0 && T2.parley.roadMul < 1 && T2.parley.giftBack.metal > 0 && T2.score.settleR > 0 && T2.score.walkDays > 0 && T2.ring.turnR > 0 && T2.ring.comeR > 0 && T2.ring.holdLong > T2.ring.holdMax;
  const lines = Object.keys(DATA.keepsakeLines).length === 6 && Object.keys(SPRITES.KEEPSAKES).every(k => /\{first\}/.test(DATA.keepsakeLines[k])) && ['taken', 'stood down', 'chief'].every(h => DATA.settleLines[h].length >= 2);
  const voices = DATA.stationOrder.every(id => ['heardKept', 'heardBroken'].every(k => DATA.keeperGrief[id][k] && /\{town\}/.test(DATA.keeperGrief[id][k])));
  const item = DATA.items.keepsake && DATA.items.keepsake.cat === 'kin' && Ledger.classify('keepsake') === 'keepsakes';
  const lessons = ['firstWireWord', 'firstKeepsake', 'firstRelight', 'firstTruceRoad', 'firstGiftRunner', 'firstSettled', 'firstLineOrders'].every(k => DATA.tutorials[k] && DATA.tutorialTitles[k]), lessonsN = Object.keys(DATA.tutorials).length;
  const causes = Object.keys(MUSTER.MOOD.causes).length, settledCause = MUSTER.MOOD.causes.settled && MUSTER.MOOD.causes.settled.v > 0;
  const q = KEYS.PROMPT_KEYS.includes('Q') && !Object.values(KEYS.ACTIONS).some(a => a.codes.includes('KeyQ'));
  return { marks, notes, stake, stone, gift, keepsakes, rows, lines, voices, item: !!item, lessons, lessonsN, causes, settledCause: !!settledCause, q };
});
ok('THE REGISTRIES: fourteen new marks (the bell, the pendant, the cold lantern, the white rag, the settled stones, the roped line, the three under the arrow, the U of the way back, six keepsakes) 7×7 in the marks\' palette and every mark distinct; the letter on the wire kept and broken; the truce stake; the settled stones; the chief\'s runner\'s gift on the rig\'s grid; six keepsakes with a mark and a token each; the rows; six kin lines and three ways to settle; sixteen keeper lines for what the wire brought; the keepsake filed under Keepsakes; seven lessons (seventy-three); twenty-seven causes; Q on the rail and no action\'s key',
  r.marks && r.notes && r.stake && r.stone && r.gift && r.keepsakes && r.rows && r.lines && r.voices && r.item && r.lessons && r.lessonsN === 73 && r.causes === 27 && r.settledCause && r.q, JSON.stringify(r));

lap(2);
/* ================= 2 · THE WORD ON THE WIRE ================= */
r = await ev(() => {
  const st = DATA.stations, T2 = DATA.T, W2 = T2.word.wire;
  /* a promise kept at Elm through the engine's own path: the book writes it, and the word walks the wire */
  S.wireWords = [];
  S.grievances = S.grievances || []; S.grievances.push({ id: 'gWire', to: 'elm', from: 'haven', kind: 'tin', name: 'a tin of buttons', t: S.time, how: 'ground', n: 1, remembered: false, word: 'promise', wordT: S.time });
  Economy.strikeGrievance({ id: 'gWire' }, 'elm');
  const words = Economy.wireWords().filter(w => w.from === 'elm');
  const near = DATA.stationOrder.filter(id => id !== 'elm' && S.stations[id].connected).sort((a, b2) => U.dist(st.elm.x, st.elm.y, st[a].x, st[a].y) - U.dist(st.elm.x, st.elm.y, st[b2].x, st[b2].y)).slice(0, 2);
  const walked = words.length === 2 && words.every(w => w.kind === 'kept' && near.includes(w.to) && Math.abs(w.eta - (w.t0 + Economy.wireRoute('elm', w.to).len / W2.speed)) < 0.01);
  /* the engine's other door: a word sent by hand walks the same way */
  const n2 = Economy.wireWord('mill', 'broken', 'a test word'), broken = n2 === 2 && Economy.wireWords().filter(w => w.from === 'mill' && w.kind === 'broken').length === 2;
  /* halfway down the wire: where the letter is */
  const w0 = words[0], mid = Economy.wireWordAt({ ...w0, t0: S.time - (w0.eta - w0.t0) / 2 });
  return { walked, broken, near, to: words.map(w => w.to), mid: { f: mid.f } };
});
const wire1 = JSON.stringify(r), wireOk1 = r.walked && r.broken && Math.abs(r.mid.f - 0.5) < 0.02;
/* the letter, seen on the wire: halfway along its route, the paper and the seal on the game canvas */
await frame(() => { const w = Economy.wireWords().find(x => x.from === 'elm'); w.t0 = S.time - (w.eta - w.t0) / 2; w.eta = S.time + 9999; const p = Economy.wireWordAt(w); Render.setZoom(2.2); Render.cam.x = p.x; Render.cam.y = p.y - 16; WL.timeScale = 0.001; window.__w = w; });
const noteSeen = await ev(() => { const p = Economy.wireWordAt(__w); return { paper: __near(p.x, p.y - 17, __hex('#e8e0c8'), 16, 26), seal: __near(p.x, p.y - 17, __hex('#ffd98f'), 20, 26) }; });
/* and on the survey sheet */
await ev(() => { WL.timeScale = 1; Render.setZoom(null); UI.toggleMap(true); });
await page.waitForTimeout(300);
const noteSheet = await ev(() => { const p = Economy.wireWordAt(__w), c = document.getElementById('map'), g = c.getContext('2d'), m = UI.mapPoint(p.x, p.y), r0 = c.getBoundingClientRect(), dpr = devicePixelRatio; const d = g.getImageData(Math.round((m.x - r0.left - 16) * dpr), Math.round((m.y - r0.top - 12) * dpr), Math.round(32 * dpr), Math.round(24 * dpr)).data; let hit = 0; for (let i = 0; i < d.length; i += 4) if (Math.abs(d[i] - 0xe8) < 14 && Math.abs(d[i + 1] - 0xe0) < 14 && Math.abs(d[i + 2] - 0xc8) < 16) hit++; UI.toggleMap(false); return hit; });
/* landing: the neighbours hear it */
r = await ev(() => {
  const W2 = DATA.T.word.wire, kept = Economy.wireWords().filter(w => w.from === 'elm'), to = kept.map(w => w.to);
  const likes0 = to.map(id => S.stations[id].likesTo), appr0 = to.map(id => S.stations[id].appr || 0);
  for (const w of Economy.wireWords()) if (w.from === 'elm') w.eta = S.time - 0.01;
  Economy.update(0.01);
  const heard = to.every((id, i) => S.stations[id].likesTo === Math.min(100, likes0[i] + W2.likes) && (S.stations[id].appr || 0) > appr0[i] && Economy.book(id).heardKept >= 1 && Economy.book(id).log[0].kind === 'heardKept' && Economy.book(id).log[0].name === 'Elm Farm' && S.stations[id].heardSay && S.stations[id].heardSay.kind === 'kept');
  const toast = /heard it on the wire/.test(document.getElementById('toasts').textContent), lesson = !!S.flags.tut.firstWireWord;
  /* the keeper at the door says what the wire brought; the terminal carries the word's weight */
  const t0 = to[0]; S.stations[t0].met = true; WL.tp(t0); UI.openStation(t0);   // a door you have met: strangers get the hello first
  const kl = document.getElementById('keeperLine').textContent, V = DATA.keeperGrief[t0].heardKept.replace(/\{town\}/g, 'Elm Farm').slice(0, 24);
  const door = kl.includes(V) || kl.toLowerCase().includes(V.toLowerCase());
  const bl = document.getElementById('bookLine').textContent, weight = /ON THE WIRE/.test(bl) && /heard: your word kept at Elm Farm/.test(bl);
  UI.gotoTab('ledger'); const ledger = /HEARD ON THE WIRE — KEPT AT/.test(document.getElementById('stationBody').textContent);
  document.getElementById('stationClose').click();
  /* a broken word lands cooler */
  const bw = Economy.wireWords().filter(w => w.from === 'mill'), bto = bw.map(w => w.to), bl0 = bto.map(id => S.stations[id].likesTo);
  for (const w of bw) w.eta = S.time - 0.01; Economy.update(0.01);
  const cooler = bto.every((id, i) => S.stations[id].likesTo === Math.max(0, bl0[i] - W2.likes) && Economy.book(id).heardBroken >= 1 && S.stations[id].heardSay.kind === 'broken');
  const gone = Economy.wireWords().length === 0;
  return { heard, toast, lesson, door, doorLine: door ? '' : kl.slice(0, 160), weight, ledger, cooler, gone };
});
const wire2 = JSON.stringify(r), wireOk2 = r.heard && r.toast && r.lesson && r.door && r.weight && r.ledger && r.cooler && r.gone;
/* the wire's own caravans are drawn again: a caravan past its route's end is taken off the wire on the next frame */
const caravan = await ev(async () => {
  const P = Economy.pulses; P.length = 0; P.push({ a: 'haven', b: 'elm', t: 1e6 }, { a: 'haven', b: 'elm', t: 0 });
  await new Promise(res => setTimeout(res, 300));
  return { gone: !P.some(p => p.t >= 1e6), live: P.some(p => p.t > 0 && p.t < 1e5) };
});
ok('THE WORD ON THE WIRE: a promise kept at Elm is written in its book and walks the wire to its two nearest lit towns on the wire\'s own route (a broken word the same, sent by the engine\'s door); halfway, the letter is on the canvas (paper and gold seal, pixel-sampled) and on the survey sheet; landing, each town hears it — a like warmer and appreciation for a word kept, a like cooler for a word broken — the book logs what it heard, the toast, the lesson; the keeper at the door says it, the terminal carries your word\'s weight and what was heard, the Ledger writes it; the wire\'s caravans are taken off at their route\'s end again',
  wireOk1 && noteSeen.paper > 8 && noteSeen.seal > 2 && noteSheet > 4 && wireOk2 && caravan.gone && caravan.live, wire1 + ' ' + JSON.stringify(noteSeen) + ' sheet=' + noteSheet + ' ' + wire2 + ' ' + JSON.stringify(caravan));

lap(3);
/* ================= 3 · THE KIN'S THANKS ================= */
r = await ev(() => {
  const mr = Math.random, T2 = DATA.T;
  Republic.tick(0.01); for (const k of Object.keys(REP.EVENTS)) S.rep.evCd[k] = 99999;
  Republic.fundMountain(); Republic.mountain().t = REP.MOUNTAIN.dur + 1; Republic.tick(0.6);
  Republic.rebellionStrike('mill'); S.stations.mill.likesTo = 55;
  Republic.fundStorm('mill'); const q = Republic.quell(); Math.random = () => 0.9; q.t = q.dur + 1; Republic.tick(0.02); Math.random = mr;
  const a = Republic.recruitOwn('mill'), c = Republic.recruitOwn('mill'); a.name = 'Halvard Penrose'; c.name = 'Ottilie Marsh';
  NPC.setOrder(a, 'hours', 'nights'); NPC.setOrder(c, 'hours', 'nights');
  S.time = Math.floor(S.time / T2.dayLen) * T2.dayLen + T2.dayLen * 0.8;
  S.stations.mill.likesTo = 5; Republic.held().mill.shields = 2;
  Math.random = () => 0.1; Republic.squareRises('mill'); Math.random = mr;
  Memorial.raise('town'); Memorial.raise('town');
  S.time = Math.floor(S.time / T2.dayLen) * T2.dayLen + T2.dayLen * 1.3;   // the next morning
  const site = Memorial.site('town');
  const ds = S.drops.find(d => d.item && d.item.defId === 'kinShield'); State.addCargo(ds.item); S.drops.splice(S.drops.indexOf(ds), 1);
  WL.tp([site.x + 20, site.y + 40]);
  const give = Systems.getInteractions().find(i => i.key === 'G' && /Halvard's shield/.test(i.label)); give && give.fn();
  const thing = Republic.keepsakeOf('Halvard Penrose'), K = SPRITES.KEEPSAKES[thing];
  const it = S.cargo.find(x => x.keepsake);
  const kept = !!give && !!it && it.name === `Halvard's ${K.name}` && it.keepsake.town === 'mill' && it.keepsake.thing === thing && it.defId === 'keepsake';
  const mail = S.mails.some(m => /something of Halvard's/.test(m.subj) && m.body.includes(DATA.keepsakeLines[thing].replace(/\{first\}/g, 'Halvard').slice(0, 20)));
  const lesson = !!S.flags.tut.firstKeepsake, stable = Republic.keepsakeOf('Halvard Penrose') === thing;
  return { kept, thing, mail, lesson, stable };
});
const ks1 = JSON.stringify(r), ksOk1 = r.kept && r.mail && r.lesson && r.stable, thing = r.thing;
/* under the pack: the token, seen — the same frame with and without the keepsake */
const tokenSeen = await ev(async thing => {
  const tok = SPRITES.KEEPSAKES[thing].token, col = __hex(SPRITES.TOKEN_PAL[tok[1][0]]);
  const T2 = DATA.T; S.time = Math.floor(S.time / T2.dayLen) * T2.dayLen + T2.dayLen * 0.3;
  WL.tp([DATA.stations.haven.x + 1700, DATA.stations.haven.y - 1300]); S.dir = 0; Systems.update(0.05, {}); Render.clearFx();
  Render.setZoom(3); Render.cam.x = S.px; Render.cam.y = S.py - 14; WL.timeScale = 0.001;
  await new Promise(res => setTimeout(res, 350));
  const withIt = __near(S.px - 11, S.py + 1, col, 14, 14);
  const it = S.cargo.find(x => x.keepsake), i = S.cargo.indexOf(it); S.cargo.splice(i, 1);
  await new Promise(res => setTimeout(res, 250));
  const without = __near(S.px - 11, S.py + 1, col, 14, 14);
  S.cargo.splice(i, 0, it); WL.timeScale = 1; Render.setZoom(null);
  return { withIt, without };
}, thing);
r = await ev(() => {
  const K = DATA.T.kin;
  /* a delivery into the Mill with the keepsake under the pack: the town sees it (the Mill lit again after its square rose —
     staged as the relight run done) */
  delete S.rep.unlit.mill; S.stations.mill.connected = true; S.stations.mill.litT = 1; State.refreshSources();
  WL.tp('haven');
  let o = null;
  for (const id of DATA.stationOrder) { if (!S.stations[id].connected || o) continue; o = (Economy.ordersFor(id) || []).find(x => x.to === 'mill' && !x.errand && !S.orders.active.some(a => a.id === x.id)) || null; if (o) WL.tp(id); }
  if (!o) return { order: false, millLit: S.stations.mill.connected, unlit: Republic.isUnlit && Republic.isUnlit('mill'), boards: DATA.stationOrder.map(id => id + ':' + (Economy.ordersFor(id) || []).map(x => x.to).join('/')).join(' ') };
  Systems.acceptOrder(o, false);
  WL.tp('mill'); WL.instantPar && WL.instantPar();
  const likes0 = S.stations.mill.likesTo;
  const res = Systems.handleDelivery('mill'), g = res.results.find(x => x.keepsake);
  const seen = !!g && g.keepsake.likes === K.keepsakeLikes && g.keepsake.names[0].startsWith('Halvard');
  UI.queueResults(res.results, null); const slip = /THE KIN'S THANKS/.test(document.getElementById('scoreRows').textContent);
  document.getElementById('results').classList.add('hidden');
  /* the plate at the Mill's terminal carries it */
  UI.openStation('mill'); const plate = /under your pack, from/.test(document.getElementById('keeperLine').textContent) && !!document.querySelector('#keeperLine .keepsakeRow img');
  document.getElementById('stationClose').click();
  /* the dossier told to store all cargo leaves it on the pack */
  const P = Ledger.led().policy, saved = JSON.stringify(P); Ledger.setMark('cargo', 'store', true); Ledger.runDossier('mill');
  const locker = S.cargo.some(c => c.keepsake) && !S.stations.mill.storage.some(c => c.keepsake); Ledger.led().policy = JSON.parse(saved);
  /* to the stone: the row keeps what was carried, and the card shows it */
  const row = { name: 'Keeper Test', cls: 'Courier', fate: 'hung up the coat', likes: 1, km: '1.0', deliveries: 1, cheated: false, seed: 77, fact: 'waylight', scars: 0, look: null, keepsakes: S.cargo.filter(c => c.keepsake).map(c => ({ name: c.name, thing: c.keepsake.thing })) };
  S.legacy.push(row); for (let i = 0; i < 6 && !Memorial.rows('waylight').find(x => x.name === 'Keeper Test' && x.raised); i++) Memorial.raise('waylight');
  Memorial.open('waylight'); const card = [...document.querySelectorAll('#memBody .memCard')].some(el => /Keeper Test/.test(el.textContent) && /the kin's thanks/.test(el.textContent) && el.querySelector('.memKin img')); Memorial.close();
  S.legacy.splice(S.legacy.indexOf(row), 1);
  return { order: true, seen, slip, plate, locker, card, row: row.keepsakes.length };
});
ok('THE KIN\'S THANKS: the shield given home, the kin gives the Walker something of Halvard\'s — a keepsake named for him and the thing (the same thing for the same name), the kin\'s own line in the mail, the lesson; it hangs under the pack (pixel-sampled against the same frame without it); a delivery into the Mill with it is a like warmer and the slip says so; the Mill\'s plate carries it; the dossier keeps it out of the lockers; the stone\'s row carries it and the card shows it',
  ksOk1 && tokenSeen.withIt > tokenSeen.without + 6 && r.order && r.seen && r.slip && r.plate && r.locker && r.card && r.row >= 1, ks1 + ' ' + JSON.stringify(tokenSeen) + ' ' + JSON.stringify(r));

lap(4);
/* ================= 4 · THE STONE'S FLAME, ASKED AGAIN ================= */
r = await ev(() => {
  const T2 = DATA.T, K = T2.kin, site = Memorial.site('town'), DL = T2.dayLen;
  /* the lantern: lit at a waylight and set at Ottilie's stone */
  const dl = S.drops.find(d => d.item && d.item.defId === 'kinLantern'); State.addCargo(dl.item); S.drops.splice(S.drops.indexOf(dl), 1);
  WL.tp('haven'); Systems.getInteractions().find(i => i.key === 'L' && /Take the flame/.test(i.label)).fn();
  WL.tp([site.x + 20, site.y + 40]); Systems.getInteractions().find(i => i.key === 'G' && /Ottilie's lantern/.test(i.label)).fn();
  const row = S.legacy.find(x => x.name === 'Ottilie Marsh'), keepsake2 = S.cargo.filter(c => c.keepsake).length === 2;
  /* it burns through the night it was set */
  S.time = Math.floor(S.time / DL) * DL + DL * 0.9; Republic.tick(0.02);
  const firstNight = row.lit === true && !Republic.kinOpen().some(e => e.kind === 'relight');
  /* and goes out at the next dark: the kin asks again */
  S.time = Math.floor(S.time / DL) * DL + DL * 1.7; Republic.tick(0.02);
  const e = Republic.kinOpen().find(x => x.kind === 'relight' && x.fallen === 'Ottilie Marsh');
  const asked = !row.lit && !!row.cold && !!e && S.mails.some(m => /Ottilie's lantern is out/.test(m.subj)) && !!S.flags.tut.firstRelight;
  UI.tick(); const compass = [...document.querySelectorAll('#compassInner .cMark')].some(m => /the stone's flame/.test(m.title));
  S.orders.active.length = 0; WL.tp('haven'); Guide.tick(0.3); const gs = Guide.current(), guide = !!gs && gs.id === 'relight' && /lantern went out/.test(gs.head);   // guided while no order rides the pack
  return { keepsake2, firstNight, asked, compass, guide, eid: e ? e.id : null };
});
const fl1 = JSON.stringify(r), flOk1 = r.keepsake2 && r.firstNight && r.asked && r.compass && r.guide;
/* the cold lantern, seen at the stone */
await frame(() => { const rw = Memorial.rows('town').find(x => x.name === 'Ottilie Marsh'), sl = Memorial.slotFor(rw.ord, 'town'); WL.tp([sl.x + 20, sl.y + 90]); S.dir = -Math.PI / 2; Render.setZoom(3); Render.cam.x = sl.x + 10; Render.cam.y = sl.y + 10; WL.timeScale = 0.001; });
const coldSeen = await ev(() => { const rw = Memorial.rows('town').find(x => x.name === 'Ottilie Marsh'), sl = Memorial.slotFor(rw.ord, 'town'); return { dark: __near(sl.x + 16, sl.y + 14, __hex('#4a4f57'), 10, 22), gold: __near(sl.x + 16, sl.y + 14, __hex('#ffd98f'), 24, 22) }; });
await unfreeze();
r = await ev(eid => {
  const T2 = DATA.T, K = T2.kin, site = Memorial.site('town'), DL = T2.dayLen, row = S.legacy.find(x => x.name === 'Ottilie Marsh');
  WL.tp([site.x + 20, site.y + 40]);
  const take = Systems.getInteractions().find(i => i.key === 'G' && /Take <b>Ottilie's lantern<\/b> from the stone/.test(i.label)); take && take.fn();
  const e = Republic.kinOpen().find(x => x.id === eid);
  const taken = !!take && S.cargo.some(c => c.defId === 'kinLantern' && c.kin === eid && !c.lit) && Republic.lanternOff('Ottilie Marsh');
  const again = !Republic.kinTakeLantern(e);   // the stone gives it once
  WL.tp('haven'); Systems.getInteractions().find(i => i.key === 'L' && /Take the flame/.test(i.label)).fn();
  const likes0 = S.stations.mill.likesTo;
  WL.tp([site.x + 20, site.y + 40]); const set = Systems.getInteractions().find(i => i.key === 'G' && /Ottilie's lantern/.test(i.label) && /lit/.test(i.label)); set && set.fn();
  const relit = !!set && row.lit && !row.cold && row.relit === 1 && S.stations.mill.likesTo === Math.min(100, likes0 + K.relightLikes) && !row.kept && !Republic.kinOpen().some(x => x.kind === 'relight');
  /* the next dark it asks again; left its days, the kin lights it themselves — and after the doctrine's count, keeps it */
  S.time = Math.floor(S.time / DL) * DL + DL * 1.7; Republic.tick(0.02);
  const e2 = Republic.kinOpen().find(x => x.kind === 'relight'); const asked2 = !!e2 && !row.lit;
  e2.t = S.time - K.errandDays * DL - 5; Republic.tick(0.02);
  const kinLit = row.lit && row.relit === 2 && row.kept === true && S.mails.some(m => /Ottilie's lantern/.test(m.subj) && /I carried the lantern to the waylight myself/.test(m.body));
  S.time = Math.floor(S.time / DL) * DL + DL * 1.7; Republic.tick(0.02);
  const keptLit = row.lit && !Republic.kinOpen().some(x => x.kind === 'relight');
  Memorial.open('town'); const card = [...document.querySelectorAll('#memBody .memCard')].some(el => /Ottilie/.test(el.textContent) && /the kin keep it now/.test(el.textContent)); Memorial.close();
  return { taken, again, relit, asked2, kinLit, keptLit, card };
}, r.eid);
ok('THE STONE\'S FLAME: Ottilie\'s lantern set lit burns through the night it was set, goes out at the next dark, and the kin asks again (the mail, the lesson, the compass, the guide); the cold lantern stands at the stone (pixel-sampled: dark, no flame); taken from the stone once (G), lit at Haven (L) and set back (G), it burns and the Mill is warmer; the next dark it asks again, and left its days the kin light it themselves — the count reached, the kin keep it, it asks no more, and the card says so',
  flOk1 && coldSeen.dark > 6 && coldSeen.gold < 4 && r.taken && r.again && r.relit && r.asked2 && r.kinLit && r.keptLit && r.card, fl1 + ' ' + JSON.stringify(coldSeen) + ' ' + JSON.stringify(r));

lap(5);
/* ================= 5 · THE TRUCE ROAD ================= */
r = await ev(() => {
  const ash = DATA.camps.find(c => c.id === 'ash'), c = S.camps.ash, T2 = DATA.T, st = DATA.stations;
  c.taken = null; c.pacified = false; c.truce = 0; c.pact = null;
  const n = S.npcs.find(x => x.state === 'pool' && x.at === 'haven');
  S.cov = 0.6; NPC.assignRoute(n, 'foundry', 'pharos');   // coverage opens the charters
  const closed = !Republic.truceRoadFor('foundry', 'pharos');
  n.route.t = 0; NPC.update(0.01); const base = n.route.t;
  c.truce = S.time;
  const open = Republic.truceRoadFor('foundry', 'pharos') === ash && !Republic.truceRoadFor('haven', 'elm');
  n.route.t = 0; NPC.update(0.01); const quick = n.route.t;
  const faster = Math.abs(quick - base * T2.parley.roadMul) < 0.01 && n.route.truce === 'ash' && (c.truceRuns || 0) >= 1 && !!S.flags.tut.firstTruceRoad;
  const A = st.foundry, B = st.pharos, cross = Republic.ringCross(A.x, A.y + 40, B.x, B.y + 40, ash);
  const crossOk = cross && cross.length === 2 && cross.every(p => Math.abs(U.dist(p.x, p.y, ash.x, ash.y) - ash.r) < 1) && cross[0].t < cross[1].t;
  const roads = Republic.truceRoads(), listed = roads.length === 1 && roads[0].cd === ash && roads[0].npc === n && roads[0].cross.length === 2;
  const roll = /the truce road/.test(UI.campRollHTML(ash, true)) && /walks straight through the ring/.test(UI.campRollHTML(ash, true));
  window.__tr = { n: n.id, cross };
  return { closed, open, base, quick, faster, crossOk, listed, roll };
});
const tr1 = JSON.stringify(r), trOk1 = r.closed && r.open && r.faster && r.crossOk && r.listed && r.roll;
/* the rags at the ring's edge, seen */
await frame(() => { const p = __tr.cross[0]; WL.tp([p.x + 22, p.y + 26]); Render.setZoom(2.2); Render.cam.x = p.x; Render.cam.y = p.y; WL.timeScale = 0.001; });   // the Walker's lamp beside it: the Ash ground is dark even by day
const ragSeen = await ev(() => { const p = __tr.cross[0]; return __near(p.x, p.y - 12, __hex('#e8e0c8'), 12, 22); });
await unfreeze();
/* the charter runner, seen walking it: the Walker near the road, a knife at the road lets them by */
r = await ev(async () => {
  const ash = DATA.camps.find(c => c.id === 'ash'), p = __tr.cross[0], n = S.npcs.find(x => x.id === __tr.n);
  WL.tp([p.x + 40, p.y + 60]);
  const amb = NPC.ambient();
  S.camps.ash.runners = [{ x: __tr.cross[1].x - 40, y: __tr.cross[1].y, cd: 0, cls: 'knife', wa: 0, state: 'patrol' }];
  for (let i = 0; i < 8; i++) NPC.update(0.5);
  const w = amb.find(x => x.truce === 'ash'), walker = !!w && w.n === n;
  for (let i = 0; i < 120 && w && !w.let; i++) { w.d += 40; NPC.update(0.02); }
  const let2 = !!w && !!w.let && S.camps.ash.runners.some(r2 => r2.letT);
  return { walker, let: let2 };
});
ok('THE TRUCE ROAD: a charter run Foundry ⇄ Pharos crosses Ash\'s ring — closed while the camp stands hostile, open under a truce (and only that road); the run through it comes quicker by the road\'s multiplier, the run\'s note names it, the camp counts it, the lesson; the line meets the ring at two points on its edge; the truce roads list it with its runner; the camp\'s roll names it; the white rags stand at the ring\'s edge (pixel-sampled); near it, the runner walks the road through the ring and a knife at the road lets them by',
  trOk1 && ragSeen > 10 && r.walker && r.let, tr1 + ' rag=' + ragSeen + ' ' + JSON.stringify(r));

lap(6);
/* ================= 6 · THE CHIEF'S RUNNER ================= */
r = await ev(() => {
  const ash = DATA.camps.find(c => c.id === 'ash'), c = S.camps.ash, T2 = DATA.T, P2 = T2.parley;
  c.truce = 0; c.pact = { t: S.time - (P2.pactDays - 1) * T2.dayLen - 1 }; S.giftRunner = null;
  Republic.tick(0.02);
  const g = S.giftRunner;
  const near = DATA.stationOrder.filter(id => S.stations[id].connected).sort((a, b2) => U.dist(ash.x, ash.y, DATA.stations[a].x, DATA.stations[a].y) - U.dist(ash.x, ash.y, DATA.stations[b2].x, DATA.stations[b2].y))[0];
  const sent = !!g && g.camp === 'ash' && g.to === near && !!c.pact.giftSent;
  UI.tick(); const compass = [...document.querySelectorAll('#compassInner .cMark')].some(m => /a runner — a gift/.test(m.title));
  window.__g = g;
  return { sent, to: g ? g.to : null, compass };
});
const gr1 = JSON.stringify(r), grOk1 = r.sent && r.compass;
await drain();
await frame(() => { const g = S.giftRunner; WL.tp([g.x + 26, g.y + 22]); S.dir = 0; Render.setZoom(3); Render.cam.x = g.x; Render.cam.y = g.y - 14; WL.timeScale = 0.001; });   // the lamp held away from him — its corona lights what is round it, and lit bone reads past the tolerance
const runnerSeen = await ev(() => { const g = S.giftRunner; return __near(g.x - 3, g.y - 14, __hex('#e8e0c8'), 22, 24) + __near(g.x - 3, g.y - 14, [199, 192, 174], 10, 24); });   // the bundle's bone, in the valley's light and its shade
await unfreeze();
r = await ev(() => {
  const T2 = DATA.T, G2 = T2.parley.giftBack, bank0 = { ...S.banked }, c = S.camps.ash;
  for (let i = 0; i < 2000 && S.giftRunner; i++) Republic.tick(0.25);
  const arrived = !S.giftRunner && S.banked.metal === bank0.metal + G2.metal && Math.round(S.banked.provisions - bank0.provisions) === G2.provisions && S.mails.some(m => /Ash Camp's runner at/.test(m.subj)) && !!S.flags.tut.firstGiftRunner && !!c.pact.giftT;
  /* a word broken while he walks: he turns back, and nothing comes */
  c.pact = { t: S.time - (T2.parley.pactDays - 1) * T2.dayLen - 1 }; Republic.tick(0.02);
  const out = !!S.giftRunner; const bank1 = S.banked.metal;
  for (let i = 0; i < 6; i++) Republic.tick(0.25);
  const took = Republic.fundTake('ash'); S.rep.quell = null; Republic.tick(0.02);   // the word broken through the engine's own door: a column sent against his fire (recalled for the rest of the suite)
  const bank2 = S.banked.metal;
  const back = !!S.giftRunner && S.giftRunner.back;
  for (let i = 0; i < 2000 && S.giftRunner; i++) Republic.tick(0.25);
  const nothing = !S.giftRunner && S.banked.metal === bank2 && bank1 >= 0;
  S.fireWordBroken = 0; Republic.reprisal && (REP && S.rep && (S.rep.reprisal = null));
  return { arrived, out, took: !!took, back, nothing };
});
ok('THE CHIEF\'S RUNNER: on the pact\'s last day a runner leaves Ash\'s fire for the nearest lit door (the compass marks him), the bundle and the white rag drawn on him (pixel-sampled); he walks there and the bank takes the gift (the mail, the lesson); with the word broken while he walks, he turns back and nothing comes',
  grOk1 && runnerSeen > 6 && r.arrived && r.out && r.took && r.back && r.nothing, gr1 + ' seen=' + runnerSeen + ' ' + JSON.stringify(r));

lap(7);
/* ================= 7 · A SCORE SETTLED ================= */
r = await ev(() => {
  const ash = DATA.camps.find(c => c.id === 'ash'), T2 = DATA.T;
  S.camps.ash.runners = []; S.orders.active.length = 0;
  for (const c2 of [...S.cargo]) if (c2.cat !== 'tool' && !c2.keepsake) State.removeCargo(c2.id);
  for (let i = 0; i < 4; i++) S.npcs.push(NPC.gen({ at: 'haven' }));   // Haven's fire, filled for the hires to come
  const n = S.npcs.find(x => x.state === 'pool' && x.at === 'haven'); NPC.hire(n, 'companion');
  WL.tp('haven'); n.cx = S.px + 20; n.cy = S.py + 20;
  Republic.scoreSet('ash', n); Republic.scorePaid(ash, 'taken');
  const sc = Republic.scores().ash, paid = sc.paid === 'taken' && S.mails.some(m => /The score with Ash Camp, paid/.test(m.subj)) && !S.settle;
  MusterUI.open(n.id); const plate = new RegExp(`ASH CAMP IS PAID — WALK ${n.name.split(' ')[0].toUpperCase()} THERE`).test(document.getElementById('musterOv').textContent); MusterUI.close();
  UI.tick(); const compass = [...document.querySelectorAll('#compassInner .cMark')].some(m => new RegExp(`settle it · ${n.name.split(' ')[0]}`).test(m.title));
  Guide.tick(0.3); const gs = Guide.current(), guide = !!gs && gs.id === 'settle';
  /* walked to the ring's edge, the one who fell steps out */
  const d = ash.r + 100; WL.tp([ash.x, ash.y + d]); n.cx = S.px + 20; n.cy = S.py + 20;
  Republic.tick(0.02);
  const started = !!S.settle && S.settle.npc === n.id;
  window.__sn = n.id;
  return { paid, plate, compass, guide, started, name: n.name };
});
const se1 = JSON.stringify(r), seOk1 = r.paid && r.plate && r.compass && r.guide && r.started;
r = await ev(() => {
  const n = S.npcs.find(x => x.id === __sn), ash = DATA.camps.find(c => c.id === 'ash');
  let said = false;
  for (let i = 0; i < 80 && S.settle; i++) { NPC.update(0.1); Republic.tick(0.1); if (S.settle && S.settle.said) said = true; }
  const stone = Republic.settleStones().find(x => x.camp === 'ash' && x.name === n.name.split(' ')[0]);
  const done = !S.settle && !Republic.scores().ash && (n.settled || []).some(x => x.camp === 'ash' && x.how === 'taken') && !!n.settledT && S.mails.some(m => /The score with Ash Camp, settled/.test(m.subj)) && !!S.flags.tut.firstSettled;
  const mood = /settled/.test(JSON.stringify(NPC.mood(n)));
  MusterUI.open(n.id); const plate = /SETTLED AT ASH CAMP/.test(document.getElementById('musterOv').textContent); MusterUI.close();
  const roll = /left a stone at the ring/.test(UI.campRollHTML(ash, true));
  window.__stone = stone;
  return { said, stone: !!stone, done, mood, plate, roll };
});
const se2 = JSON.stringify(r), seOk2 = r.said && r.stone && r.done && r.mood && r.plate && r.roll;
await drain();
await frame(() => { const s2 = __stone; WL.tp([s2.x + 30, s2.y + 30]); S.dir = 0; for (const n of NPC.party()) { n.cx = s2.x + 70; n.cy = s2.y + 44; } Render.setZoom(3); Render.cam.x = s2.x; Render.cam.y = s2.y; WL.timeScale = 0.001; });   // the backs stood off the stone so it reads whole
const stoneSeen = await ev(() => ({ stone: __near(__stone.x, __stone.y - 2, __hex('#b8c2c8'), 26, 18), thread: __near(__stone.x, __stone.y - 2, __hex('#c9553a'), 30, 18) }));
await unfreeze();
const letGo = await ev(() => {
  const n = S.npcs.find(x => x.id === __sn);
  Republic.scores().ridge = { t: S.time, npc: n.id, name: n.name, paid: 'stood down', paidT: S.time - DATA.T.score.walkDays * DATA.T.dayLen - 5 };
  Republic.tick(0.02);
  return !Republic.scores().ridge && S.mails.some(m => /The score with Ridge Camp, let go/.test(m.subj));
});
ok('A SCORE SETTLED: paid when Ash is taken — not yet settled (the mail); the plate says to walk them there, the compass marks it, the guide walks you; at the ring\'s edge the one who fell steps out toward the camp, says it, leaves a stone; the score is closed, the plate carries SETTLED AT ASH CAMP, the mood carries a score settled, the mail, the lesson; the camp\'s roll names the stone and the stone stands on the ground (pixel-sampled, the stones and the red thread); a score paid and never walked is let go',
  seOk1 && seOk2 && stoneSeen.stone > 8 && stoneSeen.thread > 2 && letGo, se1 + ' ' + se2 + ' ' + JSON.stringify(stoneSeen) + ' letGo=' + letGo);

lap(8);
/* ================= 8 · THE LINE'S ORDERS ================= */
r = await ev(() => {
  const ash = DATA.camps.find(c => c.id === 'ash'), c = S.camps.ash; c.runners = []; c.grudge = null; c.truce = 0; c.pact = null;
  const pool = S.npcs.filter(n => n.state === 'pool' && n.at === 'haven').slice(0, 1); for (const n of pool) NPC.hire(n, 'companion');
  const pt = NPC.party(); WL.tp([ash.x + 100, ash.y + 1150]); for (const n of pt) { n.cx = S.px + 20; n.cy = S.py + 20; }
  UI.toggleMap(true); UI.ringWalk('ash'); UI.toggleMap(false);
  const m = S.moveTo; WL.tp([m.x + 4, m.y + 4]); Systems.update(0.05, {});
  for (let i = 0; i < 40; i++) Systems.update(0.1, {});
  const held = !!S.ringHold && !S.ringHold.order;
  const q = Systems.getInteractions().find(i => i.key === 'Q'), rail = !!q && /HOLD or COME/.test(q.label);
  q && q.fn();
  const el = document.getElementById('keeperSay'), faces = [...el.querySelectorAll('img.lineFace')];
  const plate = !el.classList.contains('hidden') && el.classList.contains('line') && faces.length === pt.length && faces.every((f, i) => f.src === Render.handFaceURL(pt[i], 2)) && !!el.querySelector('[data-line="hold"]') && !!el.querySelector('[data-line="come"]');
  return { held, rail, plate, party: pt.length };
});
const ln1 = JSON.stringify(r), lnOk1 = r.held && r.rail && r.plate && r.party >= 2;
await page.click('#keeperSay [data-line="hold"]'); await page.waitForTimeout(150);
r = await ev(() => {
  const h = S.ringHold, ash = DATA.camps.find(c => c.id === 'ash'), T2 = DATA.T;
  const hold = !!h && h.order === 'hold' && !!S.flags.tut.firstLineOrders && document.getElementById('keeperSay').classList.contains('hidden') && Math.abs(U.dist(h.x, h.y, ash.x, ash.y) - (ash.r - 24)) < 1;   // stepped up to the ring's very edge
  /* the Walker walks in alone, past where a plain line would have lifted: the backs keep the edge */
  const ux = (ash.x - h.x), uy = (ash.y - h.y), ul = Math.hypot(ux, uy);
  WL.tp([h.x + ux / ul * (T2.ring.holdR + 80), h.y + uy / ul * (T2.ring.holdR + 80)]);
  for (let i = 0; i < 40; i++) Systems.update(0.1, {});
  const px2 = -uy / ul, py2 = ux / ul, slots = [-1, 1, -2, 2];
  const stays = !!S.ringHold && NPC.party().every((n, i) => U.dist(n.cx, n.cy, h.x + px2 * slots[i] * T2.ring.gap, h.y + py2 * slots[i] * T2.ring.gap) < 14);
  UI.tick(); const compass = [...document.querySelectorAll('#compassInner .cMark')].some(m => /THE LINE HOLDS · ASH/.test(m.title));
  window.__h = { x: h.x, y: h.y, fx: ux / ul, fy: uy / ul };
  return { hold, stays, compass };
});
const ln2 = JSON.stringify(r), lnOk2 = r.hold && r.stays && r.compass;
/* the rope from hand to hand, seen */
await frame(() => { Render.setZoom(2.4); Render.cam.x = __h.x; Render.cam.y = __h.y - 12; WL.timeScale = 0.001; });
const ropeSeen = await ev(() => __near(__h.x, __h.y - 8, __hex('#8a6a42'), 10, 40) + __near(__h.x, __h.y - 8, __hex('#a08050'), 10, 40));
await unfreeze();
r = await ev(() => {
  const h = S.ringHold, ash = DATA.camps.find(c => c.id === 'ash'), T2 = DATA.T, c = S.camps.ash;
  /* a knife comes out after the Walker past the line: the line turns him */
  S.cargo.push({ ...State.makeItem('metal') });
  const back0 = NPC.party()[0], kr = { x: back0.cx + 20, y: back0.cy - 20, cd: 0, cls: 'knife', wa: 0, state: 'patrol' };
  WL.tp([h.x + __h.fx * 100, h.y + __h.fy * 100]); c.runners = [kr];   // inside the ring, loaded, making for the line — a knife on the backs' side of it
  Systems.update(0.05, {});
  const turned = kr.cd >= T2.ring.turnCd - 0.2 && !!kr.turnedT;
  window.__kr = kr;
  return { turned };
});
const lnTurn = r.turned;
await frame(() => { Render.setZoom(2.4); Render.cam.x = __kr.x; Render.cam.y = __kr.y - 30; WL.timeScale = 0.001; });
const turnSeen = await ev(() => __near(__kr.x, __kr.y - 50, __hex('#c9553a'), 30, 14));   // the U sits clear over the hood (the ring's dark lifts the red a shade)
await unfreeze();
r = await ev(() => {
  const h = S.ringHold, T2 = DATA.T;
  if (!h) return { lifted: false, why: 'no line to fall in from' };
  /* the Walker back at the line: they fall in */
  WL.tp([h.x + 10, h.y + 10]); Systems.update(0.05, {});
  const lifted = !S.ringHold;
  return { lifted };
});
const lnLift = r.lifted;
/* COME: the line forms on the Walker and walks in; a knife holds off, a bow still looses; no running */
r = await ev(() => {
  const ash = DATA.camps.find(c => c.id === 'ash'), c = S.camps.ash, T2 = DATA.T;
  c.runners = []; S.stagger = 0;
  UI.toggleMap(true); UI.ringWalk('ash'); UI.toggleMap(false);
  const m = S.moveTo; WL.tp([m.x + 4, m.y + 4]); Systems.update(0.05, {}); for (let i = 0; i < 30; i++) Systems.update(0.1, {});
  return { held: !!S.ringHold };
});
const comeHeld = r.held;
await ev(() => UI.lineOrders()); await page.waitForTimeout(120);
await page.click('#keeperSay [data-line="come"]'); await page.waitForTimeout(150);
r = await ev(() => {
  const ash = DATA.camps.find(c => c.id === 'ash'), c = S.camps.ash, T2 = DATA.T, h = S.ringHold;
  const come = !!h && h.order === 'come';
  const ux = ash.x - S.px, uy = ash.y - S.py, ul = Math.hypot(ux, uy);
  WL.tp([S.px + ux / ul * 200, S.py + uy / ul * 200]);
  for (let i = 0; i < 30; i++) Systems.update(0.1, {});
  const onWalker = Math.abs(S.ringHold.x - S.px) < 1 && Math.abs(S.ringHold.y - S.py) < 1;
  const vx = ash.x - S.px, vy = ash.y - S.py, vl = Math.hypot(vx, vy), px2 = -vy / vl, py2 = vx / vl, slots = [-1, 1, -2, 2];
  const abreast = NPC.party().every((n, i) => U.dist(n.cx, n.cy, S.px + px2 * slots[i] * T2.ring.gap, S.py + py2 * slots[i] * T2.ring.gap) < 16);
  /* a knife inside arm's length holds off; the Walker loaded */
  if (!S.cargo.some(c2 => c2.cat === 'mat')) S.cargo.push(State.makeItem('metal'));
  const hp0 = S.health, cargo0 = S.cargo.length;
  const k = { x: S.px + vx / vl * 60, y: S.py + vy / vl * 60, cd: 0, cls: 'knife', wa: 0, state: 'patrol' };
  c.runners = [k];
  for (let i = 0; i < 30; i++) { Systems.update(0.1, {}); k.cd = Math.min(k.cd, 0); }
  const heldOff = U.dist(k.x, k.y, S.px, S.py) >= T2.ring.comeR * 0.5 && S.health >= hp0 - 0.5 && S.cargo.length === cargo0;
  /* a bow still looses */
  const bw = { x: S.px + vx / vl * 150, y: S.py + vy / vl * 150, cd: 0, cls: 'bowman', wa: 0, state: 'patrol', shotCd: 0 };
  c.runners = [bw]; S.stagger = 0; S.arrow = null;
  Systems.update(0.05, {});
  const bow = (S.stagger || 0) > 0 || !!S.arrow;
  S.arrow = null; S.scar = null; S.stagger = 0; c.runners = [];
  /* no running while the line walks */
  S.stam = S.stamMax; Systems.update(0.05, { up: true, shift: true }); const noRun = !S.sprinting;
  UI.tick(); const compass = [...document.querySelectorAll('#compassInner .cMark')].some(m => /THE LINE COMES · ASH/.test(m.title));
  /* out past the ring's edge, the line breaks back into the wedge */
  WL.tp([ash.x, ash.y + ash.r + 200]); Systems.update(0.05, {});
  const broke = !S.ringHold;
  S.stam = S.stamMax; Systems.update(0.05, { up: true, shift: true }); const runs = S.sprinting;
  return { come, onWalker, abreast, heldOff, bow, noRun, compass, broke, runs };
});
ok('THE LINE\'S ORDERS: at the held line Q is on the rail; the line\'s plate carries every back\'s own face and the two orders; HOLD by a real click — the line steps up to the ring\'s very edge, the Walker walks in past where a plain line lifts and the backs keep the edge on their slots (the compass says THE LINE HOLDS), the rope strung hand to hand (pixel-sampled); a knife after the loaded Walker near the line is turned back to its fire (the U over his hood, pixel-sampled); back at the line they fall in. COME by a real click — the line forms on the Walker and walks in abreast, a knife holds off at arm\'s length (no cut, no crate), a bow still looses, no running while it walks (the compass says THE LINE COMES); out past the ring\'s edge the line breaks and running returns',
  lnOk1 && lnOk2 && ropeSeen > 12 && lnTurn && turnSeen > 3 && lnLift && comeHeld && r.come && r.onWalker && r.abreast && r.heldOff && r.bow && r.noRun && r.compass && r.broke && r.runs, ln1 + ' ' + ln2 + ` rope=${ropeSeen} turned=${lnTurn} mark=${turnSeen} lift=${lnLift} ` + JSON.stringify(r));

lap(9);
/* ================= 9 · THE SAVE ================= */
r = await ev(() => {
  const ash = DATA.camps.find(c => c.id === 'ash');
  Economy.wireWord('green', 'kept', 'a save test');
  S.giftRunner = { camp: 'ash', to: 'foundry', x: ash.x, y: ash.y, wa: 0, back: false, moving: false, dir: 0 };
  S.camps.ash.truceRuns = 3;
  const n = NPC.party()[0]; Republic.scores().ridge = { t: S.time, npc: n.id, name: n.name, paid: 'chief', paidT: S.time };
  S.settle = { camp: 'ridge', npc: n.id, t: 1 }; S.ringHold = { camp: 'ash', x: 0, y: 0, t: S.time, order: 'hold' };
  State.save();
  S.wireWords = []; S.giftRunner = null; S.camps.ash.truceRuns = 0; delete Republic.scores().ridge;
  State.load();
  const wire = Economy.wireWords().some(w => w.from === 'green' && w.name === 'a save test');
  const runner = !!S.giftRunner && S.giftRunner.to === 'foundry', runs = S.camps.ash.truceRuns === 3, paid = Republic.scores().ridge && Republic.scores().ridge.paid === 'chief';
  const stones = Republic.settleStones().length >= 1, keepsakes = S.cargo.filter(c => c.keepsake).length === 2 && S.cargo.every(c => !c.keepsake || c.keepsake.town === 'mill');
  const settled = S.npcs.some(x => (x.settled || []).some(y => y.camp === 'ash'));
  const row = S.legacy.find(x => x.name === 'Ottilie Marsh'), relight = row.kept === true && row.relit === 2;
  const moments = !S.settle && !S.ringHold;
  S.wireWords = []; S.giftRunner = null; delete Republic.scores().ridge;
  return { wire, runner, runs, paid: !!paid, stones, keepsakes, settled, relight, moments };
});
ok('THE SAVE: a word in flight on the wire, the chief\'s runner on his way, the truce road\'s runs, a paid score, the settled stones, the keepsakes on the pack, the settled marks on the plate and the kept lantern survive a save and load; a settling and a line\'s orders are moments, not state',
  r.wire && r.runner && r.runs && r.paid && r.stones && r.keepsakes && r.settled && r.relight && r.moments, JSON.stringify(r));

ok('no page errors across the word carried', errors.length === 0, errors.slice(0, 3).join(' | '));
console.log(results.join('\n'));
console.log(`${results.filter(x => x.startsWith('PASS')).length}/${results.length} checks passed`);
await b.close();
