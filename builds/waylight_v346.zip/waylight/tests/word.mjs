/* word.mjs — v3.44 THE WORD AT THE DOOR: the Walker's answer to a keeper's face (a promise that binds the
   next run and pays kept, breaks at twice the memory; an apology that costs now for likes kept), with the
   Walker's own hand-drawn face on the plate and the word's marks; the fallen own's kin in the square (a
   figure that keeps the place, a town that recruits slower by its stones, a mood that reads them); the new
   chief's grudge (a different man walks in; the nearest post you hold is his first storm, seen or rolled;
   he says so at the fire; paid or cooled); the scar carried to the stone (the walk's record, the card's
   marks, the stone's notches, the manual's plates); the road to the ring (a pinned roll's road line plans
   the walk, the ring pin on the sheet); the save. */
import { chromium } from 'playwright';
const results = [];
const ok = (name, cond, extra = '') => { results.push(`${cond ? 'PASS' : 'FAIL'}  ${name}${extra ? '  — ' + extra : ''}`); if (!cond) process.exitCode = 1; };
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium', args: ['--disable-background-networking'] });
const page = await b.newPage({ viewport: { width: 1440, height: 860 } });
await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
const errors = [];
page.on('pageerror', e => errors.push(String(e.message)));
await page.goto('file:///home/claude/waylight/dist/test.html?debug', { waitUntil: 'domcontentloaded' });
await page.waitForFunction(() => window.WL && WL.snapshot && WL.snapshot().baked, null, { timeout: 60000 });
await page.evaluate(() => localStorage.clear());
await page.click('#btnNew'); await page.waitForTimeout(300);
await page.click('#btnBegin'); await page.waitForTimeout(400);
await page.click('#briefGo'); await page.waitForTimeout(300);
await page.click('#cgBegin'); await page.waitForTimeout(1200);
for (let i = 0; i < 30; i++) { const c = await page.evaluate(() => !!S.cine); if (!c) break; await page.evaluate(() => WL.skipCine()); await page.waitForTimeout(250); }
await page.evaluate(() => { S.flags.guideDone = true; WL.calm(); });
const ev = (fn, arg) => page.evaluate(fn, arg);
await ev(() => {
  /* pixel sampling on the game canvas itself: how many pixels inside rad of a world point sit within tol of a colour */
  window.__toScr = (wx, wy) => { const z2 = Render.effZoom() / devicePixelRatio; return { x: innerWidth / 2 + (wx - Render.cam.x) * z2, y: innerHeight / 2 + (wy - Render.cam.y) * z2 }; };
  window.__near = (wx, wy, col, tol, rad) => { const p = __toScr(wx, wy), cv = document.getElementById('game'), g = cv.getContext('2d'), dpr = devicePixelRatio; const x0 = Math.max(0, Math.round((p.x - rad) * dpr)), y0 = Math.max(0, Math.round((p.y - rad) * dpr)), w = Math.round(rad * 2 * dpr), h = w; const d = g.getImageData(x0, y0, w, h).data; let hit = 0; for (let i = 0; i < d.length; i += 4) if (Math.abs(d[i] - col[0]) < tol && Math.abs(d[i + 1] - col[1]) < tol && Math.abs(d[i + 2] - col[2]) < tol) hit++; return hit; };
});

/* ================= 1 · THE REGISTRIES ================= */
let r = await ev(() => {
  const inPal = (rows, pal, w, h) => rows.length === h && rows.every(rw => rw.length === w) && [...new Set(rows.join('').replace(/\./g, ''))].every(ch => pal[ch]);
  const face = inPal(SPRITES.WALKER_FACE, SPRITES.WALKER_FACE_PAL, 16, 16);
  const u0 = Render.walkerFaceURL(4); const look0 = S.look; S.look = { ...(S.look || {}), H: '#3d5548', S: '#a87f5e' }; const u1 = Render.walkerFaceURL(4); S.look = look0;
  const faceUrl = /^data:image\/png/.test(u0) && /^data:image\/png/.test(u1) && u0 !== u1;   // the bust follows the coat they cut
  const marks = ['promise', 'sorry', 'stone', 'grudge', 'scar', 'road'].every(k => inPal(SPRITES.MARKS[k], SPRITES.MARK_PAL, 7, 7)) && new Set(['promise', 'sorry', 'stone', 'grudge', 'scar', 'road'].map(k => SPRITES.MARKS[k].join(''))).size === 6;
  const kin = ['idle', 'A', 'B'].every(f => inPal(SPRITES.FIGURES.kin[f], SPRITES.TOWN_PAL, 14, 22));
  const chief2 = ['idle', 'A', 'B'].every(f => inPal(SPRITES.KIT.chief2[f], SPRITES.RAID_PAL, 14, 22)) && SPRITES.KIT.chief2.idle.join('') !== SPRITES.KIT.chief.idle.join('') && SPRITES.KIT.chief2.A.join('') !== SPRITES.KIT.chief2.B.join('');
  const pin = inPal(SPRITES.RINGPIN, SPRITES.RAGSTAKE_PAL, 7, 11);
  const sworn = Render.cargoGlyph({ defId: 'parcel', cat: 'goods', sworn: true, grieved: true }), torn = Render.cargoGlyph({ defId: 'parcel', cat: 'goods', grieved: true });
  const swornGlyph = sworn.rows.join('') !== torn.rows.join('') && /R/.test(sworn.rows.join('')) && sworn.pal.R === '#c9553a';
  const plates = ['bolt', 'scar', 'dressed'].map(k => Render.rigOverlayURL(k, 5)), platesOk = plates.every(u => /^data:image\/png/.test(u)) && new Set(plates).size === 3;
  const Wd = DATA.T.word, row = Wd && Wd.promiseDays > 0 && Wd.kept > 0 && Wd.keptLikes > 0 && Wd.brokenMemory > DATA.T.grievance.memory && Wd.sorryCost > 0;
  const K = REP.DOCTRINE.storm.rise.kin, G = REP.WATCHPOST.storm.seen.grudge, doctrine = K && K.days > 0 && K.slowPerStone > 0 && K.maxStones > 0 && G && G.days > 0 && G.sayR > 0;
  const V = DATA.keeperGrief, voices = DATA.stationOrder.every(id => ['promise', 'sorry', 'broken', 'kept'].every(k => V[id][k] && V[id][k].length > 8)) && DATA.stationOrder.every(id => Economy.keeperWordLine(id, 'kept', { name: 'a tin of buttons' }) && Economy.keeperWordLine(id, 'broken', { name: 'a tin of buttons' }));
  const causes = Object.keys(MUSTER.MOOD.causes).length, stoneCauses = MUSTER.MOOD.causes.stone.v < 0 && MUSTER.MOOD.causes.stones.v < MUSTER.MOOD.causes.stone.v;
  const lessons = ['firstWord', 'firstKin', 'firstGrudge', 'firstScarStone', 'firstRingWalk'].every(k => DATA.tutorials[k] && DATA.tutorialTitles[k]), lessonsN = Object.keys(DATA.tutorials).length;
  return { face, faceUrl, marks, kin, chief2, pin, swornGlyph, platesOk, row, doctrine, voices, causes, stoneCauses, lessons, lessonsN };
});
ok('THE REGISTRIES: the Walker\'s face (16×16 on the keepers\' alphabet, bound to the coat they cut — a different bust for a different look), six survey marks in the marks\' palette, the kin (14×22 in the town\'s colours), the new chief (three frames, a different man from the first), the ring pin, the sworn parcel\'s glyph in rust, three rig plates for the manual, the word\'s row, the kin and grudge doctrine, four word lines in every keeper\'s voice, two stone moods (twenty-five causes), five lessons (sixty)',
  r.face && r.faceUrl && r.marks && r.kin && r.chief2 && r.pin && r.swornGlyph && r.platesOk && r.row && r.doctrine && r.voices && r.causes === 27 && r.stoneCauses && r.lessons && r.lessonsN === 73, JSON.stringify(r));

/* ================= 2 · THE WORD — A PROMISE, KEPT ================= */
const stageGrievance = () => ev(() => {
  for (const k of Object.keys(REP.EVENTS)) S.rep.evCd[k] = 99999;
  for (const id of ['elm', 'mill']) S.stations[id].connected = true;
  S.grievances = []; S.stations.elm.met = true; S.stations.elm.faceSaid = null; S.stations.elm.madeSaid = null; S.stations.elm.wordSaid = null;
  const T2 = DATA.T, day0 = Math.floor(S.time / T2.dayLen) * T2.dayLen; S.time = day0 + T2.dayLen * 0.3;
  S.stations.haven.parcels = [{ to: 'elm', kind: 'coat', name: 'a mended coat' }];
  S.orders.active = []; for (const c2 of [...S.cargo]) if (c2.cat !== 'tool') State.removeCargo(c2.id);
  const run = Economy.ordersFor('haven').find(o => o.item === 'parcel' && o.to === 'elm'); Systems.acceptOrder(run, false);
  const it = S.cargo.find(c2 => c2.parcel);
  State.removeCargo(it.id); S.drops.push({ id: U.uid(), item: it, x: DATA.stations.haven.x + 300, y: DATA.stations.haven.y }); Economy.grieve(it, 'ground');
  document.getElementById('keeperSay').classList.add('hidden');
  WL.tp([DATA.stations.haven.x, DATA.stations.haven.y + 400]); Systems.update(0.05, {});
  WL.tp([DATA.stations.elm.x + 60, DATA.stations.elm.y + 40]); S.room = null; Systems.update(0.05, {});
  return it.parcel.id;
});
let gid = await stageGrievance();
r = await ev(() => {
  const plate = document.getElementById('keeperSay');
  const shown = !plate.classList.contains('hidden') && plate.classList.contains('open');
  const row = plate.querySelector('.ksWord'), face = row && row.querySelector('img.ksWalker') && row.querySelector('img.ksWalker').src === Render.walkerFaceURL(3);
  const btns = row ? [...row.querySelectorAll('[data-word]')].map(b2 => b2.getAttribute('data-word').split(':')[0]) : [];
  const named = row && row.textContent.includes(S.pName.split(' ')[0]);   // v3.45: the plate calls the Walker by first name, beside the parcel
  const marks = row && row.querySelectorAll('img.mkImg').length === 2;
  const rail = Systems.getInteractions(), railP = rail.find(i => i.key === 'P' && /Give your word/.test(i.label)), railX = rail.find(i => i.key === 'X' && /Apologize/.test(i.label));
  return { shown, face: !!face, btns, named: !!named, marks: !!marks, railP: !!railP, railX: !!railX };
});
const plateOk = r.shown && r.face && r.btns.join(',') === 'promise,sorry' && r.named && r.marks && r.railP && r.railX, plateJson = JSON.stringify(r);
/* the promise, given by the plate's own button — a real click */
await page.click('#keeperSay [data-word^="promise"]'); await page.waitForTimeout(150);
r = await ev(gid => {
  const g = S.grievances.find(x => x.id === gid), Wd = DATA.T.word, plate = document.getElementById('keeperSay');
  const promised = g && g.word === 'promise' && g.wordT > 0;
  const dr = S.drops.find(d => d.item && d.item.parcel && d.item.parcel.id === gid), sworn = dr && dr.item.sworn === true;
  const reply = !plate.classList.contains('hidden') && plate.classList.contains('word') && /take your word/.test(plate.textContent) && /two days/.test(plate.textContent) && plate.querySelector('.ksWord.said') && plate.querySelector('.ksWord.said img.ksWalker');
  const mail = S.mails[0] && /Elm Farm: your word/.test(S.mails[0].subj), lesson = !!S.flags.tut.firstWord;
  const answered = !Economy.canWord(g), noRail = !Systems.getInteractions().some(i => i.key === 'P');
  /* the guide: your word outranks the plan; the board reads YOUR WORD; the terminal greets with it */
  Guide.tick(0.3); const gs = Guide.current(), guide = gs && /YOUR WORD/.test(gs.head) && /on the ground/.test(gs.head);
  UI.openStation('elm'); UI.gotoTab('orders');
  const rowEl = document.querySelector('#stationBody .needRow.grv'), board = rowEl && /YOUR WORD/.test(rowEl.textContent) && /of your word left/.test(rowEl.textContent) && !rowEl.querySelector('[data-word]') && rowEl.querySelector('img.itemIc');
  const greet = /take your word/.test(document.getElementById('keeperLine').textContent) && !document.querySelector('#keeperLine .keeperWords.grief');
  document.getElementById('stationClose').click();
  /* the town waits: the fade that would have made a memory does not, while the word stands */
  g.t = S.time - DATA.T.grievance.fadeDays * DATA.T.dayLen - 5; const likes0 = S.stations.elm.likesTo;
  for (let i = 0; i < 24; i++) Systems.update(0.25, {});
  const waits = !g.remembered && g.word === 'promise' && S.stations.elm.likesTo === likes0;
  /* kept: picked up and carried through inside the word — more than made right, and a like warmer */
  State.addCargo(dr.item); S.drops.splice(S.drops.indexOf(dr), 1);
  const appr0 = S.stations.elm.appr, likes1 = S.stations.elm.likesTo;
  WL.tp('elm'); WL.instantPar();
  const res = Systems.handleDelivery('elm').results.find(x => x.order && x.order.item === 'parcel');
  const kept = !S.grievances.some(x => x.id === gid) && S.stations.elm.appr >= appr0 + DATA.T.grievance.made + Wd.kept && S.stations.elm.likesTo >= Math.min(100, likes1 + Wd.keptLikes) && res && res.made && /Your word, kept/.test(res.made[0]);
  const keptFace = !plate.classList.contains('hidden') && plate.classList.contains('made') && /kept their word|Your word, kept|kept your word/i.test(plate.textContent);
  const noSworn = !S.cargo.some(c2 => c2.sworn);
  return { promised, sworn: !!sworn, reply: !!reply, mail: !!mail, lesson, answered, noRail, guide: !!guide, board: !!board, greet, waits, kept, keptFace, noSworn };
}, gid);
ok('THE WORD, A PROMISE KEPT: at Elm\'s door the plate offers the answer — your own face, your name, PROMISE and APOLOGY with their marks, and the rail prints P and X; the promise given by the plate\'s button binds the grievance and the parcel wears the sworn string; Wren takes your word to your face (the mail, the lesson); asked once, the rail and the board stop asking; the guide walks your word first; the board reads YOUR WORD with the hours left; the terminal greets with it; the town WAITS instead of remembering while the word stands; carried through inside it the door pays kept over made-right, the town is a like warmer, the slip and the face say your word was kept, and the string comes off',
  plateOk && r.promised && r.sworn && r.reply && r.mail && r.lesson && r.answered && r.noRail && r.guide && r.board && r.greet && r.waits && r.kept && r.keptFace && r.noSworn, plateJson + ' ' + JSON.stringify(r));

/* ================= 3 · THE WORD — BROKEN ================= */
gid = await stageGrievance();
r = await ev(gid => {
  const Wd = DATA.T.word, T2 = DATA.T, plate = document.getElementById('keeperSay');
  const given = Economy.giveWord(gid, 'promise'), g = S.grievances.find(x => x.id === gid);
  const say = given && g.word === 'promise';
  const likes0 = S.stations.elm.likesTo, mailsN = S.mails.length;
  g.wordT = S.time - Wd.promiseDays * T2.dayLen - 5;
  for (let i = 0; i < 24; i++) Systems.update(0.25, {});
  const broken = g.word === 'broken' && g.remembered && S.stations.elm.likesTo === Math.max(0, likes0 - Wd.brokenMemory);
  const mail = S.mails.slice(0, 3).some(m => /your word, broken/.test(m.subj)), said = S.stations.elm.wordSaid && S.stations.elm.wordSaid.kind === 'broken';
  const noWord = !Economy.canWord(g);
  const drop = S.drops.find(d => d.item && d.item.parcel && d.item.parcel.id === gid), stringOff = drop && !drop.item.sworn;
  /* the face at the door says the broken word — the highest thing a keeper has to say */
  plate.classList.add('hidden'); S.stations.elm.faceSaid = null;
  WL.tp([DATA.stations.haven.x, DATA.stations.haven.y + 400]); Systems.update(0.05, {});
  WL.tp([DATA.stations.elm.x + 60, DATA.stations.elm.y + 40]); S.room = null; Systems.update(0.05, {});
  const face = !plate.classList.contains('hidden') && /I told the KID two days/.test(plate.textContent) && !plate.querySelector('.ksWord');
  UI.openStation('elm'); UI.gotoTab('orders');
  const rowEl = document.querySelector('#stationBody .needRow.grv'), board = rowEl && /YOUR WORD, BROKEN/.test(rowEl.textContent) && !rowEl.querySelector('[data-word]');
  document.getElementById('stationClose').click();
  return { say, broken, mail, said: !!said, noWord, stringOff: !!stringOff, face, board: !!board };
}, gid);
ok('THE WORD, BROKEN: the promise\'s span run out with the parcel still on the road — the word is broken, the town remembers at twice the memory, the mail, the string comes off; a broken word cannot be answered; at the door Wren says the broken word to your face (no answer offered); the board reads YOUR WORD, BROKEN',
  r.say && r.broken && r.mail && r.said && r.noWord && r.stringOff && r.face && r.board, JSON.stringify(r));

/* ================= 4 · THE WORD — SORRY ================= */
gid = await stageGrievance();
await ev(() => { UI.openStation('elm'); UI.gotoTab('orders'); });
const sorryBtn = await page.$('#stationBody .needRow.grv [data-word^="sorry"]');
const sorryShown = !!sorryBtn;
if (sorryBtn) { await sorryBtn.click(); await page.waitForTimeout(150); }
r = await ev(gid => {
  const Wd = DATA.T.word, T2 = DATA.T, g = S.grievances.find(x => x.id === gid);
  const appr = S.stations.elm.appr;   // read after the click: the price paid at the counter
  const sorry = g && g.word === 'sorry';
  const rowEl = document.querySelector('#stationBody .needRow.grv'), board = rowEl && /you said sorry/.test(rowEl.textContent) && !rowEl.querySelector('[data-word]');
  const greet = /Sorry counts here/.test(document.getElementById('keeperLine').textContent);
  document.getElementById('stationClose').click();
  const plate = document.getElementById('keeperSay'), face = !plate.classList.contains('hidden') && plate.classList.contains('word') && /Sorry counts here/.test(plate.textContent) && /sorry, said/.test(plate.textContent);
  /* the days run: the grievance goes quietly — the likes kept */
  const likes0 = S.stations.elm.likesTo;
  g.t = S.time - DATA.T.grievance.fadeDays * T2.dayLen - 5;
  for (let i = 0; i < 24; i++) Systems.update(0.25, {});
  const gone = !S.grievances.some(x => x.id === gid) && S.stations.elm.likesTo === likes0 && S.mails.slice(0, 3).some(m => /lets it go/.test(m.subj));
  /* a memory cannot be answered */
  S.grievances.push({ id: 'g_mem', to: 'elm', from: 'haven', kind: 'coat', name: 'a mended coat', t: S.time, how: 'ground', n: 1, remembered: true });
  const noMem = !Economy.canWord(S.grievances.find(x => x.id === 'g_mem')) && !Economy.giveWord('g_mem', 'sorry');
  UI.openStation('elm'); UI.gotoTab('orders'); const memRow = document.querySelector('#stationBody .needRow.grv'), noBtn = memRow && !memRow.querySelector('[data-word]'); document.getElementById('stationClose').click();
  S.grievances = S.grievances.filter(x => x.id !== 'g_mem');
  return { appr, sorry, board: !!board, greet, face, gone, noMem, noBtn: !!noBtn };
}, gid);
const apprBefore = await ev(() => S.stations.elm.appr);   // (read after; the check below compares the paid price by the mail's own number)
r.paid = await ev(() => S.mails.some(m => /Elm Farm: an apology/.test(m.subj) && new RegExp(String(DATA.T.word.sorryCost) + ' appreciation').test(m.body)));
ok('THE WORD, SORRY: from the board\'s grievance row the apology is given by its own button — the price paid at the counter in the mail\'s own number, the row and the greeting read it, the face on the plate carries Wren\'s answer beside what you said; the days run and the town lets it go with the likes kept; a town that already remembers cannot be answered, by the engine or by the board',
  sorryShown && r.sorry && r.board && r.greet && r.face && r.gone && r.noMem && r.noBtn && r.paid, JSON.stringify(r));

/* ================= 5 · THE KIN IN THE SQUARE ================= */
r = await ev(() => {
  const mr = Math.random, R = REP.DOCTRINE.storm.rise, K = R.kin, T2 = DATA.T;
  for (const k of Object.keys(REP.EVENTS)) S.rep.evCd[k] = 99999;
  S.banked.metal = 900; S.banked.wood = 300; S.banked.provisions = 500;
  for (const id of ['elm', 'mill', 'green', 'quarry']) S.stations[id].connected = true;
  Republic.tick(0.01); for (const k of Object.keys(REP.EVENTS)) S.rep.evCd[k] = 99999;
  Republic.fundMountain(); Republic.mountain().t = REP.MOUNTAIN.dur + 1; Republic.tick(0.6);
  Republic.rebellionStrike('mill'); S.stations.mill.likesTo = 55;
  Republic.fundStorm('mill'); const q = Republic.quell(); Math.random = () => 0.9; q.t = q.dur + 1; Republic.tick(0.02); Math.random = mr;
  const a = Republic.recruitOwn('mill'), c = Republic.recruitOwn('mill');
  NPC.setOrder(a, 'hours', 'nights'); NPC.setOrder(c, 'hours', 'nights');
  const day0 = Math.floor(S.time / T2.dayLen) * T2.dayLen; S.time = day0 + T2.dayLen * 0.8;
  S.stations.mill.likesTo = 5; Republic.held().mill.shields = 2;
  const every0 = Republic.recruitEvery('mill');
  Math.random = () => 0.1; Republic.squareRises('mill'); Math.random = mr;
  const stones = Republic.stonesOf('mill'), kin = Republic.kinAt('mill');
  const kept = !!kin && kin.names.length === stones && stones === 2 && kin.spots.length === 2;
  const slower = Republic.recruitEvery('mill') === every0 + Math.min(K.maxStones, stones) * K.slowPerStone;
  const mail = S.mails.find(m => /its own fell in the square/.test(m.subj)), mailKin = mail && /kin keep the place/.test(mail.body) && /slower/.test(mail.body);
  const lesson = !!S.flags.tut.firstKin;
  /* a new recruit at Mill feels the stones in their mood */
  S.stations.mill.likesTo = 60; Republic.tick(0.01);
  const n2 = Republic.recruitOwn('mill'); const mood = NPC.mood(n2), stoneMood = mood.causes.some(x => x.id === 'stones'), one = (() => { const i2 = S.legacy.findIndex(x => x.fact === 'town' && x.town === 'mill'); const [last] = S.legacy.splice(i2, 1); const m2 = NPC.mood(n2).causes.some(x => x.id === 'stone') && !NPC.mood(n2).causes.some(x => x.id === 'stones'); S.legacy.splice(i2, 0, last); return m2; })();
  /* the banner sheet reads the stones and the kin */
  RepublicUI.open(); const sheet = document.getElementById('repBody').textContent;
  const sheetOk = /2 of its own at THE FIELD STONES/.test(sheet) && /kin keep the place/.test(sheet); RepublicUI.close && RepublicUI.close(); UI.closeAllModals();
  /* the day runs: the kin go home */
  const day1 = S.time; S.time += K.days * T2.dayLen + 1; const home = !Republic.kinAt('mill'); S.time = day1;
  return { stones, kept, slower, mailKin: !!mailKin, lesson, stoneMood, one, sheetOk, home, spot: kin && kin.spots[0] };
});
ok('THE KIN IN THE SQUARE: both of the town\'s own on NIGHTS fell when Mill\'s square rose — their kin keep the place (two, named, at the spots they stood), the recruit clock runs two stones slower, the mail says so, the lesson; a new recruit\'s mood reads the stones (one stone, one cause; two, the heavier); the banner sheet counts the stones and the kin; the day runs and the kin go home',
  r.stones === 2 && r.kept && r.slower && r.mailKin && r.lesson && r.stoneMood && r.one && r.sheetOk && r.home, JSON.stringify(r));
/* the kin, seen: a grey shawl where the shield stood, in the square and at the field stones */
await ev(() => { const d = DATA.stations.mill; WL.tp([d.x, d.y + 150]); S.dir = -Math.PI / 2; Render.setZoom(2); Render.cam.x = S.px; Render.cam.y = d.y + 70; WL.timeScale = 0.001; });
await page.waitForTimeout(500);
const kinSeen = await ev(() => { const d = DATA.stations.mill; return { a: __near(d.x - 58, d.y + 86 - 42, [0x6e, 0x74, 0x7c], 22, 24), b: __near(d.x + 58, d.y + 86 - 42, [0x6e, 0x74, 0x7c], 22, 24), p: __toScr(d.x - 58, d.y + 44) }; });   // the shawl: the figure's upper half
await ev(() => { WL.timeScale = 1; Render.setZoom(null); });
ok('THE KIN, SEEN: with the world held, the grey mourning shawl reads at both of the spots the fallen stood in Mill\'s square (pixel-sampled from the game canvas)', kinSeen && kinSeen.a > 20 && kinSeen.b > 20, JSON.stringify(kinSeen));

/* ================= 6 · THE NEW CHIEF'S GRUDGE ================= */
r = await ev(() => {
  const ash = DATA.camps.find(c => c.id === 'ash'), c = S.camps.ash, W = REP.WATCHPOST.storm, K = W.seen, G = K.grudge, T2 = DATA.T;
  for (const k of Object.keys(REP.EVENTS)) S.rep.evCd[k] = 99999;
  for (const n of S.npcs.filter(x => x.state === 'companion')) n.state = 'pool';
  /* the post at Ash stands; the walker stands it; the knives come with the chief; the WALKER's own shove puts him down */
  c.taken = { t0: S.time, shields: 2, tithe: 0 }; c.pacified = false; c.runners = []; c.storm = null; c.chiefLost = 0; c.chiefReturn = null; c.grudge = null; c.chiefGen = 0;
  WL.tp([ash.x + 20, ash.y + 40]); S.room = null;
  const started = Republic.stormPost(ash) && !!c.storm;
  const chief = c.storm.knives.find(k => k.cls === 'chief'); const withChief = !!chief;
  chief.cd = K.downFor; chief.felledBy = 'walker';   // the shove's own record (tickStorm writes it when the hands land)
  Republic.tick(0.02); const broke = c.storm && c.storm.broke && c.storm.brokeBy === 'walker';
  c.storm.t = c.storm.dur + 1; Republic.tick(0.02);
  const fell = !c.storm && c.chiefLost > 0 && c.chiefFelledBy === 'walker';
  /* the post goes back to the camp (released) — the mourning passes and the new man walks in with a grudge */
  c.taken = null; c.runners = [];
  S.time += K.mourn * T2.dayLen + 1; Republic.tick(0.1);
  const walkingKit = Republic.chiefKit(ash, true) === 'chief2';
  for (let i = 0; i < 40; i++) Republic.tick(0.2);
  const grudge = !!c.grudge && c.chiefGen === 1 && Republic.chiefKit(ash) === 'chief2' && !!Republic.grudgeOf(ash);
  const mail = S.mails.slice(0, 3).some(m => /a new chief — and a grudge/.test(m.subj)), lesson = !!S.flags.tut.firstGrudge;
  /* on the sheet and the roll: the grudge mark and the line */
  /* a post held elsewhere: the nearest is his first storm */
  const others = DATA.camps.filter(x => x.id !== 'ash');
  for (const o of others) { S.camps[o.id].taken = null; }
  const tgt0 = Republic.grudgeTarget(ash); const noTarget = tgt0 === null;
  const nearest = others.slice().sort((p, q) => U.dist(p.x, p.y, ash.x, ash.y) - U.dist(q.x, q.y, ash.x, ash.y))[0];
  S.camps[nearest.id].taken = { t0: S.time, shields: 2, tithe: 0 }; S.camps[nearest.id].pacified = false; S.camps[nearest.id].storm = null;
  const target = Republic.grudgeTarget(ash) === nearest;
  /* he says so at the fire */
  /* the same night he came up, at the storm's hour, nothing fires — his storm is the NEXT night */
  const dayR = Math.floor(S.time / T2.dayLen); S.time = dayR * T2.dayLen + T2.dayLen * (W.at + 0.02); Republic.tick(0.02); const notTonight = !!c.grudge && !S.camps[nearest.id].storm;
  S.time = (dayR + 1) * T2.dayLen + T2.dayLen * 0.3;   // the next morning
  c.grudge.said = false; WL.tp([ash.x + 40, ash.y + 120]); Republic.tick(0.02); const said = !!c.grudge && c.grudge.said === true;
  /* the banner sheet reads it */
  RepublicUI.open(); const sheet = document.getElementById('repBody').textContent; const sheetOk = /HOLDS A GRUDGE/.test(sheet) && sheet.includes(nearest.name); RepublicUI.close && RepublicUI.close(); UI.closeAllModals();
  /* the next night at the storm's hour, season or none: the walker stands the target post — the storm is SEEN, and his */
  S.rep.reprisal = null;
  WL.tp([nearest.x + 20, nearest.y + 40]); S.room = null;
  const day0 = Math.floor(S.time / T2.dayLen) * T2.dayLen; S.time = day0 + T2.dayLen * (W.at + 0.01);
  Republic.tick(0.02);
  const tc = S.camps[nearest.id], storm = tc.storm, fired = !!storm && storm.from === 'ash' && storm.knives.some(k => k.cls === 'chief') && !!c.grudge && c.grudge.fired > 0;
  const title = /GRUDGE/.test(document.getElementById('toasts').textContent);
  /* held: the storm spends itself — the grudge is paid */
  if (tc.storm) { tc.storm.t = tc.storm.dur + 1; Republic.tick(0.02); }
  const paid = !c.grudge && !tc.storm && S.mails.slice(0, 3).some(m => /the grudge paid/.test(m.subj));
  /* a grudge that finds no post cools in its days */
  c.grudge = { t: S.time - G.days * T2.dayLen - 1, said: true, fired: 0 }; Republic.tick(0.02);
  const cooled = !c.grudge && S.mails[0] && /the grudge cools/.test(S.mails[0].subj);
  for (const o of others) S.camps[o.id].taken = null;
  return { started, withChief, broke: !!broke, fell, walkingKit, grudge, mail, lesson, noTarget, target, notTonight, said, sheetOk, fired, title: !!title, paid, cooled };
});
ok('THE NEW CHIEF\'S GRUDGE: standing the post at Ash, your own hands put the chief down — the storm breaks by YOUR hand and the camp writes that down; the mourning passed, a different man walks in (the new chief\'s kit) and carries the grudge (the mail, the lesson); with no post held there is no target, and the nearest post you take becomes his first storm; nothing fires the night he came up; he says so at the fire the next morning; the banner sheet names it; the next night at the storm\'s hour, out of season, his knives come for that post with him in front (THE GRUDGE on the title); the post holds and the grudge is paid; a grudge with nowhere to go cools in its days (the title read from the toast)',
  r.started && r.withChief && r.broke && r.fell && r.walkingKit && r.grudge && r.mail && r.lesson && r.noTarget && r.target && r.notTonight && r.said && r.sheetOk && r.fired && r.title && r.paid && r.cooled, JSON.stringify(r));

/* ================= 7 · THE SCAR CARRIED TO THE STONE ================= */
r = await ev(() => {
  const C = DATA.T.scar, T2 = DATA.T;
  S.pStats.scars = []; S.arrow = null;
  S.scar = { t0: S.time - C.healDays * T2.dayLen - 1, dressed: 3, dressT: 0, by: 'medic', lastBy: 'medic' };
  Systems.update(0.05, {}); const one = S.pStats.scars.length === 1 && S.pStats.scars[0].by === 'medic' && S.pStats.scars[0].dressedBy === 'medic' && S.pStats.scars[0].late === false && !S.scar;
  S.scar = { t0: S.time - C.undressedDays * T2.dayLen - 1, dressed: 1, dressT: 0, by: 'self', lastBy: 'town' };
  Systems.update(0.05, {}); const two = S.pStats.scars.length === 2 && S.pStats.scars[1].late === true && S.pStats.scars[1].by === 'self';
  const lesson = !!S.flags.tut.firstScarStone;
  /* the manual's page for the wound carries the plates */
  S.flags.tut.firstScar = true; ManualUI.open('lessons');
  const page2 = [...document.querySelectorAll('#fmBody .fmLesson')].find(el => /THE SCAR/.test(el.textContent) && !/ON THE STONE/.test(el.textContent));
  const plates = page2 && page2.querySelectorAll('.fmPlates img').length === 3 && [...page2.querySelectorAll('.fmPlates img')].every(im => /^data:image/.test(im.src)) && /DRESSED/.test(page2.textContent);
  const stonePage = [...document.querySelectorAll('#fmBody .fmLesson')].find(el => /THE SCAR ON THE STONE/.test(el.textContent)), stonePlates = stonePage && stonePage.querySelectorAll('.fmPlates img').length === 2;
  ManualUI.close();
  /* the walker's stone: a row the way the coat comes off, with the scars on it; the card and the stone read them */
  S.scar = { t0: S.time, dressed: 0, dressT: 0, by: 'self' };   // an open one counts too
  const before = S.legacy.length;
  S.legacy.push({ name: 'Tamsin Reade', cls: 'Courier', fate: 'hung up the coat', likes: 12, km: '4.2', deliveries: 9, cheated: false, seed: 4242, fact: 'waylight', scars: (S.pStats.scars || []).length + (S.scar ? 1 : 0) });
  S.scar = null;
  const row = S.legacy[S.legacy.length - 1], rowScars = row.scars === 3;
  for (let i = 0; i < 6 && !Memorial.rows('waylight').find(x => x.name === 'Tamsin Reade' && x.raised); i++) Memorial.raise('waylight');
  Memorial.open('waylight');
  const card = [...document.querySelectorAll('#memBody .memCard')].find(el => /Tamsin Reade/.test(el.textContent));
  const cardOk = card && card.querySelectorAll('.memScars img').length === 3 && /3 scars carried to the stone/.test(card.textContent);
  Memorial.close();
  const mr2 = Memorial.rows('waylight').find(x => x.name === 'Tamsin Reade');
  return { one, two, lesson, plates: !!plates, stonePlates: !!stonePlates, rowScars, cardOk: !!cardOk, raised: !!(mr2 && mr2.raised), ord: mr2 && mr2.ord };
});
const scarJson = JSON.stringify(r), scarOk = r.one && r.two && r.lesson && r.plates && r.stonePlates && r.rowScars && r.cardOk && r.raised;
/* the notches on the stone, seen */
await ev(() => { const row = Memorial.rows('waylight').find(x => x.name === 'Tamsin Reade'); const sl = Memorial.slotFor(row.ord, 'waylight'); WL.tp([sl.x, sl.y + 90]); S.dir = -Math.PI / 2; Render.setZoom(3); Render.cam.x = sl.x; Render.cam.y = sl.y + 10; WL.timeScale = 0.001; });
await page.waitForTimeout(500);
const stonePt = await ev(() => { const row = Memorial.rows('waylight').find(x => x.name === 'Tamsin Reade'); const sl = Memorial.slotFor(row.ord, 'waylight'); return { notches: __near(sl.x, sl.y, [0x6a, 0x2a, 0x22], 14, 40), tier: row.tier, p: __toScr(sl.x, sl.y) }; });
const notches = stonePt.notches;
await ev(() => { WL.timeScale = 1; Render.setZoom(null); });
ok('THE SCAR CARRIED TO THE STONE: a scar that closes is written on the walk (who pulled it, who dressed it, on time or late — the lesson); the manual\'s page for the scar carries three rig plates and the stone\'s page two; the coat hung up carries the count to the stone (two closed and one open, three); the memorial card shows three marks and says so; the notches read on the stone itself in the scar\'s red',
  scarOk && notches !== null && notches >= 6, scarJson + ' notches=' + notches + ' ' + JSON.stringify(stonePt));

/* ================= 8 · THE ROAD TO THE RING ================= */
await ev(() => { const ash = DATA.camps.find(c => c.id === 'ash'); S.camps.ash.chiefLost = 0; S.camps.ash.chiefReturn = null; S.camps.ash.grudge = null; S.camps.ash.taken = null; S.moveTo = null; S.route = []; S.stam = S.stamMax; S.food = 60; S.health = Math.max(S.health, 60); S.scar = null; S.arrow = null; WL.tp([ash.x + 100, ash.y + 1150]); UI.toggleMap(true); });
await page.waitForTimeout(300);
{
  const pt = await ev(() => { const ash = DATA.camps.find(c => c.id === 'ash'); return UI.mapPoint(ash.x, ash.y); });
  await page.mouse.move(pt.x, pt.y);
  for (let i = 0; i < 5; i++) { await page.mouse.wheel(0, -100); await page.waitForTimeout(80); }
  await page.waitForTimeout(300);
  await page.mouse.move(pt.x, pt.y + 220); await page.mouse.down(); await page.waitForTimeout(120);
  for (let i = 1; i <= 6; i++) { await page.mouse.move(pt.x - 60 * i, pt.y + 220); await page.waitForTimeout(60); }
  await page.waitForTimeout(500); await page.mouse.up(); await page.waitForTimeout(300);
  const pz = await ev(() => { const ash = DATA.camps.find(c => c.id === 'ash'); return UI.mapPoint(ash.x, ash.y + 22 / 0.35); });
  await page.mouse.move(pz.x, pz.y); await page.waitForTimeout(150);
  await page.mouse.down(); await page.mouse.up(); await page.waitForTimeout(200);
}
r = await ev(() => { const tip = document.getElementById('mapTip'); return { pinned: tip.style.display === 'block' && tip.classList.contains('pinned'), road: !!tip.querySelector('.crRow.crRoad') && /walk to the ring/.test(tip.textContent) && /km to its near edge/.test(tip.textContent), roadImg: !!tip.querySelector('.crRow.crRoad img') }; });
const pinJson = JSON.stringify(r), pinOk = r.pinned && r.road && r.roadImg;
await page.click('#mapTip .crRow.crRoad'); await page.waitForTimeout(250);
r = await ev(() => {
  const ash = DATA.camps.find(c => c.id === 'ash'), m = S.moveTo, tip = document.getElementById('mapTip');
  const planned = !!m && m.ring === 'ash' && Math.abs(U.dist(m.x, m.y, ash.x, ash.y) - (ash.r + 130)) < 40;
  const released = tip.style.display === 'none' && !tip.classList.contains('pinned'), mapOpen = !document.getElementById('mapWrap').classList.contains('hidden');
  const lesson = !!S.flags.tut.firstRingWalk, toast = /road to Ash Camp/.test(document.getElementById('toasts').textContent);
  const p = UI.mapPoint(m.x, m.y);
  return { planned, released, mapOpen, lesson, toast, pin: { x: p.x, y: p.y } };
});
const pinSeen = await ev(() => { const m = S.moveTo, c = document.getElementById('map'), r0 = c.getBoundingClientRect(), dpr = devicePixelRatio, p = UI.mapPoint(m.x, m.y); const g = c.getContext('2d'); const x0 = Math.max(0, Math.round((p.x - r0.left - 20) * dpr)), y0 = Math.max(0, Math.round((p.y - r0.top - 40) * dpr)); const d = g.getImageData(x0, y0, Math.round(40 * dpr), Math.round(60 * dpr)).data; let hit = 0; for (let i = 0; i < d.length; i += 4) if (Math.abs(d[i] - 0xc9) < 16 && Math.abs(d[i + 1] - 0x55) < 16 && Math.abs(d[i + 2] - 0x3a) < 16) hit++; return hit; });
const walked = await ev(() => { UI.toggleMap(false); for (let i = 0; i < 20; i++) Systems.update(0.1, {}); const m = S.moveTo; const moving = S.speed > 5 || !!m || !!(S.ringHold && S.ringHold.camp === 'ash');   /* v3.45: arrived, the line holds at the ring — the walk was walked */ /* the engine's own door: the same walk by name */ UI.toggleMap(true); const direct = UI.ringWalk('ridge') && S.moveTo && S.moveTo.ring === 'ridge'; UI.toggleMap(false); S.moveTo = null; return { moving, direct: !!direct, party: NPC.party().length }; });
ok('THE ROAD TO THE RING: a pinned roll carries the camp\'s road as a line with its mark and the distance to the ring\'s near edge; a real click on it plans the walk to the near edge of Ash Camp\'s ring (outside the loaded pack\'s danger ring), lets the roll go with the sheet still open, plants the ring pin in rust on the sheet (pixel-sampled), the toast and the lesson; the sheet closed, the walk is under way; the engine\'s own door plans the same walk by name',
  pinOk && r.planned && r.released && r.mapOpen && r.lesson && r.toast && pinSeen !== null && pinSeen >= 6 && walked.moving && walked.direct, pinJson + ' ' + JSON.stringify(r) + ' pin=' + pinSeen + ' ' + JSON.stringify(walked));

/* ================= 9 · THE SAVE ================= */
r = await ev(() => {
  S.moveTo = null;
  S.camps.ash.grudge = { t: S.time, said: true, fired: 0 }; S.camps.ash.chiefGen = 3; S.camps.ash.chiefFelledBy = 'walker';
  S.stations.mill.kin = { t: S.time, names: ['Halvard Penrose'], spots: [0] }; S.stations.elm.wordSaid = { line: 'Your word? I\'ll take your word.', t: S.time, kind: 'promise' };
  S.grievances = [{ id: 'g_save', to: 'elm', from: 'haven', kind: 'coat', name: 'a mended coat', t: S.time, how: 'ground', n: 1, remembered: false, word: 'promise', wordT: S.time }];
  S.pStats.scars = [{ t: S.time, by: 'medic', dressed: 3, dressedBy: 'medic', late: false }];
  State.save();
  S.camps.ash.grudge = null; S.camps.ash.chiefGen = 0; S.camps.ash.chiefFelledBy = null; S.stations.mill.kin = null; S.stations.elm.wordSaid = null; S.grievances = []; S.pStats.scars = [];
  State.load();
  const grudge = !!S.camps.ash.grudge && S.camps.ash.chiefGen === 3 && S.camps.ash.chiefFelledBy === 'walker' && Republic.chiefKit(DATA.camps.find(c => c.id === 'ash')) === 'chief2';
  const kin = !!Republic.kinAt('mill') && S.stations.mill.kin.names[0] === 'Halvard Penrose';
  const word = S.grievances.length === 1 && S.grievances[0].word === 'promise' && S.stations.elm.wordSaid && S.stations.elm.wordSaid.kind === 'promise';
  const scars = S.pStats.scars.length === 1 && S.pStats.scars[0].dressedBy === 'medic';
  S.grievances = []; S.camps.ash.grudge = null; S.stations.mill.kin = null;
  return { grudge, kin, word, scars };
});
ok('THE SAVE: the grudge, the chief\'s generation and whose hand it was, the kin in the square, what the keeper last answered, a promise standing, and the walk\'s scars survive a save and load', r.grudge && r.kin && r.word && r.scars, JSON.stringify(r));

ok('no page errors across the word', errors.length === 0, errors.slice(0, 3).join(' | '));
console.log(results.join('\n'));
console.log(`${results.filter(x => x.startsWith('PASS')).length}/${results.length} checks passed`);
await b.close();
