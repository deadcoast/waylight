/* feel.mjs — the seven complaints, verified: pack buttons click, the companion is clickable and fights,
   shift-click strings routes (world and map), terminals have a named voice, the Walker speaks, and the
   words 'porter' and 'likes' are out of every line a player reads. */
import { chromium } from 'playwright';
const results = [], errors = [];
const ok = (name, cond, extra = '') => { results.push(`${cond ? 'PASS' : 'FAIL'}  ${name}${extra ? '  — ' + extra : ''}`); if (!cond) process.exitCode = 1; };
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium', args: ['--disable-background-networking'] });
const page = await b.newPage({ viewport: { width: 1440, height: 860 } });
await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
page.on('pageerror', e => errors.push(e.message));
await page.goto('file:///home/claude/waylight/dist/test.html?debug', { waitUntil: 'domcontentloaded' });
await page.waitForFunction(() => window.WL && WL.snapshot().baked, null, { timeout: 60000 });
await page.evaluate(() => localStorage.clear());

/* 0. no Death Stranding vocabulary in what a player reads: title, intro, briefing, help */
await page.waitForTimeout(300);
const titleText = await page.evaluate(() => document.getElementById('titleScreen').innerText);
await page.click('#btnNew'); await page.waitForTimeout(150);
const introText = await page.evaluate(() => document.getElementById('introCard').innerText);
await page.click('#btnBegin'); await page.waitForTimeout(250);
const briefText = await page.evaluate(() => document.getElementById('briefOv').innerText);
await page.click('#briefGo'); await page.waitForTimeout(200);
const cgText = await page.evaluate(() => document.getElementById('chargen').innerText);
await page.click('#cgBegin'); await page.waitForTimeout(500);
const helpText = await page.evaluate(() => document.getElementById('helpOv') ? document.getElementById('helpOv').innerText : '');
const visible = titleText + introText + briefText + cgText + helpText;
ok('no "porter" anywhere a player reads (title, intro, briefing, chargen, help)', !/\bporters?\b/i.test(visible), (visible.match(/[^\n]*porter[^\n]*/i) || ['clean'])[0]);
ok('the trade has a name: "Waylighter" carries the intro, the creed closes it', /Waylighters/.test(introText) && /Somebody has to walk it/.test(introText) && /somebody has to walk it/i.test(titleText), introText.split('\n').slice(-3).join(' · ').slice(0, 120));
ok('pay is "trust", not likes', /trust/.test(briefText) && !/\blikes\b/i.test(briefText), (briefText.match(/[^\n]*trust[^\n]*/) || [''])[0].slice(0, 110));
ok('the briefing is told by a person — Mara Voss', /Mara Voss/.test(briefText));

await page.evaluate(() => { WL.calm(); Render.setFx(false); S.weather.state = 'clear'; S.weather.t = 99999; S.weather.intensity = 0; S.time = 60; });

/* 1. the pack is real UI: its buttons click, and clicking them never walks the Walker */
await page.evaluate(() => { WL.tp('haven'); S.px += 500; S.moveTo = null; State.addCargo(State.makeItem('ration')); });
await page.keyboard.press('i'); await page.waitForTimeout(300);
const dropBtn = await page.evaluate(() => { const el = document.querySelector('#cargoList [data-drop]'); if (!el) return null; const r = el.getBoundingClientRect(); return { x: r.x + r.width / 2, y: r.y + r.height / 2 }; });
const before = await page.evaluate(() => ({ n: S.cargo.length, drops: S.drops.length }));
await page.mouse.click(dropBtn.x, dropBtn.y); await page.waitForTimeout(250);
let r = await page.evaluate(() => ({ n: S.cargo.length, drops: S.drops.length, moveTo: !!S.moveTo }));
ok('clicking "drop" in the pack drops the item — and does NOT start a walk', r.n === before.n - 1 && r.drops === before.drops + 1 && !r.moveTo, JSON.stringify(r));
const panelPt = await page.evaluate(() => { const p = document.getElementById('cargoPanel').getBoundingClientRect(); return { x: p.x + 30, y: p.y + 20 }; });
await page.mouse.click(panelPt.x, panelPt.y); await page.waitForTimeout(200);
r = await page.evaluate(() => !!S.moveTo);
ok('clicking the pack panel itself moves nothing', !r);
await page.keyboard.press('i'); await page.waitForTimeout(150);

/* 2. the companion chip is clickable and giving works in two clicks */
await page.evaluate(() => {
  const n = NPC.gen({ at: 'haven' }); n.state = 'companion'; n.carry = []; n.x = S.px + 40; n.y = S.py; n.food = 100; S.npcs.push(n);
  State.addCargo(State.makeItem('food'));
  UI2.updateVitals ? UI2.updateVitals() : null;
});
await page.waitForTimeout(400);
const chip = await page.evaluate(() => { const el = document.getElementById('compChip'); const r2 = el.getBoundingClientRect(); return { hidden: el.classList.contains('hidden'), x: r2.x + r2.width / 2, y: r2.y + r2.height / 2, text: el.innerText }; });
ok('the companion chip shows who they are and what they carry', !chip.hidden && /carrying/.test(chip.text) && /hand over/.test(chip.text), chip.text.replace(/\n/g, ' · ').slice(0, 90));
await page.mouse.click(chip.x, chip.y); await page.waitForTimeout(300);
r = await page.evaluate(() => !document.getElementById('cargoPanel').classList.contains('hidden'));
ok('clicking the chip opens the pack for the hand-over', r);
const giveBtn = await page.evaluate(() => { const el = document.querySelector('#cargoList [data-give]'); if (!el) return null; const r2 = el.getBoundingClientRect(); return { x: r2.x + r2.width / 2, y: r2.y + r2.height / 2 }; });
await page.mouse.click(giveBtn.x, giveBtn.y); await page.waitForTimeout(250);
r = await page.evaluate(() => ({ carried: NPC.companion().carry.length, moveTo: !!S.moveTo }));
ok('clicking "give" hands the crate over — no walk, no hunting through menus', r.carried === 1 && !r.moveTo, JSON.stringify(r));
await page.keyboard.press('i'); await page.waitForTimeout(150);

/* 3. clicking the companion out in the world walks to them and opens the hand-over */
r = await page.evaluate(() => {
  const n = NPC.companion(); n.x = S.px + 300; n.y = S.py + 60;
  const okm = Systems.moveTo(n.x, n.y);
  return { okm, act: S.moveTo && S.moveTo.act, hasFn: !!(S.moveTo && S.moveTo.fn), label: S.moveTo && S.moveTo.label };
});
ok('clicking your walking partner is a real target: walk over and the pack opens', r.okm && r.act && r.hasFn, JSON.stringify(r));
await page.evaluate(() => { S.moveTo = null; });

/* 4. shift-click strings a route in the world */
r = await page.evaluate(() => {
  S.route = []; S.moveTo = null;
  Systems.queueMove(S.px + 250, S.py);          // first mark starts the walk
  Systems.queueMove(S.px + 250, S.py + 250);    // the rest string on
  Systems.queueMove(S.px, S.py + 250);
  return { moving: !!S.moveTo, queued: S.route.length };
});
ok('three marks: the first starts the walk, two wait in the string', r.moving && r.queued === 2, JSON.stringify(r));
await page.evaluate(() => { WL.timeScale = 6; });
let chained = false;
for (let i = 0; i < 60; i++) { await page.waitForTimeout(250); const st = await page.evaluate(() => ({ q: S.route.length, m: !!S.moveTo })); if (st.q === 0 && !st.m) { chained = true; break; } }
await page.evaluate(() => { WL.timeScale = 1; });
ok('the Walker takes the marks in order and finishes the string', chained);

/* 5. the map: shift-click strings marks without closing; plain click closes and walks */
await page.keyboard.press('m'); await page.waitForTimeout(400);
const mapPt = await page.evaluate(() => UI.mapPoint(S.px + 600, S.py - 300));
const mapPt2 = await page.evaluate(() => UI.mapPoint(S.px + 900, S.py - 100));
await page.keyboard.down('Shift');
await page.mouse.click(mapPt.x, mapPt.y); await page.waitForTimeout(150);
await page.mouse.click(mapPt2.x, mapPt2.y); await page.waitForTimeout(150);
await page.keyboard.up('Shift');
r = await page.evaluate(() => ({ open: !document.getElementById('mapWrap').classList.contains('hidden'), moving: !!S.moveTo, q: S.route.length }));
ok('two shift-clicks on the map: still open, walking the first, one queued', r.open && r.moving && r.q === 1, JSON.stringify(r));
const mapPt3 = await page.evaluate(() => UI.mapPoint(S.px + 300, S.py + 100));
await page.mouse.click(mapPt3.x, mapPt3.y); await page.waitForTimeout(250);
r = await page.evaluate(() => ({ open: !document.getElementById('mapWrap').classList.contains('hidden'), moving: !!S.moveTo, q: S.route.length }));
ok('a plain click closes the map, drops the string, and walks there', !r.open && r.moving && r.q === 0, JSON.stringify(r));
await page.evaluate(() => { Systems.cancelMove(); });

/* 6. the companion does not watch you die: a charging scrapper gets met and knocked flat */
r = await page.evaluate(() => {
  const n = NPC.companion(); n.x = S.px + 30; n.y = S.py; n.shoveCd = 0; n.hungry = false;
  const cdef = DATA.camps[0], c = S.camps[cdef.id];
  WL.tp([cdef.x, cdef.y]); n.x = S.px + 30; n.y = S.py;
  S.cargo.push(State.makeItem('food'));
  c.runners.length = 0; c.runners.push({ x: S.px + 120, y: S.py, wa: 0, state: 'patrol', cd: 0 });
  const r0 = c.runners[0];
  for (let i = 0; i < 40; i++) Systems.update(0.05, {});
  return { dist: U.dist(r0.x, r0.y, S.px, S.py) | 0, cd: +r0.cd.toFixed(1), taught: !!S.flags.tut.firstIntercept, hp: S.health | 0 };
});
ok('the companion meets the charge: scrapper knocked back and cooling down, you untouched', r.dist > 150 && r.cd > 0 && r.taught && r.hp === 100, JSON.stringify(r));

/* 7. every terminal has a face: Mara greets a stranger, and the line follows the station's state */
r = await page.evaluate(() => {
  WL.tp('haven'); S.stations.haven.met = false;
  WL.openStation('haven');
  const hello = document.getElementById('keeperLine').innerText;
  document.getElementById('stationClose').click();
  S.stations.haven.stock.food = 5; S.stations.haven.stock.meds = 5; S.stations.haven.stock.lumenCell = 5;
  WL.openStation('haven');
  const crit = document.getElementById('keeperLine').innerText;
  document.getElementById('stationClose').click();
  return { hello, crit };
});
ok('first visit: the keeper introduces themself by name', /MARA VOSS/i.test(r.hello) && /Board is behind me, Walker/.test(r.hello), r.hello.slice(0, 90));
ok('the greeting follows the station\'s state: empty stores get the hard line', /ledger that stopped adding up/.test(r.crit), r.crit.slice(0, 90));

/* 8. the Walker has a voice: night falls out in the open and they say so */
r = await page.evaluate(() => {
  WL.tp([6500, 10100]); S.moveTo = null; S.wasNight = false; S.flags.barks = {};
  S.time = DATA.T.dayLen * 0.62;
  Systems.update(0.05, {});
  return { barked: (S.flags.barks.night || 0) >= 1 };
});
ok('night falls in the open — the Walker says something about it (once, not a chatterbox)', r.barked, JSON.stringify(r));

/* 9. accepting an order gives visible feedback: the card flashes and slides */
r = await page.evaluate(() => {
  S.time = 60; WL.tp('haven'); S.stations.elm.met = true; S.stations.elm.stock.tools = 30;
  WL.openStation('haven');
  const btn = document.querySelector('#stationBody .orderCard:not(.prio) [data-accept]');
  if (!btn) return { none: true };
  btn.click();
  const card = document.querySelector('#stationBody .orderCard.taken');
  return { taken: !!card };
});
ok('accepting an order marks the card "taken" — it flashes gold and slides off', r.taken === true, JSON.stringify(r));

console.log(results.join('\n'));
console.log(`\n${results.filter(x => x.startsWith('PASS')).length}/${results.length} passed · errors: ${errors.length ? errors.join(' | ') : 'none'}`);
await b.close();
