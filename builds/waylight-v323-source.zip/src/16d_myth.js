'use strict';
/* Waylight v3.23 — THE MYTH IN THE FLESH.
   The Postman's return, carried through GAMEPLAY: the world reacts to the walker's LEGEND, citing
   the player's ACTUAL record — never a dialogue screen. Micro-cines are cognitive signals only
   (letterbox + one slow zoom + the FIRST line, then release). And once per town, the famous
   handoff gets the absurdly over-produced parody it deserves: slow-mo, three cuts, the SUPER ZOOM,
   a freeze frame — janky low-bit art meeting effects money can't buy, because code is our muscle. */

const Myth = (() => {
  const { stations, stationOrder, T } = DATA;

  /* ---------- the legend ladder: how loudly the valley talks ---------- */
  const TIERS = [
    [1, 'a stranger', null],
    [4, 'SPOKEN OF', 'People pause when the coat goes by.'],
    [7, 'THE WALKER', 'They stop. They point. They tell each other where they were.'],
    [10, 'THE MYTH IN THE FLESH', 'Children run the fences to keep you in sight.'],
  ];
  function tier() { let t = 0; for (let i = 0; i < TIERS.length; i++) if ((S.level || 1) >= TIERS[i][0]) t = i; return t; }

  /* a bystander's line, built from the RECORD — what this player actually did */
  function mythLine(stId) {
    const st = S.stations[stId];
    const lines = [];
    const others = stationOrder.filter(id => id !== stId && S.stations[id].connected);
    const far = others.length ? stations[others[(rnd() * others.length) | 0]].name : null;
    if (st.stars >= 3) lines.push(`${st.stars} stars over our door. ${S.pName} put every one of them there.`);
    if ((st.likesTo || 0) > 120) lines.push(`I counted the crates once. I stopped counting. It kept coming.`);
    if (st.connected) lines.push(`I lived here UNLIT. Then that coat walked out of the grey.`);
    if (far) lines.push(`I saw the ${State.titleFor(S.level).toLowerCase()} once, out past ${far}, before OUR light came.`);
    if ((S.stats.delivered || 0) > 30) lines.push(`${S.stats.delivered} deliveries, they say. I believe every one now.`);
    if (Economy.apprLevel(stId) >= 3) lines.push(`That's them. That's the one the riders answer for.`);
    lines.push(`It's the Walker. It's actually the Walker.`);
    return lines[(rnd() * lines.length) | 0];
  }
  const rnd = Math.random;

  /* ---------- the micro-cine: letterbox, ONE slow zoom, the first line, release ---------- */
  function microCine(x, y, line, opts = {}) {
    if (S.cine || S.handoff || S.mcine) return false;
    S.mcine = { t: 0, dur: Math.min(2.2, opts.dur || 2.2), x, y, line, col: opts.col || '198,206,186', said: false };
    UI.setLetterbox(true);
    return true;
  }
  function endMicro() {
    if (!S.mcine) return false;
    S.mcine = null;
    if (!S.cine && !S.handoff) UI.setLetterbox(false);
    return true;
  }

  /* ---------- bystander recognition: the yard notices, and says WHERE it was ---------- */
  const reactCd = {};
  let kidCd = 0;
  function updateLegend(dt) {
    const tr = tier();
    if (tr < 1) return;
    for (const id of stationOrder) {
      const d = stations[id], st = S.stations[id];
      if (!st.connected || st.litT <= 0) continue;
      const pd = U.dist(S.px, S.py, d.x, d.y);
      if (pd > 230) continue;
      // a NEW tier's first lit yard: the moment gets the zoom
      if ((S.flags.mythSeen || 0) < tr) {
        S.flags.mythSeen = tr;
        const bx = d.x + 46, by = d.y + 34;
        microCine(bx, by, tr >= 3 ? `It's HIM. It's actually him. THE ${State.titleFor(S.level).toUpperCase()}.` : mythLine(id), { col: '255,201,120' });
        S.mythSay = { stId: id, t: 4 };
        Snd.sfx.like(0);
        continue;
      }
      if ((reactCd[id] || 0) > S.time) continue;
      reactCd[id] = S.time + 120;
      S.mythSay = { stId: id, t: 3.2 };
      Render.say(d.x + 46, d.y + 22, mythLine(id), '198,206,186');
    }
    if (S.mythSay) { S.mythSay.t -= dt; if (S.mythSay.t <= 0) S.mythSay = null; }
    // THE MYTH: children run the fences alongside
    kidCd -= dt;
    if (tr >= 3 && kidCd <= 0 && S.speed > 20) {
      const near = stationOrder.find(id => S.stations[id].connected && U.dist(S.px, S.py, stations[id].x, stations[id].y) < 700);
      if (near) {
        kidCd = 55;
        S.kids = [];
        for (let i = 0; i < 2; i++) S.kids.push({ x: S.px - 40 - i * 22, y: S.py + 26 + i * 14, t: 0, dur: 4.5, seed: (Math.random() * 1e9) | 0 });
      }
    }
    if (S.kids) {
      for (const k of S.kids) {
        k.t += dt;
        const tx = S.px - 24 - (k.seed % 3) * 10, ty = S.py + 22 + (k.seed % 5) * 5;
        const d2 = Math.max(1, U.dist(k.x, k.y, tx, ty));
        const sp = Math.min(S.speed + 26, 150);
        k.x += (tx - k.x) / d2 * sp * dt; k.y += (ty - k.y) / d2 * sp * dt;
      }
      if (S.kids.every(k => k.t > k.dur)) { const k0 = S.kids[0]; Render.say(k0.x, k0.y - 10, U.pick(rnd, ['THE WALKER! I TOUCHED THE COAT!', 'Tell my brother! TELL HIM!', 'One day I ride too!']), '255,201,120'); S.kids = null; }
    }
  }

  /* ---------- THE HANDOFF: the famous scene, over-produced on purpose ----------
     Mounted, letters aboard for the town ahead, first time there: a kid runs to the roadside with
     a letter held HIGH. The world drops to quarter speed. Three cuts — wide, close, SUPER ZOOM —
     speed lines, the pass, a white flash, a freeze frame, a stamp. Then the road again. */
  function maybeHandoff() {
    if (S.handoff || S.cine || S.mcine || S.dead) return;
    if (!Systems.horseOn()) return;
    for (const o of S.orders.active) {
      if (o.item !== 'letters' || o.convoy || o.salvage) continue;
      const d = stations[o.to];
      const pd = U.dist(S.px, S.py, d.x, d.y);
      if (pd < 300 || pd > 430) continue;
      S.flags.handoffs = S.flags.handoffs || {};
      if (S.flags.handoffs[o.to]) continue;
      S.flags.handoffs[o.to] = true;
      beginHandoff(o.to);
      return;
    }
  }
  function beginHandoff(stId) {
    const d = stations[stId];
    const ang = Math.atan2(d.y - S.py, d.x - S.px);
    const px2 = S.px + Math.cos(ang) * 150, py2 = S.py + Math.sin(ang) * 150;   // the pass point, up the road
    S.handoff = {
      t: 0, town: stId, phase: 0,
      px: px2, py: py2,
      kidX: px2 + Math.cos(ang + Math.PI / 2) * 120, kidY: py2 + Math.sin(ang + Math.PI / 2) * 120,
      kidTX: px2 + Math.cos(ang + Math.PI / 2) * 14, kidTY: py2 + Math.sin(ang + Math.PI / 2) * 14,
      seed: (Math.random() * 1e9) | 0, passed: false, flash: 0, frozeT: 0, envT: -1,
    };
    S.timeScale = 0.25;
    UI.setLetterbox(true);
    Snd.sfx.alarm();
  }
  function updateHandoff(dt) {
    const h = S.handoff;
    if (!h) { maybeHandoff(); return; }
    h.t += dt;   // REAL time — the whole point is the world crawling underneath it
    // the kid runs out, letter high
    const kd = Math.max(1, U.dist(h.kidX, h.kidY, h.kidTX, h.kidTY));
    if (kd > 4) { h.kidX += (h.kidTX - h.kidX) / kd * 130 * dt; h.kidY += (h.kidTY - h.kidY) / kd * 130 * dt; }
    h.phase = h.t < 0.9 ? 0 : h.t < 1.8 ? 1 : 2;
    // THE PASS: the walker crosses the point, or the clock calls it
    if (!h.passed && h.phase === 2 && (U.dist(S.px, S.py, h.kidTX, h.kidTY) < 46 || h.t > 2.5)) {
      h.passed = true; h.flash = 0.14; h.envT = 0; h.frozeT = 0.42;
      S.timeScale = 0;   // the freeze frame
      Snd.sfx.like(0);
    }
    if (h.flash > 0) h.flash -= dt;
    if (h.envT >= 0) h.envT += dt;
    if (h.passed && h.frozeT > 0) { h.frozeT -= dt; if (h.frozeT <= 0) S.timeScale = 0.25; }
    if (h.t >= 3.6) endHandoff(false);
  }
  function endHandoff(skipped) {
    const h = S.handoff;
    if (!h) return false;
    S.handoff = null;
    S.timeScale = 1;
    if (!S.cine && !S.mcine) UI.setLetterbox(false);
    Economy.addAppr(h.town, 3);
    State.grantLikes(5);
    UI.toast(`The whole of ${stations[h.town].name} will hear about that handoff by dusk.`, 'gold', 5000);
    Systems.addMail(`From a mother at ${stations[h.town].name}`, `My kid hasn't stopped talking about the rider who took the letter AT FULL TROT. You could have stopped. You didn't. It was PERFECT.`);
    return true;
  }
  function skip() {
    if (S.mcine) return endMicro();
    if (S.handoff) return endHandoff(true);
    return false;
  }

  /* keeper hellos bend the knee at tier 2+ — a line before their own words */
  function legendPrefix(stId) {
    const tr = tier();
    if (tr < 2) return '';
    const pool = tr >= 3
      ? ['They said you were taller. They were wrong about everything else.', 'The kids drew you on the water tower. I let them.', 'You walk in here like the light itself owes you a favour. It does.']
      : ['Word walks faster than you do now.', 'People say your name like they checked the spelling.'];
    return `<i>${pool[(rnd() * pool.length) | 0]}</i> `;
  }

  function tick(dt) {
    if (S.mcine) {
      S.mcine.t += dt;
      if (!S.mcine.said && S.mcine.t > 0.5) { S.mcine.said = true; Render.say(S.mcine.x, S.mcine.y - 14, S.mcine.line, S.mcine.col); }
      if (S.mcine.t >= S.mcine.dur) endMicro();
    }
    updateHandoff(dt);
    if (!S.cine && !S.handoff && !S.mcine) updateLegend(dt);
  }

  return { tick, tier, microCine, endMicro, beginHandoff, endHandoff, skip, mythLine, legendPrefix, TIERS };
})();
