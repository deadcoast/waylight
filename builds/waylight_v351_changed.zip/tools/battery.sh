#!/bin/sh
# battery.sh — v3.51: run the battery, one suite at a time (the machine is small; a suite's timing is its own), each under a
# time limit, and tally it. The probes (tests/probe_*.mjs) and the scratch folder are not suites.
#   tools/battery.sh                 every suite
#   tools/battery.sh word kept       these suites
#   LOGS=/some/dir WL_URL=... tools/battery.sh
cd "$(dirname "$0")/.." || exit 1
LOGS=${LOGS:-/tmp/waylight-battery}
mkdir -p "$LOGS"
if [ $# -gt 0 ]; then SUITES="$*"; else SUITES=$(ls tests/*.mjs | sed 's#tests/##; s#\.mjs##' | grep -v '^probe_'); fi
: > "$LOGS/summary.txt"
for s in $SUITES; do
  timeout "${LIMIT:-1500}" node "tests/$s.mjs" > "$LOGS/$s.log" 2>&1
  code=$?
  tally=$(grep -E '^[0-9]+/[0-9]+ checks passed' "$LOGS/$s.log" | tail -1)
  fails=$(grep -c '^FAIL' "$LOGS/$s.log")
  echo "$s  exit=$code  ${tally:-no tally}  fails=$fails" | tee -a "$LOGS/summary.txt"
done
awk '{ split($3, a, "/"); if ($3 ~ /\//) { p += a[1]; n += a[2] } } END { print "BATTERY " p "/" n " checks passed" }' "$LOGS/summary.txt" | tee -a "$LOGS/summary.txt"
