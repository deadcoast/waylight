/* campsown.mjs — v3.41 THE CAMPS' OWN: the registries (four raider trades on the camp rows, three
   hand-drawn kit figures and the town's own in their palettes, the parcel kinds, the recruit rows,
   the count's sale); the parcels ADDRESSED (the traffic ledger steering the round, one run per door,
   the keeper's line read aloud, an older count derived into a list); the rear rail's pip as a door
   to the roll; the square standing its own (recruits at love, no rise while they stand, home when
   the love falls); the camps' own on the road (the roll on the runners, the bowman's shot, the ram's
   two shoves); the storm with the kit (the bowman standing off and pinning an arm, the ram shrugging
   a knock and taking the fire fast, the chief's rally and the break); the count bought; the save. */
import { chromium } from 'playwright';
const results = [];
const ok = (name, cond, extra = '') => { results.push(`${cond ? 'PASS' : 'FAIL'}  ${name}${extra ? '  — ' + extra : ''}`); if (!cond) process.exitCode = 1; };
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium', args: ['--disable-background-networking'] });
const page = await b.newPage({ viewport: { width: 1440, height: 860 } });
await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
const errors = [];
page.on('pageerror', e => errors.push(String(e.message)));
await page.goto('file:///home/claude/waylight/dist/test.html?debug', { waitUntil: 'domcontentloaded' });
await page.waitForFunction(() => window.WL && WL.snapshot && WL.snapshot().baked, null, { timeout: 60000 });
await page.evaluate(() => localStorage.clear());
await page.click('#btnNew'); await page.waitForTimeout(300);
await page.click('#btnBegin'); await page.waitForTimeout(400);
await page.click('#briefGo'); await page.waitForTimeout(300);
await page.click('#cgBegin'); await page.waitForTimeout(1200);
for (let i = 0; i < 30; i++) { const c = await page.evaluate(() => !!S.cine); if (!c) break; await page.evaluate(() => WL.skipCine()); await page.waitForTimeout(250); }
await page.evaluate(() => { S.flags.guideDone = true; WL.calm(); });
const ev = (fn, arg) => page.evaluate(fn, arg);

/* ================= 1 · THE REGISTRIES ================= */
let r = await ev(() => {
  const C = FACT.CAMP_CLASSES;
  const classes = ['knife', 'bowman', 'ram', 'chief'].every(k => C[k] && C[k].name && C[k].line && C[k].stats && typeof C[k].stats.speed === 'number' && C[k].stats.knocks >= 1 && C[k].stats.takeMul > 0);
  const bow = C.bowman.stats.range > 0 && C.bowman.stats.shotCd > 0 && C.bowman.stats.pin > 0 && C.bowman.stats.roadRange > 0 && C.bowman.stats.roadDmg > 0 && C.bowman.stats.stagger > 0 && C.bowman.kit === 'bowman';
  const ram = C.ram.stats.knocks === 2 && C.ram.stats.takeMul < 1 && C.ram.stats.speed < 1 && C.ram.kit === 'ram';
  const chief = C.chief.stats.rally < 1 && C.chief.stats.road === false && C.chief.kit === 'chief';
  const rolls = DATA.camps.every(cd => Array.isArray(cd.roll) && cd.roll.length >= 3 && cd.roll.every(k => C[k]) && cd.roll.filter(k => C[k].stats.road !== false).length >= 1);
  const inPal = (rows, pal) => rows.length === 22 && rows.every(rw => rw.length === 14) && [...new Set(rows.join('').replace(/\./g, ''))].every(ch => pal[ch]);
  const kit = ['bowman', 'ram', 'chief'].every(k => SPRITES.KIT[k] && ['idle', 'A', 'B'].every(f => inPal(SPRITES.KIT[k][f], SPRITES.RAID_PAL)));
  const own = SPRITES.FIGURES.townshield && ['idle', 'A', 'B'].every(f => inPal(SPRITES.FIGURES.townshield[f], SPRITES.TOWN_PAL));
  const distinct = ['bowman', 'ram', 'chief'].every(k => SPRITES.KIT[k].idle.join('') !== SPRITES.KIT.pugugly.idle.join('') && SPRITES.KIT[k].A.join('') !== SPRITES.KIT[k].B.join(''));
  const kinds = DATA.parcelKinds.length === 8 && DATA.parcelKinds.every(k => k.id && k.name && /\{who\}/.test(k.line));
  const R = REP.DOCTRINE.storm.rise;
  const recruit = R.recruitAt > R.likesAt && R.recruitEvery > 0 && R.ownMax >= 1 && R.ownLeaveBelow < R.recruitAt && !!R.ownLine;
  const SL = REP.EVENTS.bunkerSweep.sell;
  const sell = SL && SL.cost.metal > 0 && SL.cost.ceramic > 0 && SL.shields === 2 && SL.rel === 1 && /\{site\}/.test(SL.mail[1]) && !!SL.line;
  const pair = REP.RELATIONS.base['diefenbunker|waylight'] !== undefined, pairs = Object.keys(REP.RELATIONS.base).length;
  const lessons = ['firstTrades', 'firstOwn', 'firstSold'].every(k => DATA.tutorials[k] && DATA.tutorialTitles[k]), lessonsN = Object.keys(DATA.tutorials).length;
  const clsOf = Systems.clsOf({ cls: 'ram' }).knocks === 2 && Systems.clsOf({}).knocks === 1;
  const runOut = REP.WATCHPOST.storm.seen.runOut > 0;
  return { classes, bow, ram, chief, rolls, kit, own, distinct, kinds, recruit, sell, pair, pairs, lessons, lessonsN, clsOf, runOut };
});
ok('THE REGISTRIES: four raider trades (the knife, a bowman who stands off and pins, a ram of two knocks who takes a fire fast, a chief who rallies and keeps the fire), every camp\'s roll on those rows with at least one road-walker; three hand-drawn kit figures and the town\'s own at 14×22 in their own palettes, each with three distinct frames; eight parcel kinds with a keeper\'s line; the recruit rows on the rise doctrine; the count\'s sale on the sweep row; the Society–Waylight pair (seventeen); three lessons titled (fifty-one pages since v3.42); the class reader',
  r.classes && r.bow && r.ram && r.chief && r.rolls && r.kit && r.own && r.distinct && r.kinds && r.recruit && r.sell && r.pair && r.pairs === 17 && r.lessons && r.lessonsN === 86 && r.clsOf && r.runOut, JSON.stringify(r));

/* ================= 2 · THE PARCELS ADDRESSED ================= */
r = await ev(() => {
  S.banked.provisions = 600;
  for (const id of ['elm', 'mill']) S.stations[id].connected = true;
  const st = S.stations.haven;
  /* the ledger steers the round: forty trips walked between Haven and Elm, none to the Mill */
  S.traffic = { 'elm:haven': 40 };
  st.parcels = [];
  for (let i = 0; i < 40; i++) Economy.packParcel('haven');
  const toElm = st.parcels.filter(p => p.to === 'elm').length, toMill = st.parcels.filter(p => p.to === 'mill').length, addressed = st.parcels.every(p => p.to !== 'haven' && S.stations[p.to].connected && p.kind && p.name);
  /* one run per door, carrying what is addressed there */
  st.parcels = [{ to: 'elm', kind: 'coat', name: 'a mended coat' }, { to: 'elm', kind: 'preserves', name: 'a jar of preserves' }, { to: 'mill', kind: 'shoes', name: 'a child\'s shoes' }];
  S.orders.active = [];
  const runs = Economy.ordersFor('haven').filter(o => o.item === 'parcel');
  const two = runs.length === 2, elmRun = runs.find(o => o.to === 'elm'), millRun = runs.find(o => o.to === 'mill');
  const perDoor = elmRun && elmRun.n === 2 && elmRun.id === 'pc_haven_elm' && millRun && millRun.n === 1 && millRun.id === 'pc_haven_mill';
  /* the board names what is addressed */
  WL.tp('haven'); UI.openStation('haven'); UI.gotoTab('orders');
  const card = [...document.querySelectorAll('#stationBody .orderCard')].find(x => /PARCEL POST/.test(x.textContent) && /Elm Farm/.test(x.textContent));
  const named = !!card && /Addressed to Elm Farm/.test(card.textContent) && /a mended coat, a jar of preserves/.test(card.textContent);
  document.getElementById('stationClose').click();
  /* accepted, the shelf keeps what is addressed elsewhere */
  Systems.acceptOrder(elmRun, false);
  const kept = st.parcels.length === 1 && st.parcels[0].to === 'mill', carried = S.cargo.filter(c => c.defId === 'parcel').length;
  const still = Economy.ordersFor('haven').filter(o => o.item === 'parcel').map(o => o.to).join() === 'mill';
  /* the keeper's line */
  const line = Economy.parcelLine({ to: 'elm', kind: 'coat', name: 'a mended coat' }, 'elm');
  const lineWhole = line.startsWith('a mended coat — ') && line.includes(DATA.keepers.elm.name) && line.includes('Elm Farm');
  /* delivered: opened at the terminal, read aloud on the slip */
  WL.tp('elm'); WL.instantPar();
  const { results } = Systems.handleDelivery('elm');
  const res = results.find(x => x.order.item === 'parcel');
  UI.queueResults(results.slice(), null);   // the slip, as the handover shows it
  const readAloud = !!res && res.parcels && res.parcels.length === 2 && res.parcels.every(l => l.includes(DATA.keepers.elm.name));
  return { toElm, toMill, addressed, two, perDoor, named, kept, carried, still, lineWhole, readAloud };
});
await page.waitForTimeout(900);
{
  const r2 = await ev(() => {
    const slip = !document.getElementById('results').classList.contains('hidden') && document.querySelectorAll('#scoreRows .letter').length === 2 && /Opened at the terminal/.test(document.getElementById('scoreRows').textContent);
    UI.closeAllModals();
    /* an older save's count becomes a list — derived, never dropped */
    const st = S.stations.haven; st.parcels = 2;
    const migrated = Economy.parcelsOf('haven'), derived = Array.isArray(migrated) && migrated.length === 2 && migrated.every(p => p.to && p.kind);
    WL.tp([DATA.stations.haven.x, DATA.stations.haven.y + 60]);
    return { slip, derived };
  });
  Object.assign(r, r2);
}
ok('THE PARCELS ADDRESSED: the round packs for the doors the town\'s own traffic runs to (forty trips walked to Elm and none to the Mill: the parcels follow); one run per door carrying what is addressed there, the board naming the parcels; accepted, the shelf keeps what is addressed elsewhere and the other run stands; the keeper\'s line names them; delivered, every parcel is opened and read aloud on the slip; an older count is derived into a list',
  r.toElm > r.toMill * 4 && r.addressed && r.two && r.perDoor && r.named && r.kept && r.carried === 2 && r.still && r.lineWhole && r.readAloud && r.slip && r.derived, JSON.stringify(r));

/* ================= 3 · THE PIP IS A DOOR ================= */
r = await ev(() => {
  for (const n of S.npcs.filter(x => x.state === 'companion')) n.state = 'pool';
  const a = NPC.gen({ at: 'haven' }); a.feeWaived = true; S.npcs.push(a); NPC.hire(a, 'companion');
  S.dir = 0; a.cx = S.px - 42; a.cy = S.py;
  S.time += 1; for (let i = 0; i < 90; i++) UI.tick();
  const pip = document.querySelector('#compassInner .cBack');
  const door = !!pip && pip.dataset.npc === String(a.id) && /click: their plate/.test(pip.title) && getComputedStyle(pip).pointerEvents === 'auto' && getComputedStyle(pip).cursor === 'pointer';
  pip.dispatchEvent(new MouseEvent('click', { bubbles: true }));
  const opened = !document.getElementById('musterOv').classList.contains('hidden');
  const plate = opened && document.getElementById('musterOv').textContent.includes(a.name);
  MusterUI.close();
  /* with a sheet open the pip does nothing */
  RepublicUI.open();
  S.time += 1; for (let i = 0; i < 3; i++) UI.tick();
  const pip2 = document.querySelector('#compassInner .cBack'); if (pip2) pip2.dispatchEvent(new MouseEvent('click', { bubbles: true }));
  const stayed = document.getElementById('musterOv').classList.contains('hidden');
  RepublicUI.close();
  a.state = 'pool';
  return { door, opened, plate, stayed };
});
ok('THE PIP IS A DOOR: a back\'s pip on the rear rail carries their id, takes the pointer, and a click opens the muster roll on their plate; with another sheet open the click does nothing', r.door && r.opened && r.plate && r.stayed, JSON.stringify(r));

/* ================= 4 · THE SQUARE STANDS ITS OWN ================= */
r = await ev(() => {
  for (const k of Object.keys(REP.EVENTS)) S.rep.evCd[k] = 99999;
  S.banked.metal = 900; S.banked.wood = 300; S.banked.provisions = 500; S.banked.ceramic = 120;
  for (const id of ['elm', 'mill', 'green', 'quarry']) S.stations[id].connected = true;
  Republic.tick(0.01); for (const k of Object.keys(REP.EVENTS)) S.rep.evCd[k] = 99999;
  Republic.fundMountain(); Republic.mountain().t = REP.MOUNTAIN.dur + 1; Republic.tick(0.6);
  const mr = Math.random;
  Republic.rebellionStrike('mill'); S.stations.mill.likesTo = 55;
  const funded = Republic.fundStorm('mill'); const q = Republic.quell(); Math.random = () => 0.9; q.t = q.dur + 1; Republic.tick(0.02); Math.random = mr;
  const h = Republic.held().mill, R = REP.DOCTRINE.storm.rise, D = REP.DOCTRINE.storm;
  const held = !!h, own0 = Republic.ownOf('mill');
  /* the town comes round: at forty likes its own walk in, one every recruitEvery */
  S.stations.mill.likesTo = 45; S.stations.mill.stock.food = 200;
  const T2 = DATA.T, day0 = Math.floor(S.time / T2.dayLen) * T2.dayLen; S.time = day0 + T2.dayLen * 0.2;
  const run = secs => { Math.random = () => 0.9; for (let i = 0; i < secs * 2; i++) { Republic.tick(0.5); S.time += 0.5; } Math.random = mr; };
  run(R.recruitEvery * 0.5); const early = Republic.ownOf('mill');
  run(R.recruitEvery * 0.5 + 1); const one = Republic.ownOf('mill');
  const mail = S.mails.find(m => /stands its own/.test(m.subj)), lesson = !!S.flags.tut.firstOwn;
  run(R.recruitEvery + 1); const two = Republic.ownOf('mill');
  run(R.recruitEvery + 1); const capped = Republic.ownOf('mill');
  const ate = h.ate;   // the tithe counts the mountain's shields only — the town's own eat at their own tables
  const ateOnly = ate === Math.floor((R.recruitEvery * 3 + 3 + R.recruitEvery * 0.5) / D.tithePeriod) * D.titheAmt || ate <= Math.ceil((R.recruitEvery * 3.5 + 3) / D.tithePeriod) * D.titheAmt;
  /* the square does not rise while its own stand in it: two Farkeep shields + two of the town's own is not thin */
  h.shields = 2;
  const notThin = !Republic.squareRestless('mill');
  RepublicUI.open(); let html = document.getElementById('repBody').innerHTML; RepublicUI.close();
  const row = /2 of the town's own/.test(html) && /no tithe/.test(html);
  /* the love falls: below thirty the town's own go home; at three the square is restless again */
  S.stations.mill.likesTo = 20; run(1); const home = Republic.ownOf('mill') === 0 && /go home/.test(document.getElementById('toasts').textContent);
  S.stations.mill.likesTo = 3; const restless = Republic.squareRestless('mill');
  /* and RELEASE takes the town's own with the garrison */
  S.stations.mill.likesTo = 45; run(R.recruitEvery + 1); const back = Republic.ownOf('mill') === 1;
  Republic.release('mill'); const gone = Republic.ownOf('mill') === 0 && !Republic.isHeld('mill');
  return { funded, held, own0, early, one, mail: !!mail, lesson, two, capped, ate, ateOnly, notThin, row, home, restless, back, gone };
});
ok('THE SQUARE STANDS ITS OWN: a garrisoned town brought back to forty likes sends its own under the pennant — none before the first four minutes, one after, two after the next, two at most (the mail, the lesson); the tithe stays the mountain\'s shields\' alone; two Farkeep shields with two of the town\'s own is not a thin garrison (the sheet says so); the love below thirty sends them home, at three the square is restless again; back above the line they return, and RELEASE takes them with the garrison',
  r.funded && r.held && r.own0 === 0 && r.early === 0 && r.one === 1 && r.mail && r.lesson && r.two === 2 && r.capped === 2 && r.ateOnly && r.notThin && r.row && r.home && r.restless && r.back && r.gone, JSON.stringify(r));

/* ================= 5 · THE CAMPS' OWN ON THE ROAD ================= */
r = await ev(() => {
  for (const n of S.npcs.filter(x => x.state === 'companion')) n.state = 'pool';
  const ridge = DATA.camps.find(c => c.id === 'ridge'), pass = DATA.camps.find(c => c.id === 'pass');
  for (const cd of [ridge, pass]) { const c = S.camps[cd.id]; c.runners = []; c.culled = 0; c.swept = 0; }
  const T2 = DATA.T, day0 = Math.floor(S.time / T2.dayLen) * T2.dayLen; S.time = day0 + T2.dayLen * 0.3;
  WL.tp([DATA.stations.haven.x, DATA.stations.haven.y + 60]); S.room = null;
  Systems.update(0.25, {});
  const ridgeRoll = S.camps.ridge.runners.map(x => x.cls).join(), passRoll = S.camps.pass.runners.map(x => x.cls).join();
  /* the bowman's shot: inside the ring with a crate on your back, inside his range and outside his reach */
  const crate = State.makeItem('food'); State.addCargo(crate);
  const bow = S.camps.ridge.runners.find(x => x.cls === 'bowman'), ramR = S.camps.ridge.runners.find(x => x.cls === 'ram');
  for (const x of S.camps.ridge.runners) { x.cd = 0; x.shotCd = 0; }
  WL.tp([ridge.x + 200, ridge.y]); S.room = null; S.state = 'walk'; S.inside = null;
  bow.x = S.px + 150; bow.y = S.py; ramR.x = ridge.x - 300; ramR.y = ridge.y - 300; S.camps.ridge.runners[2].x = ridge.x + 300; S.camps.ridge.runners[2].y = ridge.y + 300;
  const hp0 = S.health; S.stagger = 0;
  Systems.update(0.05, {});
  const shot = bow.shotCd > 0 && S.stagger > 0 && S.health === hp0 - FACT.CAMP_CLASSES.bowman.stats.roadDmg, lesson = !!S.flags.tut.firstTrades;
  const cdBefore = bow.shotCd;
  Systems.update(0.05, {});
  const oneArrow = Math.abs(S.health - (hp0 - FACT.CAMP_CLASSES.bowman.stats.roadDmg)) < 0.5 && bow.shotCd < cdBefore;
  /* the ram shrugs the first blow — a back meets him, he is up again in a second; the second puts him down */
  const a = NPC.gen({ at: 'haven' }); a.feeWaived = true; S.npcs.push(a); NPC.hire(a, 'companion');
  a.cx = S.px; a.cy = S.py; a.shoveCd = 0; a.hungry = false;
  bow.x = ridge.x - 350; bow.y = ridge.y + 300; bow.cd = 30;
  ramR.x = S.px + 10; ramR.y = S.py; ramR.cd = 0; ramR.hits = 0;
  const met0 = NPC.svc(a).met, hp1 = S.health;
  Systems.update(0.05, {});
  const shrug = ramR.hits === 1 && ramR.cd > 0 && ramR.cd < 1.5 && NPC.svc(a).met === met0 + 1 && Math.abs(S.health - hp1) < 0.5;
  ramR.cd = 0; a.shoveCd = 0; ramR.x = S.px + 10; ramR.y = S.py;
  Systems.update(0.05, {});
  const down = ramR.hits === 0 && ramR.cd >= 4;
  /* a ram's walk is slower than a knife's */
  const kn = S.camps.ridge.runners[2]; kn.cd = 0; ramR.cd = 0; ramR.hits = 0; a.shoveCd = 99;
  kn.x = S.px + 400; kn.y = S.py + 40; ramR.x = S.px + 400; ramR.y = S.py - 40;
  const kx0 = kn.x, rx0 = ramR.x;
  Systems.update(0.2, {});
  const slower = (kx0 - kn.x) > (rx0 - ramR.x) * 1.15 && (rx0 - ramR.x) > 0;
  State.removeCargo(crate.id); a.state = 'pool';
  for (const x of S.camps.ridge.runners) x.cd = 30;
  WL.tp([DATA.stations.haven.x, DATA.stations.haven.y + 60]);
  return { ridgeRoll, passRoll, shot, lesson, oneArrow, shrug, down, slower };
});
ok('THE CAMPS\' OWN ON THE ROAD: the runners spawn by the camp\'s roll (Ridge: bowman, ram, knife; Pass: two knives — the chief keeps the fire); a bowman looses inside his range — the arrow staggers and cuts, once per cooldown (the lesson); a ram shrugs the first shove and is up again in a second, the second puts him down; his walk is slower than a knife\'s',
  r.ridgeRoll === 'bowman,ram,knife' && r.passRoll === 'knife,knife' && r.shot && r.lesson && r.oneArrow && r.shrug && r.down && r.slower, JSON.stringify(r));

/* ================= 6 · THE STORM WITH THE CAMPS' OWN ================= */
r = await ev(() => new Promise(res => setTimeout(() => res(), 1200))).then(() => ev(() => {
  const cd = DATA.camps.find(c => c.id === 'ash'), W = REP.WATCHPOST.storm, K = W.seen, C = FACT.CAMP_CLASSES, mr = Math.random;
  for (const k of Object.keys(REP.EVENTS)) S.rep.evCd[k] = 99999;
  S.banked.metal = 900; S.banked.wood = 300; S.banked.provisions = 500;
  const funded = Republic.fundTake(cd.id); const q = Republic.quell(); Math.random = () => 0.9; q.t = q.dur + 1; Republic.tick(0.02); Math.random = mr;
  const c = S.camps[cd.id]; const taken = !!c.taken; c.taken.shields = 2; c.runners = [];
  for (const n of S.npcs.filter(x => x.state === 'companion')) n.state = 'pool';
  WL.tp([cd.x + 170, cd.y + 170]); S.room = null;
  document.getElementById('toasts').innerHTML = '';
  const started = Republic.stormPost(cd) === true && !!c.storm;
  const s2 = c.storm, kinds = s2.knives.map(k => k.cls).join();
  const toast = /chief is with them/.test(document.getElementById('toasts').textContent), lesson = !!S.flags.tut.firstTrades;
  const chief = s2.knives.find(k => k.cls === 'chief'), bow = s2.knives.find(k => k.cls === 'bowman'), ram = s2.knives.find(k => k.cls === 'ram');
  /* the bowman stands off at his range and looses: an arm pinned, the shields' cadence halved */
  bow.x = cd.x + C.bowman.stats.range - 10; bow.y = cd.y; bow.cd = 0; bow.shotCd = 0.01;
  chief.x = cd.x - 600; chief.y = cd.y; ram.x = cd.x + 600; ram.y = cd.y; chief.cd = 0; ram.cd = 0;
  Republic.tick(0.02);
  const standsOff = Math.abs(U.dist(bow.x, bow.y, cd.x, cd.y) - (C.bowman.stats.range - 10)) < 3 && bow.shots === 1 && s2.pinned > C.bowman.stats.pin - 0.1;
  ram.x = cd.x + 30; ram.y = cd.y; ram.cd = 0; ram.hits = 0; s2.shieldT = 0.01;
  Republic.tick(0.02);
  const pinnedCadence = Math.abs(s2.shieldT - K.shieldCd / 1) < 0.05;   // one arm of two swings
  /* the ram shrugged that knock: staggered, up in a second — and the chief stands, so the next full knock is halved */
  const shrug = ram.hits === 1 && ram.cd > 0 && ram.cd < 1.5 && ram.downs === 1;
  ram.cd = 0; ram.x = cd.x + 30; ram.y = cd.y; s2.shieldT = 0.01; s2.pinned = 0;
  Republic.tick(0.02);
  const rallied = ram.hits === 0 && Math.abs(ram.cd - K.downFor * C.chief.stats.rally) < 0.05;
  /* the chief walks slower than the knife's pace and, knocked, BREAKS the storm: the knives run, the storm runs out HELD */
  chief.x = cd.x - 400; chief.y = cd.y; chief.cd = 0;
  const cx0 = chief.x; Republic.tick(1.0); const chiefPace = Math.abs((chief.x - cx0) - K.knifeSpeed * C.chief.stats.speed) < 2;
  chief.x = cd.x + 30; chief.y = cd.y; chief.cd = 0; s2.shieldT = 0.01; s2.pinned = 0;
  document.getElementById('toasts').innerHTML = '';
  Republic.tick(0.02);
  const broke = s2.broke === true && chief.cd > 0 && s2.dur <= s2.t + K.runOut + 0.01 && /chief is down/i.test(document.getElementById('toasts').textContent);
  ram.cd = 0; bow.cd = 0; const rd0 = U.dist(ram.x, ram.y, cd.x, cd.y), bd0 = U.dist(bow.x, bow.y, cd.x, cd.y);
  Republic.tick(1.0);
  const ran = U.dist(ram.x, ram.y, cd.x, cd.y) > rd0 + 60 && U.dist(bow.x, bow.y, cd.x, cd.y) > bd0 + 60;
  Math.random = () => 0.9; for (let i = 0; i < 12; i++) Republic.tick(0.5); Math.random = mr;
  const heldBroke = !c.storm && !!c.taken && S.mails[0] && /the post HELD — you stood it/.test(S.mails[0].subj) && /the knives saw it and ran/.test(S.mails[0].body);
  /* and a ram takes a fire FAST: the second storm is lost at six-tenths of the wait */
  const again = Republic.stormPost(cd) === true && !!c.storm;
  const s3 = c.storm, ram2 = s3.knives.find(k => k.cls === 'ram'), ch2 = s3.knives.find(k => k.cls === 'chief');
  const mourned = !ch2 && Republic.chiefGone(cd);   // v3.42: the chief who went down in the open does not come to the next storm
  for (const k of s3.knives) if (k !== ram2) { k.x = cd.x - 600; k.y = cd.y; }
  ram2.x = cd.x; ram2.y = cd.y; ram2.cd = 0; ram2.atFire = K.takeAfter * C.ram.stats.takeMul - 0.01;
  Math.random = () => 0.9; Republic.tick(0.02); Math.random = mr;
  const fast = !c.taken && !c.storm && !!c.lost;
  WL.tp([DATA.stations.haven.x, DATA.stations.haven.y + 60]);
  return { funded, taken, started, kinds, toast, lesson, standsOff, pinnedCadence, shrug, rallied, chiefPace, broke, ran, heldBroke, again, mourned, fast };
}));
ok('THE STORM WITH THE CAMPS\' OWN: Ash Camp brings its chief, its bowman and its ram (the toast names the chief, the lesson); the bowman stands off at his range and looses — an arm pinned, one shield of two swinging on the full cadence; the ram shrugs the first knock and, with the chief standing, goes down for half the span on the second; the chief walks at his own pace and, knocked, BREAKS the storm — the knives run for the grey and the post is HELD with the mail saying so; a second storm comes without the mourned chief (v3.42) and is LOST to the ram at six-tenths of the wait',
  r.funded && r.taken && r.started && r.kinds === 'chief,bowman,ram' && r.toast && r.lesson && r.standsOff && r.pinnedCadence && r.shrug && r.rallied && r.chiefPace && r.broke && r.ran && r.heldBroke && r.again && r.mourned && r.fast, JSON.stringify(r));

/* ================= 7 · THE COUNT BOUGHT ================= */
r = await ev(() => {
  const cd = DATA.camps.find(c => c.id === 'pass'), c = S.camps[cd.id], E = REP.EVENTS.bunkerSweep, SL = E.sell, mr = Math.random;
  for (const k of Object.keys(REP.EVENTS)) S.rep.evCd[k] = 99999;
  if (!S.exile) Exile.tick(0.01);
  c.taken = null; c.pacified = false; c.runners = []; c.swept = 0; c.sold = 0;
  S.exile.door = 'hidden';
  const shut = !Republic.canBuyCount(cd.id).ok && /cold door/.test(Republic.canBuyCount(cd.id).line);
  S.exile.door = 'opened';
  const uncounted = !Republic.canBuyCount(cd.id).ok && /stencil/.test(Republic.canBuyCount(cd.id).line);
  Republic.fireEvent('bunkerSweep', cd);
  const counted = Republic.canBuyCount(cd.id).ok;
  /* the sheet offers it */
  RepublicUI.open(); let html = document.getElementById('repBody').innerHTML; const btn = document.querySelector(`#repBody [data-buy="${cd.id}"]`); const offered = !!btn && !btn.disabled && /BUY THE COUNT/.test(btn.textContent); RepublicUI.close();
  /* the price */
  S.banked.metal = 10; S.banked.ceramic = 0; document.getElementById('toasts').innerHTML = '';
  const poor = Republic.buyCount(cd.id) === false && /banked/.test(document.getElementById('toasts').textContent) && !c.taken;
  S.banked.metal = 200; S.banked.ceramic = 60;
  const near = (() => { let bId = 'haven', bd = 1e9; for (const id of DATA.stationOrder) { const d = U.dist(cd.x, cd.y, DATA.stations[id].x, DATA.stations[id].y); if (d < bd) { bd = d; bId = id; } } return bId; })();
  const likes0 = S.stations[near].likesTo, relDW = Republic.rel('diefenbunker', 'waylight');
  const bought = Republic.buyCount(cd.id) === true;
  const paid = S.banked.metal === 200 - SL.cost.metal && S.banked.ceramic === 60 - SL.cost.ceramic;
  const post = !!c.taken && c.taken.via === 'society' && c.taken.shields === SL.shields && c.pacified && c.runners.length === 0 && c.sold > 0;
  const relUp = Republic.rel('diefenbunker', 'waylight') === relDW + 1, likesUp = S.stations[near].likesTo > likes0;
  const mail = S.mails[0] && /The count bought/.test(S.mails[0].subj) && S.mails[0].body.includes(cd.name), lesson = !!S.flags.tut.firstSold, title = !!(Render.crtActive && Render.crtActive());
  const noSeason = !Republic.reprisal() || Republic.reprisal().camp !== cd.id;
  const once = !Republic.canBuyCount(cd.id).ok;
  RepublicUI.open(); html = document.getElementById('repBody').innerHTML; RepublicUI.close();
  const plate = /SOLD BY THE SOCIETY/.test(html) && /THE REPUBLIC — WATCHPOST/.test(html);
  const ledger = Republic.relations().some(x => x.a === 'diefenbunker' && x.b === 'waylight' && /count bought/.test(x.why || ''));
  return { shut, uncounted, counted, offered, poor, bought, paid, post, relUp, likesUp, mail: !!mail, lesson, title, noSeason, once, plate, ledger };
});
ok('THE COUNT BOUGHT: the Society sells only through an open door and only what it counted (the gates say which); the sheet offers BUY THE COUNT on a counted camp; short of the price the buy refuses; paid, the camp is a watchpost by contract — two shields, the runners gone north, SOLD on the camp — the Society a step warmer with the Order on the ledger (the reason written), the nearest town easier, the mail, the lesson, the title, no season of reprisal; sold once, not for sale again; the sheet\'s plate',
  r.shut && r.uncounted && r.counted && r.offered && r.poor && r.bought && r.paid && r.post && r.relUp && r.likesUp && r.mail && r.lesson && r.title && r.noSeason && r.once && r.plate && r.ledger, JSON.stringify(r));

/* ================= 8 · THE SAVE ================= */
r = await ev(() => {
  const mr = Math.random;
  Republic.rebellionStrike('mill'); S.stations.mill.likesTo = 55;
  Republic.fundStorm('mill'); const q = Republic.quell(); Math.random = () => 0.9; q.t = q.dur + 1; Republic.tick(0.02); Math.random = mr;
  Republic.recruitOwn('mill'); Republic.recruitOwn('mill');   // v3.42: the town's own are records on the roll
  S.stations.haven.parcels = [{ to: 'elm', kind: 'coat', name: 'a mended coat' }];
  S.traffic = { 'elm:haven': 7 };
  const soldAt = S.camps.pass.sold;
  State.save();
  S.npcs = S.npcs.filter(n => n.state !== 'square'); S.stations.haven.parcels = []; S.traffic = {}; S.camps.pass.sold = 0; S.camps.ridge.runners = [];
  State.load();
  const own = Republic.ownOf('mill') === 2, shelf = S.stations.haven.parcels.length === 1 && S.stations.haven.parcels[0].to === 'elm', traffic = S.traffic['elm:haven'] === 7;
  const sold = S.camps.pass.sold === soldAt && S.camps.pass.taken && S.camps.pass.taken.via === 'society';
  Systems.update(0.25, {});
  const ridge = S.camps.ridge.runners.map(x => x.cls).join() === 'bowman,ram,knife';
  return { own, shelf, traffic, sold, ridge };
});
ok('THE SAVE: the town\'s own under a garrison, a town\'s addressed shelf, the traffic ledger and a camp\'s sale survive a save and load; the road\'s runners come back by the camp\'s roll', r.own && r.shelf && r.traffic && r.sold && r.ridge, JSON.stringify(r));

ok('no page errors across the camps\' own', errors.length === 0, errors.slice(0, 3).join(' | '));
console.log(results.join('\n'));
console.log(`${results.filter(x => x.startsWith('PASS')).length}/${results.length} checks passed`);
await b.close();
