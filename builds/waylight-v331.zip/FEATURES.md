# WAYLIGHT — MASTER FEATURE LIST
Compiled from every MIVIM request across development: the ADDITIONS REQUEST LOG, the post-testing
notes, the faction/diplomacy notes, and every mid-turn order. Each line carries its status:
**SHIPPED (vX)** — live in the build, covered by the test battery · **ROADMAP (vX)** — scheduled,
designed · **OPEN** — requested, not yet scheduled into a version. Current build: v3.30, 524 automated checks green across thirty-four suites — the shop audit standing among them (three legacy probes run beside the battery error-free).

## 1 · Delivery satisfaction & mission clarity
- DELIVER button/prompt when in range — the reward phase is a held moment, not an auto-vanish: gold DELIVER prompt, two-click hand-over, crate-hop animation, grade stamp slam, keeper voice on the slip — **SHIPPED (v3.7–v3.13)**
- Mission items always readable as mission items — THE LAW: gold band + gold text everywhere (tray, board, world drops, the pack itself; band row injected on every cargo glyph) — **SHIPPED (v3.13, extended v3.19)**
- Icons for every item, before the title, correctly sourced — authored pixel icon set on all rows — **SHIPPED (v3.15)**
- Icon colour-coding toggle (consumables green / gear blue / junk grey; mission gold immune to the toggle) — settings checkbox `iconColor` — **SHIPPED (v3.15)**
- Folder only on the active tab, animation plays once on select — **SHIPPED (v3.15)**
- Vitals order: hearts, stamina, load, food — **SHIPPED (v3.15)**
- Earn notifications for ALL currencies with icons, animated (trust diamond, per-town hearth-heart, material crate; Renegade bandana seated) — merge-and-count-up chips beside the trust readout — **SHIPPED (v3.20)**

## 2 · Visual identity
- Authored pixel art everywhere; kill the grid-overlay patches and blur — player rig redrawn (12×18 authored texels, cutout rig), NPC figures, structures, icon set — **SHIPPED (v3.15–v3.17)**; remaining older sprites queued for the PixelLab pass — **OPEN (asset pass)**
- The phasing screen-wide line distortions — root-caused (fractional buffer scale) and fixed with the exact 3× world buffer + snapped camera — **SHIPPED (v3.15)**
- Cargo visuals on the player: complete authored overhaul — 11-glyph cargo table, duffel for smalls, equipped frame drawn holding the tower, worn coat/boots recolour the rig — **SHIPPED (v3.19)**
- Player visually sees progression on the character (gear, pack, snow, wear) — **SHIPPED (v3.19)**; more gear stages ride future versions — **ROADMAP (v3.22+)**
- PixelLab MCP — integration SHIPPED (v3.20), then **SHELVED by directive (v3.23)**: the current aesthetic is the identity; polish it with the audited research on every source touch

## 3 · The world is ALIVE through interaction (never effect-spam)
- Leaves on the wind: gust puts leaves in motion; hit the model → deflect or stick a beat; miss → never change trajectory; sparse by law — **SHIPPED (v3.19)**
- Snow accumulation: piles on hood/shoulders by intensity and stillness, sheds with work, melts in warmth; falls as flakes in the north, never "more raindrops" — **SHIPPED (v3.19)**
- No screen-shake/motion-blur dependence; particles sparse and eloquent — standing law — **SHIPPED**
- Footprints/splashes stamped by the feet — **SHIPPED (v3.15)**
- Living-changing land: traffic wears foot paths between towns; player steps accelerate; staged permanent wear; paths guide NPCs and players and grant speed — **SHIPPED (v3.20)**

## 4 · Placement & building
- Blueprint ghosts for ALL placeables — semi-transparent, exact pose, honest validity + why; click/E lays, Esc folds away; far click past an invalid ghost walks instead of trapping the mouse — **SHIPPED (v3.19)**
- Move built objects — V re-hangs an owned structure as a free blueprint, exact re-seat — **SHIPPED (v3.19)**
- Destroy built objects — X takes down: ladders fold back onto the pack, structures refund 60% metal — **SHIPPED (v3.19)**
- Builds must FEEL useful, not required; cheap first upgrades; fully-upgraded feels earned — two-tier ladders on generator/watchtower/shelter/zipline, gold pips, U to raise — **SHIPPED (v3.21)**
- Enterable room-sized buildings (safety priced accordingly) — the tier-2 room, the tier-3 bed — **SHIPPED (v3.21)**
- POBoxes: cheap drop/donate caches — stash/take/leave-for-the-walkers — **SHIPPED (v3.21)**
- Donation visibility: donated hand tools arm a walker; ten armed = camps shrink and slow, armed watch patrols, the town TELLS you — **SHIPPED (v3.21)**
- Defensive structures that actually act — the horn tower calls out and slows pursuers, the armed post knocks them sprawling — **SHIPPED (v3.21)**

## 5 · Automation, not idle
- Chain movement from map and world (shift-click strung routes, click-to-travel, pathfound legs) — **SHIPPED (v3.2, v3.14)**
- Wobble as EARNED pushback: calm ground at sane load never rings; Balance-per-terrain auto-steadies silently; rings only past the kit; stumbles never cancel the chain — **SHIPPED (v3.19)**
- Keep-walking-when-hidden toggle for long trips — background clock, always auto-steadies, clean handback — **SHIPPED (v3.19)**
- Multiple viable automation kits (ladders vs bridges vs ziplines vs horse vs roads vs paved trails vs caravans) — **SHIPPED (cumulative; deepens each version)**
- Companions never a burden: stuck escorts self-heal to your back; companions catch up on their own — **SHIPPED (v3.19)**

## 6 · Letters, the post, and appreciation
- Letters are the Order's SERVICE — never cash; appreciation + porter XP only; all other goods are luxury and pay — **SHIPPED (v3.16, standing law)**
- Letter tiers by distance/danger/darkness (LOCAL/LONG/GREY POST), mailbag fills with time — **SHIPPED (v3.16)**
- Appreciation as its own per-town ladder (KNOWN/TRUSTED/HONOURED/BELOVED) with creative non-cash rewards — warm meals, salvage tips, town lamp, waived wages — **SHIPPED (v3.16)**
- Militia rescue passive behind an earned quest (riders gallop in, clear the chase or die trying, 5-minute cooldown) — **SHIPPED (v3.16)**; identity transfers to FARKEEPERS — **ROADMAP (v3.22, lore correction)**
- Inner-city NPC hiring: post jobs tied to skills (runner/parcels/tower/night/hearth/sort-mend), wages, XP per shift, same people field as companions — **SHIPPED (v3.16)**
- Job management: assign, change round, relieve, take as companion, inventory hand-over — **SHIPPED (v3.16)**

## 7 · The working world (field automation)
- Field crews from the Waylighters tab (3 per town, provision wages, stall honest): — **SHIPPED (v3.20)**
  - PATH PRESSER — wears custom trails in along assigned routes — **SHIPPED (v3.20)**; press player-clicked custom routes — **OPEN (v3.21 candidate)**
  - MASON — lays cobblestone along the route, a slab a stretch — **SHIPPED (v3.20)**
  - FORRESTER — fells real trees (map changes permanently, stumps stay), banks timber — **SHIPPED (v3.20)**
  - HAULER — walks real stock between towns; Hauling 5 upgrades to DONKEY CARAVAN (30 crates, drawn donkey) — **SHIPPED (v3.20)**; caravan protection contracts (Farkeepers) — **ROADMAP (v3.22)**
- Path upgrade ladder: footpath → scrap plates → cobblestone → wood way; per-tier paint/speed/preference; permanent — **SHIPPED (v3.20)**
- Easier logistics than paver-roads-only — the whole trail progression — **SHIPPED (v3.20)**
- LOOTER earner skill: companion sweeps ground cargo entering player vision, reach per Hauling level — **SHIPPED (v3.20)**; full automation (chests, nodes, self-directed hauls home to sell) — **ROADMAP (v3.22+)**

## 8 · Karma & choice (NOT good/bad — the Han Solo law)
- Renegade currency beside Appreciation, independent tiers under the KARMA ledger, its own chip, read in the character sheet — **SHIPPED (v3.22)**
- Highleaf smuggling with legible risk and caught/clean outcomes per place (heat, seizure, smoke in supplied yards) + cutpurse skim jobs — **SHIPPED (v3.22)**; mercenary-guild work (weapon + party gated, Farkeeper combat) — **ROADMAP (v3.23)**
- Consequences SEEN in the world, never text-only — smoke loungers, camp-claim respect, armed-watch eyes in the risk equation — **SHIPPED (v3.22, standing law)**

## 9 · Factions & diplomacy (CK3 / Bannerlord 2 reference)
- THE REPUBLIC OF CONNECTION (Waylight + Farkeep; famine, descent, merger) — the banner, the founding letter, the arrival milestone — **SHIPPED (v3.22)**
- Lore correction: ALL security/battle purpose transferred to FARKEEPERS in every player-facing string; the militia riders are Farkeeper riders, retroactively — **SHIPPED (v3.22)**
- Farkeepers: larger fiercely-loyal mountain people (NOT giants), drawn taller/wider in iron and pale; WARDS hireable (heavy intercept); quell/take-by-force doctrine in faction culture — **SHIPPED (v3.22)**; rebellion/taking-towns systems — **ROADMAP (v3.23+)**
- Diplomacy defaults (ABSOLUTE_ALLY Waylight/Farkeep · ABSOLUTE_HOSTILE Reapers/Cannibals) + karma-driven raider disposition — **SHIPPED (v3.22)**; full stance play — **ROADMAP (v3.23+)**
- Faction data: REAPERS, RAIDERS, REBELS, CANNIBALS, FLAME KEEPERS, IRON GIANTS — each with culture + palette — **SHIPPED (v3.22, data + doc)**
- Farkeeper classes: PUGUGLY live as the ward; LONGBOWMEN/RIFLE_RIDER/RECON_RIDER/BERSERKER as class data — **SHIPPED (v3.22, pugugly playable)**; full combat kit — **ROADMAP (v3.23)**
- Horse breed data — five real breeds, per-stable, speed/spook/drain applied in play — **SHIPPED (v3.22)**
- Expansion door open: the mountain to Farkeep, the Farlands beyond — **ROADMAP (post-v3.22)**

## 10 · Progression & pacing
- Mechanics introduced early and linearly; early movement mechanic signals the game has more than one speed; other actors visibly operate (route porters, field crews, militia, convoys, echo builders) — **SHIPPED (cumulative; v3.14 progression pass + v3.16–v3.20 world actors)**
- Nothing feels like filler: needs economy prices every delivery; letters carry the service identity; circuits/convoys/salvage diversify the work — **SHIPPED (v3.0, v3.16, v3.18)**
- Price/pace balance under continued review — greedy-bot balance law stands — **SHIPPED (standing, session bot)**
- World reset separate from New Waylighter, with explaining confirm — **SHIPPED (v3.16)**

## 11 · The myth & the character (v3.23)
- The Postman spirit through gameplay: legend tiers, record-cited bystander lines, stopped yards, keeper hello prefixes, children running the fences — **SHIPPED (v3.23)**
- Micro-cutscenes capped at one slow zoom + first line, skippable, sim never pauses — **SHIPPED (v3.23)**
- THE HANDOFF parody (slow-mo, three cuts, SUPER ZOOM, freeze-frame stamp, once per town) — **SHIPPED (v3.23)**
- Character investment suite: appearance creation on a live rig, the tailor editor, the equip-sheet paperdoll (inventory already live) — **SHIPPED (v3.23)**
- Idle breath by shading drift on uneven cadence (audited research applied) — **SHIPPED (v3.23)**
- Framing the mysterious protagonist (origin fragments, the overworld-knowledge angle) — **ROADMAP**

## 11b · The wider world & the production (v3.24)
- THE CINE ENGINE: reusable shot-list scene player (CUT/PUSH/DOLLY/VEER/HOLD, world slow-mo under a real camera clock, shared speedline/flash/stamp/vignette primitives, skip-anywhere) — **SHIPPED (v3.24)**
- 90s directing research applied (The Postman's myth beats + displaced violence; Waterworld's intimacy-first) — **SHIPPED (v3.24, research-90s-directing.md)**
- THE RIDE: once-ever firing-squad parody — "THAT'S MY DAD!", "RIDE, WAYLIGHTER!", the veer-out with gunshots HEARD, "THE MAIL GOT OUT." stamp — **SHIPPED (v3.24)**
- THE GLOBE: the valley is ONE REGION — rotatable per-pixel shaded planet (laughably past the texel world: hypsometric land, specular sea, drifting clouds + thrown shadows, night-side city lights, stepped atmosphere, zero gradient calls), valley pin on a coast, four UNCHARTED region pins as recon futureproofing — **SHIPPED (v3.24)**
- Frostpunk-style recon/outpost mission system over the globe's regions — **ROADMAP (the region data shape ships now)**
- Numeric delivery badges: crate ×N per town on the classic map + "N aboard" regional tally on the globe, one counting truth (deliverableCounts) — **SHIPPED (v3.24)**
- Party of four: hire 3 companions (wedge formation, voices in turns, roomiest-back give/take, party-iterated assists) — **SHIPPED (v3.24)**
- Companion horses: rent (loaner) or buy (for good) at any connected town's stable; mounted members hold a mounted pace — **SHIPPED (v3.24)**
- THE POOL: companions absorb lethal blows in quarters (KO → mend at the nearest town, re-hire fee paid in blood); the player character ALWAYS falls last — **SHIPPED (v3.24)**
- THE RESCUE RIDE: highest-appreciation town rides once per cooldown (odds scale with appreciation), rallies the mending party, burns the road clear — or dies trying, and death is real — **SHIPPED (v3.24)**
- THE TOWN LAW: hunger/cold death immunity inside any yard + the mercy meal ("Not in MY yard, walker.") — **SHIPPED (v3.24)**
- Rain remade as water (wash/patter/rumble) with its own persisted volume dial; wraith drone kept and taught to breathe; sfx palette designed (jittered steps, warmer bells, gunshots) — **SHIPPED (v3.24)**

## 11c · The names & the exiles (v3.25)
- Waylight = the capital city (Republic of Connection seat) — menus stop calling the world by it; the land is THE GREYMARCH, the globe header THE KNOWN WORLD — **SHIPPED (v3.25)**
- Globe pins the lore's places: Greymarch (walked) / Waylight (glowing, coastal) / the Farlands (Farkeep) / two uncharted — **SHIPPED (v3.25)**
- Protagonist framed as the scorned hero in micro-cine fragments BEFORE any mechanics (the dark walked too easily; the name "Lamplighter" dropped once) — **SHIPPED (v3.25)**
- THE LAMPLIGHTER arc: once-ever ridge rescue (cornered lane + the fall lane when no town qualifies), the raised-tongue stranger, kit handoff — **SHIPPED (v3.25)**
- Lamplighter class (world-gated in chargen): sniper identity, +6 kg exile back, spawns with C14 + 6 rounds; rifle never carries to non-exile successors — **SHIPPED (v3.25)**
- Precision fire on the karma ledger: warning crack (clean) vs the shot that connects (+renegade, +heat); ammo scarce; renegade tier steadies the hand — **SHIPPED (v3.25)**
- Factions: THE LAMPLIGHTER NOMADS (wary) + THE DIEFENBUNKER SOCIETY (unknown; Fallout homage, Canada hinted never said) — **SHIPPED (v3.25)**
- The three SBSN founding logs as styled dossier mail, in order, after first contact — **SHIPPED (v3.25)**
- The Lamplighter Nomads' own city; Diefenbunker as a walkable place; C3A1/C20 as gear tiers; ammo trade lanes — **ROADMAP**

## 11d · The Darklands table (v3.26)
- Scale ladder made honest: THE GREYMARCH → THE DARKLANDS (the developed continental briefing table) → THE KNOWN WORLD (globe demoted to aesthetic farthest-zoom, says so in its caption) — **SHIPPED (v3.26)**
- The table at the reference ANGLE in the game's own aesthetic: tilted contour terrain with relief, dotted land-density field, stippled sea, receding graticule, far coasts beyond the edge, leader-line labels, scale bar + survey stamp — **SHIPPED (v3.26)**
- One truth: continent sampled from the same planet bake as the globe; the Greymarch footprint carries the LIVE game (coverage stipple, station pips, camp rings, the walker's pulse) — **SHIPPED (v3.26)**
- Side columns fed by the real ledger (survey / conditions / trust / karma / deliveries / camps) — **SHIPPED (v3.26)**
- Uncharted region pins ON the table — the recon system's staging ground — **SHIPPED (v3.26; recon itself ROADMAP)**
- Globe atmosphere halo padding fixed (corners empty, glow unclipped — verified by pixel, on record) — **SHIPPED (v3.26)**

## 11e · The ecosystem (v3.27)
- Utilities and works named as TWO THINGS: the Fabricate sheet's two shelves + per-item ↻ loop lines + the loop law at the counter — **SHIPPED (v3.27)**
- Three production works, terrain-sited with honest ghosts: LUMEN STILL (veil-sited, storm-doubled), SAWCAMP (treeline, mutual ×1.25 synergy with a working forrester), CLAY OVEN (wet ground) — **SHIPPED (v3.27)**
- Tier production: armed post's spotter's tithe (metal), the room's drying rack (provisions, meadow-honest) — every banked resource has an automated source — **SHIPPED (v3.27)**
- The loop's honesty: every unit lands as a labeled earn chip; disrepair pauses hands; repair feeds metal back — **SHIPPED (v3.27)**
- [ THE ECOSYSTEM ] ledger block: per-work state/rate/lifetime/mended + the all-time tally, from one truth — **SHIPPED (v3.27)**
- Deeper chains (works consuming works' goods, outpost clusters) — **SHIPPED (v3.28: outposts haul into the same bank)**

## 11f · The watchdog (v3.28a — stability law)
- The step is fault-guarded: sim/myth/frame faults are caught, reported on screen with their own message, and the loop keeps walking — a freeze can no longer be silent — **SHIPPED (v3.28a)**
- The watchdog repairs stuck gates within ~2s: paused-with-no-sheet, station-sheet-with-nobody-home, stranded timeScale/letterbox, zip-with-no-ride, map flag desync, stuck mouse button — **SHIPPED (v3.28a)**
- Modal-list gaps closed: the tailor freezes/blocks like a modal, answers ESC, and closeAllModals tears it down — **SHIPPED (v3.28a)**
- Unknown legacy structure types decay away quietly instead of crashing the sim — **SHIPPED (v3.28a; amended v3.28b: they go to THE ATTIC, never the void)**
- The battery now boots the PLAYER'S page: inputs.mjs runs waylight.html with no debug flag — **SHIPPED (v3.28a, standing)**

## 11g · The dead boot law (v3.28b — the frozen-input report answered at the ROOT)
- ROOT CAUSE FOUND: a save carrying a committed death (written by the death-screen auto-save in any earlier build) booted a ZOMBIE WORLD — sim gated off, click and WASD refused, ESC menu the only living surface. The exact reported symptom, reproduced and extinguished — **SHIPPED (v3.28b)**
- Death is now committed WITH its certificate facts (S.deadInfo) and saved the moment it happens — no alt-F4 resurrection; the Zomboid law with teeth — **SHIPPED (v3.28b)**
- A dead save boots INTO the Certificate of Passage (honest fallback for older saves: "the road took them between saves") → next walker → the valley EXACTLY as left — **SHIPPED (v3.28b)**
- The watchdog presents the ceremony to ANY zombie world it meets within ~2s — **SHIPPED (v3.28b)**
- THE NO-PURGE LAW: the save as it stood is stashed whole in a backup slot before any byte is read; quarantined structures live in THE ATTIC and return the moment a build knows their type again — nothing is ever deleted as fixing — **SHIPPED (v3.28b)**
- FREE MY BOOTS: an ESC-menu release that clears any stuck gate (scenes, rings, sheets, clocks, focus) and deletes nothing, plus a live diagnostic line naming what holds the boots — **SHIPPED (v3.28b)**
- The fault chip: a fault firing every frame pins an on-screen diagnosis the player can read back verbatim — **SHIPPED (v3.28b)**
- deadboot.mjs: 19 checks — commit, dead-boot certificate, fallback, valley continuity, watchdog heal, diag line, release, no-deletion proof, fault chip, attic restore — **SHIPPED (v3.28b, standing)**

## 11h · The frontier (v3.28 — RECON & OUTPOSTS, the Frostpunk law on the Darklands table)
- The uncharted pins are MISSIONS: click a pin, the frontier desk opens on the table (LEDGERLIGHT paper — blurb, costs, the banked line, one gold button) — **SHIPPED (v3.28)**
- FUND THE RECON RIDE (20 metal · 6 provisions, wants a connected stable town): a named Farkeeper rider goes out, drawn LIVE on the table — a white dot walking the survey line, dashed, toward the pin — **SHIPPED (v3.28)**
- The hazard roll at the midpoint (30%): the rider GOES QUIET (+45s, rust label, worried mail) but always comes home — the mountain does not lose riders to weather — **SHIPPED (v3.28)**
- CHARTED reaches take an OUTPOST (40 metal · 20 wood · 12 provisions): PANHOUSE STATION on the Salt Flats (salt-pan slabs → ceramic + cured stores → provisions), MARROW DIGGINGS in Low Marrow (bog-iron → metal + bottled marsh-light → lumen) — every reach a different mouth feeding the v3.27 loop — **SHIPPED (v3.28)**
- Caravans haul every cycle (240s) into the SAME bank the ecosystem revolves through — earn chips land, the ecosystem tally counts outpost units, the caravan dot walks home on the table as the cycle closes — **SHIPPED (v3.28)**
- THE RAID DICE: an unguarded haul rolls 35% — raided caravans limp in at half, on record (mail + the table's CARAVANS RAIDED line) — **SHIPPED (v3.28)**
- THE ESCORT CONTRACT: fund the Farkeeper escort (2 provisions/cycle, the wage law) and the mountain walks beside every haul — zero raids while paid; an unpaid escort LAPSES like any unpaid hand — **SHIPPED (v3.28)**
- [ THE FRONTIER ] column on the table: riders out, reaches charted, outposts, hauls landed, caravans raided — one truth — **SHIPPED (v3.28)**
- Far pins CLAMP to the table's edge, never dropped (the pin marks the direction; recon pulls the march onto the paper) — **SHIPPED (v3.28)**
- PATH-PRESSER CUSTOM ROUTES: the presser's picker gains "→ a point on the land" — click any ground and they wear a trail from town to your mark (right-click/ESC puts the mark away) — **SHIPPED (v3.28)**
- LOOTER FULL AUTOMATION (haul ≥ 4, earned): trained backs work blooms/scrap/ruins in your sight straight into the bank, and a full back past 80% empties itself into the next lit town's lockers — kept and retrievable, never the void — **SHIPPED (v3.28)**
- RECON RIDER live on the Republic's roster; frontier state rides the save; tutorials firstRecon/firstOutpost — **SHIPPED (v3.28)**
- frontier.mjs: 24 checks — refusals, exact costs, the chart, the hauls, the raid dice, the escort and its lapse, both reaches' distinct yields, the desk, the presser's mark, the looter's sweep and deposit, save round-trip — **SHIPPED (v3.28, standing)**

## 11i · The clean shop (v3.28c — standards correction, executed)
- THE TYPE LEDGER replaces the attic/splice patchwork: a versioned structure-type migration map applied at one load() seam (history audited: additive-only, so it opens empty — the seam is the law), and genuinely foreign types become REAL inert `unmapped` world objects (authored glyph, original type carried, auto-restores when a build knows it) — **SHIPPED (v3.28c)**
- Runtime garbage is a CODE bug and behaves like one: named on screen by the fault guard, never absorbed silently — **SHIPPED (v3.28c)**
- FULL DEAD-CODE AUDIT (tools/audit.py): 61 findings raised → every one verified by eyeball → 1 unreachable branch removed, 6 dead declarations removed, 1 dead UI subsystem (the DOM cine-title that could never show) removed end to end, 44 dead exports trimmed with their living functions kept, 9 analyzer false-positives fixed IN THE INSTRUMENT (spread syntax, ternary tut() calls, destructured imports, T() reads, static DOM nodes) — full ledger in SHOP-AUDIT.md — **SHIPPED (v3.28c)**
- shopaudit.mjs: the audit is a STANDING BATTERY GATE — any future dead declaration, dead export, unread tuning constant, unfired tutorial, unreachable branch, or ghost save-field fails the build — **SHIPPED (v3.28c, standing)**

## 11j · The memorial (v3.29 — the ground that keeps the Order's own)
- THE LANTERN ROWS: a real war-memorial ground near Haven the player VISITS — site found once on open ground, kept on the save, marked on the compass and the survey sheet — **SHIPPED (v3.29)**
- Every fallen or retired walker earns a STONE, tiered by the walk they walked (small / mid / GRAND past 25 deliveries or 350 ◆ — the Darkest Dungeon headstone law); grand stones glow — **SHIPPED (v3.29)**
- VISUAL PROGRESSION: the ground GROWS with the roll — kept ground (plinth) → the stones (+ flanking lantern posts) → the rows (+ paved apron) → THE HALL (etched wall crowning the ground) — **SHIPPED (v3.29)**
- THE CEREMONY: unraised stones wait as cut blocks on skids; RAISE THE STONE by hand (the DF slab law) — +8 ◆, epitaph mail in the register's voice, oldest first; an unraised stone is a DUTY mark on the compass from anywhere — **SHIPPED (v3.29)**
- THE SHEET: playercards of the fallen — stapled portrait (the same engine that drew them alive), name, class, epitaph, numbers, fate, REMEMBERED stamp; grand walkers read gold; WALKED WITH HELP stamped where it belongs; full modal law (ESC, freeze, gate report) — **SHIPPED (v3.29)**
- CROSS-FACTION BY ARCHITECTURE (the future-proofing law): FOUR complete designs TODAY — THE LANTERN ROWS (Waylight), THE HOODED ROW (Lamplighters), THE STANDING TEETH (Farkeep), THE BRASS WALL (Diefenbunker) — unique ground name, palette, accent (flame/hood/ring/leaf) and voice each; one renderer reads the table; future faction cities plug their grounds in; unknown banners fall back honest — **SHIPPED (v3.29)**
- The identity layer the CK3-style sandbox (v3.31) hangs from: per-walker cards + per-faction grounds — **SHIPPED (v3.29, groundwork)**
- Legacy rows now carry the face and the banner (seed + faction) at write; old rows get one deterministic face forever — nothing on the roll is ever unreadable — **SHIPPED (v3.29)**
- memorial.mjs: 20 checks — site, stages, tiers, ceremony, sheet + modal law, pixels on screen, compass duty, four-design completeness, save round-trip, a real death writing a stone-ready row — **SHIPPED (v3.29, standing)**

## 11k · The exile roads (v3.30 — Shutterlight, the guild, the C-series, the Hooded Row)
- SHUTTERLIGHT, the exiles' own city: REVEALED, never charted — the v3.25 rescue marks the table ("a mark nobody made"), FOLLOW THE MARK runs the guided journey, and the city opens on the table's far NW edge with its own pin and desk — **SHIPPED (v3.30)**
- THE EXCHANGE: .338 rounds at 3 metal apiece from a cycled stock (6/cycle) — dear because the Nomads collect rifles, not brass — **SHIPPED (v3.30)**
- THE GUILD: mercenary contracts gated HONESTLY (rifle on the back + party of two) — Ridge watch / Caravan gun / Quiet collection (writes the Renegade ledger), hazard roll mid-contract ("it went loud" = half pay), guild standing 1→2 (3 done)→3 (7 done) — **SHIPPED (v3.30)**
- THE C-SERIES on ONE fire path: C14 Timberwolf (the hand-me-down) → C3A1 at standing 2 (80 metal · 20 ceramic; red leaf in the sights) → C20 behind the cold door (120 metal · 24 wood) — range/cooldown/warning multipliers, the rifle named on pack and prompt — **SHIPPED (v3.30)**
- THE COLD DOOR: turns its table corner at standing 3; a KNOCK plays the raised-tongue scene and opens the C20 shelf — the Society answers now (the walkable interior rides v3.32 with the faction-places work) — **SHIPPED (v3.30)**
- THE HOODED ROW: the Lamplighter memorial variant LIVE on the shared v3.29 architecture — its own remote ground (revealed with the city, far from every station), dark stelae with the hooded-lantern accent, UNHOODED stamps, and Lamplighter-class walkers' stones ROUTE there by banner — the cross-faction law proven in play — **SHIPPED (v3.30)**
- exileroads.mjs: 22 checks — reveal gates, journey, exchange arithmetic, restock cycle, guild gating/pay/lapse-free ledger, rank ladder, door, C-series purchases, desk on the table, stone routing, the exiles' sheet voice, save round-trip — **SHIPPED (v3.30, standing)**

## 11l · Standards revisions (v3.30, by directive)
- SCREEN SHAKE REMOVED AT THE ROOT: the per-frame random camera jolt (fed continuously by damage-over-time — the reported "violent vibration") is deleted with all nine callers and the 40Hz HUD heart jitter; impact speaks through sound, stagger, and bursts; THE STILLNESS LAW stands in the battery (ground still to the pixel under bleeding) — **SHIPPED (v3.30)**
- The appreciation icon sized like it matters: 30px on the waybill's "+N APPRECIATION" line, 16–18px in the ledgers — proven on a real local-post delivery — **SHIPPED (v3.30)**

## 11m · The delivery ledgers (v3.31 — the management layer)
- ITEM-SYSTEM AUDIT VERDICT: no database — one merged flat def map (97 defs) was already right; the management layer ships as two pure DATA layers over it (taxonomy + policy), zero defs moved — **SHIPPED (v3.31)**
- THE TAXO TREE: Cargo → Equipable (utilities/provisions/weapon/wearables BY SLOT: boots·coats·packs·charms) · Buildables · Resources (wood/metal/ceramic/lumen — every cut and grade under its one parent) · Consumables · Freight · Curios; classify() from def fields + 4-line OVERRIDES; coverage() a STANDING check (97/97 — a future def that fits no branch fails the battery) — **SHIPPED (v3.31)**
- ONE POLICY STORE, five verbs (Deliver/Store/Donate/Scrap/Pickup), resolution item→leaf→root→default; THE PARENT LAW: marking a parent clears descendant overrides and flips the whole column VISIBLY; tri-state half-bar for mixed — **SHIPPED (v3.31)**
- THE THREE SHEETS: Delivery Dossier (the pass + toggles + donate-EXEMPT search), Haulin' Manifest (streamlined — ONE take-mark tree), Cargo Checklist (in-depth — searchable five-mark grid, Enter opens the chain and lights the row); full-word column heads on a 49px pitch — **SHIPPED (v3.31)**
- THE DOSSIER PASS, strict order at any lit town: MISSIONS FIRST → Deliver (letters before cargo) → Store → Donate (exemptions held) → Scrap → Pickup (letters first, capacity honest); one slip totals the pass — **SHIPPED (v3.31)**
- THE MAP RAIL WIDGET as sketched: run-dossier-on-arrival / grab-all-letters / deliver-applicable toggles + OPEN THE LEDGERS; arrival edge once per town with cooldown — **SHIPPED (v3.31)**
- FUTURE-PROOFING (imperative): the policy engine is item-agnostic — the base for COMPANION management — **SHIPPED (v3.31, groundwork)**
- ledgers.mjs: 16 checks — coverage, chains, defaults, parent law + mixed + reassert, a full dossier at Haven (slip totalled), exemption held, letters-first, arrival edge, save round-trip, modal law, search, rail sync — **SHIPPED (v3.31, standing)**

## 11n · The fairness pass (v3.31 — four field verdicts, four roots)
- THE CHASE OBEYS THE WORLD: scrapper sprint 152-flat → 118 taxed by the SAME terrain/slope the player pays; leash 720; stall-giveup; the MOUNTED LAW — a runner watching the gap grow under hooves calls the chase off ("A horse. Forget it.") — no relative-speed cheat anywhere — **SHIPPED (v3.31)**
- THE HILL IS NOT A MINIGAME: the wobble ring requires a REASON (overload past 1.0 / sprinting on rough ground / fear / empty lungs) — a sane load WALKING any slope never rings; proof runs with the wobble LIVE (calm flag cleared — the earlier vacuous green named and replaced) — **SHIPPED (v3.31)**
- THE BALK IS A BEAT: water/rungs still dismount the rider, and the horse PICKS YOU BACK UP past the obstacle — no button, no lockout, one line once; a CHOSEN dismount stays dismounted — **SHIPPED (v3.31)**
- THE LADDER LAW: snapCrossings() projects planned waypoints ONTO span rungs (player routes AND field crews); proof: routed crossing max step 9px at 100ms sampling — **SHIPPED (v3.31)**
- EVERY WARP KILLED: escortSnap DELETED (a wedged convoy junior plans the crossing and WALKS it under the player's own passable() law; left behind = half-pace trudge, never frozen, never warped); field-hand no-progress check remeasured over a full window (slow walkers gain <1px/frame and are NOT stuck) and RETARGETS without position writes; companion 300px/7s catch-up teleport → a visible run at whatever pace the gap demands — **SHIPPED (v3.31)**
- fairness.mjs: 10 checks measuring the WORLD (gaps in px, rings counted, lockouts timed, strides bounded); body/shapes rewritten where they enshrined the old warp law — **SHIPPED (v3.31, standing)**

## 12 · Verification law (standing)
- Every claim executable: Playwright bots, pixel measurements, screenshot evidence; full battery green before any ship — currently 571 tallied checks / thirty-five suites, the shop audit among them — **SHIPPED (standing law)**
