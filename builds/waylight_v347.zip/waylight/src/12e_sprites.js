'use strict';
/* Waylight v3.33 — THE ASSET PASS: the sprite registry. Every row here is DATA in the game's own
   texel grammar (letter-keyed rows over a small hard palette, '.' transparent), drawn by ONE blit.
   Two provenances, one law:
     · THE KIT — hand-authored at the rig's Mara quality, 14×22: a Farkeeper stands a head taller
       and a hand wider than the 12×18 Waylighter rig, NOT a giant — so the height is DRAWN, never
       scaled. Each class is its own silhouette (the bow, the claymore, the breech, the wraps).
     · THE STABLE — generated (PixelLab, quadruped horse template), then QUANTIZED to a ramp
       derived from each breed's own coat and embedded at native texel density: a horse is a big
       object with more texels, drawn at the same 3 screen px a texel as everything else, and
       stands the right head-and-a-half over a walker. A rider is composed on the SEAT anchor.
   A future breed or class is a row. The renderer never learns a new shape. */

const SPRITES = (() => {
  /* ---------- THE KIT: palettes share the walker's letters so coats recolour the same way ----------
     O outline · H hair/hood · S skin · e eye · C coat · c coat shade · T leather · t leather shade
     B boots · b boot shade · F fur collar · R cloth wraps · W steel · w steel shade · Y bow/haft */
  const FK_PAL = { O: '#12161c', H: '#3a4048', S: '#d8c0a0', e: '#2a2118', C: '#3a4048', c: '#2a3038', T: '#6e5a42', t: '#54432f', B: '#23282f', b: '#171b21', F: '#d8c9b8', R: '#c9b098', W: '#b8c2c8', w: '#6e747c', Y: '#8a6534', G: '#8d979c', P: '#5a4a3a' };   // v3.41: P — a plank, the shared alphabet's newest letter

  const KIT = {
    /* PUGUGLY — bare-knuckle bruiser. Cropped hair, a jaw of iron, shoulders the whole width of
       the grid, fists wrapped in cloth. Idle A/B swing the wraps; the breath drifts the coat. */
    pugugly: {
      idle: [
        '......OOOO....', '.....OHHHHO...', '.....OHHHHHO..', '.....OHSSeSO..', '.....OSSSSSO..', '......OSSSO...',
        '...OOOOCCCOOO.', '..OCCCCCCCCCCO', '.OCCCOCCCCCCCO', '.OCcCOCcCCCCSO', '.OCcCOCcCCCCSO', '.OCcCOCcCCCCRO',
        '.ORcCOCcCCCCRO', '..OOCOCcCCOOO.', '....OcCCcCO...', '....OCCCCCO...', '....OBBOBBO...', '....OBBOBBO...',
        '....OBBOBBO...', '....ObbObbO...', '...OObbObbOO..', '..............',
      ],
      A: [
        '......OOOO....', '.....OHHHHO...', '.....OHHHHHO..', '.....OHSSeSO..', '.....OSSSSSO..', '......OSSSO...',
        '...OOOOCCCOOO.', '..OCCCCCCCCCCO', '.OCCCOCCCCCCCO', '.OCcCOCcCCCCSO', '.OCcCOCcCCCCRO', '.ORcCOCcCCCCRO',
        '.OOcCOCcCCCOO.', '...OCOCcCCO...', '....OcCCcCO...', '....OCCCCCO...', '...OBBBOBBBO..', '..OBBO..OBBO..',
        '..OBBO...OBBO.', '..ObbO...ObbO.', '.OObbO...ObbOO', '..............',
      ],
      B: [
        '......OOOO....', '.....OHHHHO...', '.....OHHHHHO..', '.....OHSSeSO..', '.....OSSSSSO..', '......OSSSO...',
        '...OOOOCCCOOO.', '..OCCCCCCCCCCO', '.OCCCOCCCCCCCO', '.OCcCOCcCCCCSO', '.ORcCOCcCCCCSO', '.ORcCOCcCCCCRO',
        '.OOcCOCcCCCOO.', '...OCOCcCCO...', '....OcCCcCO...', '....OCCCCCO...', '...OBBBOBBBO..', '..OBBO..OBBO..',
        '.OBBO....OBBO.', '.ObbO....ObbO.', 'OObbO....ObbOO', '..............',
      ],
    },
    /* LONGBOWMAN — the wall of Farkeep, carried on a shoulder: a hooded head, the bow stave (Y)
       running from the hip up past the shoulder on the back, a quiver of leather (T) beside it. */
    longbowmen: {
      idle: [
        '......OOO.....', '.....OHHHO....', '....OHHHHHO...', '....OHSSeSO...', '....OHSSSSO...', '.....OSSSO....',
        '..Y.OOCCCCOO..', '.OYOTCCCCCCCO.', '.OYTTOCCCCCCSO', 'OYTTTOCcCCCCSO', 'OYTTTOCcCCCCO.', 'OYtttOCcCCCCO.',
        '.OYOOOcCCcCCO.', '..OY.OCCCCCO..', '...Y.OCCCCO...', '...OY.OBOBO...', '....YOBBOBBO..', '.....OBBOBBO..',
        '.....ObbObbO..', '....OObbObbOO.', '..............', '..............',
      ],
      A: [
        '......OOO.....', '.....OHHHO....', '....OHHHHHO...', '....OHSSeSO...', '....OHSSSSO...', '.....OSSSO....',
        '..Y.OOCCCCOO..', '.OYOTCCCCCCCO.', '.OYTTOCCCCCCSO', 'OYTTTOCcCCCCSO', 'OYTTTOCcCCCCO.', 'OYtttOCcCCCCO.',
        '.OYOOOcCCcCCO.', '..OY.OCCCCCO..', '...Y.OCCCCO...', '...OYOBBOBBO..', '....YOBBO.OBBO', '.....OBBO.OBBO',
        '.....ObbO.ObbO', '....OObbO.ObbO', '..............', '..............',
      ],
      B: [
        '......OOO.....', '.....OHHHO....', '....OHHHHHO...', '....OHSSeSO...', '....OHSSSSO...', '.....OSSSO....',
        '..Y.OOCCCCOO..', '.OYOTCCCCCCCO.', '.OYTTOCCCCCCSO', 'OYTTTOCcCCCCSO', 'OYTTTOCcCCCCO.', 'OYtttOCcCCCCO.',
        '.OYOOOcCCcCCO.', '..OY.OCCCCCO..', '...Y.OCCCCO...', '...OYOBBOBBO..', '....YOBBOBBO..', '....OBBO.OBBO.',
        '....ObbO.ObbO.', '...OObbO.ObbO.', '..............', '..............',
      ],
    },
    /* BERSERKER — pistol and claymore. Bare head, fur collar (F), the claymore's hilt (W) standing
       above the shoulder with the blade down the back, the pistol (w) at the hip. Smaller and less
       agile than the Pugugly — narrower shoulders, same height. */
    berserker: {
      idle: [
        '.....OOOO.....', '....OHHHHO....', '...WOHHHHHO...', '...WOHSSeSO...', '..OWOSSSSSO...', '..OWOOSSSO....',
        '..OWFFFCCCFO..', '.OWWOFCCCCCFO.', '.OWWTOCCCCCCSO', '.OwWTOCcCCCCSO', '.OwWTOCcCCCCO.', '.OwwtOCcCCwwO.',
        '..OwOOcCCcCwO.', '...O.OCCCCCO..', '.....OcCCCO...', '.....OCCCCO...', '.....OBBOBBO..', '.....OBBOBBO..',
        '.....OBBOBBO..', '.....ObbObbO..', '....OObbObbOO.', '..............',
      ],
      A: [
        '.....OOOO.....', '....OHHHHO....', '...WOHHHHHO...', '...WOHSSeSO...', '..OWOSSSSSO...', '..OWOOSSSO....',
        '..OWFFFCCCFO..', '.OWWOFCCCCCFO.', '.OWWTOCCCCCCSO', '.OwWTOCcCCCCSO', '.OwWTOCcCCCCO.', '.OwwtOCcCCwwO.',
        '..OwOOcCCcCwO.', '...O.OCCCCCO..', '.....OcCCCO...', '.....OCCCCO...', '....OBBBOBBBO.', '...OBBO..OBBO.',
        '...OBBO...OBBO', '...ObbO...ObbO', '..OObbO...ObbO', '..............',
      ],
      B: [
        '.....OOOO.....', '....OHHHHO....', '...WOHHHHHO...', '...WOHSSeSO...', '..OWOSSSSSO...', '..OWOOSSSO....',
        '..OWFFFCCCFO..', '.OWWOFCCCCCFO.', '.OWWTOCCCCCCSO', '.OwWTOCcCCCCSO', '.OwWTOCcCCCCO.', '.OwwtOCcCCwwO.',
        '..OwOOcCCcCwO.', '...O.OCCCCCO..', '.....OcCCCO...', '.....OCCCCO...', '....OBBBOBBBO.', '...OBBO..OBBO.',
        '..OBBO....OBBO', '..ObbO....ObbO', '.OObbO....ObbO', '..............',
      ],
    },
    /* RIFLE RIDER — a longbowman who earned a horse and traded the bow for a breech: the rifle (W/w)
       slung across the back at a diagonal, a bandolier (T) over the chest, the hood up. */
    rifle_rider: {
      idle: [
        '......OOO.....', '.....OHHHO....', '....OHHHHHO...', '....OHSSeSO...', '....OHSSSSO...', '.....OSSSO....',
        '....OOCCCCOOW.', '...OTCCCCCCTWO', '..OWTOCCCCTCSO', '.OWWOOCcCTCCSO', '.OWwOOCcTCCCO.', '.OwwOOCcTCCCO.',
        '..OwOOcCTcCCO.', '...O.OCCCCCO..', '.....OcCCCO...', '.....OCCCCO...', '.....OBBOBBO..', '.....OBBOBBO..',
        '.....OBBOBBO..', '.....ObbObbO..', '....OObbObbOO.', '..............',
      ],
      A: [
        '......OOO.....', '.....OHHHO....', '....OHHHHHO...', '....OHSSeSO...', '....OHSSSSO...', '.....OSSSO....',
        '....OOCCCCOOW.', '...OTCCCCCCTWO', '..OWTOCCCCTCSO', '.OWWOOCcCTCCSO', '.OWwOOCcTCCCO.', '.OwwOOCcTCCCO.',
        '..OwOOcCTcCCO.', '...O.OCCCCCO..', '.....OcCCCO...', '.....OCCCCO...', '....OBBBOBBBO.', '...OBBO..OBBO.',
        '...OBBO...OBBO', '...ObbO...ObbO', '..OObbO...ObbO', '..............',
      ],
      B: [
        '......OOO.....', '.....OHHHO....', '....OHHHHHO...', '....OHSSeSO...', '....OHSSSSO...', '.....OSSSO....',
        '....OOCCCCOOW.', '...OTCCCCCCTWO', '..OWTOCCCCTCSO', '.OWWOOCcCTCCSO', '.OWwOOCcTCCCO.', '.OwwOOCcTCCCO.',
        '..OwOOcCTcCCO.', '...O.OCCCCCO..', '.....OcCCCO...', '.....OCCCCO...', '....OBBBOBBBO.', '...OBBO..OBBO.',
        '..OBBO....OBBO', '..ObbO....ObbO', '.OObbO....ObbO', '..............',
      ],
    },
    /* RECON RIDER — quick, quiet, low damage: a light short cloak (G, the Farkeep grey), no weapon,
       a satchel (T) at the hip and a spyglass (W) in the hand. Narrow, built to be forgotten. */
    recon_rider: {
      idle: [
        '......OOO.....', '.....OHHHO....', '....OHHHHHO...', '....OHSSeSO...', '....OHSSSSO...', '.....OSSSO....',
        '....OOGGGGOO..', '...OGGGGGGGGO.', '...OGGOGGGGGSO', '...OGGOCcCCCWO', '...OGGOCcCCCO.', '...OGGOCcTTCO.',
        '....OOOcCTTCO.', '.....OCCCCCO..', '.....OcCCCO...', '.....OCCCCO...', '.....OBBOBBO..', '.....OBBOBBO..',
        '.....OBBOBBO..', '.....ObbObbO..', '....OObbObbOO.', '..............',
      ],
      A: [
        '......OOO.....', '.....OHHHO....', '....OHHHHHO...', '....OHSSeSO...', '....OHSSSSO...', '.....OSSSO....',
        '....OOGGGGOO..', '...OGGGGGGGGO.', '...OGGOGGGGGSO', '...OGGOCcCCCWO', '...OGGOCcCCCO.', '...OGGOCcTTCO.',
        '....OOOcCTTCO.', '.....OCCCCCO..', '.....OcCCCO...', '.....OCCCCO...', '....OBBBOBBBO.', '...OBBO..OBBO.',
        '...OBBO...OBBO', '...ObbO...ObbO', '..OObbO...ObbO', '..............',
      ],
      B: [
        '......OOO.....', '.....OHHHO....', '....OHHHHHO...', '....OHSSeSO...', '....OHSSSSO...', '.....OSSSO....',
        '....OOGGGGOO..', '...OGGGGGGGGO.', '...OGGOGGGGGSO', '...OGGOCcCCCWO', '...OGGOCcCCCO.', '...OGGOCcTTCO.',
        '....OOOcCTTCO.', '.....OCCCCCO..', '.....OcCCCO...', '.....OCCCCO...', '....OBBBOBBBO.', '...OBBO..OBBO.',
        '..OBBO....OBBO', '..ObbO....ObbO', '.OObbO....ObbO', '..............',
      ],
    },
    /* ---------- v3.41 THE CAMPS' OWN — the raiders by trade, in their own rust and hide. The same
       14×22 grammar and the same three frames; the road and the storm read a class row, the
       renderer reads the kit. Hand-drawn: no generator fits a person to this grid. ---------- */
    /* BOWMAN — a deep hood over the brow, a SHORT bow (Y) on the left from hip to shoulder, a quiver
       of hide (T) at the back of the shoulder. Narrower than the mountain's longbowman: a poacher. */
    bowman: {
      idle: [
        '......OOO.....', '.....OHHHO....', '....OHHHHHO...', '....OHHSeSO...', '....OHSSSSO...', '.....OSSSO....',
        '....OOCCCCOO..', '...OTTCCCCCCO.', '..OYTTOCCCCCSO', '.OYOTTOCcCCCSO', '.OY.tOCcCCCCO.', '.OY..OCcCCCCO.',
        '.OY.OOcCCcCCO.', '..OY.OCCCCCO..', '...OYOCCCCO...', '....OOBBOBBO..', '.....OBBOBBO..', '.....OBBOBBO..',
        '.....ObbObbO..', '....OObbObbOO.', '..............', '..............',
      ],
      A: [
        '......OOO.....', '.....OHHHO....', '....OHHHHHO...', '....OHHSeSO...', '....OHSSSSO...', '.....OSSSO....',
        '....OOCCCCOO..', '...OTTCCCCCCO.', '..OYTTOCCCCCSO', '.OYOTTOCcCCCSO', '.OY.tOCcCCCCO.', '.OY..OCcCCCCO.',
        '.OY.OOcCCcCCO.', '..OY.OCCCCCO..', '...OYOCCCCO...', '....OBBBOBBBO.', '...OBBO..OBBO.', '...OBBO...OBBO',
        '...ObbO...ObbO', '..OObbO...ObbO', '..............', '..............',
      ],
      B: [
        '......OOO.....', '.....OHHHO....', '....OHHHHHO...', '....OHHSeSO...', '....OHSSSSO...', '.....OSSSO....',
        '....OOCCCCOO..', '...OTTCCCCCCO.', '..OYTTOCCCCCSO', '.OYOTTOCcCCCSO', '.OY.tOCcCCCCO.', '.OY..OCcCCCCO.',
        '.OY.OOcCCcCCO.', '..OY.OCCCCCO..', '...OYOCCCCO...', '....OBBBOBBBO.', '...OBBO..OBBO.', '..OBBO....OBBO',
        '..ObbO....ObbO', '.OObbO....ObbO', '..............', '..............',
      ],
    },
    /* RAM — the Pugugly's width under a raider's hood: a DOOR on the left arm (planks P, rivets W),
       a beam (Y) over the right shoulder rising past the hood. The first knock only staggers him. */
    ram: {
      idle: [
        '......OOOO..Y.', '.....OHHHHO.Y.', '.....OHHHHHOY.', '.....OHHSeSOY.', '.....OHSSSSOY.', '......OSSSOOY.',
        'OOOOOOOCCCOYYO', 'OPPWPPOCCCCCYO', 'OPPPPPOCCCCCCO', 'OPWPPWOCcCCCSO', 'OPPPPPOCcCCCSO', 'OPPPPPOCcCCCRO',
        'OPWPPWOCcCCCRO', 'OPPPPPOCcCCOO.', 'OPPWPPOcCCcCO.', 'OOOOOOOCCCCCO.', '....OBBOBBO...', '....OBBOBBO...',
        '....OBBOBBO...', '....ObbObbO...', '...OObbObbOO..', '..............',
      ],
      A: [
        '......OOOO..Y.', '.....OHHHHO.Y.', '.....OHHHHHOY.', '.....OHHSeSOY.', '.....OHSSSSOY.', '......OSSSOOY.',
        'OOOOOOOCCCOYYO', 'OPPWPPOCCCCCYO', 'OPPPPPOCCCCCCO', 'OPWPPWOCcCCCSO', 'OPPPPPOCcCCCSO', 'OPPPPPOCcCCCRO',
        'OPWPPWOCcCCCRO', 'OPPPPPOCcCCOO.', 'OPPWPPOcCCcCO.', 'OOOOOOOCCCCCO.', '...OBBBOBBBO..', '..OBBO..OBBO..',
        '..OBBO...OBBO.', '..ObbO...ObbO.', '.OObbO...ObbOO', '..............',
      ],
      B: [
        '......OOOO..Y.', '.....OHHHHO.Y.', '.....OHHHHHOY.', '.....OHHSeSOY.', '.....OHSSSSOY.', '......OSSSOOY.',
        'OOOOOOOCCCOYYO', 'OPPWPPOCCCCCYO', 'OPPPPPOCCCCCCO', 'OPWPPWOCcCCCSO', 'OPPPPPOCcCCCSO', 'OPPPPPOCcCCCRO',
        'OPWPPWOCcCCCRO', 'OPPPPPOCcCCOO.', 'OPPWPPOcCCcCO.', 'OOOOOOOCCCCCO.', '...OBBBOBBBO..', '..OBBO..OBBO..',
        '.OBBO....OBBO.', '.ObbO....ObbO.', 'OObbO....ObbOO', '..............',
      ],
    },
    /* CHIEF — the camp's own. A hood with the RED RAG (R) tied across the brow, a cloak of stitched
       pale hide (F, a stitch of T) over the left shoulder, the long knife (W/w) at the right hip. */
    chief: {
      idle: [
        '.....OOOO.....', '....OHHHHO....', '...OHHHHHHO...', '...ORRRRRRO...', '...OHSSeSSO...', '....OSSSSO....',
        '..OOFFFCCCFOO.', '.OFFFOFCCCCCFO', '.OFFFOCCCCCCSO', '.OFFFOCcCCCCSO', '.OFTFOCcCCCCO.', '.OFFFOCcCCWWO.',
        '.OFFFOcCCcCWO.', '..OFFOCCCCCwO.', '...OOOcCCCOwO.', '.....OCCCCOwO.', '.....OBBOBBO..', '.....OBBOBBO..',
        '.....OBBOBBO..', '.....ObbObbO..', '....OObbObbOO.', '..............',
      ],
      A: [
        '.....OOOO.....', '....OHHHHO....', '...OHHHHHHO...', '...ORRRRRRO...', '...OHSSeSSO...', '....OSSSSO....',
        '..OOFFFCCCFOO.', '.OFFFOFCCCCCFO', '.OFFFOCCCCCCSO', '.OFFFOCcCCCCSO', '.OFTFOCcCCCCO.', '.OFFFOCcCCWWO.',
        '.OFFFOcCCcCWO.', '..OFFOCCCCCwO.', '...OOOcCCCOwO.', '.....OCCCCOwO.', '....OBBBOBBBO.', '...OBBO..OBBO.',
        '...OBBO...OBBO', '...ObbO...ObbO', '..OObbO...ObbO', '..............',
      ],
      B: [
        '.....OOOO.....', '....OHHHHO....', '...OHHHHHHO...', '...ORRRRRRO...', '...OHSSeSSO...', '....OSSSSO....',
        '..OOFFFCCCFOO.', '.OFFFOFCCCCCFO', '.OFFFOCCCCCCSO', '.OFFFOCcCCCCSO', '.OFTFOCcCCCCO.', '.OFFFOCcCCWWO.',
        '.OFFFOcCCcCWO.', '..OFFOCCCCCwO.', '...OOOcCCCOwO.', '.....OCCCCOwO.', '....OBBBOBBBO.', '...OBBO..OBBO.',
        '..OBBO....OBBO', '..ObbO....ObbO', '.OObbO....ObbO', '..............',
      ],
    },
    /* v3.44 — THE NEW CHIEF: the man who walks in when the rag comes down is a different man, and the eye
       should see it. A beard at the jaw, a hide vest over the coat, a long spear on the road-side, the same
       rag on the brow. A camp alternates the two as its chiefs fall and come up. */
    chief2: {
      idle: [
                '.....OOOO...W.', '....OHHHHO..W.', '...OHHHHHHO.Y.', '...ORRRRRRO.Y.', '...OSSeSSSO.Y.', '....OHHHHO..Y.',
        '..OOOOOOOO..Y.', '.OCCOFFFFOCCY.', '.OCCOFFFFOCCY.', '.OCcOFFTFOCSY.', '.OCcOFFFFOCSY.', '.OOOOFFFFOCOY.',
        '....OFFFFOOOY.', '....OCCCCO..Y.', '....OCcCCO..Y.', '....OCCCCO..Y.', '.....OBBOBBO..', '.....OBBOBBO..',
        '.....OBBOBBO..', '.....ObbObbO..', '....OObbObbOO.', '..............',
      ],
      A: [
                '.....OOOO...W.', '....OHHHHO..W.', '...OHHHHHHO.Y.', '...ORRRRRRO.Y.', '...OSSeSSSO.Y.', '....OHHHHO..Y.',
        '..OOOOOOOO..Y.', '.OCCOFFFFOCCY.', '.OCCOFFFFOCCY.', '.OCcOFFTFOCSY.', '.OCcOFFFFOCSY.', '.OOOOFFFFOCOY.',
        '....OFFFFOOOY.', '....OCCCCO..Y.', '....OCcCCO..Y.', '....OCCCCO..Y.', '....OBBBOBBBO.', '...OBBO..OBBO.',
        '...OBBO...OBBO', '...ObbO...ObbO', '..OObbO...ObbO', '..............',
      ],
      B: [
                '.....OOOO...W.', '....OHHHHO..W.', '...OHHHHHHO.Y.', '...ORRRRRRO.Y.', '...OSSeSSSO.Y.', '....OHHHHO..Y.',
        '..OOOOOOOO..Y.', '.OCCOFFFFOCCY.', '.OCCOFFFFOCCY.', '.OCcOFFTFOCSY.', '.OCcOFFFFOCSY.', '.OOOOFFFFOCOY.',
        '....OFFFFOOOY.', '....OCCCCO..Y.', '....OCcCCO..Y.', '....OCCCCO..Y.', '....OBBBOBBBO.', '...OBBO..OBBO.',
        '..OBBO....OBBO', '..ObbO....ObbO', '.OObbO....ObbO', '..............',
      ],
    },
  };
  /* the raiders' palette: rust coats, dark hoods, hide and scrap — the same letters, so the kit's
     blit needs no new branch; P is the ram's plank door */
  const RAID_PAL = { O: '#150f0c', H: '#33241e', S: '#d8b890', e: '#241a12', C: '#8a4432', c: '#6b3426', T: '#5a4a3a', t: '#453a2e', B: '#20242a', b: '#15181e', F: '#c9b098', R: '#c9553a', W: '#9a9a8a', w: '#6a6a5e', Y: '#8a6534', P: '#6e5a42', G: '#8d979c' };
  /* the town's own: a cap, a leather coat, a ROUND wooden shield, a staff with a fork on it */
  const TOWN_PAL = { O: '#12161c', H: '#5a4630', S: '#d8c0a0', e: '#2a2118', C: '#6e5a42', c: '#54432f', T: '#8a6534', t: '#6e4f2a', B: '#3a3028', b: '#2a221a', F: '#c9b98a', R: '#c9b098', W: '#b8c2c8', w: '#6e747c', Y: '#a08050', G: '#a08050' };

  /* ---------- v3.34 THE FIGURES — registry rows drawn by the kit's blit that are NOT hires:
     THE SHIELD, the Farkeeper column's own figure and the watchpost's standing guard. 14×22 on the
     kit's palette: a grey helm with a spear-head over it, the iron jaw, the coat, THE SHIELD on
     the road-side arm (steel rim, cold iron boss), the haft down the other side. A/B step. ---------- */
  const FIGURES = {
    shield: {
      idle: [
        '.....OOOO.....', '....OWWWWO....', '....OWwwwWO..W', '....OHSSeSO..W', '....OSSSSSO..Y', '.....OSSSO...Y',
        '.OWWWOOCCCOO.Y', 'OWGGGWOCCCCCOY', 'OWGGGWOCCCCCOY', 'OWGwGWOCcCCCSY', 'OWGGGWOCcCCCSY', 'OWGGGWOCcCCCRY',
        'OWGGGWOCcCCCRY', 'OWGGGWOCcCCOOY', '.OWWWO.OcCCO.Y', '..OOO..OCCCO.Y', '......OBBOBBO.', '......OBBOBBO.',
        '......OBBOBBO.', '......ObbObbO.', '.....OObbObbOO', '..............',
      ],
      A: [
        '.....OOOO.....', '....OWWWWO....', '....OWwwwWO..W', '....OHSSeSO..W', '....OSSSSSO..Y', '.....OSSSO...Y',
        '.OWWWOOCCCOO.Y', 'OWGGGWOCCCCCOY', 'OWGGGWOCCCCCOY', 'OWGwGWOCcCCCSY', 'OWGGGWOCcCCCSY', 'OWGGGWOCcCCCRY',
        'OWGGGWOCcCCCRY', 'OWGGGWOCcCCOOY', '.OWWWO.OcCCO.Y', '..OOO..OCCCO.Y', '.....OBBBOBBBO', '....OBBO..OBBO',
        '....OBBO..OBBO', '....ObbO..ObbO', '...OObbO..ObbO', '..............',
      ],
      B: [
        '.....OOOO.....', '....OWWWWO....', '....OWwwwWO..W', '....OHSSeSO..W', '....OSSSSSO..Y', '.....OSSSO...Y',
        '.OWWWOOCCCOO.Y', 'OWGGGWOCCCCCOY', 'OWGGGWOCCCCCOY', 'OWGwGWOCcCCCSY', 'OWGGGWOCcCCCSY', 'OWGGGWOCcCCCRY',
        'OWGGGWOCcCCCRY', 'OWGGGWOCcCCOOY', '.OWWWO.OcCCO.Y', '..OOO..OCCCO.Y', '.....OBBBOBBBO', '....OBBO..OBBO',
        '...OBBO...OBBO', '...ObbO...ObbO', '..OObbO...ObbO', '..............',
      ],
    },
    /* v3.41 THE TOWN'S OWN — a garrison's recruit from the square it holds: a cap, a leather coat,
       a ROUND wooden shield (Y rim, T face, W boss) on the road-side arm, a staff with a fork (W)
       on the other. Drawn in TOWN_PAL, never the mountain's grey: the square stands its own. */
    townshield: {
      idle: [
        '.....OOOO...W.', '....OHHHHO..W.', '....OHHHHHO.Y.', '....OHSSeSO.Y.', '....OSSSSSO.Y.', '.....OSSSO..Y.',
        '..OOOOOCCCOOY.', '.OYTTTYOCCCCYO', 'OYTTTTTYCCCCCY', 'OYTTWTTYCcCCSY', 'OYTTTTTYCcCCSY', '.OYTTTYOCcCCRY',
        '..OYYYOCcCCCRY', '...OOOOCcCCOOY', '.......OcCCO.Y', '.......OCCCO.Y', '......OBBOBBO.', '......OBBOBBO.',
        '......OBBOBBO.', '......ObbObbO.', '.....OObbObbOO', '..............',
      ],
      A: [
        '.....OOOO...W.', '....OHHHHO..W.', '....OHHHHHO.Y.', '....OHSSeSO.Y.', '....OSSSSSO.Y.', '.....OSSSO..Y.',
        '..OOOOOCCCOOY.', '.OYTTTYOCCCCYO', 'OYTTTTTYCCCCCY', 'OYTTWTTYCcCCSY', 'OYTTTTTYCcCCSY', '.OYTTTYOCcCCRY',
        '..OYYYOCcCCCRY', '...OOOOCcCCOOY', '.......OcCCO.Y', '.......OCCCO.Y', '.....OBBBOBBBO', '....OBBO..OBBO',
        '....OBBO..OBBO', '....ObbO..ObbO', '...OObbO..ObbO', '..............',
      ],
      B: [
        '.....OOOO...W.', '....OHHHHO..W.', '....OHHHHHO.Y.', '....OHSSeSO.Y.', '....OSSSSSO.Y.', '.....OSSSO..Y.',
        '..OOOOOCCCOOY.', '.OYTTTYOCCCCYO', 'OYTTTTTYCCCCCY', 'OYTTWTTYCcCCSY', 'OYTTTTTYCcCCSY', '.OYTTTYOCcCCRY',
        '..OYYYOCcCCCRY', '...OOOOCcCCOOY', '.......OcCCO.Y', '.......OCCCO.Y', '.....OBBBOBBBO', '....OBBO..OBBO',
        '...OBBO...OBBO', '...ObbO...ObbO', '..OObbO...ObbO', '..............',
      ],
    },
    /* v3.44 — THE KIN: the fallen own's kin keeps their place in the square a day, and stands at the field
       stones — a grey mourning shawl over the head and shoulders, a dark dress, a lantern held low. Idle only: they stand. */
    kin: {
      idle: [
        '.....OOOO.....', '....OwwwwO....', '...OwwwwwwO...', '...OwwSSSwwO..', '...OwwSeSwwO..', '...OwwSSSwwO..',
        '..OwwwwwwwwwO.', '..OwwwwwwwwwO.', '..OwwOCCCOwwO.', '..OwwOCcCOwwO.', '..OOOOCcCOOOY.', '...OCCCcCCCOYO',
        '...OCCCcCCCOWO', '...OCcCcCcCOWO', '...OCCCcCCCOwO', '...OCCCcCCCOOO', '..OCCCCcCCCCO.', '..OCCCCcCCCCO.',
        '..OccccccccO..', '...OOOOOOOOO..', '..............', '..............',
      ],
    },
  };

  /* ---------- v3.42 THE REMEMBERING — the marks of what is remembered, hand-drawn in the texel
     grammar. Each is a registry row; the renderer and the survey sheet blit them, never draw them. ---------- */
  /* THE RAG ON A STAKE — where a camp's chief stood before he went down in the open: the red rag
     tied to a stake and hanging, the camp's own memorial. 7×13, over the reapers' stake in height. */
  const RAGSTAKE_PAL = { O: '#150f0c', R: '#c9553a', r: '#8a3a2c', Y: '#4a3320', y: '#33241e' };
  const RAGSTAKE = [
    '..OYO..',
    '.ORRRO.',
    'ORRYRRO',
    'OrRYRrO',
    '.OrYrO.',
    '..OYO..',
    '.ORYO..',
    '.OrYO..',
    '..OYO..',
    '..OYO..',
    '..OyO..',
    '..OyO..',
    '..OyO..'];
  /* THE SURVEY'S TRADE MARKS — 7×7 each, screen-constant on the sheet: a blade, a bow, a plank
     door, the chief's rag, the chief's fire, the Society's tongue, and the rag gone to a stake. */
  const MARK_PAL = { O: '#12161c', W: '#b8c2c8', w: '#6e747c', Y: '#a08050', y: '#6e5a42', R: '#c9553a', r: '#8a3a2c', P: '#8a6a42', p: '#5a4a3a', F: '#ffd98f', f: '#e0654a', G: '#8fb08a', g: '#4a5a48', T: '#33241e', S: '#d8b890', D: '#6a2a22', d: '#8a3a2c', K: '#e8e0c8', k: '#c9c3a8' };   // v3.44: S skin (the open hand), D/d the scar's reds; v3.45: K paper; v3.47: k the paper's shade
  const MARKS = {
    knife: ['......O', '.....OW', '....OWO', '...OWO.', '..OWO..', '.OyO...', 'Oy.....'],
    bowman: ['.OY....', 'OY.O...', 'OY..O..', 'OY...O.', 'OY..O..', 'OY.O...', '.OY....'],
    ram: ['OOOOOOO', 'OPWPPWO', 'OPPPPPO', 'OpWppWO', 'OPPPPPO', 'OPWPPWO', 'OOOOOOO'],
    chief: ['.......', 'ORRRRRO', 'ORrRRrO', '.ORRRO.', '..ORO..', '..OrO..', '...O...'],
    fire: ['...F...', '..FfF..', '.FfffF.', '.FffFF.', '..FfF..', '.OTTTO.', 'OTTOTTO'],
    tongue: ['OOOOOOO', 'OggggGO', 'OgGGGgO', 'OggGggO', 'OggGggO', 'OgggggO', 'OOOOOOO'],
    gone: ['..ORO..', '.ORrRO.', '..OYO..', '..OYO..', '..OYO..', '..OYO..', '..OyO..'],
    /* v3.44 — the Walker's word (a knotted string; an open hand), a stone at the field's edge, the new chief's
       grudge (the rag with a blade through it), the scar for the memorial card, the road to a ring */
    promise: ['.YY.YY.', 'Y..Y..Y', 'Y..Y..Y', '.YYRYY.', '...R...', '..Y.Y..', '.Y...Y.'],
    sorry:   ['..S.S..', '.SSSSS.', '.SSSSSS', '.SSSSS.', '..SSSS.', '..OSSO.', '...SS..'],
    stone:   ['..OOO..', '.OWWwO.', '.OWYWO.', '.OWWWO.', '.OWwWO.', 'OOWWWOO', 'OyyyyyO'],
    grudge:  ['......W', 'ORRRROW', 'ORrRRWO', '.ORRWO.', '..OWO..', '.OyO...', 'Oy.....'],
    scar:    ['.......', '...D...', '...d...', '.DdDdD.', '...d...', '...D...', '.......'],
    road:    ['.....RR', '....ORR', '...w.O.', '..w....', '.w.....', 'w......', '.......'],
    /* v3.45 — the word kept (a knot pulled tight, gold), broken (the string snapped), promises shut (a barred door), the keeper's
       errand (a sealed letter), the parley's gift (a bundle) and stand (boots planted), the Walker's score (the lantern crossed by
       a blade), a lantern kept lit and a shield brought home (the stone's card) */
    kept:    ['..FFF..', '.F...F.', '.F...F.', '..FfF..', '...f...', '..F.F..', '.F...F.'],
    broken:  ['YY.....', '..Y....', '...Yy..', '.......', '..yY...', '....Y..', '.....YY'],
    shut:    ['.OOOOO.', '.OPPPO.', 'WWWWWWW', '.OPpPO.', '.OPPPO.', '.OPpPO.', '.OOOOO.'],
    errand:  ['.......', 'OOOOOOO', 'OKwKwKO', 'OKKwKKO', 'OKKRKKO', 'OKRrRKO', 'OOOOOOO'],
    gift:    ['..Y.Y..', '...Y...', '.OOYOO.', 'OPPYPPO', 'OYYYYYO', 'OPPYPPO', '.OOOOO.'],
    stand:   ['.OO.OO.', '.Op.Op.', '.Op.Op.', '.Op.Op.', 'OPp.OPp', 'OOO.OOO', 'y.y.y.y'],
    score:   ['...O..W', '..OFOW.', '.OFfW..', '.OfWfO.', '.OWfFO.', '.WOOO..', 'W......'],
    lantern: ['...O...', '..OYO..', '.OOOOO.', '.OFfFO.', '.OfFfO.', '.OFfFO.', '.OOOOO.'],
    home:    ['..OOO..', '.OYYYO.', 'OYYWYYO', 'OYWWWYO', 'OYYWYYO', '.OYYYO.', '..OOO..'],
    /* v3.46 — the word heard down the wire (a brass bell), the kin's thanks (a pendant on its string), the stone's
       flame asked again (a cold lantern and the spark it wants), the truce road (a white rag on its stake), a score
       settled (two stones and the red thread), the line's orders (a roped line of posts; three backs under an
       arrow), a runner turned (the U of the way back), and the six keepsakes a kin gives the Walker */
    heard:   ['...O...', '..OYO..', '.OFFYO.', '.OFFYO.', 'OFFFFYO', 'OOOOOOO', '...Y...'],
    keepsake: ['.Y...Y.', '..Y.Y..', '...Y...', '..OOO..', '.OFWFO.', '.OFFYO.', '..OOO..'],
    relight: ['.....F.', '...O.f.', '..OYO..', '.OOOOO.', '.OwgwO.', '.OgwgO.', '.OOOOO.'],
    truce:   ['..OY...', '..OYKKK', '..OYKKK', '..OYKK.', '..OY...', '..OY...', '..Oy...'],
    settled: ['..OOO..', '.OWrWO.', '.OwRwO.', 'OOOOOOO', 'OWWwWWO', 'OwWWWwO', 'OOOOOOO'],
    hold:    ['.......', 'Y..Y..Y', 'YPPYPPY', 'Y..Y..Y', 'Y..Y..Y', 'Y..Y..Y', 'y..y..y'],
    come:    ['...F...', '..FfF..', '.F.f.F.', '...f...', '.W.W.W.', '.P.P.P.', '.p.p.p.'],
    turned:  ['.RRR...', 'R...R..', 'R...R..', 'R.RRRRR', 'R..RRR.', 'R...R..', 'R......'],
    ks_whetstone: ['.......', '.....OO', '...OOWO', '.OOWWwO', 'OWWwwO.', 'OwwOO..', '.OO....'],
    ks_button:    ['..OOO..', '.OYYYO.', 'OYOYOYO', 'OYYYYYO', 'OYOYOYO', '.OYYYO.', '..OOO..'],
    ks_bird:      ['.OO...O', 'OPOO.OP', 'YPPPOPO', '.OPPPPO', '..OPPO.', '...OO..', '.......'],
    ks_whistle:   ['.......', '.......', 'OOOOOOO', 'OWOWOWW', 'OwwwwwO', 'OOOOOOO', '.......'],
    ks_flower:    ['..r.r..', '.rRrRr.', '..rFr..', '.rRrRr.', '..rgr..', '...g...', '..gg...'],
    ks_ring:      ['.......', '..OOO..', '.OwWwO.', '.OW.WO.', '.OwWwO.', '..OOO..', '.......'],
    /* v3.47 — the word answered (the letter kept, heard down the wire: gold rays, a gold seal) and the door shut by
       hearsay (the same rays over a letter barred in rust); the keepsake set down (the string over the stone's
       shoulders, the thing at its breast); the road kept (the white rag with a gold knot new on the pole); the rags
       down (the bare pole, the rag in the dirt); the stones kicked over; the watch (the roped line under the moon) */
    answered: ['F.....F', '.F...F.', 'OOOOOOO', 'OKkKkKO', 'OKKFKKO', 'OKFfFKO', 'OOOOOOO'],
    hearsay:  ['R.....R', '.R...R.', 'OOOOOOO', 'OKkKkKO', 'RRRRRRR', 'OKKrKKO', 'OOOOOOO'],
    setdown:  ['..OOO..', '.OWWwO.', '.YWWWY.', '.OYWYO.', '.OWFWO.', '.OWWwO.', 'OOOOOOO'],
    roadkept: ['..OY...', '..FFKKK', '..OYKFK', '..OYKKK', '..OYKK.', '..OY...', '..Oy...'],
    ragsdown: ['..OY...', '..OYK..', '..OY...', '..OY...', '..OY...', '.KkOyK.', 'KkKKkKk'],
    kicked:   ['.......', '..OO...', '.OWwO.R', '..OO.R.', 'OO..r..', 'WwO.OO.', 'OO.OWwO'],
    watch:    ['..FF...', '.F.....', '.F.....', '..FF...', 'Y..Y..Y', 'YPPYPPY', 'y..y..y'],
  };
  /* THE BOLT — a bowman's arrow: in flight it is texels laid along its line (grid-true at any
     angle); in the shoulder it is this overlay on the walker's rig, the fletching out, the head in. */
  const ARROW_PAL = { R: '#c9553a', r: '#8a3a2c', Y: '#8a6534', W: '#b8c2c8' };
  const ARROW_IN = [
    'RR...',
    'rYR..',
    '..Y..',
    '...Y.',
    '....W'];

  /* ---------- v3.43 — the stake once the rag is taken down (the pole stands a day), and the bolt's
     SCAR on the rig's shoulder, then the DRESSING a medic winds over it ---------- */
  const BARESTAKE = [
    '..OYO..',
    '..OYO..',
    '.OrYO..',
    '..OYO..',
    '..OYO..',
    '..OYO..',
    '..OYO..',
    '..OYO..',
    '..OYO..',
    '..OYO..',
    '..OyO..',
    '..OyO..',
    '..OyO..'];
  /* v3.44 — the RING PIN: a stake with a rust pennant, planted on the survey sheet where a planned walk meets a camp's ring */
  const RINGPIN = [
    '..OYO..',
    '..OYRRR',
    '..OYRrR',
    '..OYRRR',
    '..OYO..',
    '..OYO..',
    '..OYO..',
    '..OYO..',
    '..OYO..',
    '..OyO..',
    '..OyO..'];
  const SCAR_PAL = { D: '#6a2a22', d: '#8a3a2c', W: '#e8e0c8', w: '#c9c3a8' };
  const SCAR = ['.D.', 'dDd', '.D.'];
  const DRESSING = ['WWWW', 'wWWw', '.WW.'];

  FIGURES.kin.A = FIGURES.kin.idle; FIGURES.kin.B = FIGURES.kin.idle;   // v3.44: the kin never walk the frame

  /* ---------- v3.43 THE FACES — the keepers at the doors, hand-drawn 16×16 busts in the texel
     grammar: a portrait each, in their own colours, on one alphabet. A keeper who has something
     to say to you says it with a face. O outline · H hair · h hair shade · S skin · s skin shade
     · e eye · m mouth · C coat · c coat shade · W white (collar, glasses, teeth) · R the accent
     (a kerchief, a scarf, a band) · K a cap or hat · k its shade · G glass · B beard/brow ---------- */
  const FACES = {
    /* Mara Voss, quartermaster — cropped dark hair, a jaw, a high bone collar, no patience */
    haven: { pal: { O: '#12161c', H: '#2a2118', h: '#1a1410', S: '#d8b890', s: '#b8946e', e: '#2a2118', m: '#8a4a3a', C: '#3a4048', c: '#2a3038', W: '#e8e0c8', B: '#2a2118' }, rows: [
      '................', '.....OOOOOO.....', '....OHHHHHHO....', '...OHHHHHHHHO...', '...OHhSSSSHHO...', '...OSSSSSSSSO...', '...OSBeSSeBSO...', '...OSSSSSSSSO...',
      '...OsSSSSSSsO...', '....OSSmmSSO....', '....OsSSSSsO....', '.....OSSSSO.....', '..OOWWOSSOWWOO..', '.OCCWWWOOWWWCCO.', 'OCCCCWWCCWWCCCCO', 'OCCCCCCCCCCCCCCO'] },
    /* Aldous Wren, farmer — a straw hat, sun-dark skin, stubble, a red kerchief */
    elm: { pal: { O: '#12161c', H: '#5a4630', h: '#3a2e1e', S: '#c9955a', s: '#a87a46', e: '#2a2118', m: '#7a4a3a', C: '#6e5a42', c: '#54432f', W: '#e8e0c8', R: '#c9553a', K: '#c9a05a', k: '#a08050', B: '#6e5a42' }, rows: [
      '.....OOOOOO.....', '....OKKKKKKO....', '.OOOOKkKKKkKOOOO', 'OKKKKKKKKKKKKKKO', '.OOOOSSSSSSOOOO.', '...OSSSSSSSSO...', '...OSeSSSSeSO...', '...OSSSSSSSSO...',
      '...OsSSSSSSsO...', '....OBSmmSBO....', '....OBBBBBBO....', '.....OBBBBO.....', '..OORROSSORROO..', '.OCCRRROORRRCCO.', 'OCCCCRRCCRRCCCCO', 'OCCCCCCCCCCCCCCO'] },
    /* Bo Tammen, head sawyer — a shaved head under a red band, a bull neck, a grin with teeth */
    mill: { pal: { O: '#12161c', H: '#3a2e1e', h: '#2a2118', S: '#d8b890', s: '#b8946e', e: '#2a2118', m: '#7a4a3a', C: '#8a6534', c: '#6e4f2a', W: '#e8e0c8', R: '#c9553a', B: '#3a2e1e' }, rows: [
      '................', '....OOOOOOOO....', '...OSSSSSSSSO...', '..ORRRRRRRRRRO..', '..OSSSSSSSSSSO..', '..OSSSSSSSSSSO..', '..OSBeSSSSeBSO..', '..OSSSSSSSSSSO..',
      '..OsSSSSSSSSsO..', '..OsSSWWWWSSsO..', '...OsSmWWmSsO...', '...OSSSSSSSSO...', '.OOOOSSSSSSOOOO.', 'OCCCCOSSSSOCCCCO', 'OCCCCCOOOOCCCCCO', 'OCCCCCCCCCCCCCCO'] },
    /* Dr. Imre Callas, botanist — wild grey hair, round glasses, a leaf-green collar */
    green: { pal: { O: '#12161c', H: '#9a9a8a', h: '#6e6e60', S: '#d8c0a0', s: '#b8a080', e: '#2a2118', m: '#8a5a4a', C: '#4a6e3a', c: '#3a5a2e', W: '#e8e0c8', G: '#a5c6e4', B: '#9a9a8a' }, rows: [
      '...OO.OOOO.OO...', '..OHHOHHHHOHHO..', '.OHHHHHHHHHHHHO.', '.OHhHHHHHHHHhHO.', '..OHSSSSSSSSHO..', '...OSSSSSSSSO...', '..OWWWWSSWWWWO..', '..OWGeWSSWeGWO..',
      '..OWWWWSSWWWWO..', '...OsSSSSSSsO...', '....OSSmmSSO....', '.....OSSSSO.....', '..OOOOOSSOOOOO..', '.OCCCCWOOWCCCCO.', 'OCCCCCCWWCCCCCCO', 'OCCCCCCCCCCCCCCO'] },
    /* Sela Marsh, forewoman — a headscarf tied back, stone-dust on the coat, a scar through one brow */
    quarry: { pal: { O: '#12161c', H: '#2a2118', h: '#1a1410', S: '#c9a07a', s: '#a8825e', e: '#2a2118', m: '#7a4a3a', C: '#6e747c', c: '#54595f', W: '#e8e0c8', R: '#8a6534', B: '#2a2118' }, rows: [
      '................', '.....OOOOOO.....', '....ORRRRRRO....', '...ORRRRRRRRORR.', '...ORRSSSSRROORO', '...OSSSSSSSSO.O.', '...OSeSSSSeSO...', '...OSSsSSSSSO...',
      '...OsSsSSSSsO...', '....OSSmmSSO....', '....OsSSSSsO....', '.....OSSSSO.....', '..OOOOOSSOOOOO..', '.OCCCCCOOCCCCCO.', 'OCCcCCCCCCCCcCCO', 'OCCCCCCCCCCCCCCO'] },
    /* Corporal Finch, signal keeper — a peaked cap, a thin moustache, the collar buttoned to the neck */
    relay: { pal: { O: '#12161c', H: '#3a2e1e', h: '#2a2118', S: '#d8b890', s: '#b8946e', e: '#2a2118', m: '#7a4a3a', C: '#3a4a3a', c: '#2a3a2a', W: '#e8e0c8', K: '#2a3a2a', k: '#1a2a1a', B: '#3a2e1e' }, rows: [
      '....OOOOOOOO....', '...OKKKKKKKKO...', '..OKKKKKKKKKKO..', '.OKkkkkkkkkkkKO.', '.OOOOSSSSSSOOOO.', '...OSSSSSSSSO...', '...OSeSSSSeSO...', '...OSSSSSSSSO...',
      '...OsSBBBBSsO...', '....OSSmmSSO....', '....OsSSSSsO....', '.....OSSSSO.....', '..OOOOWSSWOOOO..', '.OCCCCWOOWCCCCO.', 'OCCCCCWWWWCCCCCO', 'OCCCCCCCCCCCCCCO'] },
    /* Brand, smith — soot on the face, goggles pushed up on the brow, a leather apron strap */
    foundry: { pal: { O: '#12161c', H: '#1a1410', h: '#0e0c0a', S: '#c9a07a', s: '#8a6a4e', e: '#2a2118', m: '#6a3a2a', C: '#5a4a3a', c: '#453a2e', W: '#b8c2c8', w: '#6e747c', R: '#8a6534', B: '#1a1410' }, rows: [
      '................', '.....OOOOOO.....', '....OHHHHHHO....', '...OWwWWWWwWO...', '...OwWwSSwWwO...', '...OSSSSSSSSO...', '...OsBesSeBsO...', '...OSSsSSsSSO...',
      '...OssSSSSssO...', '....OSSmmSSO....', '....OsBBBBsO....', '.....OSSSSO.....', '..OOOOOSSOOOOO..', '.OCRCCCOOCCCRCO.', 'OCCRCCCCCCCCRCCO', 'OCCCRCCCCCCRCCCO'] },
    /* Keeper Aster, keeper of the great light — long pale hair, a sea-blue shawl, a gold pendant, kind eyes */
    pharos: { pal: { O: '#12161c', H: '#d8d2bd', h: '#b8b29d', S: '#d8c0a0', s: '#b8a080', e: '#3a4a66', m: '#8a5a4a', C: '#3a5a7a', c: '#2a4a6a', W: '#e8e0c8', R: '#ffd98f', B: '#d8d2bd' }, rows: [
      '.....OOOOOO.....', '....OHHHHHHO....', '...OHHHHHHHHO...', '..OHHSSSSSSHHO..', '..OHSSSSSSSSHO..', '..OHSSSSSSSSHO..', '..OHSeSSSSeSHO..', '..OHSSSSSSSSHO..',
      '..OHsSSSSSSsHO..', '..OHOSSmmSSOHO..', '..OHOsSSSSsOHO..', '..OHHOSSSSOHHO..', '.OOHHOOSSOOHHOO.', 'OCCOHOORROOHOCCO', 'OCCCOOCCCCOOCCCO', 'OCCCCCCCCCCCCCCO'] },
  };

  /* ---------- v3.44 THE WALKER'S FACE — the same 16×16 grammar as the keepers', but the colours are
     the Walker's own: the hood and the skin from the look they cut, the coat and its trim from the
     same table, so the bust on the door plate is the person in the coat, not a stranger. K/k hood ·
     S/s skin · e eye · m mouth · C/c coat · R the trim at the throat · O outline. The palette is bound
     at draw time by Render.walkerFaceURL from S.look; WALKER_FACE_PAL is the default coat. ---------- */
  const WALKER_FACE_PAL = { O: '#12161c', K: '#2c4258', k: '#1e2e3e', S: '#e0c298', s: '#b89a78', e: '#2a2118', m: '#8a5a4a', C: '#3d5a74', c: '#2c4258', R: '#c9a05a' };
  const WALKER_FACE = [
    '.....OOOOOO.....',
    '....OKKKKKKO....',
    '...OKKKKKKKKO...',
    '..OKKKkkkkKKKO..',
    '..OKKkSSSSkKKO..',
    '..OKkSSSSSSkKO..',
    '..OKkSeSSeSkKO..',
    '..OKkSSSSSSkKO..',
    '..OKksSSSSskKO..',
    '..OKKkSmmSkKKO..',
    '...OKkSSSSkKO...',
    '...OKKkSSkKKO...',
    '..OKKORRRROKKO..',
    '.OCCORRRRRROCCO.',
    'OCCCCORRRROCCCCO',
    'OCcCCCCCCCCCCcCO'];

  /* ---------- v3.45 THE HANDS' FACES — every hand on the keepers' 16×16 alphabet, composed from hand-drawn
     layers: the head (an oval or a square jaw) → the hair (eight styles; a hat hides what is above its brim)
     → the face's hair (stubble, a moustache, a beard, both) → the eyes (plain, close-set with brows, tired,
     wire glasses) → THE TRADE (what the work puts on them: the courier's cap and gold scarf, the rigger's
     goggles and hammer, the scavenger's hood and mask, the lightkeeper's mantle and flame pin, the
     mountaineer's flapped cap and rope, the medic's wrap with the green cross, the hearthkeeper's kerchief and
     apron, the drifter's brim and scarf, the lamplighter's deep hood and clasp, the mountain's helm and gorget,
     the town's flat cap and collar). The seed picks the skin, the hair and its colour, the jaw, the face's hair
     and the eyes — the same seed and trade give the same face every time. ---------- */
  const HANDS = {
    base: [
      '................',
      '................',
      '.....OOOOOO.....',
      '....OSSSSSSO....',
      '...OSSSSSSSSO...',
      '...OSSSSSSSSO...',
      '...OSeSSSSeSO...',
      '...OSSSSSSSSO...',
      '...OsSSSSSSsO...',
      '....OSSmmSSO....',
      '....OsSSSSsO....',
      '.....OSSSSO.....',
      '..OOOOOSSOOOOO..',
      '.OCCCCCOOCCCCCO.',
      'OCCCCCCCCCCCCCCO',
      'OCcCCCCCCCCCCcCO'],
    jaws: {
      oval: null,
      square: [
        '................', '................', '................', '................', '................', '................', '................', '................',
        '................',
        '...OSSSmmSSSO...',
        '...OsSSSSSSsO...',
        '....OSSSSSSO....',
        '..OOOOSSSSOOOO..',
        '................', '................', '................'],
    },
    hair: {
      crop: [
        '................',
        '.....OOOOOO.....',
        '....OHHHHHHO....',
        '...OHHHHHHHHO...',
        '...OHh....hHO...',
        '................', '................', '................', '................', '................', '................', '................', '................', '................', '................', '................'],
      long: [
        '................',
        '.....OOOOOO.....',
        '....OHHHHHHO....',
        '...OHHHHHHHHO...',
        '..OHh......hHO..',
        '..OH........HO..',
        '..OH........HO..',
        '..OH........HO..',
        '..OH........HO..',
        '..OH........HO..',
        '..OH........HO..',
        '..OHH......HHO..',
        '.OOHHO....OHHOO.',
        '...OHO....OHO...',
        '................', '................'],
      bun: [
        '......OOOO......',
        '.....OHhhHO.....',
        '....OOHHHHOO....',
        '...OHHHHHHHHO...',
        '...OHh....hHO...',
        '................', '................', '................', '................', '................', '................', '................', '................', '................', '................', '................'],
      curls: [
        '....OO.OO.OO....',
        '...OHHOHHOHHO...',
        '..OHHHHHHHHHHO..',
        '..OHhHHhHHhHHO..',
        '..OHh......hHO..',
        '..OH........HO..',
        '...O........O...',
        '................', '................', '................', '................', '................', '................', '................', '................', '................'],
      buzz: [
        '................',
        '................',
        '.....OOOOOO.....',
        '....OhhhhhhO....',
        '...Ohh....hhO...',
        '................', '................', '................', '................', '................', '................', '................', '................', '................', '................', '................'],
      swept: [
        '................',
        '....OOOOOOO.....',
        '...OHHHHHHHO....',
        '...OHHHHHHHHO...',
        '...OHHHh...hO...',
        '................',
        '................', '................', '................', '................', '................', '................', '................', '................', '................', '................'],
      braid: [
        '................',
        '.....OOOOOO.....',
        '....OHHHHHHO....',
        '...OHHHHHHHHO...',
        '...OHh....hHHO..',
        '............HHO.',
        '............OHO.',
        '............OhO.',
        '............OHO.',
        '............OhO.',
        '............OHO.',
        '............OhO.',
        '............OHO.',
        '............OhO.',
        '.............O..',
        '................'],
      bald: null,
    },
    facial: {
      none: null,
      stubble: [
        '................', '................', '................', '................', '................', '................', '................', '................',
        '................',
        '.....b....b.....',
        '.....bbbbbb.....',
        '......bbbb......',
        '................', '................', '................', '................'],
      moustache: [
        '................', '................', '................', '................', '................', '................', '................', '................',
        '......BBBB......',
        '................', '................', '................', '................', '................', '................', '................'],
      beard: [
        '................', '................', '................', '................', '................', '................', '................', '................',
        '................',
        '.....B....B.....',
        '.....BBBBBB.....',
        '......BBBB......',
        '................', '................', '................', '................'],
      full: [
        '................', '................', '................', '................', '................', '................', '................', '................',
        '......BBBB......',
        '.....BBmmBB.....',
        '.....BBBBBB.....',
        '......BBBB......',
        '.......BB.......',
        '................', '................', '................'],
    },
    eyes: {
      plain: null,
      close: [
        '................', '................', '................', '................', '................', '................',
        '....SBeSSeBS....',
        '................', '................', '................', '................', '................', '................', '................', '................', '................'],
      tired: [
        '................', '................', '................', '................', '................', '................', '................',
        '.....s....s.....',
        '................', '................', '................', '................', '................', '................', '................', '................'],
      glasses: [
        '................', '................', '................', '................', '................',
        '.....g....g.....',
        '....geggggeg....',
        '.....g....g.....',
        '................', '................', '................', '................', '................', '................', '................', '................'],
    },
    /* the trades — what the hand wears for the work, and what the work leaves on them */
    trades: {
      /* COURIER — the Order's knit cap rolled at the brim, a scarf in the trim's gold up to the chin */
      courier: { hat: 4, pal: { K: '#3d5a74', k: '#2c4258', C: '#3d5a74', c: '#2c4258', R: '#c9a05a', r: '#a5824a' }, rows: [
        '................',
        '.....OOOOOO.....',
        '....OKKKKKKO....',
        '...OKKKKKKKKO...',
        '...OkkkkkkkkO...',
        '................', '................', '................', '................', '................', '................',
        '....ORRRRRRO....',
        '..OORRrRRrRROO..',
        '.OCCORRRRRROCCO.',
        '................', '................'] },
      /* RIGGER — a rust beanie with the goggles pushed up on it, a coil of rope over the shoulder */
      rigger: { hat: 4, noGlasses: true, pal: { K: '#8a4a32', k: '#6b3426', C: '#5a5a4a', c: '#46463a', W: '#b8c2c8', w: '#6e747c', G: '#6fe3d2', Y: '#a08050', y: '#6e4f2a' }, rows: [
        '................',
        '.....OOOOOO.....',
        '....OKKKKKKO....',
        '...OWWWWWWWWO...',
        '...OWGWkkWGWO...',
        '................', '................', '................', '................',
        '................',
        '............OOO.',
        '...........OWWwO',
        '..........OYOOO.',
        '.OCCCCCOOOYyOCO.',
        'OCCCCCCCCYyCCCCO',
        'OCcCCCCCYyCCCcCO'] },
      /* SCAVENGER — a patched hood up, a cloth mask pulled down around the neck, a satchel strap */
      scavenger: { hat: 3, pal: { K: '#5a4a3a', k: '#453a2e', C: '#6e5a42', c: '#54432f', R: '#8a8f98', r: '#6e747c', Y: '#3a2e1e' }, rows: [
        '.....OOOOOO.....',
        '....OKKKKKKO....',
        '...OKKKkKKKKO...',
        '..OKKKKKKKKKKO..',
        '..OKk......kKO..',
        '..OK........KO..',
        '..OK........KO..',
        '..OK........KO..',
        '..OKk......kKO..',
        '..OKKO....OKKO..',
        '..OKKO....OKKO..',
        '..OKKORRRROKKO..',
        '.OKKOrRRRRrOKKO.',
        'OCCCCORRRROCYCCO',
        'OCCCCCCCCCCYCCCO',
        'OCcCCCCCCCYCCcCO'] },
      /* LIGHTKEEPER — a pale mantle over the shoulders, the high collar, the kept flame pinned at the throat */
      lightkeeper: { pal: { C: '#d8d2bd', c: '#b8b29d', W: '#e8e0c8', w: '#c9c3a8', R: '#ffd98f', r: '#e0a05e' }, rows: [
        '................', '................', '................', '................', '................', '................', '................', '................', '................', '................', '................',
        '....OwWWWWwO....',
        '..OOWWWRRWWWOO..',
        '.OCCCWWrrWWCCCO.',
        'OCCCCCWWWWCCCCCO',
        'OCcCCCCCCCCCCcCO'] },
      /* MOUNTAINEER — a fur-lined cap with the ear flaps down, the rope coiled on the shoulder */
      mountaineer: { hat: 4, pal: { K: '#8a4a32', k: '#6b3426', W: '#e8e0c8', w: '#c9c3a8', C: '#4a5a6e', c: '#3a4a5a', Y: '#c9b98a', y: '#a08050' }, rows: [
        '................',
        '.....OOOOOO.....',
        '....OKKKKKKO....',
        '...OKkKKKKkKO...',
        '..OwWWWWWWWWwO..',
        '..OKO......OKO..',
        '..OKO......OKO..',
        '...OO......OO...',
        '................', '................', '................', '................',
        '..........OYYO..',
        '.OCCCCCOOOYyyYO.',
        'OCCCCCCCCOYCCYOO',
        'OCcCCCCCCCOYYOcO'] },
      /* FIELD MEDIC — a white head-wrap, the bag's strap across the chest, a clean collar */
      medic: { hat: 4, pal: { K: '#e8e0c8', k: '#c9c3a8', C: '#4a6e5a', c: '#3a5a4a', W: '#e8e0c8', w: '#c9c3a8', Y: '#8a6534', y: '#6e4f2a', G: '#4a8a5a' }, rows: [
        '................',
        '.....OOOOOO.....',
        '....OKKGKKKO....',
        '...OKKGGGKKKO...',
        '...OkkkGkkkkO...',
        '................', '................', '................', '................', '................', '................', '................',
        '..OOOOWWWWOOOO..',
        '.OCCYyOWWOCCCCO.',
        'OCCCCYyCCCCCCCCO',
        'OCcCCCYyCCCCCcCO'] },
      /* HEARTHKEEPER — a kerchief knotted over the hair, the apron's bib at the chest */
      hearthkeeper: { hat: 4, pal: { K: '#7a5a7a', k: '#5a4058', W: '#e8e0c8', w: '#c9c3a8', C: '#8a4432', c: '#6b3426' }, rows: [
        '................',
        '.....OOOOOO.....',
        '....OKKKKKKO....',
        '...OKKKKKKKKOO..',
        '...OkkkkkkkkOKO.',
        '............OKO.',
        '.............O..',
        '................', '................', '................', '................', '................',
        '......W..W......',
        '.OCCCOWWWWOCCCO.',
        'OCCCCOWWWWOCCCCO',
        'OCcCCOWwwWOCCcCO'] },
      /* DRIFTER — a wide brim that has seen every weather, a long scarf gone grey */
      drifter: { hat: 4, pal: { K: '#4a3a2a', k: '#33241e', R: '#8a8578', r: '#6e6a5e', C: '#5a4a3a', c: '#453a2e' }, rows: [
        '................',
        '......OOOO......',
        '.....OKKKKO.....',
        '....OKKKKKKO....',
        '.OOOOkkkkkkOOOO.',
        'OKKKKKKKKKKKKKKO',
        '.OOOO......OOOO.',
        '................', '................', '................', '................', '................',
        '...OORRRRRRO....',
        '.OCCORrRRRRROCO.',
        'OCCCCCOOORrROCCO',
        'OCcCCCCCCORROCcO'] },
      /* LAMPLIGHTER — the exile's deep hood, the face in its own shadow, a lantern clasp at the throat */
      lamplighter: { hat: 3, noGlasses: true, pal: { K: '#2a2e36', k: '#1a1e24', C: '#33373f', c: '#23272e', R: '#ffd98f', r: '#c9a05a' }, rows: [
        '.....OOOOOO.....',
        '....OKKKKKKO....',
        '...OKKKKKKKKO...',
        '..OKKKKKKKKKKO..',
        '..OKkkkkkkkkKO..',
        '..OKk......kKO..',
        '..OK........KO..',
        '..OK........KO..',
        '..OKk......kKO..',
        '..OKKO....OKKO..',
        '..OKKO....OKKO..',
        '..OKKKO..OKKKO..',
        '.OKKKKOOOOKKKKO.',
        'OKKKKKKRRKKKKKKO',
        'OKKKKKKrrKKKKKKO',
        'OKkKKKKKKKKKKkKO'] },
      /* the MOUNTAIN'S OWN (a Farkeeper hire) — the grey helm with the nose guard, the iron gorget */
      farkeep: { hat: 4, noGlasses: true, pal: { K: '#8d979c', k: '#6e7a82', W: '#b8c2c8', C: '#4a565e', c: '#323c44', R: '#5a6a7a' }, rows: [
        '......OOOO......',
        '....OOWKKKOO....',
        '...OWKKKKKKKO...',
        '..OKKKKKKKKKKO..',
        '..OKkkkWWkkkKO..',
        '..OKO..WW..OKO..',
        '..OKO......OKO..',
        '...OO......OO...',
        '................', '................', '................',
        '....ORRRRRRO....',
        '..OORRRRRRRROO..',
        '.OCCCRRRRRRCCCO.',
        '................', '................'] },
      /* the TOWN'S OWN — a flat cap, the leather coat's collar turned up */
      town: { hat: 4, pal: { K: '#5a4630', k: '#3a2e1e', C: '#6e5a42', c: '#54432f', R: '#8a6534', r: '#6e4f2a' }, rows: [
        '................',
        '.....OOOOOO.....',
        '....OKKKKKKO....',
        '...OKKKKKKKKO...',
        '...OkkkkkkkkkkO.',
        '................', '................', '................', '................', '................', '................',
        '...ORO....ORO...',
        '..OORRO..ORROO..',
        '.OCCRROOOORRCCO.',
        '................', '................'] },
    },
  };
  /* the seed's own colours */
  const HAND_SKINS = [['#e0c8a8', '#c0a484'], ['#d8b890', '#b8946e'], ['#c9955a', '#a87a46'], ['#a87f5e', '#8a6248'], ['#8a6248', '#6e4a36'], ['#6e4a36', '#54382a']];
  const HAND_HAIRS = [['#1a1410', '#0e0c0a'], ['#2a2118', '#1a1410'], ['#5a4630', '#3a2e1e'], ['#8a5a32', '#6e4424'], ['#c9a05a', '#a08050'], ['#8a8578', '#6e6a5e'], ['#d8d2bd', '#b8b29d']];
  function handFace(seed, trade) {
    let a = seed >>> 0; const rng = () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
    const pick = arr => arr[Math.floor(rng() * arr.length)];
    const T = HANDS.trades[trade] || HANDS.trades.courier;
    const skin = pick(HAND_SKINS), old = rng() < 0.18, hair = old ? (rng() < 0.5 ? HAND_HAIRS[5] : HAND_HAIRS[6]) : pick(HAND_HAIRS.slice(0, 5));
    const hairKey = pick(['crop', 'crop', 'long', 'bun', 'curls', 'buzz', 'swept', 'braid', old ? 'bald' : 'crop']);
    const jaw = rng() < 0.4 ? 'square' : 'oval';
    const facial = pick(['none', 'none', 'none', 'stubble', 'moustache', 'beard', 'full']);
    const eyes = old ? (rng() < 0.3 && !T.noGlasses ? 'glasses' : 'tired') : pick(['plain', 'plain', 'plain', 'close', 'tired', rng() < 0.3 && !T.noGlasses ? 'glasses' : 'plain']);
    const mix = (h1, h2) => { const p = x => [1, 3, 5].map(i => parseInt(x.slice(i, i + 2), 16)); const A = p(h1), B = p(h2); return '#' + A.map((v, i) => Math.round((v + B[i]) / 2).toString(16).padStart(2, '0')).join(''); };
    const pal = { O: '#12161c', S: skin[0], s: skin[1], e: '#2a2118', m: mix(skin[1], '#7a3a2a'), H: hair[0], h: hair[1], B: hair[0], b: mix(skin[1], hair[0]), W: '#e8e0c8', w: '#c9c3a8', G: '#a5c6e4', g: '#5a5f66', C: '#4a4f57', c: '#383c44', ...T.pal };
    const rows = HANDS.base.map(r => r.split(''));
    const lay = (L, from = 0) => { if (!L) return; L.forEach((r, y) => { if (y < from) return; for (let x = 0; x < 16; x++) if (r[x] !== '.') rows[y][x] = r[x]; }); };
    lay(HANDS.jaws[jaw]); lay(HANDS.hair[hairKey], T.hat !== undefined ? T.hat + 1 : 0); lay(HANDS.facial[facial]); lay(HANDS.eyes[eyes]); lay(T.rows);   // headwear hides the hair above its brim
    return { rows: rows.map(r => r.join('')), pal, parts: { hairKey, jaw, facial, eyes, old } };
  }

  /* ---------- v3.45 THE CHIEFS' FACES — the man at the fire, and his brother who walked in when the rag came down ---------- */
  const CPAL = { O: '#150f0c', H: '#33241e', h: '#241a12', S: '#d8b890', s: '#b8946e', e: '#241a12', m: '#7a3a2a', R: '#c9553a', r: '#8a3a2c', C: '#8a4432', c: '#6b3426', F: '#c9b098', f: '#a08a70', T: '#5a4a3a', t: '#453a2e', B: '#33241e', d: '#8a4a3a' };
  const CHIEF_FACES = {
    /* the first chief — the red rag on the brow, its tails at the ear, a scar down the cheek, the fur collar */
    chief: { pal: CPAL, rows: [
      '................',
      '.....OOOOOO.....',
      '....OHHHHHHO....',
      '..OORRRRRRRRO...',
      '.ORrOrRRRRRrO...',
      '.OROOSSSSSSSO...',
      '..O.OSeSSSeSO...',
      '...OSSSSSSdSO...',
      '...OsSSSSSdsO...',
      '....OSSmmSdO....',
      '....OsSSSSsO....',
      '.....OSSSSO.....',
      '..OOFFOSSOFFOO..',
      '.OCCFfFOOFfFCCO.',
      'OCCCCFFCCFFCCCCO',
      'OCcCCCCCCCCCCcCO'] },
    /* the new chief — the same rag, a brother's beard and brows, the hide vest over the coat */
    chief2: { pal: CPAL, rows: [
      '................',
      '.....OOOOOO.....',
      '....OHHHHHHO....',
      '..OORRRRRRRRO...',
      '.ORrOrRRRRRrO...',
      '.OROOSSSSSSSO...',
      '..O.OBeSSeBSO...',
      '...OSSSSSSSSO...',
      '...OBSSSSSSBO...',
      '....OBBmmBBO....',
      '....OBBBBBBO....',
      '.....OBBBBO.....',
      '..OOTTOBBOTTOO..',
      '.OCCTtTOOTtTCCO.',
      'OCCCTTCCCCTTCCCO',
      'OCcCCCCCCCCCCcCO'] },
  };
  /* ---------- v3.45 THE KIN'S ERRAND — the fallen's round shield lying where it fell, and the lantern the kin asks
     to be kept lit at the stone (lit and dark) ---------- */
  const KPAL = { O: '#17130b', Y: '#a08050', y: '#6e5a42', W: '#b8c2c8', w: '#6e747c', F: '#ffd98f', f: '#e0a05e', g: '#6e747c', G: '#4a4f57' };
  const KINSHIELD_DOWN = ['..OOOOO..', '.OYYyYYO.', 'OYyYWYyYO', '.OYYyYYO.', '..OOOOO..'];
  const KINLANTERN = ['..O..', '.OYO.', 'OOOOO', 'OFfFO', 'OfFfO', 'OFfFO', 'OOOOO', 'OYYYO'];
  /* the lantern hung on the pack's back while it is carried — 3×5, the hook, the cage, the flame */
  const KINLANTERN_SMALL = ['.Y.', 'OOO', 'OFO', 'OfO', 'OOO'];
  const KINLANTERN_DARK = ['..O..', '.OYO.', 'OOOOO', 'OGgGO', 'OgGgO', 'OGgGO', 'OOOOO', 'OYYYO'];

  /* ---------- v3.46 THE WORD CARRIED ----------
     THE WORD ON THE WIRE — a letter walks the wire between the lit towns when your word is kept or broken: a
     folded note with its gold seal whole (kept) or its rust seal cracked (broken), 7×5, with a tail of its own
     colour. THE TRUCE ROAD — where a road crosses a camp's ring under a truce, a stake with a white rag stands at
     the ring's edge, 7×13 in the stake's shape. A SCORE SETTLED — the stone the one who fell leaves at the camp:
     two stones and the red thread, 8×7. THE CHIEF'S RUNNER — a knife sent with a gift: a cloth bundle tied with
     twine on his back and a white rag at the wrist, stamped on the rig's own grid. THE KEEPSAKES — six things a
     kin gives back, each a mark for the plates and a 2×3 token that hangs under the pack. */
  const WORD_PAL = { O: '#12161c', K: '#e8e0c8', k: '#c9c3a8', F: '#ffd98f', f: '#e0a05e', R: '#c9553a', r: '#8a3a2c' };
  const WORDNOTE = {
    kept:   ['OOOOOOO', 'OkKKKkO', 'OKkFkKO', 'OKKfKKO', 'OOOOOOO'],
    broken: ['OOOOOOO', 'OkKKKkO', 'OKRkrKO', 'OKKrKKO', 'OOOOOO.'],
  };
  const TRUCE_PAL = { O: '#150f0c', K: '#e8e0c8', k: '#b8b09a', Y: '#4a3320', y: '#33241e' };
  const TRUCESTAKE = ['..OYO..', '.OKKKO.', 'OKKYKKO', 'OkKYKkO', '.OkYkO.', '..OYO..', '.OKYO..', '.OkYO..', '..OYO..', '..OYO..', '..OyO..', '..OyO..', '..OyO..'];
  const SETTLE_PAL = { O: '#12161c', W: '#b8c2c8', w: '#6e747c', R: '#c9553a', r: '#8a3a2c' };
  const SETTLESTONE = ['..OOOO..', '.OWrrWO.', '.OwRRwO.', 'OOOOOOOO', 'OWWwWWwO', 'OwWWWWWO', 'OOOOOOOO'];
  /* the gift on the chief's runner: [column, row, letter] on the 12×18 rig, mirrored with the facing */
  const GIFT_PAL = { K: '#e8e0c8', k: '#b8b09a', Y: '#8a6534' };
  const GIFT_CELLS = [[1, 7, 'K'], [2, 7, 'K'], [1, 8, 'K'], [2, 8, 'Y'], [3, 8, 'K'], [1, 9, 'Y'], [2, 9, 'Y'], [3, 9, 'Y'], [1, 10, 'K'], [2, 10, 'Y'], [3, 10, 'k'], [1, 11, 'k'], [2, 11, 'k'], [3, 11, 'k'], [10, 9, 'K'], [10, 10, 'k']];
  const KEEPSAKES = {
    whetstone: { name: 'whetstone', mark: 'ks_whetstone', token: ['.Y', 'ww', 'wW'] },
    button:    { name: 'brass button', mark: 'ks_button', token: ['.Y', 'FF', 'fF'] },
    bird:      { name: 'carved bird', mark: 'ks_bird', token: ['.Y', 'PP', 'pP'] },
    whistle:   { name: 'tin whistle', mark: 'ks_whistle', token: ['.Y', 'WW', 'Ww'] },
    flower:    { name: 'pressed flower', mark: 'ks_flower', token: ['.Y', 'RR', 'gr'] },
    ring:      { name: 'iron ring', mark: 'ks_ring', token: ['.Y', 'ww', 'Ow'] },
  };
  const TOKEN_PAL = { Y: '#a08050', w: '#6e747c', W: '#b8c2c8', F: '#c9a05a', f: '#8a6534', P: '#8a6a42', p: '#5a4a3a', R: '#c9553a', r: '#8a3a2c', g: '#4a5a48', O: '#12161c' };

  /* ---------- v3.47 THE WORD ANSWERED ----------
     THE KEEPSAKE SET DOWN — each thing as it lies at the fallen's stone once the Walker sets it there, drawn larger than
     the token that hung under the pack (TOKEN_PAL). THE ROAD KEPT — the truce stake with a gold cord knotted new where
     the rag is tied; THE RAGS DOWN — the pole stripped (a white scrap left on the nail) and the rag in the dirt. THE
     STONES KICKED — the cairn scattered, its red thread loose. THE WATCH — the fire the line keeps behind it through
     the night (two frames, a ring of stones), and the white rag a Walker ties at the pack to walk a truce road. */
  const KEEPSAKE_SET = {
    whetstone: ['...OOOO', '..OWWwO', '.OWwwO.', 'OWwwO..', 'OwOO...', '.O.....'],
    button:    ['..OOO..', '.OFFFO.', 'OFOFOfO', 'OFFFFfO', 'OFOFOfO', '.OfffO.', '..OOO..'],
    bird:      ['..OO...', '.OPPO.O', 'OYPPPOP', '.OPPPPO', '..OpPO.', '..O.O..'],
    whistle:   ['.......', 'OOOOOOO', 'OWOWOWW', 'OwwwwwO', 'OOOOOOO', '.......'],
    flower:    ['.r.r...', 'rRrRr..', '.rFr.g.', 'rRrRrg.', '.r.rg..', '...g...', '..gg...'],
    ring:      ['.OOOOO.', 'OwWWWwO', 'OW...WO', 'OW...WO', 'OwWWWwO', '.OOOOO.'],
  };
  const TRUCESTAKE_KEPT = ['..OYO..', '.OKKKO.', 'OKKYKKO', 'OkKYKkO', '.OkYkO.', '.FFFFF.', '.OKFO..', '.OkFO..', '..OYO..', '..OYO..', '..OyO..', '..OyO..', '..OyO..'];
  const TRUCESTAKE_BARE = ['..OYO..', '..OYO..', '..OYOk.', '..OYO..', '..OYO..', '..OYO..', '..OYO..', '..OYO..', '..OYO..', '..OYO..', '..OyO..', '..OyO..', '..OyO..'];
  const RAG_DOWN = ['..OOOO..', '.OKKkKO.', 'OkKKKkKO', '.OOkKOO.'];
  const TRUCE_KEPT_PAL = { O: '#150f0c', K: '#e8e0c8', k: '#b8b09a', Y: '#4a3320', y: '#33241e', F: '#ffd98f' };
  const SETTLESTONE_DOWN = ['..OO......', '.OWwO..OO.', 'OWWwO.OWrO', '.OOO.rOwWO', '...rR..OO.'];
  const WATCHFIRE_PAL = { w: '#fff2d0', Y: '#ffd98f', R: '#e0654a', L: '#4a3320', l: '#6b4a30', O: '#12161c', W: '#8a8f98', V: '#5a626c' };
  const WATCHFIRE = [[
    '....w....',
    '...wY....',
    '...YYw...',
    '..YRYY...',
    '..RYRRY..',
    '.ORRYRRO.',
    'OWOLlLOWO',
    '.OVOOOVO.'], [
    '.........',
    '....Yw...',
    '...wYY...',
    '...YYRY..',
    '..YRRYR..',
    '.ORYRRRO.',
    'OWOLlLOWO',
    '.OVOOOVO.']];
  /* on the 12×18 rig: a switch stuck upright in the pack's back corner, clear of the head, the white rag tied at its top and
     streaming back — a truce-flag the knives read at a glance, and one that stays apart from anything lashed on the pack */
  const RAG_CELLS = [[1, 1, 'y'], [1, 2, 'Y'], [1, 3, 'Y'], [1, 4, 'Y'], [1, 5, 'Y'], [1, 6, 'Y'],
    [0, 1, 'K'], [-1, 1, 'K'], [0, 2, 'K'], [-1, 2, 'K'], [-2, 2, 'k'], [0, 3, 'k'], [-1, 3, 'k']];

  /* ---------- THE FLAME KEEPER TENDER — the promise at ALLY, kept: a robed figure with a torch,
     drawn small and still beside a fed bowl. Hand-authored, 12×18, the walker's grammar. ---------- */
  const TENDER_PAL = { O: '#12161c', H: '#642a2a', S: '#d8b890', e: '#2a2118', C: '#8a3a2a', c: '#642a2a', T: '#8a6534', t: '#6e5230', B: '#23282f', b: '#171b21', Y: '#ffb54f', y: '#ffd98f' };
  const TENDER = [
    '.....OOO....', '....OHHHO...', '...OHHHHHO..', '...OHSSeO...', '...OHSSSO...', '....OSSO...y',
    '...OOCCCCO.Y', '..OCCCCCCOOY', '..OCCOCCCCTO', '..OCcOCcCCTO', '..OCcOCcCCO.', '..OCcOCcCCO.',
    '..OcCCCCCcO.', '..OCCCCCCCO.', '..OCCCCCCCO.', '..OcCCCCCcO.', '...OOOOOOO..', '............',
  ];

  /* ---------- THE STABLE: filled by the pass — one row per breed, ramp derived per coat.
     ground: the texel under the hooves' centre · seat: where a rider's feet-centre sits.
     frames.walk holds the template's four strides; the renderer walks them on an UNEVEN cadence
     (the audited research: a 4-beat with two short beats reads as a living gait, not a loop). ---------- */
  const HORSES = {
    fjord: { w: 29, h: 23, pal: {"O": "#12161c", "M": "#6e4a4a", "b": "#8a6a4a", "B": "#a8845a", "L": "#9aa2ab", "l": "#d8dde2"}, ground: {"x": 13, "y": 22}, seat: {"x": 11, "y": 7},
      frames: { idle: [
        '......................B......',
        '.....................LBOOO...',
        '..................OOOLBOOO...',
        '.................lBBBBBOO....',
        '................lllllBBBO....',
        '...............lllllBBBBBO...',
        '.....OOOOO....llllllBBBBBO...',
        '..OOOllllOOOOOlllllBBBBBBBB..',
        '.lllllBBBBBBBllllBBBMBBBBBBO.',
        'OlllBBBBBBBBBBBBBBBBMOOOBBBO.',
        'OlOBBBBBBBBBBBBBBBBMMO..OOO..',
        'OlOBBBBBBBBBBBBBBBBMO........',
        'OlOBBBBBOBBBBBBBBBBMO........',
        'OlOBBBBBOBBBBBOBBBBMO........',
        'OlOBBBBBOMBBBBOBBBMO.........',
        'OlOOBBBBOMMMMOOBBBMO.........',
        'OO.OBBBOOOOOOOObBBO..........',
        '.O.OBBOO......ObBOO..........',
        '...OBMO.......ObBOO..........',
        '...OBMO.......ObBOO..........',
        '...OBBO.......ObbOO..........',
        '....BMMO......OOOOO..........',
        '.....OOO.......OOO...........',
      ], walk: [[
        '.............................',
        '.......................b.....',
        '......................lbMMM..',
        '...................lMMlBOMM..',
        '..................lllllBOO...',
        '................OOllllBBBO...',
        '......llOO.....llllllBBBBBM..',
        '...OOlllllOOOOOllllBBBBBBBM..',
        '..lllllBBBBBBBllllBBBBBBBBBB.',
        '.OlllBBBBBBBBBBBBBBBBBOBBBBBO',
        '.OlOBBBBBBBBBBBBBBBBBMOOBBBBO',
        '.MlOBBBBBBBBBBBBBBBBBM..OOOO.',
        '.MlOBBBBOMBBBBBBBBBBOO.......',
        '.OlOBBBBOMMBBBOBBBBBO........',
        '.OlOOBBBOMMMMMOBBBBOO........',
        '.OlOMBBBOOOOOObbOOBOO........',
        '.OOOMBBOOO..OOBBOObbO........',
        '.O.OBBOOOMO.OBBB..OOO........',
        '...OBB..OMOOOMB...OOBB.......',
        '...OBBO..OOBBM.....OBBO......',
        '....OOO..OOOO.......OOO......',
        '.............................',
        '.............................',
      ], [
        '......................Bb.....',
        '.....................bBbOOO..',
        '...................llbBBOOO..',
        '..................llllBBOO...',
        '.................lllllBBBO...',
        '................lllllBBBBMM..',
        '......OOOOO....lllllBBBBBBO..',
        '...OOlllllOOOOOllllBBBBBBBOO.',
        '..lllllBBBBBBBllllBBBBOBBBBO.',
        '.OlllBBBBBBBBBBBBBBBBBOOOBBO.',
        '.OlOBBBBBBBBBBBBBBBBMOO..OOO.',
        '.OlOBBBBBBBBBBBBBBBBMO.......',
        '.OlOBBBBBOBBBBBBBBBBMO.......',
        '.OlOBBBBBOBBBBBBBBBBMO.......',
        '.OlOBBBBBOBBBBBOBBBBO........',
        '.OlOOBBBBOOMMMBOOMBBO........',
        '.OO.OBBBOOOOOOOOOMBBO........',
        '..O.OBBB..OMMO...MBBBO.......',
        '....OBM..OOMO.....BBBO.......',
        '....OBM..OOOO......BBBB......',
        '.....OOOO.OOO.......OBBO.....',
        '.....OOOO...........OOOO.....',
        '.............................',
      ], [
        '.............................',
        '.......................B.....',
        '......................LBOOO..',
        '....................llLBOOO..',
        '..................OOlllBOO...',
        '................MMllllBBBO...',
        '......OOOOO....llllllBBBBBO..',
        '...OOlllllOOOOOllllBBBBBBBO..',
        '..lllllBBBBBBBllllBBBBBBBBBB.',
        '.OlllBBBBBBBBBBBBBBBBBOBBBBBO',
        '.OlOBBBBBBBBBBBBBBBBBMOOBBBBO',
        '.OlOBBBBBBBBBBBBBBBBMM..OOOO.',
        '.OlOBBBBBMBBBBBBBBBBMM.......',
        '.OlOBBBBBMMBBBOBBBBMM........',
        '.OlOOBBBOMMMMMOBBBBMO........',
        '.OlOBBBOOOOOOOBBBMMMOO.......',
        '.OOOBBOOOO..OOBBB.MMMO.......',
        '..OBBB.OMMO.OBBB...MMBB......',
        '..OBO..OMMOOOBB.....MBBO.....',
        '.OBBO...OOOOOO.......OOO.....',
        '.OOOO.....OOOO.......OOO.....',
        '.............................',
        '.............................',
      ], [
        '.......................B.....',
        '......................BBOOO..',
        '.....................lBBOOO..',
        '..................lOOllBOO...',
        '.................lllllBBBO...',
        '................lllllBBBBBM..',
        '......OOOOO....lllllBBBBBBM..',
        '...OOlllllOOOOlllllBBBBBBBBO.',
        '..lllllBBBBBBBlllBBBBBOBBBOO.',
        '.OlllBBBBBBBBBBBBBBBBBOOOBBO.',
        '.OlOBBBBBBBBBBBBBBBBBMM..OOO.',
        '.OlOBBBBBBBBBBBBBBBBB........',
        '.OlOBBBBBOBBBBBBBBBBO........',
        '.OlOBBBBBOBBBBBBBBBBO........',
        '.OlOBBBBBOMBBBBMBBBBO........',
        '.OlOOBBBMOMMMMMMBBBO.........',
        '.OlOOBBBMOOOOOOOBBBO.........',
        '.OOOOOBBO...ObOOOOBO.........',
        '.O.OO.BBO..OObO..OBO.........',
        '...OO..BBB..OOO..OBOO........',
        '.......BBBO.OOO...OOO........',
        '........OOO..................',
        '.............................',
      ]] } },    arabian: { w: 30, h: 22, pal: {"O": "#12161c", "M": "#48464c", "b": "#8a8f98", "B": "#9aa2ab", "L": "#b8bec6", "l": "#d8dde2"}, ground: {"x": 14, "y": 21}, seat: {"x": 11, "y": 6},
      frames: { idle: [
        '.......................MMM....',
        '....................MMMMMM....',
        '..................MMllllMM....',
        '.................llllllllM....',
        '................lllLLlllllM...',
        '......MMMMM....lllLLllllllMM..',
        '....MMllllMMMMMlllLlllMllllMM.',
        '...lllllllllllLlllllllMMMllMM.',
        '.MMlMlllllllllLllllllMM..MMM..',
        '.MllMllllBlllllllllllM........',
        '.MlbMllllBlllllllllllM........',
        '.MlbMllllBlLllllBllllM........',
        '.MlbMMlllMlLLLLLBlllM.........',
        '.MlbMMlllMMMLLLLBlllM.........',
        'MllMMMlll...MMMMMlll..........',
        'MlMMMlll........MlM...........',
        '.MM.MlM.........MlM...........',
        '....MlMM........MlM...........',
        '....MlMM........MlM...........',
        '.....MMMM.......MMMM..........',
        '.....MMMM........MMM..........',
        '......MM......................',
      ], walk: [[
        '..............................',
        '........................MMM...',
        '.....................MMMMMM...',
        '...................MMllllMM...',
        '..................lllLLLllM...',
        '.......MMMM.....MMlLLllllllM..',
        '.....MMlllMMMMMMllLLlllLlllM..',
        '....lllllllllllLlllllllLlllll.',
        '..MMlMlllllllllLlLlllllMMllllM',
        '..MllMlllllllllllLlllll.MMlllM',
        '..MllMlllllllllllllllM....MMM.',
        '..MllMlllLlllllLlllllM........',
        '..MlBMlllLlLLLLLllllM.........',
        '..MlBMlllMMLLLLLllllM.........',
        '.MllMllll.MMMMMLllllM.........',
        '.MlMMlll..M...MllMMlll........',
        'llM.MlM.MMl..llll..lllM.......',
        '.MM.MlM..MlMMlll....MlM.......',
        '....MlM..MMMMll.....MMM.......',
        '.....MMM..Mlll................',
        '.....MMM..MMM.................',
        '..............................',
      ], [
        '..............................',
        '........................MMM...',
        '.....................MMMMMM...',
        '...................MMllllMM...',
        '..................lllLllllM...',
        '......MMMMM.....MMllLLlllllM..',
        '....MMllllMMMMMMlllllllllllM..',
        '...llllllllllllllllllllMllllM.',
        '.MMlMlllllllllllllllllMMMMllM.',
        '.MlbMllllLllllllllllllM...MMM.',
        '.MlbMllllLllllllllllllM.......',
        '.MlbMllllLLLllllLlllllM.......',
        '.MlbMMlllLLLLLLLLlllll........',
        '.MlbMMllllMMLBBLLllLM.........',
        'MllMMMlllMbbMMMMMMlLM.........',
        'MlMMMlllMMbM......lllM........',
        'MMM.MllMMMMM.......MlM........',
        '....MlMMMMMMM......MllM.......',
        '....MlMMMMMMM.......MlM.......',
        '.....MlMMMM.........MMMM......',
        '.....MllM............MMM......',
        '.....MMMM.....................',
      ], [
        '..............................',
        '........................MMM...',
        '.....................MMMMMM...',
        '...................MMlllMMM...',
        '..................lllLLlllM...',
        '......MMMMM.....MMlllLlllll...',
        '....MMlllllMMMMMlllllllLllll..',
        '...llllllllllllllllllllLlllll.',
        '.MMlMllllllllllllllllllMMllllM',
        '.MllMllllLlllllllllllll.MMlllM',
        '.MlBMllllLlllllllllllM....MMM.',
        '.MlBMllllLLllllLlllllM........',
        '.MlBMMlllLLLLLLLllllMM........',
        '.MlBMMlllMMLLLLLlllllM........',
        '.MlllllMlbbMMMMlllMllM........',
        'llMllMMMMlM...MllMMMlll.......',
        '..MlMM..MlM..llll...lllM......',
        '..MlMM..MllMMlll.....MlM......',
        '..MlM....MlMMll......MMM......',
        '..MMMM...MMlll................',
        '..MMMM....MMM.................',
        '..............................',
      ], [
        '..............................',
        '........................MMM...',
        '.....................MMMMMM...',
        '...................MMllllMM...',
        '..................lllLLlllM...',
        '.......MMMMM....MMllLLlLlllM..',
        '......lllllMMMMMlllBlllLlllM..',
        '....MMlllllllllllllBlllMllllM.',
        '..MMMMllllllllllllllllMMMMllM.',
        '..MlMlllllLlllllllllllM...MMM.',
        '..MlMlllllLlllllllllllM.......',
        '..MlMlllllLLllllLLllllM.......',
        '..MlMllllllLLLLLLLlllM........',
        '..MlMMlllllMLLLLLLlllM........',
        '.lllMMMllllMMMMMMMMlM.........',
        'MllMM.Mllll..MllMMMlM.........',
        'MlMM..MllM...MlMM.MlM.........',
        'MMM....MlMM.MMlM..MllM........',
        '.......MllM..MMM...MlM........',
        '........MllMMMM....MMM........',
        '........MMllM.................',
        '.........MMMM.................',
      ]] } },    percheron: { w: 28, h: 22, pal: {"O": "#12161c", "M": "#0d1015", "b": "#151a24", "B": "#20262e", "L": "#232a36", "l": "#343c48"}, ground: {"x": 13, "y": 21}, seat: {"x": 10, "y": 7},
      frames: { idle: [
        '.....................bMM....',
        '...................MMbMMM...',
        '..................MMMMMM....',
        '.................LBBllllM...',
        '................bLllMllMM...',
        '...............BbbllMllMMM..',
        '.....MMMM....MMBBlllMllllLM.',
        '...MMlllMMMMMBBlllBbMMMLLLM.',
        '..MlMlllllllllllllBbMM.MMMM.',
        '.MMllllllllllllllllbMM..MM..',
        'MMMllllllllllllllllbM.......',
        'MbMlllllMlllllllllbbM.......',
        'MbMlllBBMbllllMllllM........',
        'MbMMlBBBMbblllMlllMM........',
        'Mb.MMLLM.bBBBMMlllM.........',
        'MM..MbbM..MMMMMllM..........',
        'M..MLLb.......MllM..........',
        'M..MbM........MllM..........',
        '...MbM........MMBB..........',
        '...MbbB.......MMM...........',
        '....MBBM.......MMMM.........',
        '....MMMM.......MMMM.........',
      ], walk: [[
        '............................',
        '......................M.M...',
        '...................MMMMMMM..',
        '..................lBBMMMM...',
        '................MBlBllMllM..',
        '...............MMBlllMBllM..',
        '.....MMMM....MMMbblllMBllMM.',
        '...MMlllMMMMMMMMBblllMBlllMM',
        '..MMMllllllllllBBbllMMMMlllM',
        '.MMlllllllllllllllbbMM.MMbbM',
        'MMMllllllllllllllllbMM...MM.',
        'MMMlllllMllllllllllbM.......',
        'M.MBBlllMblllllllllM........',
        'MM.MbbbMMbbllMLlllMM........',
        'M..MMllM.bbbbMLllMMM........',
        '...MMBM...MMMMLMMMMMM.......',
        '....MBM....MllLM..MBBM......',
        '....MMMM.MMMMMM....MMM......',
        '....MMMM.MMLLM.....MMM......',
        '...........MM...............',
        '............................',
        '............................',
      ], [
        '.....................M.M....',
        '....................LMMMMM..',
        '...................bLMMBM...',
        '..................LbbMMBMM..',
        '................MMLblMMllM..',
        '...............bbblllMllMM..',
        '.....MMMM....MMbbblllMllLLL.',
        '...MMlllMMMMMbbllbbbbMMMLLLM',
        '..MMMlllllllllllllbbbM.MMLLM',
        '.MMllllllllllllllllbbM...MM.',
        'MMMbllllllllllllllllM.......',
        'MBMbllllMllllllllllMM.......',
        'MBMbllblMbllllMllllMM.......',
        'MBMMbbblMbBbllMMllMM........',
        'MM..MMbMMMBbllMMBBlM........',
        'M...MLlM.MMMMMM.BBlM........',
        'M...MLlM.MMMM....BBMM.......',
        '.....MMM..MbM.....MMM.......',
        '.....MbM..MbM.....MMMM......',
        '.....MbbM.MMM......MMM......',
        '......MMM...................',
        '............................',
      ], [
        '............................',
        '......................M.M...',
        '...................MMMM.MM..',
        '..................MMBBMMM...',
        '................MMBMllMlMM..',
        '...............MMBBllMMllM..',
        '.....MMMM....MMMbbllbMLllMM.',
        '...MMlllMMMMMMbbbBblbMLLlMM.',
        '..MlllllllllllllBBbbbMMMllMM',
        '.MMlllllllllllllllbbMM.MMbbM',
        'MMMllllllllllllllllBMM...MM.',
        'MMMlllllMllllllllllBM.......',
        'MMMMllllMblllllllbMM........',
        'M.MMBBMMMbbllMlllbMM........',
        '..MMBBMMMMbMMMlllMMMM.......',
        '.MMMMMMM..MMMMlMMM.MMM......',
        '.MMMM..MM...MMlM...MMMM.....',
        '.MLM....MM..Mbl.....MMM.....',
        '.MLM....MM.MMb......M.......',
        '.MMM.......MMM..............',
        '...........MM...............',
        '............................',
      ], [
        '......................b.M...',
        '....................MMbMMM..',
        '...................MMBbMM...',
        '..................LbbBBbbM..',
        '.................bLLlMMllM..',
        '................MbbllMllMMM.',
        '.....MMMM.....MMMblllMllLLM.',
        '....MMlllMMMMMBBMblllMMMLLBM',
        '..MMlllllllllllBllbbbMM.LBBM',
        '.MMMlllllllllllllllbbMM..MM.',
        'MbbMllllllllllllllllMM......',
        'MbMMlllllMllllllllllMM......',
        'MbMMBBlllMbllllMllllM.......',
        'MbbMMBbBlMbblllMlllM........',
        '.MbMMMbBM.MBBBBMlllM........',
        '.MbM.MbMM.MMMMMMBBlM........',
        '.MbM.MMM...MMM..BBl.........',
        '.MM...MMM..MMM...BbbM.......',
        '.M....MMMM.MMM....MMM.......',
        '.......MMMM.................',
        '........MMM.................',
        '............................',
      ]] } },    icelandic: { w: 28, h: 22, pal: {"O": "#12161c", "b": "#c96a48", "B": "#b56a3e", "L": "#c9975a", "l": "#d8c090"}, ground: {"x": 13, "y": 21}, seat: {"x": 11, "y": 7},
      frames: { idle: [
        '.....................OO.....',
        '....................lOO.OO..',
        '..................OOlOOOOO..',
        '.................llllBBBO...',
        '................BlllOBBBO...',
        '...............lBlllOBBBBb..',
        '....OOOOOO....BlllllOBBBBbb.',
        '..OObbBBBOOOOOBlllllOBBBbbbO',
        '.llbBBBBBBBBBBbblllbOOObbbOO',
        'OllbBBBBBBBBBBBblllbO..OOOO.',
        'OlObBBBBBBBBBBBBlllbO.......',
        'OlObBBBbOBBBBBBBllllO.......',
        'OlObBBBbOBBBBBBBBBllO.......',
        'OlBOBBBbOBBBBBObBBlOO.......',
        'OlBOOBBBOBBBBBObBBBO........',
        'OlbObBBB.OOOOOObBBB.........',
        'OlbObBB.......ObbO..........',
        'OlOObO........ObbO..........',
        'OlOObOO.......ObbO..........',
        '.l.ObbO.......OObO..........',
        '....ObOO.......OBBO.........',
        '....OOOO.......OOOO.........',
      ], walk: [[
        '............................',
        '......................OO....',
        '...................OOObO.OO.',
        '..................LlllbOOBO.',
        '................bbLlllbBBB..',
        '....OOOOOO.....LbllllBBBBB..',
        '...LBBBBBBOOOOOLlllllBbBBBO.',
        '..lLBBBBBBBBBBBblllllbbBBBO.',
        '.llBBBBBBBBBBBBbbllllbbbbBBO',
        'OlOBBBBBBBBBBBBBBllllOObBBBO',
        'OlOBBBBBOBbBBBBBBlllOO.bbBOO',
        'OlOBBBBBOBbBBBBBBBllOO..OOO.',
        'OlOObBBBOBBBBOBBBBllO.......',
        'OlOObBBOOOBBOOBBBBlOO.......',
        'OlBObbO..OOOOBBBbbBO........',
        'OlBObOO....ObBBOOOBBb.......',
        'OlOObO.....ObBB...BBbO......',
        'OO.ObBO...ObbO.....OOO......',
        '...OBBO...ObOO.....OOO......',
        '....OOO...ObO...............',
        '..........OOO...............',
        '............................',
      ], [
        '............................',
        '......................OO....',
        '.....................lbO.OO.',
        '...................OOlbOOOO.',
        '.................OOlllbBBO..',
        '................OOlllObbbO..',
        '....OOOOOOO....BlllllObBbbB.',
        '..OOOBBBBBBOOOOBlllllObBBBBO',
        '.llBBBBBBBBBBBBBBllllOOBBBBO',
        'OllBBBBBbBbbBBBBBllllO.BBBBO',
        'OlOBBBBBbBBBBBBBBlllbO..OOO.',
        'OlOBBBBbOBBBBBBBBlllbO......',
        'OlOBBBBbOBBBbbOBBBllbO......',
        'OlOOBBBbOBBbbbOBBBblb.......',
        'OlbOOBBbObbBBbOBBBbbO.......',
        'OlbOOBBO.OOOOOOOOBbbOO......',
        'OlO.OOBO..ObbO...OObBO......',
        'OlO..OBO.OOOO.....OBBO......',
        'OlO..OBO.OOO.......ObbO.....',
        '.l...OBOO..........OOOO.....',
        '......OOO..........OOOO.....',
        '............................',
      ], [
        '............................',
        '......................OO....',
        '....................OObO.OO.',
        '..................OOllbOOOO.',
        '................BBLLllbbbO..',
        '....OOOOOO.....lBllllbbbbO..',
        '...BBBBBBBOOOOOlllllObBBbO..',
        '..lBBBBBBBBBBBBllllOOBBbbbB.',
        '.llBBBBBBBBBBBBBlllOObbbbbBO',
        'OlOBBBBBBBBBBBBBlllOOBBbbbbO',
        'OlOBBBBBBBBBBBBblllOO.BBbbOO',
        'OlOBBBBBOBBBBBbblllOO..OOOO.',
        'OlOOBBBBObBBBObbbBlO........',
        'OlOOBBBBObbBBOBbBBBO........',
        'OlOBOOBBOOOOOOBBBBOOO.......',
        'OlOB..BbbO..OBbBOOOBBB......',
        'OlOO...bbbb.OBbB..ObbbO.....',
        'OlOO....ObbOOBb....OOOO.....',
        'OllO....OOOObO......OOO.....',
        '.OOOO...OOOObO..............',
        '..........OOOO..............',
        '............................',
      ], [
        '......................OO....',
        '.....................LOO....',
        '...................OOLbO.OO.',
        '..................BbblbOOOO.',
        '.................bBlllBBBO..',
        '................lblllObBBO..',
        '....OOOOOOO....llllllObBBBB.',
        '...lbbBBBBbOOOOllllllObbbbB.',
        '.OOlBBBBBBbBBBBBlllllOObbbbO',
        '.OlOBBBBbbBBBBBbblllbO.BBbbO',
        'OllOBBBBBBBBbbBBblllbO..OOO.',
        'OllOBBBBBOBBBBBBBlllbO......',
        'OllOBBBBBOBBBBBBBBlBbO......',
        'OlbOOBBBbOBBBBOBBBbBb.......',
        'OlbO.BBBbObbbbOBBBbO........',
        'ObbO..Obb.OOOOOBBbbO........',
        'OlOO..ObO...OBOO.OOOO.......',
        'OlOO..ObO..OOBO...OOOO......',
        'OlO....bbB.OOBO....OOO......',
        '.l.....bbBOOOO.....OOO......',
        '........OOOO................',
        '............................',
      ]] } },    donkey: { w: 29, h: 24, pal: {"O": "#12161c", "M": "#573a3a", "b": "#5a6470", "B": "#7d8288", "L": "#b8bec6", "l": "#d8d2bd"}, ground: {"x": 13, "y": 23}, seat: {"x": 11, "y": 4},
      frames: { idle: [
        '.....................O..O....',
        '.....................OO.O....',
        '....................OBOOO....',
        '....................OBOO.....',
        '......OOOOOOOOOO...BBBBO.....',
        '......OBBBBOBMMOOOOBOBBBO....',
        '......OBBBBOBBMOOOBBOBBBOO...',
        '......OMMMMOMMMOOBBBOBBBBO...',
        '....OOOBBBBOBBMOOBBBOBBlllL..',
        '...BBBOMMMBOMMMOOBBBOBBBllLL.',
        '..OBBBOMMMMOBBMOOBBBBOOOllL..',
        '..OOBBOMMMMOBBOOOOBBO..OOO...',
        '..OOBBBOOOOOOOOOllBBO........',
        '..OOBBBBlllllllllllOO........',
        '..OOBBBBBlllllOBBllO.........',
        '.OOOOBBbbllllOOBBlO..........',
        'OO.OOBBOOOOOOOOBBlO..........',
        'OO.OOBO.......OBBO...........',
        'O..OOOO.......OBbO...........',
        '...OOOO.......OBbO...........',
        '...OOOOO......OBBOO..........',
        '...ObbOO......OBBOO..........',
        '....ObbO.......OOOO..........',
        '....OOO........OOO...........',
      ], walk: [[
        '.............................',
        '......................O..O...',
        '.......OOOOOOOOOO.....OO.O...',
        '.......OBBBBOBBMO....OBOOO...',
        '.......OBBBBOBBMO....OBOO....',
        '.......OMMMMOMMMO..OOBBBO....',
        '.......OBBBBOBBMOOObbOBBBb...',
        '.....OOOMMMBOMMMOOOBBOBBBbO..',
        '....BBBOMMMMOBBMOOBBBOBBBBO..',
        '...bBBBOMMMMOBBMOOBBBOBBllll.',
        '..ObBBBBOOOOOOOOOOBBBOBBbll..',
        '..OOBBBBBlllllllOlBBBBOOblll.',
        '..OOBBBbBlllllOOOllBBO..OOO..',
        '..OOBBBbbllllOOBBblOOO.......',
        '.OOOBBBbOOlllOOBBblOO........',
        '.OOOOBBOO.OOOOBBBOOO.........',
        'OO.ObBOO....OBBBOOOO.........',
        'OO.ObOO.....OBBB.OOOO........',
        '...ObOO....bBBB...OOOO.......',
        '...OOOOO..ObBO.....OOO.......',
        '....OO....ObbO.....OOO.......',
        '....OOO..OOOO................',
        '.........OOO.................',
        '.............................',
      ], [
        '......................O..O...',
        '......................OO.O...',
        '.....................OOO.O...',
        '.......OOOOOOOOOO....OOOO....',
        '.......OBBBBOBBMO...bBBBO....',
        '.......OBBBBOBBMOO.BbOBBBb...',
        '.......OMMMMOMMMOOOBBOBBBbO..',
        '.......OBBBBOBBMOOBBBOBBBBO..',
        '.....OOOMMMBOMMMOOBBBOBBlllL.',
        '....BBBOMMMMOBBMOOBBBOBBbllLL',
        '...OBBBOMMMMOBBMOOBBBBOObllL.',
        '...ObBBOOOOOOOOOOOOBBO..OOO..',
        '...ObBBBBlllllllOOObbO.......',
        '...ObBBBBlllllObBBBBOO.......',
        '..OOOBBBOllllOObBBbOO........',
        '.OO.OBBBOOOOOOOOBBbOO........',
        'OOO.OBBOO..OOOO.BBBOO........',
        'OO..ObbO...OOOO..BBBO........',
        '....ObO..OOOO.....BBO........',
        '....ObOO.OOO.......OOO.......',
        '....OBBO..OO.......OBBO......',
        '.....OBO............OBO......',
        '.....OOO............OOO......',
        '.............................',
      ], [
        '.............................',
        '......................O..O...',
        '......................OO.O...',
        '.......OOOOOOOOOO....OBO.O...',
        '.......OBBBBOBBMO....OBOO....',
        '.......OBBBBOBBMO..OOBBBO....',
        '.......OMMMMOMMMOOOOBOBBbO...',
        '.......OBBBBOBBMOOOBBOBBbO...',
        '....OOOOMMMBOMMMOOBBBOBBBBl..',
        '...BBBOOMMMMOBBMOOBBBOBBllll.',
        '..OBBBBOMMMMOBBMOOBBBOBBBll..',
        '..ObBBBBOOOOOOOOOlBBbbOOBlll.',
        '..ObBBBBBlllllllOllBBO..OOO..',
        '..ObBBBbBlllllOObbllOO.......',
        '..ObBBBbBllllOOBBbllO........',
        '.OObBBBbOOlllOBBBbbb.........',
        '.ObbBBOO..OOOOBBBOObB........',
        '.ObbOOOO....OOBBOOOBBB.......',
        '.ObO..OOO...OBBB...OBBO......',
        '.OOO..OOOO.bbBB....OOOO......',
        '.OOO...OOOObbO......OOO......',
        '.OOO......OOOO...............',
        '..........OOO................',
        '.............................',
      ], [
        '......................O..O...',
        '......................OO.O...',
        '.....................ObO.O...',
        '.......OOOOOOOOOO....ObOO....',
        '.......OBBBBOBBMO...bBBBO....',
        '.......OBBBBOBBMOO.BbOBBBb...',
        '.......OMMMMOMMMOOOBBOBBbbO..',
        '.......OBBBBOBBMOOBBBOBBbbO..',
        '.....OOOMMMBOMMMOOBBBOBBllll.',
        '....BBBOMMMMOBBMOOBBBOBBBBlll',
        '...OBBBOMMMMOBBMOOBBBBOOOlll.',
        '...OOBBOOOOOOOOMOlBBbO..OOO..',
        '..OOOBBBblllllllOlllbO.......',
        '..OOOBBBblllllllllllOO.......',
        '..OOOBBBbllllllOBBllO........',
        '.OOOOBBBbOllllOOLLLO.........',
        'OOOLOOBBbOOOOOOObbbO.........',
        'OOOLObbbO....OOOObbO.........',
        '.OOO..OBO...OOO..ObO.........',
        '..OO..OBBB..OOO..OOOO........',
        '.......BBBOOOO....OOO........',
        '........OBOOOO....OOO........',
        '........OOO.......OOO........',
        '.............................',
      ]] } },    mustang: { w: 27, h: 21, pal: {"O": "#12161c", "M": "#5c4232", "b": "#7a5138", "B": "#9a8468", "L": "#d8b890", "l": "#c9c4b8"}, ground: {"x": 12, "y": 20}, seat: {"x": 10, "y": 7},
      frames: { idle: [
        '......................M....',
        '....................ObM....',
        '..................OOObOO...',
        '.................OOOOBOO...',
        '................OOOOBBOOB..',
        '...............OOOOOBBBBB..',
        '....bbbb.....OOOOOBBBBBBBB.',
        '..OOBBBBbbbbBOOOBBBBbbBBBB.',
        '.OOOBBBBBBBBBOBOBBBBb.bbBB.',
        '.ObBBBBBBBBBBBBBBBBb....BB.',
        'OObBBBBbBBBBBBBBBBBb.......',
        'OObBBBBbBBBBBBBBBBb........',
        '.OOBBBBbbBBBBBbBBBb........',
        '.O.BBBBbbbBBBbbBBB.........',
        'OO.bBBbb.bbbbbbBBB.........',
        'O..bBBb.......bBb..........',
        '...BBB........bBb..........',
        '...BbM........bBb..........',
        '...BbM........bBb..........',
        '...ObOO.......bBOO.........',
        '...OOOOO.......OOO.........',
      ], walk: [[
        '...........................',
        '......................b....',
        '....................OObO...',
        '..................OOOObO...',
        '................OOOOOOBOO..',
        '...............OOOOOObBOO..',
        '....bbbb.....OOOOOOBObBOBB.',
        '..OOBBBBbbbbbBOOOBBBBBBBBBB',
        '.OOBBBBBBBBBBBBOBBBBBBBBBBB',
        '.OOBBBBBBBBBBBBBBBBBB..bbBB',
        'OOBBBBBbBBBBBBBBBBBb....bBB',
        'OOBBBBBbBBBBBBBBBBbb.......',
        'OObBBBBbbBBBBBBBBBb........',
        'OObBBBObbbBBbBBBBMb........',
        'OObBBOO..bbbbBBMMMbb.......',
        'O..Bb......bBBB..Mbb.......',
        'O..Mb.....BBBB....bB.......',
        '...MbO....BBB.....OBO......',
        '...OOO...OBO......OOO......',
        '.........OOO...............',
        '...........................',
      ], [
        '......................b....',
        '......................b....',
        '...................OOObO...',
        '.................OOOOObOO..',
        '................OOOOObBOO..',
        '...............OOOOOObBOB..',
        '....bbbb.....OOOOOBBBBBBBB.',
        '..OOBBBBbbbbbOOOOBBBBbbBBBB',
        '.OOBBBBBBBBBBOBOBBBBbb.bbBB',
        '.ObBBBBBBBBBBBBBBBBBb...bBB',
        'OObBBBBbBBBBBBBBBBBb.......',
        'OObBBBBbBBBBBBBBBBBb.......',
        '.OOBBBBbbBBBBBbBBBb........',
        '.OObBBBbbbBBBBbBBbb........',
        'OO.bBBB..bbbbOOBBb.........',
        'O..bBb......OO..bBB........',
        '...bBb.....bO...bBB........',
        '....bb...O.b.....BBB.......',
        '....bb...OOO......BBO......',
        '....bb............OOO......',
        '.....OOO...................',
      ], [
        '...........................',
        '......................b....',
        '......................bO...',
        '..................OOOObO...',
        '.................OOOOObbB..',
        '...............OOOOOOObbB..',
        '....bbbb.....OOOOObbOBBBBB.',
        '..OOBBBBbbbbbBOOOBBBbBBBBB.',
        '.OOBBBBBBBBBBBBOBBBBbBBBBBB',
        '.OOBBBBBBBBBBBBBBBBBb..BBBB',
        '.OBBBBBbBBBBBBBBBBBb....BBB',
        '.OBBBBBbBBBBBBBBBBbb.......',
        'OObBBBBbbBBBBBBBBBb........',
        'OObbBBbbbbBbbBBBBB.........',
        'OObbbO...bbbBBBMMM.........',
        'O.bbOOO....bBBB.MMMb.......',
        '.bM..OOO...bBB...bbbB......',
        '.bM....OO.Bbb......bBO.....',
        'ObM....OOOB........OOO.....',
        'OOO......OO................',
        '...........................',
      ], [
        '.......................b...',
        '.....................Obb...',
        '...................OOObOO..',
        '.................OOOOObOO..',
        '................OOOOOOBOO..',
        '...............OOOOOOBBOO..',
        '....bbbb.....OOOOOBBBBBBBB.',
        '...BBBBBbbbbbOOOOBBBBbbBBBB',
        '.ObBBBBBBBBBBOBOBBBBb..bbBB',
        'OObBBBBBBBBBBBBBBBBbb...bBB',
        'OObBBBBbBBBBBBBBBBBb.......',
        'OObBBBBbBBBBBBBBBBb........',
        'OO.bBBBbbBBBBBbBBBb........',
        'OO.bBBBbbbBBBBbBBb.........',
        'OO..bBBb..bbbOOBBb.........',
        'OO..bBBb....OO.bbbb........',
        'OO...bBb....OO..bBb........',
        'O....bbB...OO...bBb........',
        '......bBO..OO....BBO.......',
        '......OBOO..O....OOO.......',
        '......OOOOO................',
      ]] } },  };

  const CADENCE = [0.17, 0.11, 0.17, 0.11];   // seconds per walk frame — the unequal gait

  return { FK_PAL, RAID_PAL, TOWN_PAL, KIT, FIGURES, TENDER_PAL, TENDER, HORSES, CADENCE, RAGSTAKE, RAGSTAKE_PAL, MARKS, MARK_PAL, ARROW_IN, ARROW_PAL, FACES, BARESTAKE, SCAR, DRESSING, SCAR_PAL, WALKER_FACE, WALKER_FACE_PAL, RINGPIN, HANDS, HAND_SKINS, HAND_HAIRS, handFace, CHIEF_FACES, KINSHIELD_DOWN, KINLANTERN, KINLANTERN_DARK, KINLANTERN_SMALL, KPAL, WORD_PAL, WORDNOTE, TRUCE_PAL, TRUCESTAKE, SETTLE_PAL, SETTLESTONE, GIFT_PAL, GIFT_CELLS, KEEPSAKES, TOKEN_PAL, KEEPSAKE_SET, TRUCESTAKE_KEPT, TRUCESTAKE_BARE, RAG_DOWN, TRUCE_KEPT_PAL, SETTLESTONE_DOWN, WATCHFIRE_PAL, WATCHFIRE, RAG_CELLS };
})();
