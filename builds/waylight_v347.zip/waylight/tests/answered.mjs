/* answered.mjs — v3.47 THE WORD ANSWERED: the word answered (a door that never saw you keep a word, that has heard it kept
   three times down the wire, posts the keeper's errand on the wire's word; a door that has heard it broken twice shuts its
   promises by hearsay until it sees you do right there); the keepsake set down at the fallen's stone (the stone wears the
   thing, the kin's last letter); the road kept (the road's gift from any lit board walked to the chief's fire keeps the
   road; on the truce road the rag is up on the pack and the knives let you walk; run out ungifted, a new man pulls the
   rags down); the stone's keeping (your people stop at the cairns; a camp come back up kicks them over — a score again);
   the line's watch (a line left at a ring for the night: the camp stays in, the runs cross as at a truce, home at dawn,
   falling in at the door); the save. */
import { chromium } from 'playwright';
const results = [];
const ok = (name, cond, extra = '') => { results.push(`${cond ? 'PASS' : 'FAIL'}  ${name}${extra ? '  — ' + extra : ''}`); if (!cond) process.exitCode = 1; };
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium', args: ['--disable-background-networking'] });
const page = await b.newPage({ viewport: { width: 1440, height: 860 } });
await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
const errors = [];
page.on('pageerror', e => errors.push(String(e.message)));
await page.goto('file:///home/claude/waylight/dist/test.html?debug', { waitUntil: 'domcontentloaded' });
await page.waitForFunction(() => window.WL && WL.snapshot && WL.snapshot().baked, null, { timeout: 60000 });
await page.evaluate(() => localStorage.clear());
await page.click('#btnNew'); await page.waitForTimeout(300);
await page.click('#btnBegin'); await page.waitForTimeout(400);
await page.click('#briefGo'); await page.waitForTimeout(300);
await page.click('#cgBegin'); await page.waitForTimeout(1200);
for (let i = 0; i < 30; i++) { const c = await page.evaluate(() => !!S.cine); if (!c) break; await page.evaluate(() => WL.skipCine()); await page.waitForTimeout(250); }
await page.evaluate(() => { S.flags.guideDone = true; WL.calm(); S.flags.torchCross = S.flags.torchSeen = S.flags.torchNamed = true; S.flags.mythSeen = 9; });   // the first-sight scenes are spent: no letterbox takes a frame
const ev = (fn, arg) => page.evaluate(fn, arg);
await ev(() => {
  window.__toScr = (wx, wy) => { const z2 = Render.effZoom() / devicePixelRatio; return { x: innerWidth / 2 + (wx - Render.cam.x) * z2, y: innerHeight / 2 + (wy - Render.cam.y) * z2 }; };
  window.__near = (wx, wy, col, tol, rad) => { const p = __toScr(wx, wy), cv = document.getElementById('game'), g = cv.getContext('2d'), dpr = devicePixelRatio; const x0 = Math.max(0, Math.round((p.x - rad) * dpr)), y0 = Math.max(0, Math.round((p.y - rad) * dpr)), w = Math.round(rad * 2 * dpr); const d = g.getImageData(x0, y0, w, w).data; let hit = 0; for (let i = 0; i < d.length; i += 4) if (Math.abs(d[i] - col[0]) < tol && Math.abs(d[i + 1] - col[1]) < tol && Math.abs(d[i + 2] - col[2]) < tol) hit++; return hit; };
  window.__hex = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16));
  for (const k of Object.keys(REP.EVENTS)) S.rep.evCd[k] = 99999;
  for (const id of ['elm', 'mill', 'green', 'quarry', 'relay', 'foundry', 'pharos']) S.stations[id].connected = true;
  S.banked.metal = 900; S.banked.wood = 300; S.banked.provisions = 500; S.banked.ceramic = 120; S.cov = 0.6;
  for (let i = 0; i < 6; i++) S.npcs.push(NPC.gen({ at: 'haven' }));
});
const frame = async (fn, arg) => { await ev(fn, arg); await page.waitForTimeout(450); };
const drain = async () => { for (let i = 0; i < 150; i++) { const on = await ev(() => Render.crtActive && Render.crtActive()); if (!on) break; await page.waitForTimeout(200); } };
const at = f => ev(f => { const DL = DATA.T.dayLen; S.time = Math.floor(S.time / DL) * DL + DL * f; }, f);   // the hour of the day: by day 0.3, at night 0.75
const unfreeze = () => ev(() => { WL.timeScale = 1; Render.setZoom(null); });

/* ================= 1 · THE REGISTRIES ================= */
let r = await ev(() => {
  const inPal = (rows, pal, w, h) => rows.length === h && rows.every(rw => rw.length === w) && [...new Set(rows.join('').replace(/\./g, ''))].every(ch => pal[ch]);
  const NEW = ['answered', 'hearsay', 'setdown', 'roadkept', 'ragsdown', 'kicked', 'watch'];
  const marks = NEW.every(k => inPal(SPRITES.MARKS[k], SPRITES.MARK_PAL, 7, 7)) && new Set(Object.values(SPRITES.MARKS).map(m => m.join(''))).size === Object.keys(SPRITES.MARKS).length;
  const set = Object.keys(SPRITES.KEEPSAKES).every(k => { const rows = SPRITES.KEEPSAKE_SET[k]; return !!rows && rows[0].length === 7 && rows.length >= 5 && inPal(rows, SPRITES.TOKEN_PAL, 7, rows.length); }) && new Set(Object.values(SPRITES.KEEPSAKE_SET).map(x => x.join(''))).size === 6;
  const stakes = inPal(SPRITES.TRUCESTAKE_KEPT, SPRITES.TRUCE_KEPT_PAL, 7, 13) && inPal(SPRITES.TRUCESTAKE_BARE, SPRITES.TRUCE_KEPT_PAL, 7, 13) && inPal(SPRITES.RAG_DOWN, SPRITES.TRUCE_KEPT_PAL, 8, 4) && SPRITES.TRUCESTAKE_KEPT.join('').includes('F') && !SPRITES.TRUCESTAKE_BARE.join('').includes('K');
  const down = inPal(SPRITES.SETTLESTONE_DOWN, SPRITES.SETTLE_PAL, 10, 5);
  const fire = SPRITES.WATCHFIRE.length === 2 && SPRITES.WATCHFIRE.every(f => inPal(f, SPRITES.WATCHFIRE_PAL, 9, 8)) && SPRITES.WATCHFIRE[0].join('') !== SPRITES.WATCHFIRE[1].join('');
  const rag = SPRITES.RAG_CELLS.length >= 4 && SPRITES.RAG_CELLS.every(([c, r2, ch]) => c >= -2 && c < 12 && r2 >= 0 && r2 < 18 && SPRITES.TRUCE_KEPT_PAL[ch]);
  const g = Render.cargoGlyph({ defId: 'fireGift', cat: 'gift' }), gift = inPal(g.rows, g.pal, 8, 6);
  const T2 = DATA.T, rows = T2.word.answer.kept === 3 && T2.word.answer.broken === 2 && T2.kin.setLikes > 0 && T2.kin.setR > 0 && T2.road.gift.provisions > 0 && T2.road.roadW > 0 && T2.road.bareDays > 0 && T2.stone.pauseT > 0 && T2.stone.walk > 0 && T2.watch.fireR > 0 && T2.watch.fallInR > 0;
  const voices = DATA.stationOrder.every(id => ['answered', 'hearsay', 'seen'].every(k => DATA.keeperGrief[id][k]) && /\{town\}/.test(DATA.keeperGrief[id].answered));
  const lines = Object.keys(SPRITES.KEEPSAKES).every(k => /\{first\}/.test(DATA.keepsakeSetLines[k])) && ['own', 'others', 'kicked', 'kicker'].every(k => DATA.stoneLines[k].length >= 2) && ['kept', 'down', 'walk', 'gift'].every(k => DATA.roadLines[k].length >= 2) && ['order', 'dark', 'dawn', 'inside', 'home'].every(k => DATA.watchLines[k].length >= 2);
  const item = !!DATA.items.fireGift && DATA.items.fireGift.cat === 'gift' && Ledger.classify('fireGift') === 'gifts' && Ledger.coverage().length === 0;
  const lessons = ['firstAnswered', 'firstHearsay', 'firstKeepsakeSet', 'firstRoadKept', 'firstRagsDown', 'firstStonesKicked', 'firstWatch'].every(k => DATA.tutorials[k] && DATA.tutorialTitles[k]), lessonsN = Object.keys(DATA.tutorials).length;
  const causes = Object.keys(MUSTER.MOOD.causes).length, newCauses = MUSTER.MOOD.causes.cairn.v > 0 && MUSTER.MOOD.causes.watched.v > 0;
  return { marks, set, stakes, down, fire, rag, gift, rows, voices, lines, item, lessons, lessonsN, causes, newCauses };
});
ok('THE REGISTRIES: seven new marks (the word answered, shut by hearsay, the keepsake set down, the road kept, the rags down, the stones kicked, the watch) 7×7 in the marks\' palette and every mark distinct; six keepsakes as they lie at the stone; the stake kept (a gold knot) and stripped, the rag in the dirt; the stones kicked over; the watch fire\'s two frames; the rag at the pack on the rig\'s grid; the road\'s gift on the pack; the rows; twenty-four keeper lines for what the door made of the wire; the kin\'s last letters, the stones\', the road\'s and the watch\'s voices; the gift filed under Gifts; seven lessons (eighty); twenty-nine causes',
  r.marks && r.set && r.stakes && r.down && r.fire && r.rag && r.gift && r.rows && r.voices && r.lines && r.item && r.lessons && r.lessonsN === 80 && r.causes === 29 && r.newCauses, JSON.stringify(r));

/* ================= 2 · THE WORD ANSWERED ================= */
r = await ev(() => {
  const A = DATA.T.word.answer;
  S.wireWords = [];
  const b = Economy.book('quarry'), fresh = !b.kept && !b.errands && !b.answered;
  const land = (to, kind, n) => { for (let i = 0; i < n; i++) S.wireWords.push({ id: 'tw' + to + kind + i, from: 'haven', to, kind, name: 'a test word', t0: S.time - 1, eta: S.time - 0.01 }); Economy.update(0.01); };
  land('quarry', 'kept', A.kept - 1);
  const notYet = !b.answered && !Economy.answeredAt('quarry');
  land('quarry', 'kept', 1);
  const answered = !!b.answered && Economy.answeredAt('quarry') && b.log[0].kind === 'answered' && S.mails.some(m => /Quarry.*the word answered|the word answered/.test(m.subj)) && !!S.flags.tut.firstAnswered;
  const o = (Economy.ordersFor('quarry') || []).find(x => x.errand === 'quarry');
  const posted = !!o && o.answered === true;
  S.stations.quarry.met = true; WL.tp('quarry'); UI.openStation('quarry');
  const V = DATA.keeperGrief.quarry, plate = !!o && document.getElementById('keeperLine').textContent.includes(V.answered.replace(/\{town\}/g, DATA.stations[o.to].name).slice(0, 22));
  const header = /AN ERRAND ON THE WIRE'S WORD/.test(document.getElementById('bookLine').textContent);
  const card = /THE KEEPER'S ERRAND · ON THE WIRE'S WORD/.test(document.getElementById('stationBody').textContent);
  document.getElementById('stationClose').click();
  Systems.acceptOrder(o, false);
  const spent = !!b.answeredSpent && !b.wireCredit && !Economy.answeredAt('quarry') && S.orders.active.some(x => x.errand === 'quarry' && x.answered);
  const said = document.getElementById('keeperSay').textContent.includes(V.answered.replace(/\{town\}/g, DATA.stations[o.to].name).slice(0, 18));
  /* kept at the far door: the door has now seen it — the wire's credit no longer posts for it */
  const act = S.orders.active.find(x => x.errand === 'quarry'); WL.tp(act.to); WL.instantPar(); Systems.handleDelivery(act.to);
  land('quarry', 'kept', A.kept);
  const onlySeen = b.kept === 1 && !Economy.answeredAt('quarry') && !(Economy.ordersFor('quarry') || []).some(x => x.errand === 'quarry' && x.answered);
  return { fresh, notYet, answered, posted, plate, header, card, spent, said, onlySeen, to: o ? o.to : null };
});
const an1 = JSON.stringify(r), anOk1 = r.fresh && r.notYet && r.answered && r.posted && r.plate && r.header && r.card && r.spent && r.said && r.onlySeen;
r = await ev(() => {
  const A = DATA.T.word.answer, b = Economy.book('relay');
  const land = (to, kind, n) => { for (let i = 0; i < n; i++) S.wireWords.push({ id: 'tb' + to + kind + i + S.time, from: 'green', to, kind, name: 'a test word', t0: S.time - 1, eta: S.time - 0.01 }); Economy.update(0.01); };
  land('relay', 'broken', A.broken - 1);
  const notYet = !b.shut;
  land('relay', 'broken', 1);
  const shut = !!b.shut && b.shutBy === 'wire' && b.log[0].kind === 'hearsay' && S.mails.some(m => /shut by what it heard/.test(m.subj)) && !!S.flags.tut.firstHearsay && Economy.shutAt('relay');
  S.stations.relay.met = true; WL.tp('relay'); UI.openStation('relay');
  const header = /PROMISES SHUT — BY HEARSAY/.test(document.getElementById('bookLine').textContent);
  const plate = document.getElementById('keeperLine').textContent.includes(DATA.keeperGrief.relay.hearsay.slice(0, 24));
  UI.gotoTab('ledger'); const ledger = /SHUT BY HEARSAY/.test(document.getElementById('stationBody').textContent);
  document.getElementById('stationClose').click();
  /* a promise at the door is refused in its own words; a late delivery does not open it */
  S.grievances = S.grievances || []; const g = { id: 'gHear', to: 'relay', from: 'haven', kind: 'tin', name: 'a tin of nails', t: S.time, how: 'ground', n: 1, remembered: false }; S.grievances.push(g);
  const refused = !Economy.canPromise(g) && !Economy.giveWord('gHear', 'promise') && /by hearsay/.test(document.getElementById('toasts').textContent);
  S.grievances.splice(S.grievances.indexOf(g), 1);
  const lateStays = Economy.doneRight('relay', 'C') === null && !!b.shut;
  /* a delivery through the door in good time: the door sees it */
  let o = null; for (const id of DATA.stationOrder) { if (!S.stations[id].connected || o || id === 'relay') continue; o = (Economy.ordersFor(id) || []).find(x => x.to === 'relay' && !x.errand && !x.circuit && !x.convoy && !x.salvage) || null; if (o) WL.tp(id); }
  if (!o) return { notYet, shut, header, plate, ledger, refused, lateStays, order: false };
  Systems.acceptOrder(o, false); WL.tp('relay'); WL.instantPar();
  const res = Systems.handleDelivery('relay'), gd = res.results.find(x => x.seen);
  const opened = !!gd && !b.shut && !b.shutBy && b.log.some(e => e.kind === 'seen') && S.mails.some(m => /opens its door again/.test(m.subj));
  UI.queueResults(res.results, null); const slip = /SEEN AT THE DOOR/.test(document.getElementById('scoreRows').textContent); document.getElementById('results').classList.add('hidden');
  return { notYet, shut, header, plate, ledger, refused, lateStays, order: true, opened, slip };
});
ok('THE WORD ANSWERED: a door that never saw you keep a word hears it kept down the wire — at the third it answers (the mail, the lesson, the book): the keeper\'s errand posts on the wire\'s word, the plate says so in the keeper\'s voice, the header and the board carry it; accepted, the wire\'s credit is spent and the keeper says it to your face; kept at the far door, the door has seen it and the wire posts no more for it. A door that hears your word broken twice shuts by hearsay (the mail, the lesson, the book, the header, the plate, the Ledger); a promise there is refused in its words; a late delivery leaves it shut, and a delivery walked through it in good time opens it — the slip says SEEN AT THE DOOR',
  anOk1 && r.notYet && r.shut && r.header && r.plate && r.ledger && r.refused && r.lateStays && r.order && r.opened && r.slip, an1 + ' ' + JSON.stringify(r));

/* ================= 3 · THE KEEPSAKE SET DOWN ================= */
r = await ev(() => {
  const mr = Math.random, T2 = DATA.T;
  Republic.tick(0.01); for (const k of Object.keys(REP.EVENTS)) S.rep.evCd[k] = 99999;
  Republic.fundMountain(); Republic.mountain().t = REP.MOUNTAIN.dur + 1; Republic.tick(0.6);
  Republic.rebellionStrike('mill'); S.stations.mill.likesTo = 55;
  Republic.fundStorm('mill'); const q = Republic.quell(); Math.random = () => 0.9; q.t = q.dur + 1; Republic.tick(0.02); Math.random = mr;
  const a = Republic.recruitOwn('mill'), c = Republic.recruitOwn('mill'); a.name = 'Halvard Penrose'; c.name = 'Ottilie Marsh';
  NPC.setOrder(a, 'hours', 'nights'); NPC.setOrder(c, 'hours', 'nights');
  S.time = Math.floor(S.time / T2.dayLen) * T2.dayLen + T2.dayLen * 0.8;
  S.stations.mill.likesTo = 5; Republic.held().mill.shields = 2;
  Math.random = () => 0.1; Republic.squareRises('mill'); Math.random = mr;
  Memorial.raise('town'); Memorial.raise('town');
  S.time = Math.floor(S.time / T2.dayLen) * T2.dayLen + T2.dayLen * 1.3;
  const site = Memorial.site('town');
  const ds = S.drops.find(d => d.item && d.item.defId === 'kinShield'); State.addCargo(ds.item); S.drops.splice(S.drops.indexOf(ds), 1);
  WL.tp([site.x + 20, site.y + 40]);
  const give = Systems.getInteractions().find(i => i.key === 'G' && /Halvard's shield/.test(i.label)); give && give.fn();
  const it = S.cargo.find(x => x.keepsake && x.keepsake.fallen === 'Halvard Penrose');
  /* the compass marks the stone while the keepsake rides; at the stone, G sets it down */
  UI.tick(); const compass = [...document.querySelectorAll('#compassInner .cMark')].some(m => /set it down · Halvard/.test(m.title));
  const row = Memorial.rows('town').find(x => x.name === 'Halvard Penrose'), sl = Memorial.slotFor(row.ord, 'town');
  WL.tp([sl.x + 6, sl.y + 34]);
  const likes0 = S.stations.mill.likesTo, appr0 = S.stations.mill.appr || 0, K = T2.kin;
  const set = Systems.getInteractions().find(i => i.key === 'G' && /Set <b>Halvard's/.test(i.label)); set && set.fn();
  const leg = S.legacy.find(x => x.name === 'Halvard Penrose');
  const done = !!it && !!set && !S.cargo.includes(it) && leg.keepsake === it.keepsake.thing && S.stations.mill.likesTo === Math.min(100, likes0 + K.setLikes) && (S.stations.mill.appr || 0) > appr0;
  const letter = S.mails.some(m => m.subj.startsWith(it.keepsake.kin) && /Halvard's/.test(m.subj) && m.body.includes(DATA.keepsakeSetLines[it.keepsake.thing].replace(/\{first\}/g, 'Halvard').slice(0, 20)) && /I won't write again/.test(m.body));
  const lesson = !!S.flags.tut.firstKeepsakeSet, once = !Systems.getInteractions().some(i => /Set <b>Halvard's/.test(i.label));
  Memorial.open('town'); const card = [...document.querySelectorAll('#memBody .memCard')].some(el => /Halvard/.test(el.textContent) && /at the stone — you set it down/.test(el.textContent)); Memorial.close();
  return { compass, done, letter, lesson, once, card, thing: it ? it.keepsake.thing : null };
});
const ks1 = JSON.stringify(r), ksOk1 = r.compass && r.done && r.letter && r.lesson && r.once && r.card;
/* the stone wears it: the thing at the foot of the stone, against the same frame without it */
await drain(); await at(0.3);
const setSeen = await ev(async () => {
  const leg = S.legacy.find(x => x.name === 'Halvard Penrose'), rowsK = SPRITES.KEEPSAKE_SET[leg.keepsake];
  const counts = {}; for (const rw of rowsK) for (const ch of rw) if (ch !== '.' && ch !== 'O') counts[ch] = (counts[ch] || 0) + 1;
  const main = Object.entries(counts).sort((a, b2) => b2[1] - a[1])[0][0], col = __hex(SPRITES.TOKEN_PAL[main]);
  const row = Memorial.rows('town').find(x => x.name === 'Halvard Penrose'), sl = Memorial.slotFor(row.ord, 'town');
  WL.tp([sl.x + 70, sl.y + 60]); S.dir = 0; Render.setZoom(3); Render.cam.x = sl.x; Render.cam.y = sl.y + 10; WL.timeScale = 0.001;
  await new Promise(res => setTimeout(res, 400));
  const hRows = row.tier === 'grand' ? 14 : row.tier === 'mid' ? 11 : 9, tx = row.tier === 'grand' ? 3.5 : 3;   // the stone's own height: the thing lies at its foot
  const foot = sl.y + hRows * tx * 0.5 + 3 - rowsK.length, withIt = __near(sl.x + 3, foot, col, 22, 16);
  const th = leg.keepsake; leg.keepsake = null;
  await new Promise(res => setTimeout(res, 300));
  const without = __near(sl.x + 3, foot, col, 22, 16);
  leg.keepsake = th; WL.timeScale = 1; Render.setZoom(null);
  return { withIt, without, main };
});
ok('THE KEEPSAKE SET DOWN: while Halvard\'s keepsake rides, the compass marks his stone; at the stone G sets it down — it leaves the pack, the row wears the thing, the Mill is warmer (likes and appreciation), the kin write one last time (their line for the thing, "I won\'t write again"), the lesson; the stone takes it once; the memorial card says it; the thing lies at the foot of the stone (pixel-sampled against the same frame without it)',
  ksOk1 && setSeen.withIt > setSeen.without + 6, ks1 + ' ' + JSON.stringify(setSeen));

/* ================= 4 · THE ROAD KEPT ================= */
r = await ev(() => {
  const ash = DATA.camps.find(c => c.id === 'ash'), c = S.camps.ash, T2 = DATA.T, st = DATA.stations;
  c.taken = null; c.pacified = false; c.truce = 0; c.pact = null; c.runners = []; c.grudge = null;
  S.cargo = S.cargo.filter(x => x.cat === 'tool'); S.orders.active.length = 0;
  const n = S.npcs.find(x => x.state === 'pool' && x.at === 'haven'); S.cov = 0.6; NPC.assignRoute(n, 'foundry', 'pharos');   // coverage opens the charters
  c.pact = { t: S.time }; Republic.tick(0.02);
  const listed = Republic.roadCamps().some(cd => cd.id === 'ash') && Republic.wordLeft(ash) > 0;
  WL.tp('haven'); S.stations.haven.met = true; UI.openStation('haven');
  const card = /THE ROAD'S GIFT/.test(document.getElementById('stationBody').textContent) && !!document.querySelector('#stationBody [data-roadgift="ash"]');
  window.__road = { n: n.id };
  return { listed, card, pv0: S.banked.provisions, mt0: S.banked.metal };
});
const rd0 = r;
if (!rd0.card) console.log('ROADDBG', JSON.stringify(rd0), JSON.stringify(await ev(() => ({ open: !document.getElementById('stationOv').classList.contains('hidden'), cur: document.getElementById('stationName').textContent, camps: Republic.roadCamps().map(c => c.id), open2: Republic.crossable(DATA.camps.find(c => c.id === 'ash')), through: Republic.roadsThrough(DATA.camps.find(c => c.id === 'ash')).length, route: S.npcs.filter(n => n.state === 'route').map(n => n.route.a + '>' + n.route.b), roll: DATA.camps.find(c => c.id === 'ash').roll, body: document.getElementById('stationBody').textContent.slice(0, 200) }))));
await page.click('#stationBody [data-roadgift="ash"]'); await page.waitForTimeout(400);
r = await ev(rd0 => {
  const ash = DATA.camps.find(c => c.id === 'ash'), R = DATA.T.road;
  const gift = Republic.giftFor('ash'), taken = !!gift && gift.defId === 'fireGift' && S.banked.provisions === rd0.pv0 - R.gift.provisions && S.banked.metal === rd0.mt0 - R.gift.metal;
  const onPack = /on your pack/.test(document.getElementById('stationBody').textContent);
  document.getElementById('stationClose').click();
  Guide.tick(0.3); const gs = Guide.current(), guide = !!gs && gs.id === 'roadgift';
  UI.tick(); const compass = [...document.querySelectorAll('#compassInner .cMark')].some(m => /the road's gift · Ash/.test(m.title) || (m.classList.contains('guide') && /^Walk the road's gift|^Ash/.test(m.title)));   // the guide's own mark stands where the gift's would
  return { taken, onPack, compass, guide };
}, rd0);
const road1 = JSON.stringify(rd0) + ' ' + JSON.stringify(r), roadOk1 = rd0.listed && rd0.card && r.taken && r.onPack && r.compass && r.guide;
/* on the truce road, loaded, the knives let you walk; off it they do not (the gift set aside to test the road alone) */
r = await ev(() => {
  const ash = DATA.camps.find(c => c.id === 'ash'), c = S.camps.ash, st = DATA.stations, A = st.foundry, B = st.pharos;
  const cross = Republic.ringCross(A.x, A.y + 40, B.x, B.y + 40, ash), mid = { x: (cross[0].x + cross[1].x) / 2, y: (cross[0].y + cross[1].y) / 2 };
  const g = Republic.giftFor('ash'); S.cargo.splice(S.cargo.indexOf(g), 1); window.__gift = g;
  S.cargo.push(State.makeItem('metal'));
  const trial = (x, y) => { WL.tp([x, y]); S.stagger = 0; S.struggle = null; const hp0 = S.health, n0 = S.cargo.length, k = { x: S.px + 26, y: S.py - 6, cd: 0, cls: 'knife', wa: 0, state: 'patrol' }; c.runners = [k]; for (let i = 0; i < 20; i++) { Systems.update(0.1, {}); } const hit = S.health < hp0 - 0.5 || S.cargo.length !== n0 || (S.stagger || 0) > 0; c.runners = []; S.stagger = 0; return hit; };
  const onIt = Republic.onRoad(ash) === false ? null : null;
  WL.tp([mid.x, mid.y]); const road = Republic.onRoad(ash) && Republic.onAnyRoad();
  const onHit = trial(mid.x, mid.y);
  const ux = B.x - A.x, uy = B.y - A.y, ul = Math.hypot(ux, uy), off = { x: mid.x - uy / ul * 260, y: mid.y + ux / ul * 260 };
  WL.tp([off.x, off.y]); const offRoad = !Republic.onRoad(ash) && U.dist(off.x, off.y, ash.x, ash.y) < ash.r;
  const offHit = trial(off.x, off.y);
  window.__mid = mid; window.__off = off;
  return { road, onHit, offRoad, offHit };
});
const road2 = JSON.stringify(r), roadOk2 = r.road && !r.onHit && r.offRoad && r.offHit;
/* the rag at the pack, seen: on the road and off it */
await drain(); await at(0.3);
const ragSeen = await ev(async () => {
  const col = __hex('#e8e0c8');
  const look = async p => { WL.tp([p.x, p.y]); S.dir = 0; Systems.update(0.02, {}); Render.clearFx(); Render.setZoom(3); Render.cam.x = S.px; Render.cam.y = S.py - 16; WL.timeScale = 0.001; await new Promise(res => setTimeout(res, 380)); const n = __near(S.px - 12, S.py - 22, col, 18, 18); WL.timeScale = 1; return n; };
  const on = await look(__mid), off = await look(__off);
  Render.setZoom(null);
  return { on, off };
});
/* the gift walked to the fire: the road kept */
r = await ev(() => {
  const ash = DATA.camps.find(c => c.id === 'ash'), c = S.camps.ash, P = DATA.T.parley;
  S.cargo = S.cargo.filter(x => x.cat === 'tool'); S.cargo.push(__gift);
  c.pact.t = S.time - DATA.T.dayLen * 2;   // the word nearly run
  WL.tp([ash.x - 30, ash.y + 60]);
  const give = Systems.getInteractions().find(i => i.key === 'G' && /the road's gift/.test(i.label)); give && give.fn();
  const kept = !!give && !Republic.giftFor('ash') && Math.abs(c.pact.t - S.time) < 0.01 && c.pact.kept === 1 && Math.abs(c.roadKept - S.time) < 0.01 && Republic.pactAt(ash) && S.mails.some(m => /the road kept/.test(m.subj)) && !!S.flags.tut.firstRoadKept;
  const roll = /the road kept/.test(UI.campRollHTML(ash, true));
  return { kept, roll };
});
const road3 = JSON.stringify(r), roadOk3 = r.kept && r.roll;
/* the gold knot new on the pole, seen */
await drain(); await at(0.3);
const knotSeen = await ev(async () => {
  const st = DATA.stations, A = st.foundry, B = st.pharos, ash = DATA.camps.find(c => c.id === 'ash'), p = Republic.ringCross(A.x, A.y + 40, B.x, B.y + 40, ash)[0];
  WL.tp([p.x + 30, p.y + 24]); S.dir = 0; Render.setZoom(2.6); Render.cam.x = p.x; Render.cam.y = p.y; WL.timeScale = 0.001;
  await new Promise(res => setTimeout(res, 380));
  const gold = __near(p.x, p.y - 18 + 5 * 2.5 + 1, __hex('#ffd98f'), 30, 14);
  const t0 = S.camps.ash.roadKept; S.camps.ash.roadKept = S.time - DATA.T.dayLen * 2;
  await new Promise(res => setTimeout(res, 300));
  const plain = __near(p.x, p.y - 18 + 5 * 2.5 + 1, __hex('#ffd98f'), 30, 14);
  S.camps.ash.roadKept = t0; WL.timeScale = 1; Render.setZoom(null);
  return { gold, plain, p };
});
/* run out ungifted: a new man, the rags down */
r = await ev(() => {
  const ash = DATA.camps.find(c => c.id === 'ash'), c = S.camps.ash, P = DATA.T.parley, DL = DATA.T.dayLen, gen0 = c.chiefGen || 0;
  c.pact.t = S.time - P.pactDays * DL - 1; Republic.tick(0.02);
  const down = !!c.ragsDown && !c.ragsDown.broke && c.ragsDown.pts.length === 2 && (c.chiefGen || 0) === gen0 + 1 && !!c.newChief && !Republic.truceRoadFor('foundry', 'pharos') && S.mails.some(m => /the rags came down/.test(m.subj) && /their own man/.test(m.body)) && !!S.flags.tut.firstRagsDown;
  const roll = /the rags down/.test(UI.campRollHTML(ash, true));
  c.ragsDown.t = S.time - 8;   // the scene played: the poles bare, the rags in the dirt
  window.__rp = c.ragsDown.pts[0];
  return { down, roll, gen: c.chiefGen };
});
const road4 = JSON.stringify(r), roadOk4 = r.down && r.roll;
await drain(); await at(0.3);
const bareSeen = await ev(async () => {
  const p = __rp; WL.tp([p.x + 34, p.y + 30]); S.dir = 0; Render.setZoom(2.6); Render.cam.x = p.x + 6; Render.cam.y = p.y; WL.timeScale = 0.001;
  await new Promise(res => setTimeout(res, 380));
  const col = __hex('#e8e0c8'), top = __near(p.x, p.y - 12, col, 20, 14), ground = __near(p.x + 12, p.y + 14, col, 20, 12);
  WL.timeScale = 1; Render.setZoom(null);
  return { top, ground };
});
/* a word broken brings them down too — the same chief */
r = await ev(() => {
  const ash = DATA.camps.find(c => c.id === 'ash'), c = S.camps.ash, gen0 = c.chiefGen || 0;
  c.ragsDown = null; c.pact = { t: S.time }; Republic.tick(0.02);
  const took = Republic.fundTake('ash'); S.rep.quell = null; Republic.tick(0.02);
  const broke = !!took && !!c.ragsDown && c.ragsDown.broke === true && (c.chiefGen || 0) === gen0 && S.mails.some(m => /the rags came down/.test(m.subj) && /You broke your word/.test(m.body));
  S.fireWordBroken = 0; S.rep && (S.rep.reprisal = null); c.ragsDown = null;
  return { broke };
});
ok('THE ROAD KEPT: while Ash holds your word and a charter road crosses its ring, every lit board offers THE ROAD\'S GIFT (a real click takes it: the bank pays, the pack carries it; the card, the compass and the guide follow it); on the truce road inside the ring a loaded Walker walks and the knives let them (off the road they do not), the white rag tied at the pack (pixel-sampled, on the road and off it); the gift given at the fire keeps the road — the word renewed, counted, the mail, the lesson, the roll — and the poles wear a gold knot new (pixel-sampled against the plain stake); run out ungifted, a new man comes up and the rags come down (the mail, the lesson, the roll, the road shut) — the poles bare and the rags in the dirt (pixel-sampled); a word broken brings them down with the same chief',
  roadOk1 && roadOk2 && ragSeen.on > ragSeen.off + 4 && roadOk3 && knotSeen.gold > knotSeen.plain + 4 && roadOk4 && bareSeen.ground > 6 && bareSeen.top < 20 && r.broke, road1 + ' ' + road2 + ' rag=' + JSON.stringify(ragSeen) + ' ' + road3 + ' knot=' + JSON.stringify({ g: knotSeen.gold, p: knotSeen.plain }) + ' ' + road4 + ' bare=' + JSON.stringify(bareSeen) + ' ' + JSON.stringify(r));

/* ================= 5 · THE STONE'S KEEPING ================= */
r = await ev(() => {
  const ash = DATA.camps.find(c => c.id === 'ash'), c = S.camps.ash, St = DATA.T.stone;
  c.pacified = true; c.pact = null; c.truce = 0; c.runners = [];
  for (const x of S.npcs.filter(y => y.state === 'companion')) x.state = 'pool';
  const n = S.npcs.find(x => x.state === 'pool' && x.at === 'haven'); NPC.hire(n, 'companion');
  const first = n.name.split(' ')[0], sx = ash.x + 40, sy = ash.y + ash.r + 60;
  const st2 = { x: sx, y: sy, name: first, npc: n.id, camp: 'ash', t: S.time, how: 'stood down', calm: true };
  Republic.settleStones().length = 0; Republic.settleStones().push(st2);
  n.settled = [{ camp: 'ash', t: S.time + 2, how: 'stood down' }]; n.settledT = S.time - 99999;
  /* passing: the one who set it stops a beat, faces it, and says so; their stones seen standing lift them */
  WL.tp([sx + 160, sy + 40]); n.cx = sx + 40; n.cy = sy + 6; n.pauseT = 0; n.stonePass = {};
  const says0 = Render.clearFx(); NPC.update(0.05);
  const paused = n.pauseT > 0 && Math.abs(n.pauseDir - Math.atan2(sy - (sy + 6), sx - (sx + 40))) < 0.3 && !!n.cairnT && /cairn/.test(JSON.stringify(NPC.mood(n)));
  const cx0 = n.cx; NPC.update(0.3); const held = Math.abs(n.cx - cx0) < 1;
  /* the Order's walkers on the road stop too */
  const amb = NPC.ambient(), w = { n: NPC.gen({}), pts: [[sx - 140, sy + 20], [sx + 140, sy + 20]], len: 280, d: 110, sp: 90, said: false, crates: 1 }; amb.push(w);
  NPC.update(0.05); const d0 = w.d; NPC.update(0.3); const ambStop = w.pauseT > 0 && Math.abs(w.d - d0) < 0.5; amb.splice(amb.indexOf(w), 1);
  window.__st = { x: sx, y: sy, n: n.id };
  return { paused, held, ambStop };
});
const sk1 = JSON.stringify(r), skOk1 = r.paused && r.held && r.ambStop;
/* the cairn standing, seen; then the camp comes back up and a knife kicks it over */
await drain(); await at(0.3);
const standSeen = await ev(async () => { const s2 = __st; WL.tp([s2.x + 60, s2.y + 50]); S.dir = 0; for (const n of NPC.party()) { n.cx = s2.x + 120; n.cy = s2.y + 60; } Render.setZoom(3); Render.cam.x = s2.x; Render.cam.y = s2.y; WL.timeScale = 0.001; await new Promise(res => setTimeout(res, 380)); const top = __near(s2.x, s2.y - 4, __hex('#c9553a'), 30, 8); WL.timeScale = 1; Render.setZoom(null); return { top }; });   // the red thread across the cairn's top stone
r = await ev(() => {
  const ash = DATA.camps.find(c => c.id === 'ash'), c = S.camps.ash, St = DATA.T.stone, st2 = Republic.settleStones()[0], n = S.npcs.find(x => x.id === __st.n);
  delete Republic.scores().ash;
  Republic.tick(0.02); const standsWhileDown = !st2.down && !st2.kick;
  c.pacified = false; c.chiefLost = 0; c.chiefReturn = null;   // the camp comes back up
  Republic.tick(0.02); const walking = !!st2.kick && !st2.down;
  for (let i = 0; i < Math.ceil((St.walk + St.kick) / 0.25) + 2 && !st2.down; i++) Republic.tick(0.25);
  const sc = Republic.scores().ash;
  const kicked = !!st2.down && !!sc && sc.npc === n.id && sc.why === 'stones' && S.mails.some(m => /again/.test(m.subj) && /kicked over the stones/.test(m.body)) && !!S.flags.tut.firstStonesKicked;
  MusterUI.open(n.id); const txt = document.getElementById('musterOv').textContent; MusterUI.close();
  const plate = /KICKED OVER AT ASH CAMP — YOUR SCORE/.test(txt) && /SETTLED AT ASH CAMP — KICKED OVER/.test(txt);
  const roll = /kicked over/.test(UI.campRollHTML(ash, true));
  return { standsWhileDown, walking, kicked, plate, roll };
});
const sk2 = JSON.stringify(r), skOk2 = r.standsWhileDown && r.walking && r.kicked && r.plate && r.roll;
await drain(); await at(0.3);
const kickSeen = await ev(async () => { const s2 = __st; WL.tp([s2.x + 60, s2.y + 50]); S.dir = 0; for (const n of NPC.party()) { n.cx = s2.x + 120; n.cy = s2.y + 60; } Render.setZoom(3); Render.cam.x = s2.x; Render.cam.y = s2.y; WL.timeScale = 0.001; await new Promise(res => setTimeout(res, 380)); const top = __near(s2.x, s2.y - 4, __hex('#c9553a'), 30, 8), low = __near(s2.x, s2.y + 2, __hex('#b8c2c8'), 30, 16); WL.timeScale = 1; Render.setZoom(null); return { top, low }; });
ok('THE STONE\'S KEEPING: a back of yours passing a standing cairn stops a beat and faces it (their stones seen standing, in the mood), and holds there; the Order\'s walkers on the road stop too; the cairn stands while its camp is down — when the camp comes back up a knife walks out and kicks it over: the stones in the dirt (pixel-sampled — the red thread gone from its top, the stones low), the one who set them has a score again (the mail, the lesson), the plate reads KICKED OVER AT ASH CAMP — YOUR SCORE and SETTLED AT ASH CAMP — KICKED OVER, the roll says so',
  skOk1 && skOk2 && standSeen.top > 6 && kickSeen.top < standSeen.top - 4 && kickSeen.low > 6, sk1 + ' ' + sk2 + ' stand=' + JSON.stringify(standSeen) + ' kick=' + JSON.stringify(kickSeen));

/* ================= 6 · THE WATCH ================= */
r = await ev(() => {
  const ash = DATA.camps.find(c => c.id === 'ash'), c = S.camps.ash;
  c.runners = []; c.grudge = null; c.truce = 0; c.pact = null; c.pacified = false; delete Republic.scores().ash;
  S.cargo = S.cargo.filter(x => x.cat === 'tool');
  const pool = S.npcs.filter(n => n.state === 'pool' && n.at === 'haven').slice(0, 1); for (const n of pool) NPC.hire(n, 'companion');
  const pt = NPC.party(); WL.tp([ash.x + 100, ash.y + 1150]); for (const n of pt) { n.cx = S.px + 20; n.cy = S.py + 20; }
  UI.toggleMap(true); UI.ringWalk('ash'); UI.toggleMap(false);
  const m = S.moveTo; WL.tp([m.x + 4, m.y + 4]); S.stagger = 0; S.struggle = null; Systems.update(0.05, {});
  for (let i = 0; i < 40; i++) Systems.update(0.1, {});
  const q = Systems.getInteractions().find(i => i.key === 'Q'), rail = !!q && /HOLD, COME or WATCH/.test(q.label);
  q && q.fn();
  const three = !!document.querySelector('#keeperSay [data-line="watch"]') && !!document.querySelector('#keeperSay [data-line="hold"]') && !!document.querySelector('#keeperSay [data-line="come"]');
  return { held: !!S.ringHold, rail, three, party: pt.length };
});
const w0 = r;
await page.click('#keeperSay [data-line="watch"]'); await page.waitForTimeout(200);
r = await ev(() => {
  const ash = DATA.camps.find(c => c.id === 'ash'), W = Systems.watches(), w = W[0];
  const made = W.length === 1 && w.camp === 'ash' && !S.ringHold && NPC.party().length === 0 && Systems.watchers(w).length >= 2 && Systems.watchers(w).every(n => n.state === 'watch') && S.mails.some(m => /The watch at Ash Camp's ring/.test(m.subj)) && !!S.flags.tut.firstWatch;
  const edge = Math.abs(U.dist(w.x, w.y, ash.x, ash.y) - (ash.r - 24)) < 1;
  /* the Walker walks off; the watch keeps its slots */
  WL.tp([ash.x + 2400, ash.y + 1600]); for (let i = 0; i < 30; i++) Systems.update(0.1, {});
  const stays = Systems.watchers(w).every((n, i) => { const sl = Systems.watchSlot(w, n.watchSlot); return U.dist(n.cx, n.cy, sl.x, sl.y) < 8; }) && Systems.watches().length === 1;
  const roll = NPC.everyone().some(e => e.where === 'watch' && /on the watch at Ash Camp's ring/.test(e.place));
  UI.tick(); const compass = [...document.querySelectorAll('#compassInner .cMark')].some(m => /THE WATCH · ASH/.test(m.title));
  /* before dark it holds the edge like a held line: a knife after the loaded Walker near it is turned */
  S.cargo.push(State.makeItem('metal'));
  const n0 = Systems.watchers(w)[0], kr = { x: n0.cx + 20, y: n0.cy - 20, cd: 0, cls: 'knife', wa: 0, state: 'patrol' };
  WL.tp([w.x + w.fx * 100, w.y + w.fy * 100]); S.camps.ash.runners = [kr]; S.stagger = 0; Systems.update(0.05, {});
  const turned = !!kr.turnedT && !Systems.watchDark(ash);
  S.camps.ash.runners = [];
  return { made, edge, stays, roll, compass, turned };
});
const wa1 = JSON.stringify(w0) + ' ' + JSON.stringify(r), waOk1 = w0.held && w0.rail && w0.three && w0.party >= 2 && r.made && r.edge && r.stays && r.roll && r.compass && r.turned;
/* the fire laid by day */
await drain(); await at(0.3);
const dayFire = await ev(async () => { const w = Systems.watches()[0], fp = Systems.watchFire(w); WL.tp([fp.x + 80, fp.y + 60]); S.dir = 0; Systems.update(0.02, {}); Render.setZoom(2.6); Render.cam.x = fp.x; Render.cam.y = fp.y - 6; WL.timeScale = 0.001; await new Promise(res => setTimeout(res, 380)); const flame = __near(fp.x, fp.y - 8, __hex('#ffd98f'), 26, 12) + __near(fp.x, fp.y - 8, __hex('#fff2d0'), 16, 12); WL.timeScale = 1; Render.setZoom(null); return flame; });
/* dark: a watch — the camp stays in, the runs cross as at a truce, a grudge's storm stays in */
await at(0.72);
r = await ev(() => {
  const ash = DATA.camps.find(c => c.id === 'ash'), c = S.camps.ash, w = Systems.watches()[0], DL = DATA.T.dayLen;
  Systems.update(0.05, {});
  const dark = w.dark === true && Systems.watchDark(ash);
  /* a knife near a loaded Walker in the ring goes back to its fire */
  WL.tp([ash.x + 60, ash.y + ash.r * 0.5]); S.stagger = 0; S.struggle = null;
  const hp0 = S.health, n0 = S.cargo.length, k = { x: S.px + 26, y: S.py - 6, cd: 0, cls: 'knife', wa: 0, state: 'patrol' }; c.runners = [k];
  for (let i = 0; i < 40; i++) Systems.update(0.1, {});
  const stayedIn = S.health >= hp0 - 0.5 && S.cargo.length === n0 && U.dist(k.x, k.y, ash.x, ash.y) < ash.r * 0.3;
  c.runners = [];
  /* a charter run across the ring passes as at a truce */
  const rn = S.npcs.find(x => x.state === 'route' && x.route && ((x.route.a === 'foundry' && x.route.b === 'pharos') || (x.route.a === 'pharos' && x.route.b === 'foundry')));
  const runs = Republic.truceRoadFor('foundry', 'pharos') === ash && Republic.truceRoads().some(tr => tr.cd === ash && tr.watch === true) && (!rn || (() => { rn.route.t = 0; NPC.update(0.01); return rn.route.truce === 'ash'; })());
  /* a grudge's storm from this fire stays in */
  const ridge = DATA.camps.find(x => x.id !== 'ash' && S.camps[x.id]); S.camps[ridge.id].taken = { shields: 2, stash: [] };
  const storm = Republic.stormPost(ridge, null, ash) === false && S.mails.some(m => /the storm stayed in/.test(m.subj));
  S.camps[ridge.id].taken = null;
  return { dark, stayedIn, runs, storm };
});
const wa2 = JSON.stringify(r), waOk2 = r.dark && r.stayedIn && r.runs && r.storm;
await drain();
const nightFire = await ev(async () => { const w = Systems.watches()[0], fp = Systems.watchFire(w); WL.tp([fp.x + 80, fp.y + 60]); S.dir = 0; S.cargo = S.cargo.filter(x => x.cat === 'tool'); Systems.update(0.02, {}); Render.setZoom(2.6); Render.cam.x = fp.x; Render.cam.y = fp.y - 6; WL.timeScale = 0.001; await new Promise(res => setTimeout(res, 380)); const flame = __near(fp.x, fp.y - 8, __hex('#ffd98f'), 26, 12) + __near(fp.x, fp.y - 8, __hex('#fff2d0'), 16, 12); WL.timeScale = 1; Render.setZoom(null); return flame; });
/* dawn: home to the nearest lit door, waiting there, falling in when you come by */
await at(1.08);
r = await ev(() => {
  const w = Systems.watches()[0], ns = Systems.watchers(w), W = DATA.T.watch;
  Systems.update(0.05, {});
  const dawn = !!w.home && ns.every(n => !!n.walkHome) && S.mails.some(m => /The watch comes home/.test(m.subj));
  const to = w.home.to;
  for (let i = 0; i < 4000 && Systems.watchers(w).length; i++) Systems.update(0.25, {});
  const waiting = ns.every(n => n.state === 'waiting' && n.waitAt === to) && Systems.watches().length === 0 && ns.every(n => /watched/.test(JSON.stringify(NPC.mood(n))));
  UI.tick(); const compass = [...document.querySelectorAll('#compassInner .cMark')].some(m => /the watch, home/.test(m.title));
  WL.tp(to); Systems.update(0.05, {});
  const fellIn = ns.every(n => n.state === 'companion') && NPC.party().length >= ns.length;
  /* a watch called in early: Q at the line */
  const ash = DATA.camps.find(c => c.id === 'ash');
  UI.toggleMap(true); WL.tp([ash.x + 100, ash.y + 1150]); UI.ringWalk('ash'); UI.toggleMap(false);
  const m = S.moveTo; WL.tp([m.x + 4, m.y + 4]); S.stagger = 0; S.struggle = null; Systems.update(0.05, {}); for (let i = 0; i < 30; i++) Systems.update(0.1, {});
  Systems.lineOrder('watch');
  const w2 = Systems.watches()[0]; WL.tp([w2.x + 10, w2.y + 10]); Systems.update(0.05, {});
  const q = Systems.getInteractions().find(i => i.key === 'Q' && /call it in/.test(i.label)); q && q.fn();
  const calledIn = !!q && Systems.watches().length === 0 && NPC.party().length >= 2;
  return { dawn, to, waiting, compass, fellIn, calledIn };
});
ok('THE WATCH: at a held line Q offers HOLD, COME or WATCH and the plate carries all three; WATCH by a real click leaves the line at the ring\'s very edge for the night (the wedge empty, the mail, the lesson); it keeps its slots with the Walker gone, the roll and the compass name it, and before dark it turns a knife at the edge; the fire lies laid by day and burns at dark (pixel-sampled); from dark it is a watch — a knife near a loaded Walker in the ring goes back to its fire, a charter run across the ring passes as at a truce, a grudge\'s storm from that fire stays in; at dawn the line walks home to the nearest lit door (the mail), waits there with the watch in its mood (the compass marks it) and falls in when you come by; a watch called in early (Q) falls in at once',
  waOk1 && dayFire < 6 && waOk2 && nightFire > 10 && r.dawn && r.waiting && r.compass && r.fellIn && r.calledIn, wa1 + ' dayFire=' + dayFire + ' ' + wa2 + ' nightFire=' + nightFire + ' ' + JSON.stringify(r));

/* ================= 7 · THE SAVE ================= */
r = await ev(() => {
  const ash = DATA.camps.find(c => c.id === 'ash'), c = S.camps.ash, DL = DATA.T.dayLen;
  /* a watch standing, a stone kicked, the rags down, a road kept, a door answered and a door shut by hearsay, a keepsake at its stone */
  const pt = NPC.party(); const h = { camp: 'ash', x: ash.x, y: ash.y + ash.r + 60, t: S.time }; S.ringHold = h; Systems.lineOrder('watch');
  c.ragsDown = { t: S.time, pts: [{ x: ash.x, y: ash.y + ash.r }], broke: false }; c.pact = { t: S.time, kept: 2 };
  const bq = Economy.book('green'); bq.shut = S.time; bq.shutBy = 'wire'; bq.answered = S.time;
  State.save();
  S.watches = []; c.ragsDown = null; c.pact = null; bq.shutBy = null;
  State.load();
  const w = (S.watches || [])[0], c2 = S.camps.ash;
  const watch = !!w && w.camp === 'ash' && S.npcs.filter(n => n.state === 'watch' && n.watchId === w.id).length === pt.length;
  const stone = Republic.settleStones().some(st2 => st2.down);
  const rags = !!c2.ragsDown && c2.ragsDown.pts.length === 1, kept = !!c2.pact && c2.pact.kept === 2;
  const book = Economy.book('green').shutBy === 'wire' && !!Economy.book('green').answered;
  const keepsake = S.legacy.some(x => x.name === 'Halvard Penrose' && !!x.keepsake);
  return { watch, stone, rags, kept, book, keepsake };
});
ok('THE SAVE: a watch standing with its backs, the stones kicked over, the rags down, a road kept twice, a door answered and shut by hearsay, and a keepsake at its stone all survive a save and load',
  r.watch && r.stone && r.rags && r.kept && r.book && r.keepsake, JSON.stringify(r));

ok('no page errors across the word answered', errors.length === 0, errors.slice(0, 3).join(' | '));
console.log(results.join('\n'));
console.log(`${results.filter(x => x.startsWith('PASS')).length}/${results.length} checks passed`);
await b.close();
